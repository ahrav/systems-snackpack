
/tmp/topic48-f367af8954de2626c8d0ef0b26f77eebf4dd6e99-xxl-final-20260828T082544Z/prefetch_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401f70 <kernel_demand>:
  401f70:	49 89 f9             	mov    %rdi,%r9
  401f73:	48 85 c9             	test   %rcx,%rcx
  401f76:	74 35                	je     401fad <kernel_demand+0x3d>
  401f78:	4c 8d 14 96          	lea    (%rsi,%rdx,4),%r10
  401f7c:	45 31 db             	xor    %r11d,%r11d
  401f7f:	31 c0                	xor    %eax,%eax
  401f81:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  401f88:	48 89 f7             	mov    %rsi,%rdi
  401f8b:	48 85 d2             	test   %rdx,%rdx
  401f8e:	74 14                	je     401fa4 <kernel_demand+0x34>
  401f90:	44 8b 07             	mov    (%rdi),%r8d
  401f93:	48 83 c7 04          	add    $0x4,%rdi
  401f97:	49 c1 e0 06          	shl    $0x6,%r8
  401f9b:	4b 03 04 01          	add    (%r9,%r8,1),%rax
  401f9f:	49 39 fa             	cmp    %rdi,%r10
  401fa2:	75 ec                	jne    401f90 <kernel_demand+0x20>
  401fa4:	49 ff c3             	inc    %r11
  401fa7:	4c 39 d9             	cmp    %r11,%rcx
  401faa:	75 dc                	jne    401f88 <kernel_demand+0x18>
  401fac:	c3                   	ret
  401fad:	31 c0                	xor    %eax,%eax
  401faf:	c3                   	ret

Disassembly of section .fini:
