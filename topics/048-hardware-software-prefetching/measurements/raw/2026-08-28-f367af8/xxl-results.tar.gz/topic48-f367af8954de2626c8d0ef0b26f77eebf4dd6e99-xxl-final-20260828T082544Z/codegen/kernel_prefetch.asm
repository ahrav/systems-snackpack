
/tmp/topic48-f367af8954de2626c8d0ef0b26f77eebf4dd6e99-xxl-final-20260828T082544Z/prefetch_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401fb0 <kernel_prefetch>:
  401fb0:	49 89 f1             	mov    %rsi,%r9
  401fb3:	48 89 d6             	mov    %rdx,%rsi
  401fb6:	4c 29 c6             	sub    %r8,%rsi
  401fb9:	31 c0                	xor    %eax,%eax
  401fbb:	49 39 d0             	cmp    %rdx,%r8
  401fbe:	48 0f 43 f0          	cmovae %rax,%rsi
  401fc2:	48 85 c9             	test   %rcx,%rcx
  401fc5:	74 79                	je     402040 <kernel_prefetch+0x90>
  401fc7:	41 54                	push   %r12
  401fc9:	4f 8d 14 81          	lea    (%r9,%r8,4),%r10
  401fcd:	4d 8d 24 b1          	lea    (%r9,%rsi,4),%r12
  401fd1:	55                   	push   %rbp
  401fd2:	4d 8d 04 91          	lea    (%r9,%rdx,4),%r8
  401fd6:	48 89 cd             	mov    %rcx,%rbp
  401fd9:	53                   	push   %rbx
  401fda:	45 31 db             	xor    %r11d,%r11d
  401fdd:	48 89 d3             	mov    %rdx,%rbx
  401fe0:	31 d2                	xor    %edx,%edx
  401fe2:	48 85 f6             	test   %rsi,%rsi
  401fe5:	74 29                	je     402010 <kernel_prefetch+0x60>
  401fe7:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
  401ff0:	41 8b 0c 92          	mov    (%r10,%rdx,4),%ecx
  401ff4:	48 c1 e1 06          	shl    $0x6,%rcx
  401ff8:	0f 18 04 0f          	prefetchnta (%rdi,%rcx,1)
  401ffc:	41 8b 0c 91          	mov    (%r9,%rdx,4),%ecx
  402000:	48 ff c2             	inc    %rdx
  402003:	48 c1 e1 06          	shl    $0x6,%rcx
  402007:	48 03 04 0f          	add    (%rdi,%rcx,1),%rax
  40200b:	48 39 d6             	cmp    %rdx,%rsi
  40200e:	75 e0                	jne    401ff0 <kernel_prefetch+0x40>
  402010:	48 39 de             	cmp    %rbx,%rsi
  402013:	73 1e                	jae    402033 <kernel_prefetch+0x83>
  402015:	4c 89 e2             	mov    %r12,%rdx
  402018:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  402020:	8b 0a                	mov    (%rdx),%ecx
  402022:	48 83 c2 04          	add    $0x4,%rdx
  402026:	48 c1 e1 06          	shl    $0x6,%rcx
  40202a:	48 03 04 0f          	add    (%rdi,%rcx,1),%rax
  40202e:	49 39 d0             	cmp    %rdx,%r8
  402031:	75 ed                	jne    402020 <kernel_prefetch+0x70>
  402033:	49 ff c3             	inc    %r11
  402036:	4c 39 dd             	cmp    %r11,%rbp
  402039:	75 a5                	jne    401fe0 <kernel_prefetch+0x30>
  40203b:	5b                   	pop    %rbx
  40203c:	5d                   	pop    %rbp
  40203d:	41 5c                	pop    %r12
  40203f:	c3                   	ret
  402040:	31 c0                	xor    %eax,%eax
  402042:	c3                   	ret

Disassembly of section .fini:
