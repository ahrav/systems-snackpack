
/tmp/topic48-f367af8954de2626c8d0ef0b26f77eebf4dd6e99-arm-final-20260828T082544Z/prefetch_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410ca0 <kernel_demand>:
  410ca0:	b4000263 	cbz	x3, 410cec <kernel_demand+0x4c>
  410ca4:	8b020827 	add	x7, x1, x2, lsl #2
  410ca8:	d2800008 	mov	x8, #0x0                   	// #0
  410cac:	d2800006 	mov	x6, #0x0                   	// #0
  410cb0:	aa0103e5 	mov	x5, x1
  410cb4:	b4000122 	cbz	x2, 410cd8 <kernel_demand+0x38>
  410cb8:	d503201f 	nop
  410cbc:	d503201f 	nop
  410cc0:	b84044a4 	ldr	w4, [x5], #4
  410cc4:	d37ae484 	lsl	x4, x4, #6
  410cc8:	f8646804 	ldr	x4, [x0, x4]
  410ccc:	8b0400c6 	add	x6, x6, x4
  410cd0:	eb0500ff 	cmp	x7, x5
  410cd4:	54ffff61 	b.ne	410cc0 <kernel_demand+0x20>  // b.any
  410cd8:	91000508 	add	x8, x8, #0x1
  410cdc:	eb08007f 	cmp	x3, x8
  410ce0:	54fffe81 	b.ne	410cb0 <kernel_demand+0x10>  // b.any
  410ce4:	aa0603e0 	mov	x0, x6
  410ce8:	d65f03c0 	ret
  410cec:	d2800006 	mov	x6, #0x0                   	// #0
  410cf0:	aa0603e0 	mov	x0, x6
  410cf4:	d65f03c0 	ret

Disassembly of section .fini:
