
/tmp/topic48-f367af8954de2626c8d0ef0b26f77eebf4dd6e99-arm-final-20260828T082544Z/prefetch_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410d00 <kernel_prefetch>:
  410d00:	eb02009f 	cmp	x4, x2
  410d04:	cb040048 	sub	x8, x2, x4
  410d08:	9a9f3108 	csel	x8, x8, xzr, cc	// cc = lo, ul, last
  410d0c:	b4000403 	cbz	x3, 410d8c <kernel_prefetch+0x8c>
  410d10:	8b040829 	add	x9, x1, x4, lsl #2
  410d14:	d280000b 	mov	x11, #0x0                   	// #0
  410d18:	d2800005 	mov	x5, #0x0                   	// #0
  410d1c:	8b08082c 	add	x12, x1, x8, lsl #2
  410d20:	8b02082a 	add	x10, x1, x2, lsl #2
  410d24:	d2800004 	mov	x4, #0x0                   	// #0
  410d28:	b4000168 	cbz	x8, 410d54 <kernel_prefetch+0x54>
  410d2c:	b8647827 	ldr	w7, [x1, x4, lsl #2]
  410d30:	b8647926 	ldr	w6, [x9, x4, lsl #2]
  410d34:	91000484 	add	x4, x4, #0x1
  410d38:	d37ae4e7 	lsl	x7, x7, #6
  410d3c:	f8676807 	ldr	x7, [x0, x7]
  410d40:	8b061806 	add	x6, x0, x6, lsl #6
  410d44:	f98000c1 	prfm	pldl1strm, [x6]
  410d48:	8b0700a5 	add	x5, x5, x7
  410d4c:	eb04011f 	cmp	x8, x4
  410d50:	54fffee1 	b.ne	410d2c <kernel_prefetch+0x2c>  // b.any
  410d54:	eb02011f 	cmp	x8, x2
  410d58:	54000102 	b.cs	410d78 <kernel_prefetch+0x78>  // b.hs, b.nlast
  410d5c:	aa0c03e6 	mov	x6, x12
  410d60:	b84044c4 	ldr	w4, [x6], #4
  410d64:	d37ae484 	lsl	x4, x4, #6
  410d68:	f8646804 	ldr	x4, [x0, x4]
  410d6c:	8b0400a5 	add	x5, x5, x4
  410d70:	eb06015f 	cmp	x10, x6
  410d74:	54ffff61 	b.ne	410d60 <kernel_prefetch+0x60>  // b.any
  410d78:	9100056b 	add	x11, x11, #0x1
  410d7c:	eb0b007f 	cmp	x3, x11
  410d80:	54fffd21 	b.ne	410d24 <kernel_prefetch+0x24>  // b.any
  410d84:	aa0503e0 	mov	x0, x5
  410d88:	d65f03c0 	ret
  410d8c:	d2800005 	mov	x5, #0x0                   	// #0
  410d90:	aa0503e0 	mov	x0, x5
  410d94:	d65f03c0 	ret

Disassembly of section .fini:
