
/tmp/topic48-postartifact-43ba2249-x86-01/prefetch_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401f30 <kernel_prefetch>:
  401f30:	49 89 f1             	mov    %rsi,%r9
  401f33:	48 89 d6             	mov    %rdx,%rsi
  401f36:	4c 29 c6             	sub    %r8,%rsi
  401f39:	31 c0                	xor    %eax,%eax
  401f3b:	49 39 d0             	cmp    %rdx,%r8
  401f3e:	48 0f 43 f0          	cmovae %rax,%rsi
  401f42:	48 85 c9             	test   %rcx,%rcx
  401f45:	74 79                	je     401fc0 <kernel_prefetch+0x90>
  401f47:	41 54                	push   %r12
  401f49:	4f 8d 14 81          	lea    (%r9,%r8,4),%r10
  401f4d:	4d 8d 24 b1          	lea    (%r9,%rsi,4),%r12
  401f51:	55                   	push   %rbp
  401f52:	4d 8d 04 91          	lea    (%r9,%rdx,4),%r8
  401f56:	48 89 cd             	mov    %rcx,%rbp
  401f59:	53                   	push   %rbx
  401f5a:	45 31 db             	xor    %r11d,%r11d
  401f5d:	48 89 d3             	mov    %rdx,%rbx
  401f60:	31 d2                	xor    %edx,%edx
  401f62:	48 85 f6             	test   %rsi,%rsi
  401f65:	74 29                	je     401f90 <kernel_prefetch+0x60>
  401f67:	66 0f 1f 84 00 00 00 00 00 	nopw   0x0(%rax,%rax,1)
  401f70:	41 8b 0c 92          	mov    (%r10,%rdx,4),%ecx
  401f74:	48 c1 e1 06          	shl    $0x6,%rcx
  401f78:	0f 18 04 0f          	prefetchnta (%rdi,%rcx,1)
  401f7c:	41 8b 0c 91          	mov    (%r9,%rdx,4),%ecx
  401f80:	48 ff c2             	inc    %rdx
  401f83:	48 c1 e1 06          	shl    $0x6,%rcx
  401f87:	48 03 04 0f          	add    (%rdi,%rcx,1),%rax
  401f8b:	48 39 d6             	cmp    %rdx,%rsi
  401f8e:	75 e0                	jne    401f70 <kernel_prefetch+0x40>
  401f90:	48 39 de             	cmp    %rbx,%rsi
  401f93:	73 1e                	jae    401fb3 <kernel_prefetch+0x83>
  401f95:	4c 89 e2             	mov    %r12,%rdx
  401f98:	0f 1f 84 00 00 00 00 00 	nopl   0x0(%rax,%rax,1)
  401fa0:	8b 0a                	mov    (%rdx),%ecx
  401fa2:	48 83 c2 04          	add    $0x4,%rdx
  401fa6:	48 c1 e1 06          	shl    $0x6,%rcx
  401faa:	48 03 04 0f          	add    (%rdi,%rcx,1),%rax
  401fae:	49 39 d0             	cmp    %rdx,%r8
  401fb1:	75 ed                	jne    401fa0 <kernel_prefetch+0x70>
  401fb3:	49 ff c3             	inc    %r11
  401fb6:	4c 39 dd             	cmp    %r11,%rbp
  401fb9:	75 a5                	jne    401f60 <kernel_prefetch+0x30>
  401fbb:	5b                   	pop    %rbx
  401fbc:	5d                   	pop    %rbp
  401fbd:	41 5c                	pop    %r12
  401fbf:	c3                   	ret
  401fc0:	31 c0                	xor    %eax,%eax
  401fc2:	c3                   	ret

Disassembly of section .fini:
