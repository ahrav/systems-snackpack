
/tmp/topic48-postartifact-43ba2249-x86-01/prefetch_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ef0 <kernel_demand>:
  401ef0:	49 89 f9             	mov    %rdi,%r9
  401ef3:	48 85 c9             	test   %rcx,%rcx
  401ef6:	74 35                	je     401f2d <kernel_demand+0x3d>
  401ef8:	4c 8d 14 96          	lea    (%rsi,%rdx,4),%r10
  401efc:	45 31 db             	xor    %r11d,%r11d
  401eff:	31 c0                	xor    %eax,%eax
  401f01:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
  401f08:	48 89 f7             	mov    %rsi,%rdi
  401f0b:	48 85 d2             	test   %rdx,%rdx
  401f0e:	74 14                	je     401f24 <kernel_demand+0x34>
  401f10:	44 8b 07             	mov    (%rdi),%r8d
  401f13:	48 83 c7 04          	add    $0x4,%rdi
  401f17:	49 c1 e0 06          	shl    $0x6,%r8
  401f1b:	4b 03 04 01          	add    (%r9,%r8,1),%rax
  401f1f:	49 39 fa             	cmp    %rdi,%r10
  401f22:	75 ec                	jne    401f10 <kernel_demand+0x20>
  401f24:	49 ff c3             	inc    %r11
  401f27:	4c 39 d9             	cmp    %r11,%rcx
  401f2a:	75 dc                	jne    401f08 <kernel_demand+0x18>
  401f2c:	c3                   	ret
  401f2d:	31 c0                	xor    %eax,%eax
  401f2f:	c3                   	ret

Disassembly of section .fini:
