
/tmp/topic48-postartifact-43ba2249-arm-01/prefetch_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410c20 <kernel_demand>:
  410c20:	b4000263 	cbz	x3, 410c6c <kernel_demand+0x4c>
  410c24:	8b020827 	add	x7, x1, x2, lsl #2
  410c28:	d2800008 	mov	x8, #0x0                   	// #0
  410c2c:	d2800006 	mov	x6, #0x0                   	// #0
  410c30:	aa0103e5 	mov	x5, x1
  410c34:	b4000122 	cbz	x2, 410c58 <kernel_demand+0x38>
  410c38:	d503201f 	nop
  410c3c:	d503201f 	nop
  410c40:	b84044a4 	ldr	w4, [x5], #4
  410c44:	d37ae484 	lsl	x4, x4, #6
  410c48:	f8646804 	ldr	x4, [x0, x4]
  410c4c:	8b0400c6 	add	x6, x6, x4
  410c50:	eb0500ff 	cmp	x7, x5
  410c54:	54ffff61 	b.ne	410c40 <kernel_demand+0x20>  // b.any
  410c58:	91000508 	add	x8, x8, #0x1
  410c5c:	eb08007f 	cmp	x3, x8
  410c60:	54fffe81 	b.ne	410c30 <kernel_demand+0x10>  // b.any
  410c64:	aa0603e0 	mov	x0, x6
  410c68:	d65f03c0 	ret
  410c6c:	d2800006 	mov	x6, #0x0                   	// #0
  410c70:	aa0603e0 	mov	x0, x6
  410c74:	d65f03c0 	ret

Disassembly of section .fini:
