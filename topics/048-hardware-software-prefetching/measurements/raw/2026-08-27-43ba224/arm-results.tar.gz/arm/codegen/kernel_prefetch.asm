
/tmp/topic48-postartifact-43ba2249-arm-01/prefetch_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410c80 <kernel_prefetch>:
  410c80:	eb02009f 	cmp	x4, x2
  410c84:	cb040048 	sub	x8, x2, x4
  410c88:	9a9f3108 	csel	x8, x8, xzr, cc	// cc = lo, ul, last
  410c8c:	b4000403 	cbz	x3, 410d0c <kernel_prefetch+0x8c>
  410c90:	8b040829 	add	x9, x1, x4, lsl #2
  410c94:	d280000b 	mov	x11, #0x0                   	// #0
  410c98:	d2800005 	mov	x5, #0x0                   	// #0
  410c9c:	8b08082c 	add	x12, x1, x8, lsl #2
  410ca0:	8b02082a 	add	x10, x1, x2, lsl #2
  410ca4:	d2800004 	mov	x4, #0x0                   	// #0
  410ca8:	b4000168 	cbz	x8, 410cd4 <kernel_prefetch+0x54>
  410cac:	b8647827 	ldr	w7, [x1, x4, lsl #2]
  410cb0:	b8647926 	ldr	w6, [x9, x4, lsl #2]
  410cb4:	91000484 	add	x4, x4, #0x1
  410cb8:	d37ae4e7 	lsl	x7, x7, #6
  410cbc:	f8676807 	ldr	x7, [x0, x7]
  410cc0:	8b061806 	add	x6, x0, x6, lsl #6
  410cc4:	f98000c1 	prfm	pldl1strm, [x6]
  410cc8:	8b0700a5 	add	x5, x5, x7
  410ccc:	eb04011f 	cmp	x8, x4
  410cd0:	54fffee1 	b.ne	410cac <kernel_prefetch+0x2c>  // b.any
  410cd4:	eb02011f 	cmp	x8, x2
  410cd8:	54000102 	b.cs	410cf8 <kernel_prefetch+0x78>  // b.hs, b.nlast
  410cdc:	aa0c03e6 	mov	x6, x12
  410ce0:	b84044c4 	ldr	w4, [x6], #4
  410ce4:	d37ae484 	lsl	x4, x4, #6
  410ce8:	f8646804 	ldr	x4, [x0, x4]
  410cec:	8b0400a5 	add	x5, x5, x4
  410cf0:	eb06015f 	cmp	x10, x6
  410cf4:	54ffff61 	b.ne	410ce0 <kernel_prefetch+0x60>  // b.any
  410cf8:	9100056b 	add	x11, x11, #0x1
  410cfc:	eb0b007f 	cmp	x3, x11
  410d00:	54fffd21 	b.ne	410ca4 <kernel_prefetch+0x24>  // b.any
  410d04:	aa0503e0 	mov	x0, x5
  410d08:	d65f03c0 	ret
  410d0c:	d2800005 	mov	x5, #0x0                   	// #0
  410d10:	aa0503e0 	mov	x0, x5
  410d14:	d65f03c0 	ret

Disassembly of section .fini:
