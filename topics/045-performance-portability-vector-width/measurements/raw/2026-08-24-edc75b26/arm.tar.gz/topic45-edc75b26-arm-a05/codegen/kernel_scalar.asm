
/tmp/topic45-edc75b26-arm-a05/binary/width_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410620 <kernel_scalar>:
  410620:	adrp	x1, 420000 <_IO_stdin_used>
  410624:	movi	d0, #0x0
  410628:	adrp	x3, 440000 <exit@GLIBC_2.17>
  41062c:	add	x3, x3, #0x88
  410630:	mov	x2, #0x0                   	// #0
  410634:	ldr	d2, [x1, #416]
  410638:	adrp	x1, 420000 <_IO_stdin_used>
  41063c:	ldr	d1, [x1, #432]
  410640:	add	x4, x2, #0x1
  410644:	add	x1, x2, #0x2
  410648:	add	x11, x2, #0x3
  41064c:	add	x10, x2, #0x4
  410650:	ldr	d3, [x3, x2, lsl #3]
  410654:	add	x9, x2, #0x5
  410658:	add	x8, x2, #0x6
  41065c:	add	x7, x2, #0x7
  410660:	add	x6, x2, #0x8
  410664:	ldr	d22, [x3, x4, lsl #3]
  410668:	add	x5, x2, #0x9
  41066c:	add	x4, x2, #0xa
  410670:	ldr	d21, [x3, x1, lsl #3]
  410674:	add	x1, x2, #0xb
  410678:	ldr	d20, [x3, x11, lsl #3]
  41067c:	ldr	d19, [x3, x10, lsl #3]
  410680:	ldr	d18, [x3, x9, lsl #3]
  410684:	ldr	d17, [x3, x8, lsl #3]
  410688:	ldr	d16, [x3, x7, lsl #3]
  41068c:	ldr	d7, [x3, x6, lsl #3]
  410690:	ldr	d6, [x3, x5, lsl #3]
  410694:	ldr	d5, [x3, x4, lsl #3]
  410698:	ldr	d4, [x3, x1, lsl #3]
  41069c:	cbz	x0, 4106e0 <kernel_scalar+0xc0>
  4106a0:	mov	x1, #0x0                   	// #0
  4106a4:	add	x1, x1, #0x1
  4106a8:	fmadd	d3, d2, d1, d3
  4106ac:	fmadd	d22, d2, d1, d22
  4106b0:	fmadd	d21, d2, d1, d21
  4106b4:	fmadd	d20, d2, d1, d20
  4106b8:	fmadd	d19, d2, d1, d19
  4106bc:	fmadd	d18, d2, d1, d18
  4106c0:	fmadd	d17, d2, d1, d17
  4106c4:	fmadd	d16, d2, d1, d16
  4106c8:	fmadd	d7, d2, d1, d7
  4106cc:	fmadd	d6, d2, d1, d6
  4106d0:	fmadd	d5, d2, d1, d5
  4106d4:	fmadd	d4, d2, d1, d4
  4106d8:	cmp	x0, x1
  4106dc:	b.ne	4106a4 <kernel_scalar+0x84>  // b.any
  4106e0:	add	x2, x2, #0xc
  4106e4:	fadd	d3, d3, d22
  4106e8:	fadd	d3, d3, d21
  4106ec:	fadd	d3, d3, d20
  4106f0:	fadd	d3, d3, d19
  4106f4:	fadd	d3, d3, d18
  4106f8:	fadd	d3, d3, d17
  4106fc:	fadd	d3, d3, d16
  410700:	fadd	d3, d3, d7
  410704:	fadd	d3, d3, d6
  410708:	fadd	d3, d3, d5
  41070c:	fadd	d3, d3, d4
  410710:	fadd	d0, d0, d3
  410714:	cmp	x2, #0x60
  410718:	b.ne	410640 <kernel_scalar+0x20>  // b.any
  41071c:	mov	x0, #0x4058000000000000    	// #4636455816377925632
  410720:	fmov	d1, x0
  410724:	fdiv	d0, d0, d1
  410728:	ret

Disassembly of section .fini:
