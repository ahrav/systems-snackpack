
/tmp/topic45-edc75b26-arm-a05/binary/width_bench:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000410000 <_init>:
  410000:	paciasp
  410004:	stp	x29, x30, [sp, #-16]!
  410008:	mov	x29, sp
  41000c:	bl	410548 <call_weak_fn>
  410010:	ldp	x29, x30, [sp], #16
  410014:	autiasp
  410018:	ret

Disassembly of section .plt:

0000000000410020 <.plt>:
  410020:	stp	x16, x30, [sp, #-16]!
  410024:	adrp	x16, 43f000 <__FRAME_END__+0x1eb38>
  410028:	ldr	x17, [x16, #4088]
  41002c:	add	x16, x16, #0xff8
  410030:	br	x17
  410034:	nop
  410038:	nop
  41003c:	nop

0000000000410040 <exit@plt>:
  410040:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410044:	ldr	x17, [x16]
  410048:	add	x16, x16, #0x0
  41004c:	br	x17

0000000000410050 <__libc_start_main@plt>:
  410050:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410054:	ldr	x17, [x16, #8]
  410058:	add	x16, x16, #0x8
  41005c:	br	x17

0000000000410060 <perror@plt>:
  410060:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410064:	ldr	x17, [x16, #16]
  410068:	add	x16, x16, #0x10
  41006c:	br	x17

0000000000410070 <clock_gettime@plt>:
  410070:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410074:	ldr	x17, [x16, #24]
  410078:	add	x16, x16, #0x18
  41007c:	br	x17

0000000000410080 <sched_getcpu@plt>:
  410080:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410084:	ldr	x17, [x16, #32]
  410088:	add	x16, x16, #0x20
  41008c:	br	x17

0000000000410090 <__gmon_start__@plt>:
  410090:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410094:	ldr	x17, [x16, #40]
  410098:	add	x16, x16, #0x28
  41009c:	br	x17

00000000004100a0 <abort@plt>:
  4100a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100a4:	ldr	x17, [x16, #48]
  4100a8:	add	x16, x16, #0x30
  4100ac:	br	x17

00000000004100b0 <puts@plt>:
  4100b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100b4:	ldr	x17, [x16, #56]
  4100b8:	add	x16, x16, #0x38
  4100bc:	br	x17

00000000004100c0 <strcmp@plt>:
  4100c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100c4:	ldr	x17, [x16, #64]
  4100c8:	add	x16, x16, #0x40
  4100cc:	br	x17

00000000004100d0 <strtoull@plt>:
  4100d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100d4:	ldr	x17, [x16, #72]
  4100d8:	add	x16, x16, #0x48
  4100dc:	br	x17

00000000004100e0 <fwrite@plt>:
  4100e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100e4:	ldr	x17, [x16, #80]
  4100e8:	add	x16, x16, #0x50
  4100ec:	br	x17

00000000004100f0 <printf@plt>:
  4100f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100f4:	ldr	x17, [x16, #88]
  4100f8:	add	x16, x16, #0x58
  4100fc:	br	x17

0000000000410100 <__errno_location@plt>:
  410100:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410104:	ldr	x17, [x16, #96]
  410108:	add	x16, x16, #0x60
  41010c:	br	x17

0000000000410110 <fprintf@plt>:
  410110:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410114:	ldr	x17, [x16, #104]
  410118:	add	x16, x16, #0x68
  41011c:	br	x17

Disassembly of section .text:

0000000000410140 <main>:
  410140:	stp	x29, x30, [sp, #-160]!
  410144:	mov	x2, #0x3eb0000000000000    	// #4517110426252607488
  410148:	mov	x29, sp
  41014c:	fmov	d2, #2.500000000000000000e-01
  410150:	stp	x19, x20, [sp, #16]
  410154:	adrp	x19, 440000 <exit@GLIBC_2.17>
  410158:	mov	x20, x1
  41015c:	add	x19, x19, #0x88
  410160:	fmov	d1, x2
  410164:	mov	x2, #0x0                   	// #0
  410168:	scvtf	d0, x2
  41016c:	fmadd	d0, d0, d1, d2
  410170:	str	d0, [x19, x2, lsl #3]
  410174:	add	x2, x2, #0x1
  410178:	cmp	x2, #0x60
  41017c:	b.ne	410168 <main+0x28>  // b.any
  410180:	cmp	w0, #0x2
  410184:	b.eq	410280 <main+0x140>  // b.none
  410188:	cmp	w0, #0x3
  41018c:	b.eq	410408 <main+0x2c8>  // b.none
  410190:	cmp	w0, #0x4
  410194:	b.ne	4102ac <main+0x16c>  // b.any
  410198:	adrp	x1, 420000 <_IO_stdin_used>
  41019c:	stp	x21, x22, [sp, #32]
  4101a0:	add	x1, x1, #0x128
  4101a4:	ldp	x21, x0, [x20, #8]
  4101a8:	bl	4108e0 <parse_u64>
  4101ac:	adrp	x1, 420000 <_IO_stdin_used>
  4101b0:	mov	x2, x0
  4101b4:	ldr	x0, [x20, #24]
  4101b8:	add	x1, x1, #0x130
  4101bc:	mov	x20, x2
  4101c0:	bl	4108e0 <parse_u64>
  4101c4:	mov	x22, x0
  4101c8:	cbz	x20, 4103e4 <main+0x2a4>
  4101cc:	mov	x0, x21
  4101d0:	bl	41088c <mode_supported>
  4101d4:	cbz	w0, 4103e4 <main+0x2a4>
  4101d8:	stp	x23, x24, [sp, #48]
  4101dc:	stp	d8, d9, [sp, #80]
  4101e0:	bl	4109e0 <monotonic_raw_ns>
  4101e4:	mov	x1, x22
  4101e8:	mov	x24, x0
  4101ec:	mov	x0, x21
  4101f0:	bl	410968 <run_kernel>
  4101f4:	str	d0, [x19, #768]
  4101f8:	bl	4109e0 <monotonic_raw_ns>
  4101fc:	mov	x22, x0
  410200:	bl	4109e0 <monotonic_raw_ns>
  410204:	mov	x1, x20
  410208:	mov	x23, x0
  41020c:	mov	x0, x21
  410210:	sub	x22, x22, x24
  410214:	bl	410968 <run_kernel>
  410218:	fmov	d8, d0
  41021c:	bl	4109e0 <monotonic_raw_ns>
  410220:	sub	x23, x0, x23
  410224:	str	d8, [x19, #768]
  410228:	bl	410080 <sched_getcpu@plt>
  41022c:	adrp	x6, 420000 <_IO_stdin_used>
  410230:	fmov	d0, d8
  410234:	mov	x4, x23
  410238:	mov	x3, x22
  41023c:	mov	w5, w0
  410240:	mov	x1, x21
  410244:	mov	x2, x20
  410248:	add	x0, x6, #0x168
  41024c:	bl	4100f0 <printf@plt>
  410250:	mov	x0, #0x7fefffffffffffff    	// #9218868437227405311
  410254:	fabs	d8, d8
  410258:	ldp	x21, x22, [sp, #32]
  41025c:	fmov	d0, x0
  410260:	ldp	x23, x24, [sp, #48]
  410264:	fcmp	d8, d0
  410268:	ldp	d8, d9, [sp, #80]
  41026c:	cset	w19, hi	// hi = pmore
  410270:	mov	w0, w19
  410274:	ldp	x19, x20, [sp, #16]
  410278:	ldp	x29, x30, [sp], #160
  41027c:	ret
  410280:	adrp	x1, 420000 <_IO_stdin_used>
  410284:	ldr	x0, [x20, #8]
  410288:	add	x1, x1, #0x60
  41028c:	bl	4100c0 <strcmp@plt>
  410290:	mov	w19, w0
  410294:	cbz	w0, 410454 <main+0x314>
  410298:	adrp	x1, 420000 <_IO_stdin_used>
  41029c:	ldr	x0, [x20, #8]
  4102a0:	add	x1, x1, #0x68
  4102a4:	bl	4100c0 <strcmp@plt>
  4102a8:	cbz	w0, 4102cc <main+0x18c>
  4102ac:	adrp	x1, 420000 <_IO_stdin_used>
  4102b0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4102b4:	ldr	x2, [x20]
  4102b8:	add	x1, x1, #0x100
  4102bc:	mov	w19, #0x2                   	// #2
  4102c0:	ldr	x0, [x0, #120]
  4102c4:	bl	410110 <fprintf@plt>
  4102c8:	b	410270 <main+0x130>
  4102cc:	stp	x21, x22, [sp, #32]
  4102d0:	mov	x22, #0x2717                	// #10007
  4102d4:	stp	x23, x24, [sp, #48]
  4102d8:	str	x25, [sp, #64]
  4102dc:	str	d14, [sp, #72]
  4102e0:	stp	d8, d9, [sp, #80]
  4102e4:	stp	d10, d11, [sp, #96]
  4102e8:	stp	d12, d13, [sp, #112]
  4102ec:	mov	x0, x22
  4102f0:	adrp	x21, 420000 <_IO_stdin_used>
  4102f4:	bl	410620 <kernel_scalar>
  4102f8:	adrp	x0, 420000 <_IO_stdin_used>
  4102fc:	mov	x2, #0x3d10000000000000    	// #4400016835940974592
  410300:	fmov	d10, d0
  410304:	add	x0, x0, #0x1c0
  410308:	mov	x1, #0x7fefffffffffffff    	// #9218868437227405311
  41030c:	fabs	d13, d0
  410310:	fmov	d12, x2
  410314:	adrp	x25, 420000 <_IO_stdin_used>
  410318:	add	x23, sp, #0x80
  41031c:	fmov	d11, x1
  410320:	add	x21, x21, #0x10
  410324:	add	x25, x25, #0xa0
  410328:	ld1	{v2.16b-v3.16b}, [x0]
  41032c:	mov	w24, #0x0                   	// #0
  410330:	mov	x19, #0x0                   	// #0
  410334:	st1	{v2.16b-v3.16b}, [x23]
  410338:	ldr	x20, [x23, x19, lsl #3]
  41033c:	mov	x1, x21
  410340:	mov	x0, x20
  410344:	bl	4100c0 <strcmp@plt>
  410348:	mov	w2, w0
  41034c:	adrp	x1, 420000 <_IO_stdin_used>
  410350:	add	x1, x1, #0x20
  410354:	mov	x0, x20
  410358:	cbz	w2, 410364 <main+0x224>
  41035c:	bl	4100c0 <strcmp@plt>
  410360:	cbnz	w0, 4103b0 <main+0x270>
  410364:	mov	x1, x22
  410368:	mov	x0, x20
  41036c:	bl	410968 <run_kernel>
  410370:	fabd	d14, d0, d10
  410374:	fmov	d9, #1.000000000000000000e+00
  410378:	fmaxnm	d9, d9, d13
  41037c:	fmul	d9, d9, d12
  410380:	fmov	d8, d0
  410384:	mov	x1, x20
  410388:	fmov	d1, d10
  41038c:	mov	x0, x25
  410390:	fmov	d2, d14
  410394:	bl	4100f0 <printf@plt>
  410398:	fabs	d8, d8
  41039c:	fcmp	d8, d11
  4103a0:	b.hi	4104bc <main+0x37c>  // b.pmore
  4103a4:	fcmpe	d14, d9
  4103a8:	add	w24, w24, #0x1
  4103ac:	b.gt	4104bc <main+0x37c>
  4103b0:	add	x19, x19, #0x1
  4103b4:	cmp	x19, #0x4
  4103b8:	b.ne	410338 <main+0x1f8>  // b.any
  4103bc:	cmp	w24, #0x1
  4103c0:	cset	w19, le
  4103c4:	ldp	x21, x22, [sp, #32]
  4103c8:	ldp	x23, x24, [sp, #48]
  4103cc:	ldr	x25, [sp, #64]
  4103d0:	ldr	d14, [sp, #72]
  4103d4:	ldp	d8, d9, [sp, #80]
  4103d8:	ldp	d10, d11, [sp, #96]
  4103dc:	ldp	d12, d13, [sp, #112]
  4103e0:	b	410270 <main+0x130>
  4103e4:	adrp	x1, 420000 <_IO_stdin_used>
  4103e8:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4103ec:	mov	x2, x21
  4103f0:	ldr	x0, [x0, #120]
  4103f4:	add	x1, x1, #0x140
  4103f8:	bl	410110 <fprintf@plt>
  4103fc:	mov	w19, #0x2                   	// #2
  410400:	ldp	x21, x22, [sp, #32]
  410404:	b	410270 <main+0x130>
  410408:	adrp	x1, 420000 <_IO_stdin_used>
  41040c:	ldr	x0, [x20, #8]
  410410:	add	x1, x1, #0x68
  410414:	bl	4100c0 <strcmp@plt>
  410418:	cbnz	w0, 4102ac <main+0x16c>
  41041c:	adrp	x1, 420000 <_IO_stdin_used>
  410420:	ldr	x0, [x20, #16]
  410424:	add	x1, x1, #0x70
  410428:	stp	x21, x22, [sp, #32]
  41042c:	bl	4108e0 <parse_u64>
  410430:	mov	x22, x0
  410434:	cbz	x0, 410494 <main+0x354>
  410438:	stp	x23, x24, [sp, #48]
  41043c:	str	x25, [sp, #64]
  410440:	str	d14, [sp, #72]
  410444:	stp	d8, d9, [sp, #80]
  410448:	stp	d10, d11, [sp, #96]
  41044c:	stp	d12, d13, [sp, #112]
  410450:	b	4102ec <main+0x1ac>
  410454:	adrp	x20, 420000 <_IO_stdin_used>
  410458:	add	x20, x20, #0x10
  41045c:	mov	x0, x20
  410460:	bl	41088c <mode_supported>
  410464:	cbnz	w0, 410488 <main+0x348>
  410468:	adrp	x20, 420000 <_IO_stdin_used>
  41046c:	add	x20, x20, #0x20
  410470:	mov	x0, x20
  410474:	bl	41088c <mode_supported>
  410478:	cbz	w0, 410270 <main+0x130>
  41047c:	mov	x0, x20
  410480:	bl	4100b0 <puts@plt>
  410484:	b	410270 <main+0x130>
  410488:	mov	x0, x20
  41048c:	bl	4100b0 <puts@plt>
  410490:	b	410468 <main+0x328>
  410494:	adrp	x1, 440000 <exit@GLIBC_2.17>
  410498:	adrp	x0, 420000 <_IO_stdin_used>
  41049c:	ldr	x3, [x1, #120]
  4104a0:	add	x0, x0, #0x80
  4104a4:	mov	x2, #0x1d                  	// #29
  4104a8:	mov	x1, #0x1                   	// #1
  4104ac:	mov	w19, #0x2                   	// #2
  4104b0:	bl	4100e0 <fwrite@plt>
  4104b4:	ldp	x21, x22, [sp, #32]
  4104b8:	b	410270 <main+0x130>
  4104bc:	adrp	x1, 420000 <_IO_stdin_used>
  4104c0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4104c4:	fmov	d1, d9
  4104c8:	fmov	d0, d14
  4104cc:	mov	x2, x20
  4104d0:	add	x1, x1, #0xc0
  4104d4:	ldr	x0, [x0, #120]
  4104d8:	mov	w19, #0x1                   	// #1
  4104dc:	bl	410110 <fprintf@plt>
  4104e0:	b	4103c4 <main+0x284>
  4104e4:	nop
  4104e8:	nop
  4104ec:	nop
  4104f0:	nop
  4104f4:	nop
  4104f8:	nop
  4104fc:	nop

0000000000410500 <_start>:
  410500:	bti	c
  410504:	mov	x29, #0x0                   	// #0
  410508:	mov	x30, #0x0                   	// #0
  41050c:	mov	x5, x0
  410510:	ldr	x1, [sp]
  410514:	add	x2, sp, #0x8
  410518:	mov	x6, sp
  41051c:	adrp	x0, 410000 <_init>
  410520:	add	x0, x0, #0x534
  410524:	mov	x3, #0x0                   	// #0
  410528:	mov	x4, #0x0                   	// #0
  41052c:	bl	410050 <__libc_start_main@plt>
  410530:	bl	4100a0 <abort@plt>

0000000000410534 <__wrap_main>:
  410534:	bti	c
  410538:	b	410140 <main>
  41053c:	nop

0000000000410540 <_dl_relocate_static_pie>:
  410540:	bti	c
  410544:	ret

0000000000410548 <call_weak_fn>:
  410548:	adrp	x0, 43f000 <__FRAME_END__+0x1eb38>
  41054c:	ldr	x0, [x0, #4056]
  410550:	cbz	x0, 410558 <call_weak_fn+0x10>
  410554:	b	410090 <__gmon_start__@plt>
  410558:	ret
  41055c:	nop

0000000000410560 <deregister_tm_clones>:
  410560:	adrp	x0, 440000 <exit@GLIBC_2.17>
  410564:	adrp	x1, 440000 <exit@GLIBC_2.17>
  410568:	add	x0, x0, #0x78
  41056c:	add	x1, x1, #0x78
  410570:	cmp	x1, x0
  410574:	b.eq	41058c <deregister_tm_clones+0x2c>  // b.none
  410578:	adrp	x1, 43f000 <__FRAME_END__+0x1eb38>
  41057c:	ldr	x1, [x1, #4048]
  410580:	cbz	x1, 41058c <deregister_tm_clones+0x2c>
  410584:	mov	x16, x1
  410588:	br	x16
  41058c:	ret

0000000000410590 <register_tm_clones>:
  410590:	adrp	x0, 440000 <exit@GLIBC_2.17>
  410594:	adrp	x1, 440000 <exit@GLIBC_2.17>
  410598:	add	x0, x0, #0x78
  41059c:	add	x1, x1, #0x78
  4105a0:	sub	x1, x1, x0
  4105a4:	lsr	x2, x1, #63
  4105a8:	add	x1, x2, x1, asr #3
  4105ac:	asr	x1, x1, #1
  4105b0:	cbz	x1, 4105c8 <register_tm_clones+0x38>
  4105b4:	adrp	x2, 43f000 <__FRAME_END__+0x1eb38>
  4105b8:	ldr	x2, [x2, #4064]
  4105bc:	cbz	x2, 4105c8 <register_tm_clones+0x38>
  4105c0:	mov	x16, x2
  4105c4:	br	x16
  4105c8:	ret

00000000004105cc <__do_global_dtors_aux>:
  4105cc:	paciasp
  4105d0:	stp	x29, x30, [sp, #-32]!
  4105d4:	mov	x29, sp
  4105d8:	str	x19, [sp, #16]
  4105dc:	adrp	x19, 440000 <exit@GLIBC_2.17>
  4105e0:	ldrb	w0, [x19, #128]
  4105e4:	cbnz	w0, 4105f4 <__do_global_dtors_aux+0x28>
  4105e8:	bl	410560 <deregister_tm_clones>
  4105ec:	mov	w0, #0x1                   	// #1
  4105f0:	strb	w0, [x19, #128]
  4105f4:	ldr	x19, [sp, #16]
  4105f8:	ldp	x29, x30, [sp], #32
  4105fc:	autiasp
  410600:	ret

0000000000410604 <frame_dummy>:
  410604:	bti	c
  410608:	b	410590 <register_tm_clones>
  41060c:	nop
  410610:	nop
  410614:	nop
  410618:	nop
  41061c:	nop

0000000000410620 <kernel_scalar>:
  410620:	adrp	x1, 420000 <_IO_stdin_used>
  410624:	movi	d0, #0x0
  410628:	adrp	x3, 440000 <exit@GLIBC_2.17>
  41062c:	add	x3, x3, #0x88
  410630:	mov	x2, #0x0                   	// #0
  410634:	ldr	d2, [x1, #416]
  410638:	adrp	x1, 420000 <_IO_stdin_used>
  41063c:	ldr	d1, [x1, #432]
  410640:	add	x4, x2, #0x1
  410644:	add	x1, x2, #0x2
  410648:	add	x11, x2, #0x3
  41064c:	add	x10, x2, #0x4
  410650:	ldr	d3, [x3, x2, lsl #3]
  410654:	add	x9, x2, #0x5
  410658:	add	x8, x2, #0x6
  41065c:	add	x7, x2, #0x7
  410660:	add	x6, x2, #0x8
  410664:	ldr	d22, [x3, x4, lsl #3]
  410668:	add	x5, x2, #0x9
  41066c:	add	x4, x2, #0xa
  410670:	ldr	d21, [x3, x1, lsl #3]
  410674:	add	x1, x2, #0xb
  410678:	ldr	d20, [x3, x11, lsl #3]
  41067c:	ldr	d19, [x3, x10, lsl #3]
  410680:	ldr	d18, [x3, x9, lsl #3]
  410684:	ldr	d17, [x3, x8, lsl #3]
  410688:	ldr	d16, [x3, x7, lsl #3]
  41068c:	ldr	d7, [x3, x6, lsl #3]
  410690:	ldr	d6, [x3, x5, lsl #3]
  410694:	ldr	d5, [x3, x4, lsl #3]
  410698:	ldr	d4, [x3, x1, lsl #3]
  41069c:	cbz	x0, 4106e0 <kernel_scalar+0xc0>
  4106a0:	mov	x1, #0x0                   	// #0
  4106a4:	add	x1, x1, #0x1
  4106a8:	fmadd	d3, d2, d1, d3
  4106ac:	fmadd	d22, d2, d1, d22
  4106b0:	fmadd	d21, d2, d1, d21
  4106b4:	fmadd	d20, d2, d1, d20
  4106b8:	fmadd	d19, d2, d1, d19
  4106bc:	fmadd	d18, d2, d1, d18
  4106c0:	fmadd	d17, d2, d1, d17
  4106c4:	fmadd	d16, d2, d1, d16
  4106c8:	fmadd	d7, d2, d1, d7
  4106cc:	fmadd	d6, d2, d1, d6
  4106d0:	fmadd	d5, d2, d1, d5
  4106d4:	fmadd	d4, d2, d1, d4
  4106d8:	cmp	x0, x1
  4106dc:	b.ne	4106a4 <kernel_scalar+0x84>  // b.any
  4106e0:	add	x2, x2, #0xc
  4106e4:	fadd	d3, d3, d22
  4106e8:	fadd	d3, d3, d21
  4106ec:	fadd	d3, d3, d20
  4106f0:	fadd	d3, d3, d19
  4106f4:	fadd	d3, d3, d18
  4106f8:	fadd	d3, d3, d17
  4106fc:	fadd	d3, d3, d16
  410700:	fadd	d3, d3, d7
  410704:	fadd	d3, d3, d6
  410708:	fadd	d3, d3, d5
  41070c:	fadd	d3, d3, d4
  410710:	fadd	d0, d0, d3
  410714:	cmp	x2, #0x60
  410718:	b.ne	410640 <kernel_scalar+0x20>  // b.any
  41071c:	mov	x0, #0x4058000000000000    	// #4636455816377925632
  410720:	fmov	d1, x0
  410724:	fdiv	d0, d0, d1
  410728:	ret

000000000041072c <kernel_v128>:
  41072c:	adrp	x1, 420000 <_IO_stdin_used>
  410730:	adrp	x2, 440000 <exit@GLIBC_2.17>
  410734:	movi	d0, #0x0
  410738:	add	x2, x2, #0x88
  41073c:	sub	sp, sp, #0x10
  410740:	ldr	q2, [x1, #416]
  410744:	adrp	x1, 420000 <_IO_stdin_used>
  410748:	add	x3, x2, #0x300
  41074c:	ldr	q1, [x1, #432]
  410750:	ldp	q22, q21, [x2]
  410754:	ldp	q20, q19, [x2, #32]
  410758:	ldp	q18, q17, [x2, #64]
  41075c:	ldp	q16, q7, [x2, #96]
  410760:	ldp	q6, q5, [x2, #128]
  410764:	ldp	q4, q3, [x2, #160]
  410768:	cbz	x0, 4107ac <kernel_v128+0x80>
  41076c:	mov	x1, #0x0                   	// #0
  410770:	add	x1, x1, #0x1
  410774:	fmla	v22.2d, v2.2d, v1.2d
  410778:	fmla	v21.2d, v2.2d, v1.2d
  41077c:	fmla	v20.2d, v2.2d, v1.2d
  410780:	fmla	v19.2d, v2.2d, v1.2d
  410784:	fmla	v18.2d, v2.2d, v1.2d
  410788:	fmla	v17.2d, v2.2d, v1.2d
  41078c:	fmla	v16.2d, v2.2d, v1.2d
  410790:	fmla	v7.2d, v2.2d, v1.2d
  410794:	fmla	v6.2d, v2.2d, v1.2d
  410798:	fmla	v5.2d, v2.2d, v1.2d
  41079c:	fmla	v4.2d, v2.2d, v1.2d
  4107a0:	fmla	v3.2d, v2.2d, v1.2d
  4107a4:	cmp	x0, x1
  4107a8:	b.ne	410770 <kernel_v128+0x44>  // b.any
  4107ac:	str	q22, [sp]
  4107b0:	add	x2, x2, #0xc0
  4107b4:	ldp	d22, d23, [sp]
  4107b8:	str	q21, [sp]
  4107bc:	ldp	d21, d24, [sp]
  4107c0:	str	q20, [sp]
  4107c4:	fadd	d22, d22, d23
  4107c8:	ldp	d20, d23, [sp]
  4107cc:	str	q19, [sp]
  4107d0:	fadd	d21, d21, d24
  4107d4:	ldp	d19, d24, [sp]
  4107d8:	str	q18, [sp]
  4107dc:	fadd	d22, d22, d0
  4107e0:	fadd	d20, d20, d23
  4107e4:	ldp	d0, d23, [sp]
  4107e8:	str	q17, [sp]
  4107ec:	fadd	d19, d19, d24
  4107f0:	ldp	d17, d18, [sp]
  4107f4:	str	q16, [sp]
  4107f8:	fadd	d21, d21, d22
  4107fc:	fadd	d0, d0, d23
  410800:	fadd	d17, d17, d18
  410804:	fadd	d20, d20, d21
  410808:	ldp	d16, d21, [sp]
  41080c:	str	q7, [sp]
  410810:	ldp	d7, d18, [sp]
  410814:	str	q6, [sp]
  410818:	fadd	d19, d19, d20
  41081c:	ldp	d6, d20, [sp]
  410820:	fadd	d16, d16, d21
  410824:	str	q5, [sp]
  410828:	fadd	d7, d7, d18
  41082c:	ldp	d5, d18, [sp]
  410830:	str	q4, [sp]
  410834:	fadd	d0, d0, d19
  410838:	ldp	d4, d19, [sp]
  41083c:	fadd	d6, d6, d20
  410840:	str	q3, [sp]
  410844:	fadd	d5, d5, d18
  410848:	fadd	d17, d17, d0
  41084c:	fadd	d3, d4, d19
  410850:	ldp	d0, d18, [sp]
  410854:	fadd	d4, d16, d17
  410858:	fadd	d0, d0, d18
  41085c:	fadd	d4, d7, d4
  410860:	fadd	d4, d6, d4
  410864:	fadd	d4, d5, d4
  410868:	fadd	d3, d3, d4
  41086c:	fadd	d0, d0, d3
  410870:	cmp	x3, x2
  410874:	b.ne	410750 <kernel_v128+0x24>  // b.any
  410878:	mov	x0, #0x4058000000000000    	// #4636455816377925632
  41087c:	add	sp, sp, #0x10
  410880:	fmov	d1, x0
  410884:	fdiv	d0, d0, d1
  410888:	ret

000000000041088c <mode_supported>:
  41088c:	adrp	x1, 420000 <_IO_stdin_used>
  410890:	stp	x29, x30, [sp, #-32]!
  410894:	mov	x29, sp
  410898:	add	x1, x1, #0x10
  41089c:	str	x19, [sp, #16]
  4108a0:	mov	x19, x0
  4108a4:	bl	4100c0 <strcmp@plt>
  4108a8:	cbz	w0, 4108d0 <mode_supported+0x44>
  4108ac:	adrp	x1, 420000 <_IO_stdin_used>
  4108b0:	mov	x0, x19
  4108b4:	add	x1, x1, #0x20
  4108b8:	bl	4100c0 <strcmp@plt>
  4108bc:	cmp	w0, #0x0
  4108c0:	cset	w0, eq	// eq = none
  4108c4:	ldr	x19, [sp, #16]
  4108c8:	ldp	x29, x30, [sp], #32
  4108cc:	ret
  4108d0:	mov	w0, #0x1                   	// #1
  4108d4:	ldr	x19, [sp, #16]
  4108d8:	ldp	x29, x30, [sp], #32
  4108dc:	ret

00000000004108e0 <parse_u64>:
  4108e0:	stp	x29, x30, [sp, #-64]!
  4108e4:	mov	x29, sp
  4108e8:	stp	x19, x20, [sp, #16]
  4108ec:	mov	x19, x0
  4108f0:	str	x21, [sp, #32]
  4108f4:	mov	x21, x1
  4108f8:	str	xzr, [sp, #56]
  4108fc:	bl	410100 <__errno_location@plt>
  410900:	mov	x20, x0
  410904:	add	x1, sp, #0x38
  410908:	mov	w2, #0xa                   	// #10
  41090c:	mov	x0, x19
  410910:	str	wzr, [x20]
  410914:	bl	4100d0 <strtoull@plt>
  410918:	ldr	w1, [x20]
  41091c:	cbnz	w1, 410944 <parse_u64+0x64>
  410920:	ldr	x1, [sp, #56]
  410924:	cmp	x1, x19
  410928:	b.eq	410944 <parse_u64+0x64>  // b.none
  41092c:	ldrb	w1, [x1]
  410930:	cbnz	w1, 410944 <parse_u64+0x64>
  410934:	ldp	x19, x20, [sp, #16]
  410938:	ldr	x21, [sp, #32]
  41093c:	ldp	x29, x30, [sp], #64
  410940:	ret
  410944:	adrp	x1, 420000 <_IO_stdin_used>
  410948:	adrp	x0, 440000 <exit@GLIBC_2.17>
  41094c:	ldr	x0, [x0, #120]
  410950:	mov	x3, x19
  410954:	mov	x2, x21
  410958:	add	x1, x1, #0x28
  41095c:	bl	410110 <fprintf@plt>
  410960:	mov	w0, #0x2                   	// #2
  410964:	bl	410040 <exit@plt>

0000000000410968 <run_kernel>:
  410968:	stp	x29, x30, [sp, #-32]!
  41096c:	adrp	x3, 420000 <_IO_stdin_used>
  410970:	mov	x29, sp
  410974:	stp	x19, x20, [sp, #16]
  410978:	mov	x19, x1
  41097c:	add	x1, x3, #0x10
  410980:	mov	x20, x0
  410984:	bl	4100c0 <strcmp@plt>
  410988:	cbz	w0, 4109b0 <run_kernel+0x48>
  41098c:	adrp	x1, 420000 <_IO_stdin_used>
  410990:	mov	x0, x20
  410994:	add	x1, x1, #0x20
  410998:	bl	4100c0 <strcmp@plt>
  41099c:	cbnz	w0, 4109c0 <run_kernel+0x58>
  4109a0:	mov	x0, x19
  4109a4:	ldp	x19, x20, [sp, #16]
  4109a8:	ldp	x29, x30, [sp], #32
  4109ac:	b	41072c <kernel_v128>
  4109b0:	mov	x0, x19
  4109b4:	ldp	x19, x20, [sp, #16]
  4109b8:	ldp	x29, x30, [sp], #32
  4109bc:	b	410620 <kernel_scalar>
  4109c0:	adrp	x1, 420000 <_IO_stdin_used>
  4109c4:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4109c8:	ldr	x0, [x0, #120]
  4109cc:	mov	x2, x20
  4109d0:	add	x1, x1, #0x38
  4109d4:	bl	410110 <fprintf@plt>
  4109d8:	mov	w0, #0x2                   	// #2
  4109dc:	bl	410040 <exit@plt>

00000000004109e0 <monotonic_raw_ns>:
  4109e0:	stp	x29, x30, [sp, #-32]!
  4109e4:	mov	w0, #0x4                   	// #4
  4109e8:	mov	x29, sp
  4109ec:	add	x1, sp, #0x10
  4109f0:	bl	410070 <clock_gettime@plt>
  4109f4:	cbnz	w0, 410a10 <monotonic_raw_ns+0x30>
  4109f8:	ldp	x2, x1, [sp, #16]
  4109fc:	mov	x0, #0xca00                	// #51712
  410a00:	movk	x0, #0x3b9a, lsl #16
  410a04:	ldp	x29, x30, [sp], #32
  410a08:	madd	x0, x2, x0, x1
  410a0c:	ret
  410a10:	adrp	x0, 420000 <_IO_stdin_used>
  410a14:	add	x0, x0, #0x50
  410a18:	bl	410060 <perror@plt>
  410a1c:	mov	w0, #0x2                   	// #2
  410a20:	bl	410040 <exit@plt>

Disassembly of section .fini:

0000000000410a24 <_fini>:
  410a24:	paciasp
  410a28:	stp	x29, x30, [sp, #-16]!
  410a2c:	mov	x29, sp
  410a30:	ldp	x29, x30, [sp], #16
  410a34:	autiasp
  410a38:	ret
