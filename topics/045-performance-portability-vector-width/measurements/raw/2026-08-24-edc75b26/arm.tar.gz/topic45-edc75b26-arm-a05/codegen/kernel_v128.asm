
/tmp/topic45-edc75b26-arm-a05/binary/width_bench:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000041072c <kernel_v128>:
  41072c:	adrp	x1, 420000 <_IO_stdin_used>
  410730:	adrp	x2, 440000 <exit@GLIBC_2.17>
  410734:	movi	d0, #0x0
  410738:	add	x2, x2, #0x88
  41073c:	sub	sp, sp, #0x10
  410740:	ldr	q2, [x1, #416]
  410744:	adrp	x1, 420000 <_IO_stdin_used>
  410748:	add	x3, x2, #0x300
  41074c:	ldr	q1, [x1, #432]
  410750:	ldp	q22, q21, [x2]
  410754:	ldp	q20, q19, [x2, #32]
  410758:	ldp	q18, q17, [x2, #64]
  41075c:	ldp	q16, q7, [x2, #96]
  410760:	ldp	q6, q5, [x2, #128]
  410764:	ldp	q4, q3, [x2, #160]
  410768:	cbz	x0, 4107ac <kernel_v128+0x80>
  41076c:	mov	x1, #0x0                   	// #0
  410770:	add	x1, x1, #0x1
  410774:	fmla	v22.2d, v2.2d, v1.2d
  410778:	fmla	v21.2d, v2.2d, v1.2d
  41077c:	fmla	v20.2d, v2.2d, v1.2d
  410780:	fmla	v19.2d, v2.2d, v1.2d
  410784:	fmla	v18.2d, v2.2d, v1.2d
  410788:	fmla	v17.2d, v2.2d, v1.2d
  41078c:	fmla	v16.2d, v2.2d, v1.2d
  410790:	fmla	v7.2d, v2.2d, v1.2d
  410794:	fmla	v6.2d, v2.2d, v1.2d
  410798:	fmla	v5.2d, v2.2d, v1.2d
  41079c:	fmla	v4.2d, v2.2d, v1.2d
  4107a0:	fmla	v3.2d, v2.2d, v1.2d
  4107a4:	cmp	x0, x1
  4107a8:	b.ne	410770 <kernel_v128+0x44>  // b.any
  4107ac:	str	q22, [sp]
  4107b0:	add	x2, x2, #0xc0
  4107b4:	ldp	d22, d23, [sp]
  4107b8:	str	q21, [sp]
  4107bc:	ldp	d21, d24, [sp]
  4107c0:	str	q20, [sp]
  4107c4:	fadd	d22, d22, d23
  4107c8:	ldp	d20, d23, [sp]
  4107cc:	str	q19, [sp]
  4107d0:	fadd	d21, d21, d24
  4107d4:	ldp	d19, d24, [sp]
  4107d8:	str	q18, [sp]
  4107dc:	fadd	d22, d22, d0
  4107e0:	fadd	d20, d20, d23
  4107e4:	ldp	d0, d23, [sp]
  4107e8:	str	q17, [sp]
  4107ec:	fadd	d19, d19, d24
  4107f0:	ldp	d17, d18, [sp]
  4107f4:	str	q16, [sp]
  4107f8:	fadd	d21, d21, d22
  4107fc:	fadd	d0, d0, d23
  410800:	fadd	d17, d17, d18
  410804:	fadd	d20, d20, d21
  410808:	ldp	d16, d21, [sp]
  41080c:	str	q7, [sp]
  410810:	ldp	d7, d18, [sp]
  410814:	str	q6, [sp]
  410818:	fadd	d19, d19, d20
  41081c:	ldp	d6, d20, [sp]
  410820:	fadd	d16, d16, d21
  410824:	str	q5, [sp]
  410828:	fadd	d7, d7, d18
  41082c:	ldp	d5, d18, [sp]
  410830:	str	q4, [sp]
  410834:	fadd	d0, d0, d19
  410838:	ldp	d4, d19, [sp]
  41083c:	fadd	d6, d6, d20
  410840:	str	q3, [sp]
  410844:	fadd	d5, d5, d18
  410848:	fadd	d17, d17, d0
  41084c:	fadd	d3, d4, d19
  410850:	ldp	d0, d18, [sp]
  410854:	fadd	d4, d16, d17
  410858:	fadd	d0, d0, d18
  41085c:	fadd	d4, d7, d4
  410860:	fadd	d4, d6, d4
  410864:	fadd	d4, d5, d4
  410868:	fadd	d3, d3, d4
  41086c:	fadd	d0, d0, d3
  410870:	cmp	x3, x2
  410874:	b.ne	410750 <kernel_v128+0x24>  // b.any
  410878:	mov	x0, #0x4058000000000000    	// #4636455816377925632
  41087c:	add	sp, sp, #0x10
  410880:	fmov	d1, x0
  410884:	fdiv	d0, d0, d1
  410888:	ret

Disassembly of section .fini:
