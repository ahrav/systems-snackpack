
/tmp/topic45-edc75b26-xxl-a05/binary/width_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402710 <kernel_v128>:
  402710:	mov    $0x4060c0,%edx
  402715:	mov    $0x4063c0,%ecx
  40271a:	vxorpd %xmm0,%xmm0,%xmm0
  40271e:	vmovapd 0x1afa(%rip),%xmm2        # 404220 <__dso_handle+0x218>
  402726:	vmovapd 0x1b12(%rip),%xmm1        # 404240 <__dso_handle+0x238>
  40272e:	vmovapd (%rdx),%xmm14
  402732:	vmovapd 0x10(%rdx),%xmm13
  402737:	vmovapd 0x20(%rdx),%xmm12
  40273c:	vmovapd 0x30(%rdx),%xmm11
  402741:	vmovapd 0x40(%rdx),%xmm10
  402746:	vmovapd 0x50(%rdx),%xmm9
  40274b:	vmovapd 0x60(%rdx),%xmm7
  402750:	vmovapd 0x70(%rdx),%xmm6
  402755:	vmovapd 0x80(%rdx),%xmm5
  40275d:	vmovapd 0x90(%rdx),%xmm4
  402765:	vmovapd 0xa0(%rdx),%xmm3
  40276d:	vmovapd 0xb0(%rdx),%xmm8
  402775:	test   %rdi,%rdi
  402778:	je     4027c5 <kernel_v128+0xb5>
  40277a:	xor    %eax,%eax
  40277c:	nopl   0x0(%rax)
  402780:	vfmadd231pd %xmm1,%xmm2,%xmm14
  402785:	vfmadd231pd %xmm1,%xmm2,%xmm13
  40278a:	add    $0x1,%rax
  40278e:	vfmadd231pd %xmm1,%xmm2,%xmm12
  402793:	vfmadd231pd %xmm1,%xmm2,%xmm11
  402798:	vfmadd231pd %xmm1,%xmm2,%xmm10
  40279d:	vfmadd231pd %xmm1,%xmm2,%xmm9
  4027a2:	vfmadd231pd %xmm1,%xmm2,%xmm7
  4027a7:	vfmadd231pd %xmm1,%xmm2,%xmm6
  4027ac:	vfmadd231pd %xmm1,%xmm2,%xmm5
  4027b1:	vfmadd231pd %xmm1,%xmm2,%xmm4
  4027b6:	vfmadd231pd %xmm1,%xmm2,%xmm3
  4027bb:	vfmadd231pd %xmm1,%xmm2,%xmm8
  4027c0:	cmp    %rax,%rdi
  4027c3:	jne    402780 <kernel_v128+0x70>
  4027c5:	vhaddpd %xmm14,%xmm14,%xmm14
  4027ca:	vhaddpd %xmm13,%xmm13,%xmm13
  4027cf:	add    $0xc0,%rdx
  4027d6:	vhaddpd %xmm12,%xmm12,%xmm12
  4027db:	vhaddpd %xmm11,%xmm11,%xmm11
  4027e0:	vhaddpd %xmm10,%xmm10,%xmm10
  4027e5:	vhaddpd %xmm9,%xmm9,%xmm9
  4027ea:	vhaddpd %xmm7,%xmm7,%xmm7
  4027ee:	vhaddpd %xmm6,%xmm6,%xmm6
  4027f2:	vaddsd %xmm0,%xmm14,%xmm14
  4027f6:	vhaddpd %xmm5,%xmm5,%xmm5
  4027fa:	vhaddpd %xmm4,%xmm4,%xmm4
  4027fe:	vhaddpd %xmm3,%xmm3,%xmm3
  402802:	vhaddpd %xmm8,%xmm8,%xmm8
  402807:	vaddsd %xmm14,%xmm13,%xmm13
  40280c:	vaddsd %xmm13,%xmm12,%xmm12
  402811:	vaddsd %xmm12,%xmm11,%xmm11
  402816:	vaddsd %xmm11,%xmm10,%xmm10
  40281b:	vaddsd %xmm10,%xmm9,%xmm9
  402820:	vaddsd %xmm9,%xmm7,%xmm7
  402825:	vaddsd %xmm7,%xmm6,%xmm6
  402829:	vaddsd %xmm6,%xmm5,%xmm5
  40282d:	vaddsd %xmm5,%xmm4,%xmm4
  402831:	vaddsd %xmm4,%xmm3,%xmm3
  402835:	vaddsd %xmm3,%xmm8,%xmm0
  402839:	cmp    %rdx,%rcx
  40283c:	jne    40272e <kernel_v128+0x1e>
  402842:	vdivsd 0x191e(%rip),%xmm0,%xmm0        # 404168 <__dso_handle+0x160>
  40284a:	ret

Disassembly of section .fini:
