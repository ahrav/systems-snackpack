
/tmp/topic45-edc75b26-xxl-a05/binary/width_bench:     file format elf64-x86-64


Disassembly of section .init:

0000000000401000 <_init>:
  401000:	endbr64
  401004:	sub    $0x8,%rsp
  401008:	mov    0x4fc9(%rip),%rax        # 405fd8 <__gmon_start__@Base>
  40100f:	test   %rax,%rax
  401012:	je     401016 <_init+0x16>
  401014:	call   *%rax
  401016:	add    $0x8,%rsp
  40101a:	ret

Disassembly of section .plt:

0000000000401020 <__errno_location@plt-0x10>:
  401020:	push   0x4fca(%rip)        # 405ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
  401026:	jmp    *0x4fcc(%rip)        # 405ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
  40102c:	nopl   0x0(%rax)

0000000000401030 <__errno_location@plt>:
  401030:	jmp    *0x4fca(%rip)        # 406000 <__errno_location@GLIBC_2.2.5>
  401036:	push   $0x0
  40103b:	jmp    401020 <_init+0x20>

0000000000401040 <fmax@plt>:
  401040:	jmp    *0x4fc2(%rip)        # 406008 <fmax@GLIBC_2.2.5>
  401046:	push   $0x1
  40104b:	jmp    401020 <_init+0x20>

0000000000401050 <puts@plt>:
  401050:	jmp    *0x4fba(%rip)        # 406010 <puts@GLIBC_2.2.5>
  401056:	push   $0x2
  40105b:	jmp    401020 <_init+0x20>

0000000000401060 <clock_gettime@plt>:
  401060:	jmp    *0x4fb2(%rip)        # 406018 <clock_gettime@GLIBC_2.17>
  401066:	push   $0x3
  40106b:	jmp    401020 <_init+0x20>

0000000000401070 <printf@plt>:
  401070:	jmp    *0x4faa(%rip)        # 406020 <printf@GLIBC_2.2.5>
  401076:	push   $0x4
  40107b:	jmp    401020 <_init+0x20>

0000000000401080 <strtoull@plt>:
  401080:	jmp    *0x4fa2(%rip)        # 406028 <strtoull@GLIBC_2.2.5>
  401086:	push   $0x5
  40108b:	jmp    401020 <_init+0x20>

0000000000401090 <strcmp@plt>:
  401090:	jmp    *0x4f9a(%rip)        # 406030 <strcmp@GLIBC_2.2.5>
  401096:	push   $0x6
  40109b:	jmp    401020 <_init+0x20>

00000000004010a0 <fprintf@plt>:
  4010a0:	jmp    *0x4f92(%rip)        # 406038 <fprintf@GLIBC_2.2.5>
  4010a6:	push   $0x7
  4010ab:	jmp    401020 <_init+0x20>

00000000004010b0 <perror@plt>:
  4010b0:	jmp    *0x4f8a(%rip)        # 406040 <perror@GLIBC_2.2.5>
  4010b6:	push   $0x8
  4010bb:	jmp    401020 <_init+0x20>

00000000004010c0 <sched_getcpu@plt>:
  4010c0:	jmp    *0x4f82(%rip)        # 406048 <sched_getcpu@GLIBC_2.6>
  4010c6:	push   $0x9
  4010cb:	jmp    401020 <_init+0x20>

00000000004010d0 <exit@plt>:
  4010d0:	jmp    *0x4f7a(%rip)        # 406050 <exit@GLIBC_2.2.5>
  4010d6:	push   $0xa
  4010db:	jmp    401020 <_init+0x20>

00000000004010e0 <fwrite@plt>:
  4010e0:	jmp    *0x4f72(%rip)        # 406058 <fwrite@GLIBC_2.2.5>
  4010e6:	push   $0xb
  4010eb:	jmp    401020 <_init+0x20>

Disassembly of section .text:

00000000004010f0 <main>:
  4010f0:	push   %rbp
  4010f1:	xor    %eax,%eax
  4010f3:	mov    %rsp,%rbp
  4010f6:	push   %r15
  4010f8:	push   %r14
  4010fa:	push   %r13
  4010fc:	push   %r12
  4010fe:	push   %rbx
  4010ff:	mov    %rsi,%rbx
  401102:	sub    $0x58,%rsp
  401106:	movsd  0x3062(%rip),%xmm2        # 404170 <__dso_handle+0x168>
  40110e:	movsd  0x3062(%rip),%xmm1        # 404178 <__dso_handle+0x170>
  401116:	cs nopw 0x0(%rax,%rax,1)
  401120:	pxor   %xmm0,%xmm0
  401124:	cvtsi2sd %rax,%xmm0
  401129:	mulsd  %xmm2,%xmm0
  40112d:	addsd  %xmm1,%xmm0
  401131:	movsd  %xmm0,0x4060c0(,%rax,8)
  40113a:	add    $0x1,%rax
  40113e:	cmp    $0x60,%rax
  401142:	jne    401120 <main+0x30>
  401144:	cmp    $0x2,%edi
  401147:	je     401250 <main+0x160>
  40114d:	cmp    $0x3,%edi
  401150:	je     4013e6 <main+0x2f6>
  401156:	cmp    $0x4,%edi
  401159:	jne    40127d <main+0x18d>
  40115f:	mov    0x10(%rbx),%rdi
  401163:	mov    $0x40406b,%esi
  401168:	mov    0x8(%rbx),%r13
  40116c:	call   402ef0 <parse_u64>
  401171:	mov    0x18(%rbx),%rdi
  401175:	mov    $0x4040ab,%esi
  40117a:	mov    %rax,%r12
  40117d:	call   402ef0 <parse_u64>
  401182:	mov    %rax,%r14
  401185:	test   %r12,%r12
  401188:	je     40129b <main+0x1ab>
  40118e:	mov    %r13,%rdi
  401191:	call   403020 <mode_supported>
  401196:	test   %eax,%eax
  401198:	je     40129b <main+0x1ab>
  40119e:	call   4030f0 <monotonic_raw_ns>
  4011a3:	mov    %r14,%rsi
  4011a6:	mov    %r13,%rdi
  4011a9:	mov    %rax,%r15
  4011ac:	call   402f70 <run_kernel>
  4011b1:	movsd  %xmm0,0x4ee7(%rip)        # 4060a0 <result_sink>
  4011b9:	call   4030f0 <monotonic_raw_ns>
  4011be:	mov    %rax,%r14
  4011c1:	call   4030f0 <monotonic_raw_ns>
  4011c6:	mov    %r12,%rsi
  4011c9:	mov    %r13,%rdi
  4011cc:	mov    %rax,%rbx
  4011cf:	call   402f70 <run_kernel>
  4011d4:	movsd  %xmm0,-0x58(%rbp)
  4011d9:	call   4030f0 <monotonic_raw_ns>
  4011de:	movsd  -0x58(%rbp),%xmm7
  4011e3:	mov    %rax,-0x60(%rbp)
  4011e7:	movsd  %xmm7,0x4eb1(%rip)        # 4060a0 <result_sink>
  4011ef:	call   4010c0 <sched_getcpu@plt>
  4011f4:	mov    -0x60(%rbp),%r8
  4011f8:	mov    %r14,%rcx
  4011fb:	mov    %r12,%rdx
  4011fe:	movsd  -0x58(%rbp),%xmm0
  401203:	mov    %eax,%r9d
  401206:	sub    %r15,%rcx
  401209:	mov    %r13,%rsi
  40120c:	sub    %rbx,%r8
  40120f:	mov    $0x404148,%edi
  401214:	mov    $0x1,%eax
  401219:	xor    %r12d,%r12d
  40121c:	call   401070 <printf@plt>
  401221:	movsd  -0x58(%rbp),%xmm0
  401226:	movsd  0x2f62(%rip),%xmm1        # 404190 <__dso_handle+0x188>
  40122e:	andpd  0x302a(%rip),%xmm0        # 404260 <__dso_handle+0x258>
  401236:	ucomisd %xmm0,%xmm1
  40123a:	setb   %r12b
  40123e:	add    $0x58,%rsp
  401242:	mov    %r12d,%eax
  401245:	pop    %rbx
  401246:	pop    %r12
  401248:	pop    %r13
  40124a:	pop    %r14
  40124c:	pop    %r15
  40124e:	pop    %rbp
  40124f:	ret
  401250:	mov    0x8(%rbx),%r13
  401254:	mov    $0x404056,%esi
  401259:	mov    %r13,%rdi
  40125c:	call   401090 <strcmp@plt>
  401261:	mov    %eax,%r12d
  401264:	test   %eax,%eax
  401266:	je     40143c <main+0x34c>
  40126c:	mov    $0x40405d,%esi
  401271:	mov    %r13,%rdi
  401274:	call   401090 <strcmp@plt>
  401279:	test   %eax,%eax
  40127b:	je     4012b9 <main+0x1c9>
  40127d:	mov    (%rbx),%rdx
  401280:	mov    $0x4040f8,%esi
  401285:	xor    %eax,%eax
  401287:	mov    $0x2,%r12d
  40128d:	mov    0x4dec(%rip),%rdi        # 406080 <stderr@GLIBC_2.2.5>
  401294:	call   4010a0 <fprintf@plt>
  401299:	jmp    40123e <main+0x14e>
  40129b:	mov    %r13,%rdx
  40129e:	mov    $0x404120,%esi
  4012a3:	xor    %eax,%eax
  4012a5:	mov    $0x2,%r12d
  4012ab:	mov    0x4dce(%rip),%rdi        # 406080 <stderr@GLIBC_2.2.5>
  4012b2:	call   4010a0 <fprintf@plt>
  4012b7:	jmp    40123e <main+0x14e>
  4012b9:	mov    $0x2717,%r12d
  4012bf:	mov    %r12,%rdi
  4012c2:	xor    %r14d,%r14d
  4012c5:	lea    -0x50(%rbp),%r13
  4012c9:	xor    %ebx,%ebx
  4012cb:	call   4025b0 <kernel_scalar>
  4012d0:	movq   $0x404020,-0x50(%rbp)
  4012d8:	movq   $0x404027,-0x48(%rbp)
  4012e0:	movq   $0x40402c,-0x40(%rbp)
  4012e8:	movq   $0x404031,-0x38(%rbp)
  4012f0:	movsd  %xmm0,-0x58(%rbp)
  4012f5:	mov    0x0(%r13,%rbx,8),%r15
  4012fa:	mov    %r15,%rdi
  4012fd:	call   403020 <mode_supported>
  401302:	test   %eax,%eax
  401304:	je     4013c8 <main+0x2d8>
  40130a:	mov    %r12,%rsi
  40130d:	mov    %r15,%rdi
  401310:	call   402f70 <run_kernel>
  401315:	movsd  -0x58(%rbp),%xmm5
  40131a:	movapd %xmm0,%xmm2
  40131e:	movsd  %xmm0,-0x78(%rbp)
  401323:	movsd  0x2e55(%rip),%xmm0        # 404180 <__dso_handle+0x178>
  40132b:	movapd %xmm5,%xmm6
  40132f:	andpd  0x2f29(%rip),%xmm6        # 404260 <__dso_handle+0x258>
  401337:	subsd  %xmm5,%xmm2
  40133b:	andpd  0x2f1d(%rip),%xmm2        # 404260 <__dso_handle+0x258>
  401343:	movapd %xmm6,%xmm1
  401347:	movsd  %xmm2,-0x60(%rbp)
  40134c:	call   401040 <fmax@plt>
  401351:	movsd  0x2e2f(%rip),%xmm4        # 404188 <__dso_handle+0x180>
  401359:	movsd  -0x78(%rbp),%xmm3
  40135e:	mov    %r15,%rsi
  401361:	movsd  -0x60(%rbp),%xmm2
  401366:	movsd  -0x58(%rbp),%xmm1
  40136b:	mov    $0x40408f,%edi
  401370:	mov    $0x3,%eax
  401375:	mulsd  %xmm0,%xmm4
  401379:	movapd %xmm3,%xmm0
  40137d:	movsd  %xmm3,-0x60(%rbp)
  401382:	movsd  %xmm2,-0x68(%rbp)
  401387:	movsd  %xmm4,-0x70(%rbp)
  40138c:	call   401070 <printf@plt>
  401391:	movsd  -0x60(%rbp),%xmm3
  401396:	movsd  -0x68(%rbp),%xmm2
  40139b:	andpd  0x2ebd(%rip),%xmm3        # 404260 <__dso_handle+0x258>
  4013a3:	movsd  0x2de5(%rip),%xmm0        # 404190 <__dso_handle+0x188>
  4013ab:	movsd  -0x70(%rbp),%xmm4
  4013b0:	ucomisd %xmm3,%xmm0
  4013b4:	jb     40148c <main+0x39c>
  4013ba:	comisd %xmm4,%xmm2
  4013be:	ja     40148c <main+0x39c>
  4013c4:	add    $0x1,%r14d
  4013c8:	add    $0x1,%rbx
  4013cc:	cmp    $0x4,%rbx
  4013d0:	jne    4012f5 <main+0x205>
  4013d6:	xor    %r12d,%r12d
  4013d9:	sub    $0x1,%r14d
  4013dd:	setle  %r12b
  4013e1:	jmp    40123e <main+0x14e>
  4013e6:	mov    0x8(%rbx),%rdi
  4013ea:	mov    $0x40405d,%esi
  4013ef:	call   401090 <strcmp@plt>
  4013f4:	test   %eax,%eax
  4013f6:	jne    40127d <main+0x18d>
  4013fc:	mov    0x10(%rbx),%rdi
  401400:	mov    $0x404065,%esi
  401405:	call   402ef0 <parse_u64>
  40140a:	mov    %rax,%r12
  40140d:	test   %rax,%rax
  401410:	jne    4012bf <main+0x1cf>
  401416:	mov    $0x1d,%edx
  40141b:	mov    $0x1,%esi
  401420:	mov    $0x404071,%edi
  401425:	mov    0x4c54(%rip),%rcx        # 406080 <stderr@GLIBC_2.2.5>
  40142c:	mov    $0x2,%r12d
  401432:	call   4010e0 <fwrite@plt>
  401437:	jmp    40123e <main+0x14e>
  40143c:	movq   $0x404020,-0x50(%rbp)
  401444:	xor    %ebx,%ebx
  401446:	lea    -0x50(%rbp),%r13
  40144a:	movq   $0x404027,-0x48(%rbp)
  401452:	movq   $0x40402c,-0x40(%rbp)
  40145a:	movq   $0x404031,-0x38(%rbp)
  401462:	mov    0x0(%r13,%rbx,8),%r14
  401467:	mov    %r14,%rdi
  40146a:	call   403020 <mode_supported>
  40146f:	test   %eax,%eax
  401471:	jne    401482 <main+0x392>
  401473:	add    $0x1,%rbx
  401477:	cmp    $0x4,%rbx
  40147b:	jne    401462 <main+0x372>
  40147d:	jmp    40123e <main+0x14e>
  401482:	mov    %r14,%rdi
  401485:	call   401050 <puts@plt>
  40148a:	jmp    401473 <main+0x383>
  40148c:	movapd %xmm4,%xmm1
  401490:	movapd %xmm2,%xmm0
  401494:	mov    %r15,%rdx
  401497:	mov    $0x4040b8,%esi
  40149c:	mov    0x4bdd(%rip),%rdi        # 406080 <stderr@GLIBC_2.2.5>
  4014a3:	mov    $0x2,%eax
  4014a8:	mov    $0x1,%r12d
  4014ae:	call   4010a0 <fprintf@plt>
  4014b3:	jmp    40123e <main+0x14e>
  4014b8:	nopl   0x0(%rax,%rax,1)

00000000004014c0 <has_cpu_feature.part.0.constprop.0>:
  4014c0:	mov    %edi,%ecx
  4014c2:	mov    $0x1,%eax
  4014c7:	shl    %cl,%eax
  4014c9:	cmp    $0x40,%edi
  4014cc:	lea    0x4eed(%rip),%rcx        # 4063c0 <__cpu_features2>
  4014d3:	sbb    %rdx,%rdx
  4014d6:	not    %rdx
  4014d9:	and    $0x4,%edx
  4014dc:	and    (%rcx,%rdx,1),%eax
  4014df:	ret

00000000004014e0 <__cpu_indicator_init>:
  4014e0:	endbr64
  4014e4:	push   %r15
  4014e6:	push   %r14
  4014e8:	push   %r13
  4014ea:	xor    %r13d,%r13d
  4014ed:	push   %r12
  4014ef:	push   %rbp
  4014f0:	push   %rbx
  4014f1:	sub    $0x10,%rsp
  4014f5:	mov    0x4ed5(%rip),%eax        # 4063d0 <__cpu_model>
  4014fb:	test   %eax,%eax
  4014fd:	jne    401b24 <__cpu_indicator_init+0x644>
  401503:	mov    %r13d,%eax
  401506:	cpuid
  401508:	test   %eax,%eax
  40150a:	je     4020ea <__cpu_indicator_init+0xc0a>
  401510:	mov    %r13d,%eax
  401513:	cpuid
  401515:	mov    %ebx,%ebp
  401517:	mov    %eax,%r8d
  40151a:	test   %eax,%eax
  40151c:	jle    4020ea <__cpu_indicator_init+0xc0a>
  401522:	mov    %r13d,%eax
  401525:	cpuid
  401527:	test   %eax,%eax
  401529:	je     4020ea <__cpu_indicator_init+0xc0a>
  40152f:	mov    $0x1,%eax
  401534:	cpuid
  401536:	mov    %eax,%r9d
  401539:	shr    $0x4,%eax
  40153c:	mov    %ecx,%r12d
  40153f:	mov    %edx,%r11d
  401542:	and    $0xf,%eax
  401545:	mov    %ecx,%r10d
  401548:	mov    %eax,0x8(%rsp)
  40154c:	mov    %r9d,%eax
  40154f:	shr    $0x8,%eax
  401552:	and    $0xf,%eax
  401555:	mov    %eax,0x4(%rsp)
  401559:	mov    %r9d,%eax
  40155c:	shr    $0xc,%eax
  40155f:	and    $0xf0,%eax
  401564:	mov    %eax,0xc(%rsp)
  401568:	and    $0x8000000,%r12d
  40156f:	jne    401b36 <__cpu_indicator_init+0x656>
  401575:	movl   $0x0,(%rsp)
  40157c:	xor    %r15d,%r15d
  40157f:	xor    %r13d,%r13d
  401582:	test   $0x8000,%r11d
  401589:	je     401592 <__cpu_indicator_init+0xb2>
  40158b:	orl    $0x1,0x4e4a(%rip)        # 4063dc <__cpu_model+0xc>
  401592:	test   $0x800000,%r11d
  401599:	je     4015a2 <__cpu_indicator_init+0xc2>
  40159b:	orl    $0x2,0x4e3a(%rip)        # 4063dc <__cpu_model+0xc>
  4015a2:	test   $0x2000000,%r11d
  4015a9:	je     4015b2 <__cpu_indicator_init+0xd2>
  4015ab:	orl    $0x8,0x4e2a(%rip)        # 4063dc <__cpu_model+0xc>
  4015b2:	test   $0x4000000,%r11d
  4015b9:	je     4015c2 <__cpu_indicator_init+0xe2>
  4015bb:	orl    $0x10,0x4e1a(%rip)        # 4063dc <__cpu_model+0xc>
  4015c2:	test   $0x100,%r11d
  4015c9:	jne    401bc2 <__cpu_indicator_init+0x6e2>
  4015cf:	and    $0x1000000,%r11d
  4015d6:	jne    401bb3 <__cpu_indicator_init+0x6d3>
  4015dc:	test   $0x800000,%r10d
  4015e3:	je     4015ec <__cpu_indicator_init+0x10c>
  4015e5:	orl    $0x4,0x4df0(%rip)        # 4063dc <__cpu_model+0xc>
  4015ec:	mov    %r10d,%r11d
  4015ef:	and    $0x2000000,%r11d
  4015f6:	je     401602 <__cpu_indicator_init+0x122>
  4015f8:	orl    $0x40000,0x4dda(%rip)        # 4063dc <__cpu_model+0xc>
  401602:	test   $0x2,%r10b
  401606:	je     401612 <__cpu_indicator_init+0x132>
  401608:	orl    $0x80000,0x4dca(%rip)        # 4063dc <__cpu_model+0xc>
  401612:	test   $0x1,%r10b
  401616:	je     40161f <__cpu_indicator_init+0x13f>
  401618:	orl    $0x20,0x4dbd(%rip)        # 4063dc <__cpu_model+0xc>
  40161f:	test   $0x200,%r10d
  401626:	je     40162f <__cpu_indicator_init+0x14f>
  401628:	orl    $0x40,0x4dad(%rip)        # 4063dc <__cpu_model+0xc>
  40162f:	test   $0x80000,%r10d
  401636:	je     401642 <__cpu_indicator_init+0x162>
  401638:	orl    $0x80,0x4d9a(%rip)        # 4063dc <__cpu_model+0xc>
  401642:	test   $0x100000,%r10d
  401649:	je     401655 <__cpu_indicator_init+0x175>
  40164b:	orl    $0x100,0x4d87(%rip)        # 4063dc <__cpu_model+0xc>
  401655:	test   %r12d,%r12d
  401658:	jne    401ba4 <__cpu_indicator_init+0x6c4>
  40165e:	test   $0x2000,%r10d
  401665:	jne    401b95 <__cpu_indicator_init+0x6b5>
  40166b:	test   $0x400000,%r10d
  401672:	jne    401b68 <__cpu_indicator_init+0x688>
  401678:	test   %r11d,%r11d
  40167b:	je     401687 <__cpu_indicator_init+0x1a7>
  40167d:	orl    $0x40000,0x4d55(%rip)        # 4063dc <__cpu_model+0xc>
  401687:	test   $0x40000000,%r10d
  40168e:	jne    401b86 <__cpu_indicator_init+0x6a6>
  401694:	test   $0x4000000,%r10d
  40169b:	jne    401b77 <__cpu_indicator_init+0x697>
  4016a1:	test   %r13d,%r13d
  4016a4:	je     4016d3 <__cpu_indicator_init+0x1f3>
  4016a6:	test   $0x10000000,%r10d
  4016ad:	je     4016b9 <__cpu_indicator_init+0x1d9>
  4016af:	orl    $0x200,0x4d23(%rip)        # 4063dc <__cpu_model+0xc>
  4016b9:	test   $0x1000,%r10d
  4016c0:	jne    401c7c <__cpu_indicator_init+0x79c>
  4016c6:	and    $0x20000000,%r10d
  4016cd:	jne    401dec <__cpu_indicator_init+0x90c>
  4016d3:	xor    %r14d,%r14d
  4016d6:	cmp    $0x6,%r8d
  4016da:	jbe    4019ad <__cpu_indicator_init+0x4cd>
  4016e0:	mov    $0x7,%r12d
  4016e6:	mov    %r14d,%ecx
  4016e9:	mov    %r12d,%eax
  4016ec:	cpuid
  4016ee:	mov    %edx,%r11d
  4016f1:	mov    %ecx,%r10d
  4016f4:	mov    %eax,%r12d
  4016f7:	test   $0x8,%bl
  4016fa:	jne    401c6d <__cpu_indicator_init+0x78d>
  401700:	test   $0x4,%bl
  401703:	jne    401fca <__cpu_indicator_init+0xaea>
  401709:	test   $0x10,%bl
  40170c:	jne    401fe8 <__cpu_indicator_init+0xb08>
  401712:	test   $0x8,%bh
  401715:	jne    401fd9 <__cpu_indicator_init+0xaf9>
  40171b:	test   %r13d,%r13d
  40171e:	je     40174f <__cpu_indicator_init+0x26f>
  401720:	test   $0x20,%bl
  401723:	je     40172f <__cpu_indicator_init+0x24f>
  401725:	orl    $0x400,0x4cad(%rip)        # 4063dc <__cpu_model+0xc>
  40172f:	test   $0x400,%r10d
  401736:	jne    4020bd <__cpu_indicator_init+0xbdd>
  40173c:	test   $0x200,%r10d
  401743:	je     40174f <__cpu_indicator_init+0x26f>
  401745:	mov    $0x4e,%edi
  40174a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40174f:	test   $0x1,%bh
  401752:	jne    401c5e <__cpu_indicator_init+0x77e>
  401758:	test   $0x1,%bl
  40175b:	jne    402060 <__cpu_indicator_init+0xb80>
  401761:	test   $0x40000,%ebx
  401767:	jne    402051 <__cpu_indicator_init+0xb71>
  40176d:	test   $0x80000,%ebx
  401773:	jne    402042 <__cpu_indicator_init+0xb62>
  401779:	test   $0x20000000,%ebx
  40177f:	jne    402033 <__cpu_indicator_init+0xb53>
  401785:	test   $0x800000,%ebx
  40178b:	jne    402024 <__cpu_indicator_init+0xb44>
  401791:	test   $0x1000000,%ebx
  401797:	jne    402015 <__cpu_indicator_init+0xb35>
  40179d:	test   $0x1,%r10b
  4017a1:	jne    402006 <__cpu_indicator_init+0xb26>
  4017a7:	test   $0x10,%r10b
  4017ab:	jne    401ff7 <__cpu_indicator_init+0xb17>
  4017b1:	test   $0x400000,%r10d
  4017b8:	jne    401fbb <__cpu_indicator_init+0xadb>
  4017be:	test   $0x100,%r10d
  4017c5:	jne    401fac <__cpu_indicator_init+0xacc>
  4017cb:	test   $0x8000000,%r10d
  4017d2:	jne    401f9d <__cpu_indicator_init+0xabd>
  4017d8:	test   $0x10000000,%r10d
  4017df:	jne    401f8e <__cpu_indicator_init+0xaae>
  4017e5:	test   $0x20000000,%r10d
  4017ec:	jne    401f7f <__cpu_indicator_init+0xa9f>
  4017f2:	test   $0x2000000,%r10d
  4017f9:	jne    401f70 <__cpu_indicator_init+0xa90>
  4017ff:	test   $0x20,%r10b
  401803:	jne    401f61 <__cpu_indicator_init+0xa81>
  401809:	test   $0x80,%r10b
  40180d:	jne    401f52 <__cpu_indicator_init+0xa72>
  401813:	mov    %r10d,%r14d
  401816:	shr    $0x17,%r14d
  40181a:	and    $0x1,%r14d
  40181e:	test   $0x4000,%r11d
  401825:	jne    401f43 <__cpu_indicator_init+0xa63>
  40182b:	test   $0x10000,%r11d
  401832:	jne    401f34 <__cpu_indicator_init+0xa54>
  401838:	test   $0x40000,%r11d
  40183f:	jne    401f25 <__cpu_indicator_init+0xa45>
  401845:	test   $0x100000,%r11d
  40184c:	jne    401f16 <__cpu_indicator_init+0xa36>
  401852:	test   $0x20,%r11b
  401856:	jne    401f07 <__cpu_indicator_init+0xa27>
  40185c:	cmpl   $0x0,(%rsp)
  401860:	je     40188f <__cpu_indicator_init+0x3af>
  401862:	test   $0x1000000,%r11d
  401869:	jne    40209f <__cpu_indicator_init+0xbbf>
  40186f:	test   $0x2000000,%r11d
  401876:	jne    402090 <__cpu_indicator_init+0xbb0>
  40187c:	test   $0x400000,%r11d
  401883:	je     40188f <__cpu_indicator_init+0x3af>
  401885:	mov    $0x57,%edi
  40188a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40188f:	test   %r15d,%r15d
  401892:	je     4019a4 <__cpu_indicator_init+0x4c4>
  401898:	test   $0x10000,%ebx
  40189e:	je     4018aa <__cpu_indicator_init+0x3ca>
  4018a0:	orl    $0x8000,0x4b32(%rip)        # 4063dc <__cpu_model+0xc>
  4018aa:	test   %ebx,%ebx
  4018ac:	jns    4018b8 <__cpu_indicator_init+0x3d8>
  4018ae:	orl    $0x100000,0x4b24(%rip)        # 4063dc <__cpu_model+0xc>
  4018b8:	test   $0x40000000,%ebx
  4018be:	je     4018ca <__cpu_indicator_init+0x3ea>
  4018c0:	orl    $0x200000,0x4b12(%rip)        # 4063dc <__cpu_model+0xc>
  4018ca:	test   $0x20000,%ebx
  4018d0:	je     4018dc <__cpu_indicator_init+0x3fc>
  4018d2:	orl    $0x400000,0x4b00(%rip)        # 4063dc <__cpu_model+0xc>
  4018dc:	test   $0x10000000,%ebx
  4018e2:	je     4018ee <__cpu_indicator_init+0x40e>
  4018e4:	orl    $0x800000,0x4aee(%rip)        # 4063dc <__cpu_model+0xc>
  4018ee:	test   $0x4000000,%ebx
  4018f4:	je     401900 <__cpu_indicator_init+0x420>
  4018f6:	orl    $0x2000000,0x4adc(%rip)        # 4063dc <__cpu_model+0xc>
  401900:	test   $0x8000000,%ebx
  401906:	je     401912 <__cpu_indicator_init+0x432>
  401908:	orl    $0x1000000,0x4aca(%rip)        # 4063dc <__cpu_model+0xc>
  401912:	and    $0x200000,%ebx
  401918:	je     401924 <__cpu_indicator_init+0x444>
  40191a:	orl    $0x8000000,0x4ab8(%rip)        # 4063dc <__cpu_model+0xc>
  401924:	test   $0x2,%r10b
  401928:	je     401934 <__cpu_indicator_init+0x454>
  40192a:	orl    $0x4000000,0x4aa8(%rip)        # 4063dc <__cpu_model+0xc>
  401934:	test   $0x40,%r10b
  401938:	je     401944 <__cpu_indicator_init+0x464>
  40193a:	orl    $0x80000000,0x4a98(%rip)        # 4063dc <__cpu_model+0xc>
  401944:	test   $0x800,%r10d
  40194b:	jne    4020cc <__cpu_indicator_init+0xbec>
  401951:	test   $0x1000,%r10d
  401958:	jne    4020ae <__cpu_indicator_init+0xbce>
  40195e:	and    $0x4000,%r10d
  401965:	je     401971 <__cpu_indicator_init+0x491>
  401967:	orl    $0x40000000,0x4a6b(%rip)        # 4063dc <__cpu_model+0xc>
  401971:	test   $0x4,%r11b
  401975:	je     401981 <__cpu_indicator_init+0x4a1>
  401977:	orl    $0x10000000,0x4a5b(%rip)        # 4063dc <__cpu_model+0xc>
  401981:	test   $0x8,%r11b
  401985:	je     401991 <__cpu_indicator_init+0x4b1>
  401987:	orl    $0x20000000,0x4a4b(%rip)        # 4063dc <__cpu_model+0xc>
  401991:	and    $0x100,%r11d
  401998:	je     4019a4 <__cpu_indicator_init+0x4c4>
  40199a:	mov    $0x25,%edi
  40199f:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4019a4:	test   %r12d,%r12d
  4019a7:	jne    401c0f <__cpu_indicator_init+0x72f>
  4019ad:	cmp    $0xc,%r8d
  4019b1:	jbe    4019e2 <__cpu_indicator_init+0x502>
  4019b3:	mov    $0xd,%r10d
  4019b9:	mov    $0x1,%ecx
  4019be:	mov    %r10d,%eax
  4019c1:	cpuid
  4019c3:	mov    %eax,%r10d
  4019c6:	test   $0x1,%al
  4019c8:	jne    401e80 <__cpu_indicator_init+0x9a0>
  4019ce:	test   $0x2,%r10b
  4019d2:	jne    401e71 <__cpu_indicator_init+0x991>
  4019d8:	and    $0x8,%r10b
  4019dc:	jne    401e62 <__cpu_indicator_init+0x982>
  4019e2:	cmp    $0x13,%r8d
  4019e6:	jbe    4019fa <__cpu_indicator_init+0x51a>
  4019e8:	mov    $0x14,%eax
  4019ed:	xor    %ecx,%ecx
  4019ef:	cpuid
  4019f1:	and    $0x10,%bl
  4019f4:	jne    401e53 <__cpu_indicator_init+0x973>
  4019fa:	cmp    $0x18,%r8d
  4019fe:	jbe    401a10 <__cpu_indicator_init+0x530>
  401a00:	mov    $0x19,%eax
  401a05:	cpuid
  401a07:	test   $0x1,%bl
  401a0a:	jne    401e0a <__cpu_indicator_init+0x92a>
  401a10:	mov    $0x80000000,%eax
  401a15:	cpuid
  401a17:	mov    %eax,%r8d
  401a1a:	cmp    $0x80000000,%eax
  401a1f:	jbe    401adb <__cpu_indicator_init+0x5fb>
  401a25:	mov    $0x80000001,%eax
  401a2a:	cpuid
  401a2c:	mov    %edx,%r11d
  401a2f:	mov    %ecx,%r10d
  401a32:	test   $0x40,%cl
  401a35:	jne    401c00 <__cpu_indicator_init+0x720>
  401a3b:	test   $0x1,%r10b
  401a3f:	jne    401e44 <__cpu_indicator_init+0x964>
  401a45:	mov    %r10d,%ebx
  401a48:	and    $0x20,%ebx
  401a4b:	jne    401e35 <__cpu_indicator_init+0x955>
  401a51:	test   $0x8000,%r10d
  401a58:	jne    401ee9 <__cpu_indicator_init+0xa09>
  401a5e:	test   $0x200000,%r10d
  401a65:	jne    401eda <__cpu_indicator_init+0x9fa>
  401a6b:	test   %ebx,%ebx
  401a6d:	jne    401ecb <__cpu_indicator_init+0x9eb>
  401a73:	test   $0x100,%r10d
  401a7a:	jne    401ebc <__cpu_indicator_init+0x9dc>
  401a80:	test   $0x20000000,%r10d
  401a87:	jne    401ead <__cpu_indicator_init+0x9cd>
  401a8d:	test   $0x20000000,%r11d
  401a94:	jne    401e9e <__cpu_indicator_init+0x9be>
  401a9a:	test   $0x40000000,%r11d
  401aa1:	jne    401e8f <__cpu_indicator_init+0x9af>
  401aa7:	test   %r11d,%r11d
  401aaa:	js     40206f <__cpu_indicator_init+0xb8f>
  401ab0:	test   %r13d,%r13d
  401ab3:	jne    401bd1 <__cpu_indicator_init+0x6f1>
  401ab9:	cmp    $0x80000007,%r8d
  401ac0:	jbe    401adb <__cpu_indicator_init+0x5fb>
  401ac2:	mov    $0x80000008,%eax
  401ac7:	cpuid
  401ac9:	test   $0x1,%bl
  401acc:	jne    401dfb <__cpu_indicator_init+0x91b>
  401ad2:	and    $0x2,%bh
  401ad5:	jne    401ef8 <__cpu_indicator_init+0xa18>
  401adb:	cmp    $0x756e6547,%ebp
  401ae1:	je     401c9d <__cpu_indicator_init+0x7bd>
  401ae7:	cmp    $0x68747541,%ebp
  401aed:	je     401d88 <__cpu_indicator_init+0x8a8>
  401af3:	cmp    $0x746e6543,%ebp
  401af9:	je     401c8b <__cpu_indicator_init+0x7ab>
  401aff:	cmp    $0x69727943,%ebp
  401b05:	je     40207e <__cpu_indicator_init+0xb9e>
  401b0b:	cmp    $0x646f6547,%ebp
  401b11:	je     402331 <__cpu_indicator_init+0xe51>
  401b17:	movl   $0x3,0x48af(%rip)        # 4063d0 <__cpu_model>
  401b21:	xor    %r13d,%r13d
  401b24:	add    $0x10,%rsp
  401b28:	mov    %r13d,%eax
  401b2b:	pop    %rbx
  401b2c:	pop    %rbp
  401b2d:	pop    %r12
  401b2f:	pop    %r13
  401b31:	pop    %r14
  401b33:	pop    %r15
  401b35:	ret
  401b36:	mov    %r13d,%ecx
  401b39:	xgetbv
  401b3c:	mov    %eax,%edx
  401b3e:	and    $0x6,%edx
  401b41:	cmp    $0x6,%edx
  401b44:	je     401dcc <__cpu_indicator_init+0x8ec>
  401b4a:	xor    %r15d,%r15d
  401b4d:	xor    %r13d,%r13d
  401b50:	and    $0x60000,%eax
  401b55:	cmp    $0x60000,%eax
  401b5a:	sete   %al
  401b5d:	movzbl %al,%eax
  401b60:	mov    %eax,(%rsp)
  401b63:	jmp    401582 <__cpu_indicator_init+0xa2>
  401b68:	mov    $0x3a,%edi
  401b6d:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401b72:	jmp    401678 <__cpu_indicator_init+0x198>
  401b77:	mov    $0x51,%edi
  401b7c:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401b81:	jmp    4016a1 <__cpu_indicator_init+0x1c1>
  401b86:	mov    $0x45,%edi
  401b8b:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401b90:	jmp    401694 <__cpu_indicator_init+0x1b4>
  401b95:	mov    $0x2e,%edi
  401b9a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401b9f:	jmp    40166b <__cpu_indicator_init+0x18b>
  401ba4:	mov    $0x3e,%edi
  401ba9:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401bae:	jmp    40165e <__cpu_indicator_init+0x17e>
  401bb3:	mov    $0x33,%edi
  401bb8:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401bbd:	jmp    4015dc <__cpu_indicator_init+0xfc>
  401bc2:	mov    $0x2f,%edi
  401bc7:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401bcc:	jmp    4015cf <__cpu_indicator_init+0xef>
  401bd1:	test   $0x10000,%r10d
  401bd8:	je     401be4 <__cpu_indicator_init+0x704>
  401bda:	orl    $0x1000,0x47f8(%rip)        # 4063dc <__cpu_model+0xc>
  401be4:	and    $0x800,%r10d
  401beb:	je     401ab9 <__cpu_indicator_init+0x5d9>
  401bf1:	orl    $0x2000,0x47e1(%rip)        # 4063dc <__cpu_model+0xc>
  401bfb:	jmp    401ab9 <__cpu_indicator_init+0x5d9>
  401c00:	orl    $0x800,0x47d2(%rip)        # 4063dc <__cpu_model+0xc>
  401c0a:	jmp    401a3b <__cpu_indicator_init+0x55b>
  401c0f:	mov    $0x7,%r10d
  401c15:	mov    $0x1,%ecx
  401c1a:	mov    %r10d,%eax
  401c1d:	cpuid
  401c1f:	mov    %eax,%r10d
  401c22:	test   $0x400000,%eax
  401c27:	jne    4020db <__cpu_indicator_init+0xbfb>
  401c2d:	test   %r13d,%r13d
  401c30:	je     401c3c <__cpu_indicator_init+0x75c>
  401c32:	test   $0x10,%r10b
  401c36:	jne    402352 <__cpu_indicator_init+0xe72>
  401c3c:	test   %r15d,%r15d
  401c3f:	je     4019ad <__cpu_indicator_init+0x4cd>
  401c45:	and    $0x20,%r10b
  401c49:	je     4019ad <__cpu_indicator_init+0x4cd>
  401c4f:	mov    $0x24,%edi
  401c54:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401c59:	jmp    4019ad <__cpu_indicator_init+0x4cd>
  401c5e:	orl    $0x20000,0x4774(%rip)        # 4063dc <__cpu_model+0xc>
  401c68:	jmp    401758 <__cpu_indicator_init+0x278>
  401c6d:	orl    $0x10000,0x4765(%rip)        # 4063dc <__cpu_model+0xc>
  401c77:	jmp    401700 <__cpu_indicator_init+0x220>
  401c7c:	orl    $0x4000,0x4756(%rip)        # 4063dc <__cpu_model+0xc>
  401c86:	jmp    4016c6 <__cpu_indicator_init+0x1e6>
  401c8b:	movl   $0x4,0x473b(%rip)        # 4063d0 <__cpu_model>
  401c95:	xor    %r13d,%r13d
  401c98:	jmp    401b24 <__cpu_indicator_init+0x644>
  401c9d:	cmpl   $0x6,0x4(%rsp)
  401ca2:	je     401cb6 <__cpu_indicator_init+0x7d6>
  401ca4:	movl   $0x1,0x4722(%rip)        # 4063d0 <__cpu_model>
  401cae:	xor    %r13d,%r13d
  401cb1:	jmp    401b24 <__cpu_indicator_init+0x644>
  401cb6:	mov    0x8(%rsp),%ecx
  401cba:	or     0xc(%rsp),%ecx
  401cbe:	cmp    $0xa7,%ecx
  401cc4:	ja     401ca4 <__cpu_indicator_init+0x7c4>
  401cc6:	cmp    $0x46,%ecx
  401cc9:	jbe    401ce4 <__cpu_indicator_init+0x804>
  401ccb:	sub    $0x47,%ecx
  401cce:	cmp    $0x60,%ecx
  401cd1:	ja     401ca4 <__cpu_indicator_init+0x7c4>
  401cd3:	lea    0x2596(%rip),%rdx        # 404270 <__dso_handle+0x268>
  401cda:	movslq (%rdx,%rcx,4),%rax
  401cde:	add    %rdx,%rax
  401ce1:	notrack jmp *%rax
  401ce4:	cmp    $0x37,%ecx
  401ce7:	ja     401d28 <__cpu_indicator_init+0x848>
  401ce9:	cmp    $0x24,%ecx
  401cec:	ja     401d6b <__cpu_indicator_init+0x88b>
  401cee:	lea    -0xf(%rcx),%eax
  401cf1:	cmp    $0x10,%eax
  401cf4:	ja     401ca4 <__cpu_indicator_init+0x7c4>
  401cf6:	mov    $0x1,%eax
  401cfb:	shl    %cl,%rax
  401cfe:	test   $0x20808000,%eax
  401d03:	jne    4023d5 <__cpu_indicator_init+0xef5>
  401d09:	test   $0xc4000000,%eax
  401d0e:	jne    402223 <__cpu_indicator_init+0xd43>
  401d14:	cmp    $0x1c,%ecx
  401d17:	jne    401ca4 <__cpu_indicator_init+0x7c4>
  401d19:	movl   $0x1,0x46b1(%rip)        # 4063d4 <__cpu_model+0x4>
  401d23:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  401d28:	sub    $0x3a,%ecx
  401d2b:	cmp    $0xc,%ecx
  401d2e:	ja     401ca4 <__cpu_indicator_init+0x7c4>
  401d34:	mov    $0x1,%eax
  401d39:	shl    %cl,%rax
  401d3c:	test   $0x1824,%eax
  401d41:	jne    4023e4 <__cpu_indicator_init+0xf04>
  401d47:	test   $0x11,%al
  401d49:	jne    4023c2 <__cpu_indicator_init+0xee2>
  401d4f:	cmp    $0x3,%ecx
  401d52:	jne    401ca4 <__cpu_indicator_init+0x7c4>
  401d58:	mov    0x2461(%rip),%rax        # 4041c0 <__dso_handle+0x1b8>
  401d5f:	mov    %rax,0x466e(%rip)        # 4063d4 <__cpu_model+0x4>
  401d66:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  401d6b:	sub    $0x25,%ecx
  401d6e:	cmp    $0x12,%ecx
  401d71:	ja     401ca4 <__cpu_indicator_init+0x7c4>
  401d77:	lea    0x2676(%rip),%rdx        # 4043f4 <__dso_handle+0x3ec>
  401d7e:	movslq (%rdx,%rcx,4),%rax
  401d82:	add    %rdx,%rax
  401d85:	notrack jmp *%rax
  401d88:	cmpl   $0xf,0x4(%rsp)
  401d8d:	je     401da1 <__cpu_indicator_init+0x8c1>
  401d8f:	movl   $0x2,0x4637(%rip)        # 4063d0 <__cpu_model>
  401d99:	xor    %r13d,%r13d
  401d9c:	jmp    401b24 <__cpu_indicator_init+0x644>
  401da1:	shr    $0x14,%r9d
  401da5:	mov    0x8(%rsp),%eax
  401da9:	or     0xc(%rsp),%eax
  401dad:	movzbl %r9b,%r9d
  401db1:	sub    $0x1,%r9d
  401db5:	cmp    $0x9,%r9d
  401db9:	ja     401d8f <__cpu_indicator_init+0x8af>
  401dbb:	lea    0x267e(%rip),%rcx        # 404440 <__dso_handle+0x438>
  401dc2:	movslq (%rcx,%r9,4),%rdx
  401dc6:	add    %rcx,%rdx
  401dc9:	notrack jmp *%rdx
  401dcc:	mov    %eax,%edx
  401dce:	xor    %r15d,%r15d
  401dd1:	mov    $0x1,%r13d
  401dd7:	and    $0xe6,%edx
  401ddd:	cmp    $0xe6,%edx
  401de3:	sete   %r15b
  401de7:	jmp    401b50 <__cpu_indicator_init+0x670>
  401dec:	mov    $0x31,%edi
  401df1:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401df6:	jmp    4016d3 <__cpu_indicator_init+0x1f3>
  401dfb:	mov    $0x2d,%edi
  401e00:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e05:	jmp    401ad2 <__cpu_indicator_init+0x5f2>
  401e0a:	mov    $0x5b,%edi
  401e0f:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e14:	and    $0x4,%bl
  401e17:	jne    402343 <__cpu_indicator_init+0xe63>
  401e1d:	test   %r14d,%r14d
  401e20:	je     401a10 <__cpu_indicator_init+0x530>
  401e26:	mov    $0x5a,%edi
  401e2b:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e30:	jmp    401a10 <__cpu_indicator_init+0x530>
  401e35:	mov    $0x29,%edi
  401e3a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e3f:	jmp    401a51 <__cpu_indicator_init+0x571>
  401e44:	mov    $0x36,%edi
  401e49:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e4e:	jmp    401a45 <__cpu_indicator_init+0x565>
  401e53:	mov    $0x43,%edi
  401e58:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e5d:	jmp    4019fa <__cpu_indicator_init+0x51a>
  401e62:	mov    $0x54,%edi
  401e67:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e6c:	jmp    4019e2 <__cpu_indicator_init+0x502>
  401e71:	mov    $0x52,%edi
  401e76:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e7b:	jmp    4019d8 <__cpu_indicator_init+0x4f8>
  401e80:	mov    $0x53,%edi
  401e85:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e8a:	jmp    4019ce <__cpu_indicator_init+0x4ee>
  401e8f:	mov    $0x27,%edi
  401e94:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401e99:	jmp    401aa7 <__cpu_indicator_init+0x5c7>
  401e9e:	mov    $0x37,%edi
  401ea3:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ea8:	jmp    401a9a <__cpu_indicator_init+0x5ba>
  401ead:	mov    $0x3d,%edi
  401eb2:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401eb7:	jmp    401a8d <__cpu_indicator_init+0x5ad>
  401ebc:	mov    $0x42,%edi
  401ec1:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ec6:	jmp    401a80 <__cpu_indicator_init+0x5a0>
  401ecb:	mov    $0x39,%edi
  401ed0:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ed5:	jmp    401a73 <__cpu_indicator_init+0x593>
  401eda:	mov    $0x4c,%edi
  401edf:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ee4:	jmp    401a6b <__cpu_indicator_init+0x58b>
  401ee9:	mov    $0x38,%edi
  401eee:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ef3:	jmp    401a5e <__cpu_indicator_init+0x57e>
  401ef8:	mov    $0x50,%edi
  401efd:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f02:	jmp    401adb <__cpu_indicator_init+0x5fb>
  401f07:	mov    $0x58,%edi
  401f0c:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f11:	jmp    40185c <__cpu_indicator_init+0x37c>
  401f16:	mov    $0x35,%edi
  401f1b:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f20:	jmp    401852 <__cpu_indicator_init+0x372>
  401f25:	mov    $0x3f,%edi
  401f2a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f2f:	jmp    401845 <__cpu_indicator_init+0x365>
  401f34:	mov    $0x4d,%edi
  401f39:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f3e:	jmp    401838 <__cpu_indicator_init+0x358>
  401f43:	mov    $0x48,%edi
  401f48:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f4d:	jmp    40182b <__cpu_indicator_init+0x34b>
  401f52:	mov    $0x4b,%edi
  401f57:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f5c:	jmp    401813 <__cpu_indicator_init+0x333>
  401f61:	mov    $0x4f,%edi
  401f66:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f6b:	jmp    401809 <__cpu_indicator_init+0x329>
  401f70:	mov    $0x2a,%edi
  401f75:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f7a:	jmp    4017ff <__cpu_indicator_init+0x31f>
  401f7f:	mov    $0x30,%edi
  401f84:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f89:	jmp    4017f2 <__cpu_indicator_init+0x312>
  401f8e:	mov    $0x3b,%edi
  401f93:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401f98:	jmp    4017e5 <__cpu_indicator_init+0x305>
  401f9d:	mov    $0x3c,%edi
  401fa2:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401fa7:	jmp    4017d8 <__cpu_indicator_init+0x2f8>
  401fac:	mov    $0x20,%edi
  401fb1:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401fb6:	jmp    4017cb <__cpu_indicator_init+0x2eb>
  401fbb:	mov    $0x44,%edi
  401fc0:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401fc5:	jmp    4017be <__cpu_indicator_init+0x2de>
  401fca:	mov    $0x49,%edi
  401fcf:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401fd4:	jmp    401709 <__cpu_indicator_init+0x229>
  401fd9:	mov    $0x47,%edi
  401fde:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401fe3:	jmp    40171b <__cpu_indicator_init+0x23b>
  401fe8:	mov    $0x34,%edi
  401fed:	call   403130 <set_cpu_feature.part.0.constprop.0>
  401ff2:	jmp    401712 <__cpu_indicator_init+0x232>
  401ff7:	mov    $0x40,%edi
  401ffc:	call   403130 <set_cpu_feature.part.0.constprop.0>
  402001:	jmp    4017b1 <__cpu_indicator_init+0x2d1>
  402006:	mov    $0x41,%edi
  40200b:	call   403130 <set_cpu_feature.part.0.constprop.0>
  402010:	jmp    4017a7 <__cpu_indicator_init+0x2c7>
  402015:	mov    $0x2c,%edi
  40201a:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40201f:	jmp    40179d <__cpu_indicator_init+0x2bd>
  402024:	mov    $0x2b,%edi
  402029:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40202e:	jmp    401791 <__cpu_indicator_init+0x2b1>
  402033:	mov    $0x4a,%edi
  402038:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40203d:	jmp    401785 <__cpu_indicator_init+0x2a5>
  402042:	mov    $0x28,%edi
  402047:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40204c:	jmp    401779 <__cpu_indicator_init+0x299>
  402051:	mov    $0x46,%edi
  402056:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40205b:	jmp    40176d <__cpu_indicator_init+0x28d>
  402060:	mov    $0x32,%edi
  402065:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40206a:	jmp    401761 <__cpu_indicator_init+0x281>
  40206f:	mov    $0x26,%edi
  402074:	call   403130 <set_cpu_feature.part.0.constprop.0>
  402079:	jmp    401ab0 <__cpu_indicator_init+0x5d0>
  40207e:	movl   $0x5,0x4348(%rip)        # 4063d0 <__cpu_model>
  402088:	xor    %r13d,%r13d
  40208b:	jmp    401b24 <__cpu_indicator_init+0x644>
  402090:	mov    $0x56,%edi
  402095:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40209a:	jmp    40187c <__cpu_indicator_init+0x39c>
  40209f:	mov    $0x55,%edi
  4020a4:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4020a9:	jmp    40186f <__cpu_indicator_init+0x38f>
  4020ae:	mov    $0x23,%edi
  4020b3:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4020b8:	jmp    40195e <__cpu_indicator_init+0x47e>
  4020bd:	mov    $0x21,%edi
  4020c2:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4020c7:	jmp    40173c <__cpu_indicator_init+0x25c>
  4020cc:	mov    $0x22,%edi
  4020d1:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4020d6:	jmp    401951 <__cpu_indicator_init+0x471>
  4020db:	mov    $0x59,%edi
  4020e0:	call   403130 <set_cpu_feature.part.0.constprop.0>
  4020e5:	jmp    401c2d <__cpu_indicator_init+0x74d>
  4020ea:	movl   $0x3,0x42dc(%rip)        # 4063d0 <__cpu_model>
  4020f4:	or     $0xffffffff,%r13d
  4020f8:	jmp    401b24 <__cpu_indicator_init+0x644>
  4020fd:	mov    0x209c(%rip),%rax        # 4041a0 <__dso_handle+0x198>
  402104:	mov    %rax,0x42c9(%rip)        # 4063d4 <__cpu_model+0x4>
  40210b:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402110:	mov    0x2091(%rip),%rax        # 4041a8 <__dso_handle+0x1a0>
  402117:	mov    %rax,0x42b6(%rip)        # 4063d4 <__cpu_model+0x4>
  40211e:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402123:	movl   $0x8,0x42a7(%rip)        # 4063d4 <__cpu_model+0x4>
  40212d:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402132:	movl   $0x4,0x4298(%rip)        # 4063d4 <__cpu_model+0x4>
  40213c:	cmp    $0x4,%eax
  40213f:	je     402406 <__cpu_indicator_init+0xf26>
  402145:	cmp    $0x8,%eax
  402148:	je     4023f7 <__cpu_indicator_init+0xf17>
  40214e:	cmp    $0x2,%eax
  402151:	jne    401d8f <__cpu_indicator_init+0x8af>
  402157:	movl   $0x4,0x4277(%rip)        # 4063d8 <__cpu_model+0x8>
  402161:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402166:	movl   $0xf,0x4264(%rip)        # 4063d4 <__cpu_model+0x4>
  402170:	cmp    $0xf,%eax
  402173:	jbe    402373 <__cpu_indicator_init+0xe93>
  402179:	lea    -0x10(%rax),%edx
  40217c:	cmp    $0xf,%edx
  40217f:	jbe    402196 <__cpu_indicator_init+0xcb6>
  402181:	sub    $0x60,%eax
  402184:	cmp    $0x4f,%eax
  402187:	jbe    402196 <__cpu_indicator_init+0xcb6>
  402189:	testb  $0x80,0x424d(%rip)        # 4063dd <__cpu_model+0xd>
  402190:	je     402361 <__cpu_indicator_init+0xe81>
  402196:	movl   $0x1c,0x4238(%rip)        # 4063d8 <__cpu_model+0x8>
  4021a0:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4021a5:	movl   $0xa,0x4225(%rip)        # 4063d4 <__cpu_model+0x4>
  4021af:	cmp    $0x1f,%eax
  4021b2:	ja     402391 <__cpu_indicator_init+0xeb1>
  4021b8:	movl   $0xb,0x4216(%rip)        # 4063d8 <__cpu_model+0x8>
  4021c2:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4021c7:	movl   $0x9,0x4203(%rip)        # 4063d4 <__cpu_model+0x4>
  4021d1:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4021d6:	movl   $0x5,0x41f4(%rip)        # 4063d4 <__cpu_model+0x4>
  4021e0:	cmp    $0x2,%eax
  4021e3:	je     402382 <__cpu_indicator_init+0xea2>
  4021e9:	cmp    $0xf,%eax
  4021ec:	ja     4023a5 <__cpu_indicator_init+0xec5>
  4021f2:	movl   $0x7,0x41dc(%rip)        # 4063d8 <__cpu_model+0x8>
  4021fc:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402201:	mov    0x1fc0(%rip),%rax        # 4041c8 <__dso_handle+0x1c0>
  402208:	mov    %rax,0x41c5(%rip)        # 4063d4 <__cpu_model+0x4>
  40220f:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402214:	movl   $0x6,0x41b6(%rip)        # 4063d4 <__cpu_model+0x4>
  40221e:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402223:	mov    0x1f6e(%rip),%rax        # 404198 <__dso_handle+0x190>
  40222a:	mov    %rax,0x41a3(%rip)        # 4063d4 <__cpu_model+0x4>
  402231:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402236:	movl   $0xe,0x4194(%rip)        # 4063d4 <__cpu_model+0x4>
  402240:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402245:	mov    0x1f9c(%rip),%rax        # 4041e8 <__dso_handle+0x1e0>
  40224c:	mov    %rax,0x4181(%rip)        # 4063d4 <__cpu_model+0x4>
  402253:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402258:	mov    0x1f99(%rip),%rax        # 4041f8 <__dso_handle+0x1f0>
  40225f:	mov    %rax,0x416e(%rip)        # 4063d4 <__cpu_model+0x4>
  402266:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  40226b:	mov    0x1f7e(%rip),%rax        # 4041f0 <__dso_handle+0x1e8>
  402272:	mov    %rax,0x415b(%rip)        # 4063d4 <__cpu_model+0x4>
  402279:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  40227e:	mov    0x1f5b(%rip),%rax        # 4041e0 <__dso_handle+0x1d8>
  402285:	mov    %rax,0x4148(%rip)        # 4063d4 <__cpu_model+0x4>
  40228c:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402291:	movl   $0xc,0x4139(%rip)        # 4063d4 <__cpu_model+0x4>
  40229b:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022a0:	movl   $0xd,0x412a(%rip)        # 4063d4 <__cpu_model+0x4>
  4022aa:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022af:	mov    0x1f22(%rip),%rax        # 4041d8 <__dso_handle+0x1d0>
  4022b6:	mov    %rax,0x4117(%rip)        # 4063d4 <__cpu_model+0x4>
  4022bd:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022c2:	mov    0x1f07(%rip),%rax        # 4041d0 <__dso_handle+0x1c8>
  4022c9:	mov    %rax,0x4104(%rip)        # 4063d4 <__cpu_model+0x4>
  4022d0:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022d5:	mov    0x1f24(%rip),%rax        # 404200 <__dso_handle+0x1f8>
  4022dc:	mov    %rax,0x40f1(%rip)        # 4063d4 <__cpu_model+0x4>
  4022e3:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022e8:	movl   $0xb,0x40e2(%rip)        # 4063d4 <__cpu_model+0x4>
  4022f2:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4022f7:	movl   $0x7,0x40d3(%rip)        # 4063d4 <__cpu_model+0x4>
  402301:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402306:	movl   $0x3,0x40c4(%rip)        # 4063d4 <__cpu_model+0x4>
  402310:	mov    $0x24,%edi
  402315:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  40231a:	test   %eax,%eax
  40231c:	je     40243e <__cpu_indicator_init+0xf5e>
  402322:	movl   $0x17,0x40ac(%rip)        # 4063d8 <__cpu_model+0x8>
  40232c:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  402331:	movl   $0x6,0x4095(%rip)        # 4063d0 <__cpu_model>
  40233b:	xor    %r13d,%r13d
  40233e:	jmp    401b24 <__cpu_indicator_init+0x644>
  402343:	mov    $0x5c,%edi
  402348:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40234d:	jmp    401e1d <__cpu_indicator_init+0x93d>
  402352:	mov    $0x5d,%edi
  402357:	call   403130 <set_cpu_feature.part.0.constprop.0>
  40235c:	jmp    401c3c <__cpu_indicator_init+0x75c>
  402361:	mov    $0x4e,%edi
  402366:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  40236b:	test   %eax,%eax
  40236d:	je     401d8f <__cpu_indicator_init+0x8af>
  402373:	movl   $0x1a,0x405b(%rip)        # 4063d8 <__cpu_model+0x8>
  40237d:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402382:	movl   $0x8,0x404c(%rip)        # 4063d8 <__cpu_model+0x8>
  40238c:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402391:	cmp    $0x2f,%eax
  402394:	jbe    402415 <__cpu_indicator_init+0xf35>
  402396:	movl   $0x14,0x4038(%rip)        # 4063d8 <__cpu_model+0x8>
  4023a0:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4023a5:	cmp    $0x2f,%eax
  4023a8:	jbe    402382 <__cpu_indicator_init+0xea2>
  4023aa:	cmp    $0x4f,%eax
  4023ad:	ja     40245b <__cpu_indicator_init+0xf7b>
  4023b3:	movl   $0x9,0x401b(%rip)        # 4063d8 <__cpu_model+0x8>
  4023bd:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4023c2:	mov    0x1de7(%rip),%rax        # 4041b0 <__dso_handle+0x1a8>
  4023c9:	mov    %rax,0x4004(%rip)        # 4063d4 <__cpu_model+0x4>
  4023d0:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4023d5:	movl   $0x2,0x3ff5(%rip)        # 4063d4 <__cpu_model+0x4>
  4023df:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4023e4:	mov    0x1dcd(%rip),%rax        # 4041b8 <__dso_handle+0x1b0>
  4023eb:	mov    %rax,0x3fe2(%rip)        # 4063d4 <__cpu_model+0x4>
  4023f2:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  4023f7:	movl   $0x6,0x3fd7(%rip)        # 4063d8 <__cpu_model+0x8>
  402401:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402406:	movl   $0x5,0x3fc8(%rip)        # 4063d8 <__cpu_model+0x8>
  402410:	jmp    401d8f <__cpu_indicator_init+0x8af>
  402415:	mov    $0x2c,%edi
  40241a:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  40241f:	test   %eax,%eax
  402421:	jne    402396 <__cpu_indicator_init+0xeb6>
  402427:	mov    $0x2d,%edi
  40242c:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  402431:	test   %eax,%eax
  402433:	jne    4021b8 <__cpu_indicator_init+0xcd8>
  402439:	jmp    401d8f <__cpu_indicator_init+0x8af>
  40243e:	mov    $0x22,%edi
  402443:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  402448:	test   %eax,%eax
  40244a:	je     40247d <__cpu_indicator_init+0xf9d>
  40244c:	movl   $0x15,0x3f82(%rip)        # 4063d8 <__cpu_model+0x8>
  402456:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  40245b:	cmp    $0x7f,%eax
  40245e:	jbe    40246e <__cpu_indicator_init+0xf8e>
  402460:	mov    0x3f76(%rip),%esi        # 4063dc <__cpu_model+0xc>
  402466:	test   $0x400,%esi
  40246c:	je     40248c <__cpu_indicator_init+0xfac>
  40246e:	movl   $0xa,0x3f60(%rip)        # 4063d8 <__cpu_model+0x8>
  402478:	jmp    401d8f <__cpu_indicator_init+0x8af>
  40247d:	movl   $0x10,0x3f51(%rip)        # 4063d8 <__cpu_model+0x8>
  402487:	jmp    401ca4 <__cpu_indicator_init+0x7c4>
  40248c:	mov    $0x53,%edi
  402491:	call   4014c0 <has_cpu_feature.part.0.constprop.0>
  402496:	test   %eax,%eax
  402498:	jne    4023b3 <__cpu_indicator_init+0xed3>
  40249e:	test   $0x10000,%esi
  4024a4:	jne    402382 <__cpu_indicator_init+0xea2>
  4024aa:	and    $0x2000,%esi
  4024b0:	jne    4021f2 <__cpu_indicator_init+0xd12>
  4024b6:	jmp    401d8f <__cpu_indicator_init+0x8af>
  4024bb:	nopl   0x0(%rax,%rax,1)

00000000004024c0 <_start>:
  4024c0:	endbr64
  4024c4:	xor    %ebp,%ebp
  4024c6:	mov    %rdx,%r9
  4024c9:	pop    %rsi
  4024ca:	mov    %rsp,%rdx
  4024cd:	and    $0xfffffffffffffff0,%rsp
  4024d1:	push   %rax
  4024d2:	push   %rsp
  4024d3:	xor    %r8d,%r8d
  4024d6:	xor    %ecx,%ecx
  4024d8:	mov    $0x4010f0,%rdi
  4024df:	call   *0x3ae3(%rip)        # 405fc8 <__libc_start_main@GLIBC_2.34>
  4024e5:	hlt
  4024e6:	cs nopw 0x0(%rax,%rax,1)

00000000004024f0 <_dl_relocate_static_pie>:
  4024f0:	endbr64
  4024f4:	ret
  4024f5:	cs nopw 0x0(%rax,%rax,1)
  4024ff:	nop

0000000000402500 <deregister_tm_clones>:
  402500:	lea    0x3b61(%rip),%rdi        # 406068 <__TMC_END__>
  402507:	lea    0x3b5a(%rip),%rax        # 406068 <__TMC_END__>
  40250e:	cmp    %rdi,%rax
  402511:	je     402528 <deregister_tm_clones+0x28>
  402513:	mov    0x3ab6(%rip),%rax        # 405fd0 <_ITM_deregisterTMCloneTable@Base>
  40251a:	test   %rax,%rax
  40251d:	je     402528 <deregister_tm_clones+0x28>
  40251f:	jmp    *%rax
  402521:	nopl   0x0(%rax)
  402528:	ret
  402529:	nopl   0x0(%rax)

0000000000402530 <register_tm_clones>:
  402530:	lea    0x3b31(%rip),%rdi        # 406068 <__TMC_END__>
  402537:	lea    0x3b2a(%rip),%rsi        # 406068 <__TMC_END__>
  40253e:	sub    %rdi,%rsi
  402541:	mov    %rsi,%rax
  402544:	shr    $0x3f,%rsi
  402548:	sar    $0x3,%rax
  40254c:	add    %rax,%rsi
  40254f:	sar    $1,%rsi
  402552:	je     402568 <register_tm_clones+0x38>
  402554:	mov    0x3a85(%rip),%rax        # 405fe0 <_ITM_registerTMCloneTable@Base>
  40255b:	test   %rax,%rax
  40255e:	je     402568 <register_tm_clones+0x38>
  402560:	jmp    *%rax
  402562:	nopw   0x0(%rax,%rax,1)
  402568:	ret
  402569:	nopl   0x0(%rax)

0000000000402570 <__do_global_dtors_aux>:
  402570:	endbr64
  402574:	cmpb   $0x0,0x3b0d(%rip)        # 406088 <completed.0>
  40257b:	jne    402590 <__do_global_dtors_aux+0x20>
  40257d:	push   %rbp
  40257e:	mov    %rsp,%rbp
  402581:	call   402500 <deregister_tm_clones>
  402586:	movb   $0x1,0x3afb(%rip)        # 406088 <completed.0>
  40258d:	pop    %rbp
  40258e:	ret
  40258f:	nop
  402590:	ret
  402591:	data16 cs nopw 0x0(%rax,%rax,1)
  40259c:	nopl   0x0(%rax)

00000000004025a0 <frame_dummy>:
  4025a0:	endbr64
  4025a4:	jmp    402530 <register_tm_clones>
  4025a6:	cs nopw 0x0(%rax,%rax,1)

00000000004025b0 <kernel_scalar>:
  4025b0:	vmovsd 0x1c68(%rip),%xmm1        # 404220 <__dso_handle+0x218>
  4025b8:	vmovsd 0x1c80(%rip),%xmm0        # 404240 <__dso_handle+0x238>
  4025c0:	xor    %edx,%edx
  4025c2:	vxorpd %xmm4,%xmm4,%xmm4
  4025c6:	cs nopw 0x0(%rax,%rax,1)
  4025d0:	vmovsd 0x4060c0(,%rdx,8),%xmm2
  4025d9:	lea    0x1(%rdx),%rax
  4025dd:	vmovsd 0x4060c0(,%rax,8),%xmm14
  4025e6:	lea    0x2(%rdx),%rax
  4025ea:	vmovsd 0x4060c0(,%rax,8),%xmm13
  4025f3:	lea    0x3(%rdx),%rax
  4025f7:	vmovsd 0x4060c0(,%rax,8),%xmm12
  402600:	lea    0x4(%rdx),%rax
  402604:	vmovsd 0x4060c0(,%rax,8),%xmm11
  40260d:	lea    0x5(%rdx),%rax
  402611:	vmovsd 0x4060c0(,%rax,8),%xmm10
  40261a:	lea    0x6(%rdx),%rax
  40261e:	vmovsd 0x4060c0(,%rax,8),%xmm9
  402627:	lea    0x7(%rdx),%rax
  40262b:	vmovsd 0x4060c0(,%rax,8),%xmm8
  402634:	lea    0x8(%rdx),%rax
  402638:	vmovsd 0x4060c0(,%rax,8),%xmm7
  402641:	lea    0x9(%rdx),%rax
  402645:	vmovsd 0x4060c0(,%rax,8),%xmm6
  40264e:	lea    0xa(%rdx),%rax
  402652:	vmovsd 0x4060c0(,%rax,8),%xmm5
  40265b:	lea    0xb(%rdx),%rax
  40265f:	vmovsd 0x4060c0(,%rax,8),%xmm3
  402668:	test   %rdi,%rdi
  40266b:	je     4026b5 <kernel_scalar+0x105>
  40266d:	xor    %eax,%eax
  40266f:	nop
  402670:	vfmadd231sd %xmm0,%xmm1,%xmm2
  402675:	vfmadd231sd %xmm0,%xmm1,%xmm14
  40267a:	add    $0x1,%rax
  40267e:	vfmadd231sd %xmm0,%xmm1,%xmm13
  402683:	vfmadd231sd %xmm0,%xmm1,%xmm12
  402688:	vfmadd231sd %xmm0,%xmm1,%xmm11
  40268d:	vfmadd231sd %xmm0,%xmm1,%xmm10
  402692:	vfmadd231sd %xmm0,%xmm1,%xmm9
  402697:	vfmadd231sd %xmm0,%xmm1,%xmm8
  40269c:	vfmadd231sd %xmm0,%xmm1,%xmm7
  4026a1:	vfmadd231sd %xmm0,%xmm1,%xmm6
  4026a6:	vfmadd231sd %xmm0,%xmm1,%xmm5
  4026ab:	vfmadd231sd %xmm0,%xmm1,%xmm3
  4026b0:	cmp    %rax,%rdi
  4026b3:	jne    402670 <kernel_scalar+0xc0>
  4026b5:	vaddsd %xmm14,%xmm2,%xmm2
  4026ba:	add    $0xc,%rdx
  4026be:	vaddsd %xmm13,%xmm2,%xmm2
  4026c3:	vaddsd %xmm12,%xmm2,%xmm2
  4026c8:	vaddsd %xmm11,%xmm2,%xmm2
  4026cd:	vaddsd %xmm10,%xmm2,%xmm2
  4026d2:	vaddsd %xmm9,%xmm2,%xmm2
  4026d7:	vaddsd %xmm8,%xmm2,%xmm2
  4026dc:	vaddsd %xmm7,%xmm2,%xmm2
  4026e0:	vaddsd %xmm6,%xmm2,%xmm2
  4026e4:	vaddsd %xmm5,%xmm2,%xmm2
  4026e8:	vaddsd %xmm3,%xmm2,%xmm2
  4026ec:	vaddsd %xmm2,%xmm4,%xmm4
  4026f0:	cmp    $0x60,%rdx
  4026f4:	jne    4025d0 <kernel_scalar+0x20>
  4026fa:	vdivsd 0x1a66(%rip),%xmm4,%xmm0        # 404168 <__dso_handle+0x160>
  402702:	ret
  402703:	data16 cs nopw 0x0(%rax,%rax,1)
  40270e:	xchg   %ax,%ax

0000000000402710 <kernel_v128>:
  402710:	mov    $0x4060c0,%edx
  402715:	mov    $0x4063c0,%ecx
  40271a:	vxorpd %xmm0,%xmm0,%xmm0
  40271e:	vmovapd 0x1afa(%rip),%xmm2        # 404220 <__dso_handle+0x218>
  402726:	vmovapd 0x1b12(%rip),%xmm1        # 404240 <__dso_handle+0x238>
  40272e:	vmovapd (%rdx),%xmm14
  402732:	vmovapd 0x10(%rdx),%xmm13
  402737:	vmovapd 0x20(%rdx),%xmm12
  40273c:	vmovapd 0x30(%rdx),%xmm11
  402741:	vmovapd 0x40(%rdx),%xmm10
  402746:	vmovapd 0x50(%rdx),%xmm9
  40274b:	vmovapd 0x60(%rdx),%xmm7
  402750:	vmovapd 0x70(%rdx),%xmm6
  402755:	vmovapd 0x80(%rdx),%xmm5
  40275d:	vmovapd 0x90(%rdx),%xmm4
  402765:	vmovapd 0xa0(%rdx),%xmm3
  40276d:	vmovapd 0xb0(%rdx),%xmm8
  402775:	test   %rdi,%rdi
  402778:	je     4027c5 <kernel_v128+0xb5>
  40277a:	xor    %eax,%eax
  40277c:	nopl   0x0(%rax)
  402780:	vfmadd231pd %xmm1,%xmm2,%xmm14
  402785:	vfmadd231pd %xmm1,%xmm2,%xmm13
  40278a:	add    $0x1,%rax
  40278e:	vfmadd231pd %xmm1,%xmm2,%xmm12
  402793:	vfmadd231pd %xmm1,%xmm2,%xmm11
  402798:	vfmadd231pd %xmm1,%xmm2,%xmm10
  40279d:	vfmadd231pd %xmm1,%xmm2,%xmm9
  4027a2:	vfmadd231pd %xmm1,%xmm2,%xmm7
  4027a7:	vfmadd231pd %xmm1,%xmm2,%xmm6
  4027ac:	vfmadd231pd %xmm1,%xmm2,%xmm5
  4027b1:	vfmadd231pd %xmm1,%xmm2,%xmm4
  4027b6:	vfmadd231pd %xmm1,%xmm2,%xmm3
  4027bb:	vfmadd231pd %xmm1,%xmm2,%xmm8
  4027c0:	cmp    %rax,%rdi
  4027c3:	jne    402780 <kernel_v128+0x70>
  4027c5:	vhaddpd %xmm14,%xmm14,%xmm14
  4027ca:	vhaddpd %xmm13,%xmm13,%xmm13
  4027cf:	add    $0xc0,%rdx
  4027d6:	vhaddpd %xmm12,%xmm12,%xmm12
  4027db:	vhaddpd %xmm11,%xmm11,%xmm11
  4027e0:	vhaddpd %xmm10,%xmm10,%xmm10
  4027e5:	vhaddpd %xmm9,%xmm9,%xmm9
  4027ea:	vhaddpd %xmm7,%xmm7,%xmm7
  4027ee:	vhaddpd %xmm6,%xmm6,%xmm6
  4027f2:	vaddsd %xmm0,%xmm14,%xmm14
  4027f6:	vhaddpd %xmm5,%xmm5,%xmm5
  4027fa:	vhaddpd %xmm4,%xmm4,%xmm4
  4027fe:	vhaddpd %xmm3,%xmm3,%xmm3
  402802:	vhaddpd %xmm8,%xmm8,%xmm8
  402807:	vaddsd %xmm14,%xmm13,%xmm13
  40280c:	vaddsd %xmm13,%xmm12,%xmm12
  402811:	vaddsd %xmm12,%xmm11,%xmm11
  402816:	vaddsd %xmm11,%xmm10,%xmm10
  40281b:	vaddsd %xmm10,%xmm9,%xmm9
  402820:	vaddsd %xmm9,%xmm7,%xmm7
  402825:	vaddsd %xmm7,%xmm6,%xmm6
  402829:	vaddsd %xmm6,%xmm5,%xmm5
  40282d:	vaddsd %xmm5,%xmm4,%xmm4
  402831:	vaddsd %xmm4,%xmm3,%xmm3
  402835:	vaddsd %xmm3,%xmm8,%xmm0
  402839:	cmp    %rdx,%rcx
  40283c:	jne    40272e <kernel_v128+0x1e>
  402842:	vdivsd 0x191e(%rip),%xmm0,%xmm0        # 404168 <__dso_handle+0x160>
  40284a:	ret
  40284b:	nopl   0x0(%rax,%rax,1)

0000000000402850 <kernel_v256>:
  402850:	push   %rbp
  402851:	vxorpd %xmm3,%xmm3,%xmm3
  402855:	mov    $0x4060c0,%edx
  40285a:	mov    $0x4063c0,%ecx
  40285f:	mov    %rsp,%rbp
  402862:	and    $0xffffffffffffffe0,%rsp
  402866:	vmovsd %xmm3,-0x8(%rsp)
  40286c:	vmovapd 0x19ac(%rip),%ymm1        # 404220 <__dso_handle+0x218>
  402874:	vmovapd 0x19c4(%rip),%ymm0        # 404240 <__dso_handle+0x238>
  40287c:	vmovapd (%rdx),%ymm13
  402880:	vmovapd 0x20(%rdx),%ymm12
  402885:	vmovapd 0x40(%rdx),%ymm11
  40288a:	vmovapd 0x60(%rdx),%ymm10
  40288f:	vmovapd 0x80(%rdx),%ymm9
  402897:	vmovapd 0xa0(%rdx),%ymm8
  40289f:	vmovapd 0xc0(%rdx),%ymm7
  4028a7:	vmovapd 0xe0(%rdx),%ymm6
  4028af:	vmovapd 0x100(%rdx),%ymm5
  4028b7:	vmovapd 0x120(%rdx),%ymm4
  4028bf:	vmovapd 0x140(%rdx),%ymm3
  4028c7:	vmovapd 0x160(%rdx),%ymm2
  4028cf:	test   %rdi,%rdi
  4028d2:	je     402925 <kernel_v256+0xd5>
  4028d4:	xor    %eax,%eax
  4028d6:	cs nopw 0x0(%rax,%rax,1)
  4028e0:	vfmadd231pd %ymm0,%ymm1,%ymm13
  4028e5:	vfmadd231pd %ymm0,%ymm1,%ymm12
  4028ea:	add    $0x1,%rax
  4028ee:	vfmadd231pd %ymm0,%ymm1,%ymm11
  4028f3:	vfmadd231pd %ymm0,%ymm1,%ymm10
  4028f8:	vfmadd231pd %ymm0,%ymm1,%ymm9
  4028fd:	vfmadd231pd %ymm0,%ymm1,%ymm8
  402902:	vfmadd231pd %ymm0,%ymm1,%ymm7
  402907:	vfmadd231pd %ymm0,%ymm1,%ymm6
  40290c:	vfmadd231pd %ymm0,%ymm1,%ymm5
  402911:	vfmadd231pd %ymm0,%ymm1,%ymm4
  402916:	vfmadd231pd %ymm0,%ymm1,%ymm3
  40291b:	vfmadd231pd %ymm0,%ymm1,%ymm2
  402920:	cmp    %rax,%rdi
  402923:	jne    4028e0 <kernel_v256+0x90>
  402925:	vhaddpd %xmm13,%xmm13,%xmm15
  40292a:	vextractf128 $0x1,%ymm13,%xmm13
  402930:	add    $0x180,%rdx
  402937:	vaddsd %xmm13,%xmm15,%xmm14
  40293c:	vunpckhpd %xmm13,%xmm13,%xmm13
  402941:	vaddsd %xmm13,%xmm14,%xmm14
  402946:	vhaddpd %xmm12,%xmm12,%xmm13
  40294b:	vextractf128 $0x1,%ymm12,%xmm12
  402951:	vaddsd -0x8(%rsp),%xmm14,%xmm14
  402957:	vaddsd %xmm12,%xmm13,%xmm13
  40295c:	vunpckhpd %xmm12,%xmm12,%xmm12
  402961:	vaddsd %xmm12,%xmm13,%xmm13
  402966:	vhaddpd %xmm11,%xmm11,%xmm12
  40296b:	vextractf128 $0x1,%ymm11,%xmm11
  402971:	vaddsd %xmm11,%xmm12,%xmm12
  402976:	vunpckhpd %xmm11,%xmm11,%xmm11
  40297b:	vaddsd %xmm14,%xmm13,%xmm13
  402980:	vaddsd %xmm11,%xmm12,%xmm12
  402985:	vhaddpd %xmm10,%xmm10,%xmm11
  40298a:	vextractf128 $0x1,%ymm10,%xmm10
  402990:	vaddsd %xmm10,%xmm11,%xmm11
  402995:	vunpckhpd %xmm10,%xmm10,%xmm10
  40299a:	vaddsd %xmm13,%xmm12,%xmm12
  40299f:	vaddsd %xmm10,%xmm11,%xmm11
  4029a4:	vhaddpd %xmm9,%xmm9,%xmm10
  4029a9:	vextractf128 $0x1,%ymm9,%xmm9
  4029af:	vaddsd %xmm9,%xmm10,%xmm10
  4029b4:	vunpckhpd %xmm9,%xmm9,%xmm9
  4029b9:	vaddsd %xmm12,%xmm11,%xmm11
  4029be:	vaddsd %xmm9,%xmm10,%xmm10
  4029c3:	vhaddpd %xmm8,%xmm8,%xmm9
  4029c8:	vextractf128 $0x1,%ymm8,%xmm8
  4029ce:	vaddsd %xmm8,%xmm9,%xmm9
  4029d3:	vunpckhpd %xmm8,%xmm8,%xmm8
  4029d8:	vaddsd %xmm11,%xmm10,%xmm10
  4029dd:	vaddsd %xmm8,%xmm9,%xmm9
  4029e2:	vhaddpd %xmm7,%xmm7,%xmm8
  4029e6:	vextractf128 $0x1,%ymm7,%xmm7
  4029ec:	vaddsd %xmm7,%xmm8,%xmm8
  4029f0:	vunpckhpd %xmm7,%xmm7,%xmm7
  4029f4:	vaddsd %xmm10,%xmm9,%xmm9
  4029f9:	vaddsd %xmm7,%xmm8,%xmm8
  4029fd:	vhaddpd %xmm6,%xmm6,%xmm7
  402a01:	vextractf128 $0x1,%ymm6,%xmm6
  402a07:	vaddsd %xmm6,%xmm7,%xmm7
  402a0b:	vunpckhpd %xmm6,%xmm6,%xmm6
  402a0f:	vaddsd %xmm9,%xmm8,%xmm8
  402a14:	vaddsd %xmm6,%xmm7,%xmm7
  402a18:	vhaddpd %xmm5,%xmm5,%xmm6
  402a1c:	vextractf128 $0x1,%ymm5,%xmm5
  402a22:	vaddsd %xmm5,%xmm6,%xmm6
  402a26:	vunpckhpd %xmm5,%xmm5,%xmm5
  402a2a:	vaddsd %xmm8,%xmm7,%xmm7
  402a2f:	vaddsd %xmm5,%xmm6,%xmm6
  402a33:	vhaddpd %xmm4,%xmm4,%xmm5
  402a37:	vextractf128 $0x1,%ymm4,%xmm4
  402a3d:	vaddsd %xmm4,%xmm5,%xmm5
  402a41:	vunpckhpd %xmm4,%xmm4,%xmm4
  402a45:	vaddsd %xmm7,%xmm6,%xmm6
  402a49:	vaddsd %xmm4,%xmm5,%xmm5
  402a4d:	vhaddpd %xmm3,%xmm3,%xmm4
  402a51:	vextractf128 $0x1,%ymm3,%xmm3
  402a57:	vaddsd %xmm3,%xmm4,%xmm4
  402a5b:	vunpckhpd %xmm3,%xmm3,%xmm3
  402a5f:	vaddsd %xmm6,%xmm5,%xmm5
  402a63:	vaddsd %xmm3,%xmm4,%xmm3
  402a67:	vhaddpd %xmm2,%xmm2,%xmm4
  402a6b:	vextractf128 $0x1,%ymm2,%xmm2
  402a71:	vaddsd %xmm2,%xmm4,%xmm4
  402a75:	vunpckhpd %xmm2,%xmm2,%xmm2
  402a79:	vaddsd %xmm5,%xmm3,%xmm3
  402a7d:	vaddsd %xmm2,%xmm4,%xmm4
  402a81:	vaddsd %xmm3,%xmm4,%xmm2
  402a85:	vmovsd %xmm2,-0x8(%rsp)
  402a8b:	cmp    %rdx,%rcx
  402a8e:	jne    40287c <kernel_v256+0x2c>
  402a94:	vdivsd 0x16cc(%rip),%xmm2,%xmm0        # 404168 <__dso_handle+0x160>
  402a9c:	vzeroupper
  402a9f:	leave
  402aa0:	ret
  402aa1:	data16 cs nopw 0x0(%rax,%rax,1)
  402aac:	nopl   0x0(%rax)

0000000000402ab0 <kernel_v512>:
  402ab0:	vmovupd 0x3606(%rip),%zmm13        # 4060c0 <initial_values>
  402aba:	vmovupd 0x363c(%rip),%zmm12        # 406100 <initial_values+0x40>
  402ac4:	vmovupd 0x3672(%rip),%zmm11        # 406140 <initial_values+0x80>
  402ace:	vmovupd 0x36a8(%rip),%zmm10        # 406180 <initial_values+0xc0>
  402ad8:	vmovupd 0x36de(%rip),%zmm9        # 4061c0 <initial_values+0x100>
  402ae2:	vmovupd 0x3714(%rip),%zmm8        # 406200 <initial_values+0x140>
  402aec:	vmovupd 0x374a(%rip),%zmm7        # 406240 <initial_values+0x180>
  402af6:	vmovupd 0x3780(%rip),%zmm6        # 406280 <initial_values+0x1c0>
  402b00:	vmovupd 0x37b6(%rip),%zmm5        # 4062c0 <initial_values+0x200>
  402b0a:	vmovupd 0x37ec(%rip),%zmm4        # 406300 <initial_values+0x240>
  402b14:	vmovupd 0x3822(%rip),%zmm3        # 406340 <initial_values+0x280>
  402b1e:	vmovupd 0x3858(%rip),%zmm2        # 406380 <initial_values+0x2c0>
  402b28:	test   %rdi,%rdi
  402b2b:	je     402b99 <kernel_v512+0xe9>
  402b2d:	vbroadcastsd 0x16e9(%rip),%zmm1        # 404220 <__dso_handle+0x218>
  402b37:	xor    %eax,%eax
  402b39:	vbroadcastsd 0x16fd(%rip),%zmm0        # 404240 <__dso_handle+0x238>
  402b43:	nopl   0x0(%rax,%rax,1)
  402b48:	vfmadd231pd %zmm0,%zmm1,%zmm13
  402b4e:	vfmadd231pd %zmm0,%zmm1,%zmm12
  402b54:	add    $0x1,%rax
  402b58:	vfmadd231pd %zmm0,%zmm1,%zmm11
  402b5e:	vfmadd231pd %zmm0,%zmm1,%zmm10
  402b64:	vfmadd231pd %zmm0,%zmm1,%zmm9
  402b6a:	vfmadd231pd %zmm0,%zmm1,%zmm8
  402b70:	vfmadd231pd %zmm0,%zmm1,%zmm7
  402b76:	vfmadd231pd %zmm0,%zmm1,%zmm6
  402b7c:	vfmadd231pd %zmm0,%zmm1,%zmm5
  402b82:	vfmadd231pd %zmm0,%zmm1,%zmm4
  402b88:	vfmadd231pd %zmm0,%zmm1,%zmm3
  402b8e:	vfmadd231pd %zmm0,%zmm1,%zmm2
  402b94:	cmp    %rax,%rdi
  402b97:	jne    402b48 <kernel_v512+0x98>
  402b99:	vxorpd %xmm14,%xmm14,%xmm14
  402b9e:	vunpckhpd %xmm13,%xmm13,%xmm1
  402ba3:	vextractf128 $0x1,%ymm13,%xmm0
  402ba9:	vaddsd %xmm13,%xmm14,%xmm14
  402bae:	vextractf64x4 $0x1,%zmm13,%ymm13
  402bb5:	vaddsd %xmm14,%xmm1,%xmm1
  402bba:	vaddsd %xmm1,%xmm0,%xmm1
  402bbe:	vunpckhpd %xmm0,%xmm0,%xmm0
  402bc2:	vaddsd %xmm1,%xmm0,%xmm0
  402bc6:	vunpckhpd %xmm13,%xmm13,%xmm1
  402bcb:	vaddsd %xmm0,%xmm13,%xmm0
  402bcf:	vextractf128 $0x1,%ymm13,%xmm13
  402bd5:	vaddsd %xmm0,%xmm1,%xmm1
  402bd9:	vaddsd %xmm1,%xmm13,%xmm0
  402bdd:	vunpckhpd %xmm13,%xmm13,%xmm13
  402be2:	vunpckhpd %xmm12,%xmm12,%xmm1
  402be7:	vaddsd %xmm0,%xmm13,%xmm13
  402beb:	vextractf128 $0x1,%ymm12,%xmm0
  402bf1:	vaddsd %xmm13,%xmm12,%xmm13
  402bf6:	vextractf64x4 $0x1,%zmm12,%ymm12
  402bfd:	vaddsd %xmm13,%xmm1,%xmm1
  402c02:	vaddsd %xmm1,%xmm0,%xmm1
  402c06:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c0a:	vaddsd %xmm1,%xmm0,%xmm0
  402c0e:	vunpckhpd %xmm12,%xmm12,%xmm1
  402c13:	vaddsd %xmm0,%xmm12,%xmm0
  402c17:	vextractf128 $0x1,%ymm12,%xmm12
  402c1d:	vaddsd %xmm0,%xmm1,%xmm1
  402c21:	vaddsd %xmm1,%xmm12,%xmm0
  402c25:	vunpckhpd %xmm12,%xmm12,%xmm12
  402c2a:	vunpckhpd %xmm11,%xmm11,%xmm1
  402c2f:	vaddsd %xmm0,%xmm12,%xmm12
  402c33:	vextractf128 $0x1,%ymm11,%xmm0
  402c39:	vaddsd %xmm12,%xmm11,%xmm12
  402c3e:	vextractf64x4 $0x1,%zmm11,%ymm11
  402c45:	vaddsd %xmm12,%xmm1,%xmm1
  402c4a:	vaddsd %xmm1,%xmm0,%xmm1
  402c4e:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c52:	vaddsd %xmm1,%xmm0,%xmm0
  402c56:	vunpckhpd %xmm11,%xmm11,%xmm1
  402c5b:	vaddsd %xmm0,%xmm11,%xmm0
  402c5f:	vextractf128 $0x1,%ymm11,%xmm11
  402c65:	vaddsd %xmm0,%xmm1,%xmm1
  402c69:	vaddsd %xmm1,%xmm11,%xmm0
  402c6d:	vunpckhpd %xmm11,%xmm11,%xmm11
  402c72:	vunpckhpd %xmm10,%xmm10,%xmm1
  402c77:	vaddsd %xmm0,%xmm11,%xmm11
  402c7b:	vextractf128 $0x1,%ymm10,%xmm0
  402c81:	vaddsd %xmm11,%xmm10,%xmm11
  402c86:	vextractf64x4 $0x1,%zmm10,%ymm10
  402c8d:	vaddsd %xmm11,%xmm1,%xmm1
  402c92:	vaddsd %xmm1,%xmm0,%xmm1
  402c96:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c9a:	vaddsd %xmm1,%xmm0,%xmm0
  402c9e:	vunpckhpd %xmm10,%xmm10,%xmm1
  402ca3:	vaddsd %xmm0,%xmm10,%xmm0
  402ca7:	vextractf128 $0x1,%ymm10,%xmm10
  402cad:	vaddsd %xmm0,%xmm1,%xmm1
  402cb1:	vaddsd %xmm1,%xmm10,%xmm0
  402cb5:	vunpckhpd %xmm10,%xmm10,%xmm10
  402cba:	vunpckhpd %xmm9,%xmm9,%xmm1
  402cbf:	vaddsd %xmm0,%xmm10,%xmm10
  402cc3:	vextractf128 $0x1,%ymm9,%xmm0
  402cc9:	vaddsd %xmm10,%xmm9,%xmm10
  402cce:	vextractf64x4 $0x1,%zmm9,%ymm9
  402cd5:	vaddsd %xmm10,%xmm1,%xmm1
  402cda:	vaddsd %xmm1,%xmm0,%xmm1
  402cde:	vunpckhpd %xmm0,%xmm0,%xmm0
  402ce2:	vaddsd %xmm1,%xmm0,%xmm0
  402ce6:	vunpckhpd %xmm9,%xmm9,%xmm1
  402ceb:	vaddsd %xmm0,%xmm9,%xmm0
  402cef:	vextractf128 $0x1,%ymm9,%xmm9
  402cf5:	vaddsd %xmm0,%xmm1,%xmm1
  402cf9:	vaddsd %xmm1,%xmm9,%xmm0
  402cfd:	vunpckhpd %xmm9,%xmm9,%xmm9
  402d02:	vunpckhpd %xmm8,%xmm8,%xmm1
  402d07:	vaddsd %xmm0,%xmm9,%xmm9
  402d0b:	vextractf128 $0x1,%ymm8,%xmm0
  402d11:	vaddsd %xmm9,%xmm8,%xmm9
  402d16:	vextractf64x4 $0x1,%zmm8,%ymm8
  402d1d:	vaddsd %xmm9,%xmm1,%xmm1
  402d22:	vaddsd %xmm1,%xmm0,%xmm1
  402d26:	vunpckhpd %xmm0,%xmm0,%xmm0
  402d2a:	vaddsd %xmm1,%xmm0,%xmm0
  402d2e:	vunpckhpd %xmm8,%xmm8,%xmm1
  402d33:	vaddsd %xmm0,%xmm8,%xmm0
  402d37:	vextractf128 $0x1,%ymm8,%xmm8
  402d3d:	vaddsd %xmm0,%xmm1,%xmm1
  402d41:	vaddsd %xmm1,%xmm8,%xmm0
  402d45:	vunpckhpd %xmm8,%xmm8,%xmm8
  402d4a:	vunpckhpd %xmm7,%xmm7,%xmm1
  402d4e:	vaddsd %xmm0,%xmm8,%xmm8
  402d52:	vextractf128 $0x1,%ymm7,%xmm0
  402d58:	vaddsd %xmm8,%xmm7,%xmm8
  402d5d:	vextractf64x4 $0x1,%zmm7,%ymm7
  402d64:	vaddsd %xmm8,%xmm1,%xmm1
  402d69:	vaddsd %xmm1,%xmm0,%xmm1
  402d6d:	vunpckhpd %xmm0,%xmm0,%xmm0
  402d71:	vaddsd %xmm1,%xmm0,%xmm0
  402d75:	vunpckhpd %xmm7,%xmm7,%xmm1
  402d79:	vaddsd %xmm0,%xmm7,%xmm0
  402d7d:	vextractf128 $0x1,%ymm7,%xmm7
  402d83:	vaddsd %xmm0,%xmm1,%xmm1
  402d87:	vaddsd %xmm1,%xmm7,%xmm0
  402d8b:	vunpckhpd %xmm7,%xmm7,%xmm7
  402d8f:	vunpckhpd %xmm6,%xmm6,%xmm1
  402d93:	vaddsd %xmm0,%xmm7,%xmm7
  402d97:	vextractf128 $0x1,%ymm6,%xmm0
  402d9d:	vaddsd %xmm7,%xmm6,%xmm7
  402da1:	vextractf64x4 $0x1,%zmm6,%ymm6
  402da8:	vaddsd %xmm7,%xmm1,%xmm1
  402dac:	vaddsd %xmm1,%xmm0,%xmm1
  402db0:	vunpckhpd %xmm0,%xmm0,%xmm0
  402db4:	vaddsd %xmm1,%xmm0,%xmm0
  402db8:	vunpckhpd %xmm6,%xmm6,%xmm1
  402dbc:	vaddsd %xmm0,%xmm6,%xmm0
  402dc0:	vextractf128 $0x1,%ymm6,%xmm6
  402dc6:	vaddsd %xmm0,%xmm1,%xmm1
  402dca:	vaddsd %xmm1,%xmm6,%xmm0
  402dce:	vunpckhpd %xmm6,%xmm6,%xmm6
  402dd2:	vunpckhpd %xmm5,%xmm5,%xmm1
  402dd6:	vaddsd %xmm0,%xmm6,%xmm6
  402dda:	vextractf128 $0x1,%ymm5,%xmm0
  402de0:	vaddsd %xmm6,%xmm5,%xmm6
  402de4:	vextractf64x4 $0x1,%zmm5,%ymm5
  402deb:	vaddsd %xmm6,%xmm1,%xmm1
  402def:	vaddsd %xmm1,%xmm0,%xmm1
  402df3:	vunpckhpd %xmm0,%xmm0,%xmm0
  402df7:	vaddsd %xmm1,%xmm0,%xmm0
  402dfb:	vunpckhpd %xmm5,%xmm5,%xmm1
  402dff:	vaddsd %xmm0,%xmm5,%xmm0
  402e03:	vextractf128 $0x1,%ymm5,%xmm5
  402e09:	vaddsd %xmm0,%xmm1,%xmm1
  402e0d:	vaddsd %xmm1,%xmm5,%xmm0
  402e11:	vunpckhpd %xmm5,%xmm5,%xmm5
  402e15:	vunpckhpd %xmm4,%xmm4,%xmm1
  402e19:	vaddsd %xmm0,%xmm5,%xmm5
  402e1d:	vextractf128 $0x1,%ymm4,%xmm0
  402e23:	vaddsd %xmm5,%xmm4,%xmm5
  402e27:	vextractf64x4 $0x1,%zmm4,%ymm4
  402e2e:	vaddsd %xmm5,%xmm1,%xmm1
  402e32:	vaddsd %xmm1,%xmm0,%xmm1
  402e36:	vunpckhpd %xmm0,%xmm0,%xmm0
  402e3a:	vaddsd %xmm1,%xmm0,%xmm0
  402e3e:	vunpckhpd %xmm4,%xmm4,%xmm1
  402e42:	vaddsd %xmm0,%xmm4,%xmm0
  402e46:	vextractf128 $0x1,%ymm4,%xmm4
  402e4c:	vaddsd %xmm0,%xmm1,%xmm1
  402e50:	vaddsd %xmm1,%xmm4,%xmm0
  402e54:	vunpckhpd %xmm4,%xmm4,%xmm4
  402e58:	vunpckhpd %xmm3,%xmm3,%xmm1
  402e5c:	vaddsd %xmm0,%xmm4,%xmm4
  402e60:	vextractf128 $0x1,%ymm3,%xmm0
  402e66:	vaddsd %xmm4,%xmm3,%xmm4
  402e6a:	vextractf64x4 $0x1,%zmm3,%ymm3
  402e71:	vaddsd %xmm4,%xmm1,%xmm1
  402e75:	vaddsd %xmm1,%xmm0,%xmm1
  402e79:	vunpckhpd %xmm0,%xmm0,%xmm0
  402e7d:	vaddsd %xmm1,%xmm0,%xmm0
  402e81:	vunpckhpd %xmm3,%xmm3,%xmm1
  402e85:	vaddsd %xmm0,%xmm3,%xmm0
  402e89:	vextractf128 $0x1,%ymm3,%xmm3
  402e8f:	vaddsd %xmm0,%xmm1,%xmm1
  402e93:	vaddsd %xmm1,%xmm3,%xmm0
  402e97:	vunpckhpd %xmm3,%xmm3,%xmm3
  402e9b:	vunpckhpd %xmm2,%xmm2,%xmm1
  402e9f:	vaddsd %xmm0,%xmm3,%xmm3
  402ea3:	vextractf128 $0x1,%ymm2,%xmm0
  402ea9:	vaddsd %xmm3,%xmm2,%xmm3
  402ead:	vextractf64x4 $0x1,%zmm2,%ymm2
  402eb4:	vaddsd %xmm3,%xmm1,%xmm1
  402eb8:	vaddsd %xmm1,%xmm0,%xmm1
  402ebc:	vunpckhpd %xmm0,%xmm0,%xmm0
  402ec0:	vaddsd %xmm1,%xmm0,%xmm0
  402ec4:	vunpckhpd %xmm2,%xmm2,%xmm1
  402ec8:	vaddsd %xmm0,%xmm2,%xmm0
  402ecc:	vextractf128 $0x1,%ymm2,%xmm2
  402ed2:	vaddsd %xmm0,%xmm1,%xmm1
  402ed6:	vaddsd %xmm1,%xmm2,%xmm0
  402eda:	vunpckhpd %xmm2,%xmm2,%xmm2
  402ede:	vaddsd %xmm0,%xmm2,%xmm0
  402ee2:	vdivsd 0x127e(%rip),%xmm0,%xmm0        # 404168 <__dso_handle+0x160>
  402eea:	vzeroupper
  402eed:	ret
  402eee:	xchg   %ax,%ax

0000000000402ef0 <parse_u64>:
  402ef0:	push   %rbp
  402ef1:	mov    %rsp,%rbp
  402ef4:	push   %r13
  402ef6:	mov    %rsi,%r13
  402ef9:	push   %r12
  402efb:	mov    %rdi,%r12
  402efe:	push   %rbx
  402eff:	sub    $0x18,%rsp
  402f03:	movq   $0x0,-0x28(%rbp)
  402f0b:	call   401030 <__errno_location@plt>
  402f10:	mov    $0xa,%edx
  402f15:	lea    -0x28(%rbp),%rsi
  402f19:	mov    %r12,%rdi
  402f1c:	movl   $0x0,(%rax)
  402f22:	mov    %rax,%rbx
  402f25:	call   401080 <strtoull@plt>
  402f2a:	mov    (%rbx),%edx
  402f2c:	test   %edx,%edx
  402f2e:	jne    402f49 <parse_u64+0x59>
  402f30:	mov    -0x28(%rbp),%rdx
  402f34:	cmp    %r12,%rdx
  402f37:	je     402f49 <parse_u64+0x59>
  402f39:	cmpb   $0x0,(%rdx)
  402f3c:	jne    402f49 <parse_u64+0x59>
  402f3e:	add    $0x18,%rsp
  402f42:	pop    %rbx
  402f43:	pop    %r12
  402f45:	pop    %r13
  402f47:	pop    %rbp
  402f48:	ret
  402f49:	mov    0x3130(%rip),%rdi        # 406080 <stderr@GLIBC_2.2.5>
  402f50:	mov    %r12,%rcx
  402f53:	mov    %r13,%rdx
  402f56:	xor    %eax,%eax
  402f58:	mov    $0x404010,%esi
  402f5d:	call   4010a0 <fprintf@plt>
  402f62:	mov    $0x2,%edi
  402f67:	call   4010d0 <exit@plt>
  402f6c:	nopl   0x0(%rax)

0000000000402f70 <run_kernel>:
  402f70:	push   %rbp
  402f71:	mov    %rsp,%rbp
  402f74:	push   %r13
  402f76:	mov    %rsi,%r13
  402f79:	mov    $0x404020,%esi
  402f7e:	push   %r12
  402f80:	mov    %rdi,%r12
  402f83:	call   401090 <strcmp@plt>
  402f88:	test   %eax,%eax
  402f8a:	je     402fe0 <run_kernel+0x70>
  402f8c:	mov    $0x404027,%esi
  402f91:	mov    %r12,%rdi
  402f94:	call   401090 <strcmp@plt>
  402f99:	test   %eax,%eax
  402f9b:	je     402fd0 <run_kernel+0x60>
  402f9d:	mov    $0x40402c,%esi
  402fa2:	mov    %r12,%rdi
  402fa5:	call   401090 <strcmp@plt>
  402faa:	test   %eax,%eax
  402fac:	je     402ff0 <run_kernel+0x80>
  402fae:	mov    $0x404031,%esi
  402fb3:	mov    %r12,%rdi
  402fb6:	call   401090 <strcmp@plt>
  402fbb:	test   %eax,%eax
  402fbd:	jne    402ffd <run_kernel+0x8d>
  402fbf:	pop    %r12
  402fc1:	mov    %r13,%rdi
  402fc4:	pop    %r13
  402fc6:	pop    %rbp
  402fc7:	jmp    402ab0 <kernel_v512>
  402fcc:	nopl   0x0(%rax)
  402fd0:	pop    %r12
  402fd2:	mov    %r13,%rdi
  402fd5:	pop    %r13
  402fd7:	pop    %rbp
  402fd8:	jmp    402710 <kernel_v128>
  402fdd:	nopl   (%rax)
  402fe0:	pop    %r12
  402fe2:	mov    %r13,%rdi
  402fe5:	pop    %r13
  402fe7:	pop    %rbp
  402fe8:	jmp    4025b0 <kernel_scalar>
  402fed:	nopl   (%rax)
  402ff0:	pop    %r12
  402ff2:	mov    %r13,%rdi
  402ff5:	pop    %r13
  402ff7:	pop    %rbp
  402ff8:	jmp    402850 <kernel_v256>
  402ffd:	mov    0x307c(%rip),%rdi        # 406080 <stderr@GLIBC_2.2.5>
  403004:	mov    %r12,%rdx
  403007:	mov    $0x404036,%esi
  40300c:	xor    %eax,%eax
  40300e:	call   4010a0 <fprintf@plt>
  403013:	mov    $0x2,%edi
  403018:	call   4010d0 <exit@plt>
  40301d:	nopl   (%rax)

0000000000403020 <mode_supported>:
  403020:	push   %rbp
  403021:	mov    %rsp,%rbp
  403024:	push   %r12
  403026:	mov    %rdi,%r12
  403029:	sub    $0x8,%rsp
  40302d:	call   4014e0 <__cpu_indicator_init>
  403032:	mov    $0x404020,%esi
  403037:	mov    %r12,%rdi
  40303a:	call   401090 <strcmp@plt>
  40303f:	test   %eax,%eax
  403041:	je     4030a0 <mode_supported+0x80>
  403043:	mov    $0x404027,%esi
  403048:	mov    %r12,%rdi
  40304b:	call   401090 <strcmp@plt>
  403050:	test   %eax,%eax
  403052:	je     403080 <mode_supported+0x60>
  403054:	mov    $0x40402c,%esi
  403059:	mov    %r12,%rdi
  40305c:	call   401090 <strcmp@plt>
  403061:	test   %eax,%eax
  403063:	je     4030d0 <mode_supported+0xb0>
  403065:	mov    $0x404031,%esi
  40306a:	mov    %r12,%rdi
  40306d:	call   401090 <strcmp@plt>
  403072:	test   %eax,%eax
  403074:	je     4030b8 <mode_supported+0x98>
  403076:	mov    -0x8(%rbp),%r12
  40307a:	xor    %eax,%eax
  40307c:	leave
  40307d:	ret
  40307e:	xchg   %ax,%ax
  403080:	mov    0x3356(%rip),%ecx        # 4063dc <__cpu_model+0xc>
  403086:	mov    %ecx,%edx
  403088:	shr    $0xe,%edx
  40308b:	and    $0x1,%edx
  40308e:	and    $0x2,%ch
  403091:	cmovne %edx,%eax
  403094:	mov    -0x8(%rbp),%r12
  403098:	leave
  403099:	ret
  40309a:	nopw   0x0(%rax,%rax,1)
  4030a0:	mov    0x3336(%rip),%eax        # 4063dc <__cpu_model+0xc>
  4030a6:	mov    -0x8(%rbp),%r12
  4030aa:	leave
  4030ab:	and    $0x4000,%eax
  4030b0:	ret
  4030b1:	nopl   0x0(%rax)
  4030b8:	mov    0x331e(%rip),%ecx        # 4063dc <__cpu_model+0xc>
  4030be:	mov    %ecx,%edx
  4030c0:	shr    $0xe,%edx
  4030c3:	and    $0x1,%edx
  4030c6:	and    $0x80,%ch
  4030c9:	cmovne %edx,%eax
  4030cc:	jmp    403094 <mode_supported+0x74>
  4030ce:	xchg   %ax,%ax
  4030d0:	mov    0x3306(%rip),%ecx        # 4063dc <__cpu_model+0xc>
  4030d6:	mov    -0x8(%rbp),%r12
  4030da:	leave
  4030db:	mov    %ecx,%edx
  4030dd:	shr    $0xe,%edx
  4030e0:	and    $0x1,%edx
  4030e3:	and    $0x4,%ch
  4030e6:	cmovne %edx,%eax
  4030e9:	ret
  4030ea:	nopw   0x0(%rax,%rax,1)

00000000004030f0 <monotonic_raw_ns>:
  4030f0:	push   %rbp
  4030f1:	mov    $0x4,%edi
  4030f6:	mov    %rsp,%rbp
  4030f9:	sub    $0x10,%rsp
  4030fd:	lea    -0x10(%rbp),%rsi
  403101:	call   401060 <clock_gettime@plt>
  403106:	test   %eax,%eax
  403108:	jne    403118 <monotonic_raw_ns+0x28>
  40310a:	imul   $0x3b9aca00,-0x10(%rbp),%rax
  403112:	add    -0x8(%rbp),%rax
  403116:	leave
  403117:	ret
  403118:	mov    $0x404048,%edi
  40311d:	call   4010b0 <perror@plt>
  403122:	mov    $0x2,%edi
  403127:	call   4010d0 <exit@plt>
  40312c:	nopl   0x0(%rax)

0000000000403130 <set_cpu_feature.part.0.constprop.0>:
  403130:	cmp    $0x40,%edi
  403133:	mov    %edi,%ecx
  403135:	mov    $0x1,%edx
  40313a:	sbb    %rax,%rax
  40313d:	lea    0x327c(%rip),%rsi        # 4063c0 <__cpu_features2>
  403144:	shl    %cl,%edx
  403146:	not    %rax
  403149:	and    $0x4,%eax
  40314c:	or     %edx,(%rsi,%rax,1)
  40314f:	ret

Disassembly of section .fini:

0000000000403150 <_fini>:
  403150:	endbr64
  403154:	sub    $0x8,%rsp
  403158:	add    $0x8,%rsp
  40315c:	ret
