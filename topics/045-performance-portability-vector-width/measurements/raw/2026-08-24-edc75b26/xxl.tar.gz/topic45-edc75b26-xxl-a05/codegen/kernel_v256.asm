
/tmp/topic45-edc75b26-xxl-a05/binary/width_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402850 <kernel_v256>:
  402850:	push   %rbp
  402851:	vxorpd %xmm3,%xmm3,%xmm3
  402855:	mov    $0x4060c0,%edx
  40285a:	mov    $0x4063c0,%ecx
  40285f:	mov    %rsp,%rbp
  402862:	and    $0xffffffffffffffe0,%rsp
  402866:	vmovsd %xmm3,-0x8(%rsp)
  40286c:	vmovapd 0x19ac(%rip),%ymm1        # 404220 <__dso_handle+0x218>
  402874:	vmovapd 0x19c4(%rip),%ymm0        # 404240 <__dso_handle+0x238>
  40287c:	vmovapd (%rdx),%ymm13
  402880:	vmovapd 0x20(%rdx),%ymm12
  402885:	vmovapd 0x40(%rdx),%ymm11
  40288a:	vmovapd 0x60(%rdx),%ymm10
  40288f:	vmovapd 0x80(%rdx),%ymm9
  402897:	vmovapd 0xa0(%rdx),%ymm8
  40289f:	vmovapd 0xc0(%rdx),%ymm7
  4028a7:	vmovapd 0xe0(%rdx),%ymm6
  4028af:	vmovapd 0x100(%rdx),%ymm5
  4028b7:	vmovapd 0x120(%rdx),%ymm4
  4028bf:	vmovapd 0x140(%rdx),%ymm3
  4028c7:	vmovapd 0x160(%rdx),%ymm2
  4028cf:	test   %rdi,%rdi
  4028d2:	je     402925 <kernel_v256+0xd5>
  4028d4:	xor    %eax,%eax
  4028d6:	cs nopw 0x0(%rax,%rax,1)
  4028e0:	vfmadd231pd %ymm0,%ymm1,%ymm13
  4028e5:	vfmadd231pd %ymm0,%ymm1,%ymm12
  4028ea:	add    $0x1,%rax
  4028ee:	vfmadd231pd %ymm0,%ymm1,%ymm11
  4028f3:	vfmadd231pd %ymm0,%ymm1,%ymm10
  4028f8:	vfmadd231pd %ymm0,%ymm1,%ymm9
  4028fd:	vfmadd231pd %ymm0,%ymm1,%ymm8
  402902:	vfmadd231pd %ymm0,%ymm1,%ymm7
  402907:	vfmadd231pd %ymm0,%ymm1,%ymm6
  40290c:	vfmadd231pd %ymm0,%ymm1,%ymm5
  402911:	vfmadd231pd %ymm0,%ymm1,%ymm4
  402916:	vfmadd231pd %ymm0,%ymm1,%ymm3
  40291b:	vfmadd231pd %ymm0,%ymm1,%ymm2
  402920:	cmp    %rax,%rdi
  402923:	jne    4028e0 <kernel_v256+0x90>
  402925:	vhaddpd %xmm13,%xmm13,%xmm15
  40292a:	vextractf128 $0x1,%ymm13,%xmm13
  402930:	add    $0x180,%rdx
  402937:	vaddsd %xmm13,%xmm15,%xmm14
  40293c:	vunpckhpd %xmm13,%xmm13,%xmm13
  402941:	vaddsd %xmm13,%xmm14,%xmm14
  402946:	vhaddpd %xmm12,%xmm12,%xmm13
  40294b:	vextractf128 $0x1,%ymm12,%xmm12
  402951:	vaddsd -0x8(%rsp),%xmm14,%xmm14
  402957:	vaddsd %xmm12,%xmm13,%xmm13
  40295c:	vunpckhpd %xmm12,%xmm12,%xmm12
  402961:	vaddsd %xmm12,%xmm13,%xmm13
  402966:	vhaddpd %xmm11,%xmm11,%xmm12
  40296b:	vextractf128 $0x1,%ymm11,%xmm11
  402971:	vaddsd %xmm11,%xmm12,%xmm12
  402976:	vunpckhpd %xmm11,%xmm11,%xmm11
  40297b:	vaddsd %xmm14,%xmm13,%xmm13
  402980:	vaddsd %xmm11,%xmm12,%xmm12
  402985:	vhaddpd %xmm10,%xmm10,%xmm11
  40298a:	vextractf128 $0x1,%ymm10,%xmm10
  402990:	vaddsd %xmm10,%xmm11,%xmm11
  402995:	vunpckhpd %xmm10,%xmm10,%xmm10
  40299a:	vaddsd %xmm13,%xmm12,%xmm12
  40299f:	vaddsd %xmm10,%xmm11,%xmm11
  4029a4:	vhaddpd %xmm9,%xmm9,%xmm10
  4029a9:	vextractf128 $0x1,%ymm9,%xmm9
  4029af:	vaddsd %xmm9,%xmm10,%xmm10
  4029b4:	vunpckhpd %xmm9,%xmm9,%xmm9
  4029b9:	vaddsd %xmm12,%xmm11,%xmm11
  4029be:	vaddsd %xmm9,%xmm10,%xmm10
  4029c3:	vhaddpd %xmm8,%xmm8,%xmm9
  4029c8:	vextractf128 $0x1,%ymm8,%xmm8
  4029ce:	vaddsd %xmm8,%xmm9,%xmm9
  4029d3:	vunpckhpd %xmm8,%xmm8,%xmm8
  4029d8:	vaddsd %xmm11,%xmm10,%xmm10
  4029dd:	vaddsd %xmm8,%xmm9,%xmm9
  4029e2:	vhaddpd %xmm7,%xmm7,%xmm8
  4029e6:	vextractf128 $0x1,%ymm7,%xmm7
  4029ec:	vaddsd %xmm7,%xmm8,%xmm8
  4029f0:	vunpckhpd %xmm7,%xmm7,%xmm7
  4029f4:	vaddsd %xmm10,%xmm9,%xmm9
  4029f9:	vaddsd %xmm7,%xmm8,%xmm8
  4029fd:	vhaddpd %xmm6,%xmm6,%xmm7
  402a01:	vextractf128 $0x1,%ymm6,%xmm6
  402a07:	vaddsd %xmm6,%xmm7,%xmm7
  402a0b:	vunpckhpd %xmm6,%xmm6,%xmm6
  402a0f:	vaddsd %xmm9,%xmm8,%xmm8
  402a14:	vaddsd %xmm6,%xmm7,%xmm7
  402a18:	vhaddpd %xmm5,%xmm5,%xmm6
  402a1c:	vextractf128 $0x1,%ymm5,%xmm5
  402a22:	vaddsd %xmm5,%xmm6,%xmm6
  402a26:	vunpckhpd %xmm5,%xmm5,%xmm5
  402a2a:	vaddsd %xmm8,%xmm7,%xmm7
  402a2f:	vaddsd %xmm5,%xmm6,%xmm6
  402a33:	vhaddpd %xmm4,%xmm4,%xmm5
  402a37:	vextractf128 $0x1,%ymm4,%xmm4
  402a3d:	vaddsd %xmm4,%xmm5,%xmm5
  402a41:	vunpckhpd %xmm4,%xmm4,%xmm4
  402a45:	vaddsd %xmm7,%xmm6,%xmm6
  402a49:	vaddsd %xmm4,%xmm5,%xmm5
  402a4d:	vhaddpd %xmm3,%xmm3,%xmm4
  402a51:	vextractf128 $0x1,%ymm3,%xmm3
  402a57:	vaddsd %xmm3,%xmm4,%xmm4
  402a5b:	vunpckhpd %xmm3,%xmm3,%xmm3
  402a5f:	vaddsd %xmm6,%xmm5,%xmm5
  402a63:	vaddsd %xmm3,%xmm4,%xmm3
  402a67:	vhaddpd %xmm2,%xmm2,%xmm4
  402a6b:	vextractf128 $0x1,%ymm2,%xmm2
  402a71:	vaddsd %xmm2,%xmm4,%xmm4
  402a75:	vunpckhpd %xmm2,%xmm2,%xmm2
  402a79:	vaddsd %xmm5,%xmm3,%xmm3
  402a7d:	vaddsd %xmm2,%xmm4,%xmm4
  402a81:	vaddsd %xmm3,%xmm4,%xmm2
  402a85:	vmovsd %xmm2,-0x8(%rsp)
  402a8b:	cmp    %rdx,%rcx
  402a8e:	jne    40287c <kernel_v256+0x2c>
  402a94:	vdivsd 0x16cc(%rip),%xmm2,%xmm0        # 404168 <__dso_handle+0x160>
  402a9c:	vzeroupper
  402a9f:	leave
  402aa0:	ret

Disassembly of section .fini:
