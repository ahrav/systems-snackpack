
/tmp/topic45-edc75b26-xxl-a05/binary/width_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ab0 <kernel_v512>:
  402ab0:	vmovupd 0x3606(%rip),%zmm13        # 4060c0 <initial_values>
  402aba:	vmovupd 0x363c(%rip),%zmm12        # 406100 <initial_values+0x40>
  402ac4:	vmovupd 0x3672(%rip),%zmm11        # 406140 <initial_values+0x80>
  402ace:	vmovupd 0x36a8(%rip),%zmm10        # 406180 <initial_values+0xc0>
  402ad8:	vmovupd 0x36de(%rip),%zmm9        # 4061c0 <initial_values+0x100>
  402ae2:	vmovupd 0x3714(%rip),%zmm8        # 406200 <initial_values+0x140>
  402aec:	vmovupd 0x374a(%rip),%zmm7        # 406240 <initial_values+0x180>
  402af6:	vmovupd 0x3780(%rip),%zmm6        # 406280 <initial_values+0x1c0>
  402b00:	vmovupd 0x37b6(%rip),%zmm5        # 4062c0 <initial_values+0x200>
  402b0a:	vmovupd 0x37ec(%rip),%zmm4        # 406300 <initial_values+0x240>
  402b14:	vmovupd 0x3822(%rip),%zmm3        # 406340 <initial_values+0x280>
  402b1e:	vmovupd 0x3858(%rip),%zmm2        # 406380 <initial_values+0x2c0>
  402b28:	test   %rdi,%rdi
  402b2b:	je     402b99 <kernel_v512+0xe9>
  402b2d:	vbroadcastsd 0x16e9(%rip),%zmm1        # 404220 <__dso_handle+0x218>
  402b37:	xor    %eax,%eax
  402b39:	vbroadcastsd 0x16fd(%rip),%zmm0        # 404240 <__dso_handle+0x238>
  402b43:	nopl   0x0(%rax,%rax,1)
  402b48:	vfmadd231pd %zmm0,%zmm1,%zmm13
  402b4e:	vfmadd231pd %zmm0,%zmm1,%zmm12
  402b54:	add    $0x1,%rax
  402b58:	vfmadd231pd %zmm0,%zmm1,%zmm11
  402b5e:	vfmadd231pd %zmm0,%zmm1,%zmm10
  402b64:	vfmadd231pd %zmm0,%zmm1,%zmm9
  402b6a:	vfmadd231pd %zmm0,%zmm1,%zmm8
  402b70:	vfmadd231pd %zmm0,%zmm1,%zmm7
  402b76:	vfmadd231pd %zmm0,%zmm1,%zmm6
  402b7c:	vfmadd231pd %zmm0,%zmm1,%zmm5
  402b82:	vfmadd231pd %zmm0,%zmm1,%zmm4
  402b88:	vfmadd231pd %zmm0,%zmm1,%zmm3
  402b8e:	vfmadd231pd %zmm0,%zmm1,%zmm2
  402b94:	cmp    %rax,%rdi
  402b97:	jne    402b48 <kernel_v512+0x98>
  402b99:	vxorpd %xmm14,%xmm14,%xmm14
  402b9e:	vunpckhpd %xmm13,%xmm13,%xmm1
  402ba3:	vextractf128 $0x1,%ymm13,%xmm0
  402ba9:	vaddsd %xmm13,%xmm14,%xmm14
  402bae:	vextractf64x4 $0x1,%zmm13,%ymm13
  402bb5:	vaddsd %xmm14,%xmm1,%xmm1
  402bba:	vaddsd %xmm1,%xmm0,%xmm1
  402bbe:	vunpckhpd %xmm0,%xmm0,%xmm0
  402bc2:	vaddsd %xmm1,%xmm0,%xmm0
  402bc6:	vunpckhpd %xmm13,%xmm13,%xmm1
  402bcb:	vaddsd %xmm0,%xmm13,%xmm0
  402bcf:	vextractf128 $0x1,%ymm13,%xmm13
  402bd5:	vaddsd %xmm0,%xmm1,%xmm1
  402bd9:	vaddsd %xmm1,%xmm13,%xmm0
  402bdd:	vunpckhpd %xmm13,%xmm13,%xmm13
  402be2:	vunpckhpd %xmm12,%xmm12,%xmm1
  402be7:	vaddsd %xmm0,%xmm13,%xmm13
  402beb:	vextractf128 $0x1,%ymm12,%xmm0
  402bf1:	vaddsd %xmm13,%xmm12,%xmm13
  402bf6:	vextractf64x4 $0x1,%zmm12,%ymm12
  402bfd:	vaddsd %xmm13,%xmm1,%xmm1
  402c02:	vaddsd %xmm1,%xmm0,%xmm1
  402c06:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c0a:	vaddsd %xmm1,%xmm0,%xmm0
  402c0e:	vunpckhpd %xmm12,%xmm12,%xmm1
  402c13:	vaddsd %xmm0,%xmm12,%xmm0
  402c17:	vextractf128 $0x1,%ymm12,%xmm12
  402c1d:	vaddsd %xmm0,%xmm1,%xmm1
  402c21:	vaddsd %xmm1,%xmm12,%xmm0
  402c25:	vunpckhpd %xmm12,%xmm12,%xmm12
  402c2a:	vunpckhpd %xmm11,%xmm11,%xmm1
  402c2f:	vaddsd %xmm0,%xmm12,%xmm12
  402c33:	vextractf128 $0x1,%ymm11,%xmm0
  402c39:	vaddsd %xmm12,%xmm11,%xmm12
  402c3e:	vextractf64x4 $0x1,%zmm11,%ymm11
  402c45:	vaddsd %xmm12,%xmm1,%xmm1
  402c4a:	vaddsd %xmm1,%xmm0,%xmm1
  402c4e:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c52:	vaddsd %xmm1,%xmm0,%xmm0
  402c56:	vunpckhpd %xmm11,%xmm11,%xmm1
  402c5b:	vaddsd %xmm0,%xmm11,%xmm0
  402c5f:	vextractf128 $0x1,%ymm11,%xmm11
  402c65:	vaddsd %xmm0,%xmm1,%xmm1
  402c69:	vaddsd %xmm1,%xmm11,%xmm0
  402c6d:	vunpckhpd %xmm11,%xmm11,%xmm11
  402c72:	vunpckhpd %xmm10,%xmm10,%xmm1
  402c77:	vaddsd %xmm0,%xmm11,%xmm11
  402c7b:	vextractf128 $0x1,%ymm10,%xmm0
  402c81:	vaddsd %xmm11,%xmm10,%xmm11
  402c86:	vextractf64x4 $0x1,%zmm10,%ymm10
  402c8d:	vaddsd %xmm11,%xmm1,%xmm1
  402c92:	vaddsd %xmm1,%xmm0,%xmm1
  402c96:	vunpckhpd %xmm0,%xmm0,%xmm0
  402c9a:	vaddsd %xmm1,%xmm0,%xmm0
  402c9e:	vunpckhpd %xmm10,%xmm10,%xmm1
  402ca3:	vaddsd %xmm0,%xmm10,%xmm0
  402ca7:	vextractf128 $0x1,%ymm10,%xmm10
  402cad:	vaddsd %xmm0,%xmm1,%xmm1
  402cb1:	vaddsd %xmm1,%xmm10,%xmm0
  402cb5:	vunpckhpd %xmm10,%xmm10,%xmm10
  402cba:	vunpckhpd %xmm9,%xmm9,%xmm1
  402cbf:	vaddsd %xmm0,%xmm10,%xmm10
  402cc3:	vextractf128 $0x1,%ymm9,%xmm0
  402cc9:	vaddsd %xmm10,%xmm9,%xmm10
  402cce:	vextractf64x4 $0x1,%zmm9,%ymm9
  402cd5:	vaddsd %xmm10,%xmm1,%xmm1
  402cda:	vaddsd %xmm1,%xmm0,%xmm1
  402cde:	vunpckhpd %xmm0,%xmm0,%xmm0
  402ce2:	vaddsd %xmm1,%xmm0,%xmm0
  402ce6:	vunpckhpd %xmm9,%xmm9,%xmm1
  402ceb:	vaddsd %xmm0,%xmm9,%xmm0
  402cef:	vextractf128 $0x1,%ymm9,%xmm9
  402cf5:	vaddsd %xmm0,%xmm1,%xmm1
  402cf9:	vaddsd %xmm1,%xmm9,%xmm0
  402cfd:	vunpckhpd %xmm9,%xmm9,%xmm9
  402d02:	vunpckhpd %xmm8,%xmm8,%xmm1
  402d07:	vaddsd %xmm0,%xmm9,%xmm9
  402d0b:	vextractf128 $0x1,%ymm8,%xmm0
  402d11:	vaddsd %xmm9,%xmm8,%xmm9
  402d16:	vextractf64x4 $0x1,%zmm8,%ymm8
  402d1d:	vaddsd %xmm9,%xmm1,%xmm1
  402d22:	vaddsd %xmm1,%xmm0,%xmm1
  402d26:	vunpckhpd %xmm0,%xmm0,%xmm0
  402d2a:	vaddsd %xmm1,%xmm0,%xmm0
  402d2e:	vunpckhpd %xmm8,%xmm8,%xmm1
  402d33:	vaddsd %xmm0,%xmm8,%xmm0
  402d37:	vextractf128 $0x1,%ymm8,%xmm8
  402d3d:	vaddsd %xmm0,%xmm1,%xmm1
  402d41:	vaddsd %xmm1,%xmm8,%xmm0
  402d45:	vunpckhpd %xmm8,%xmm8,%xmm8
  402d4a:	vunpckhpd %xmm7,%xmm7,%xmm1
  402d4e:	vaddsd %xmm0,%xmm8,%xmm8
  402d52:	vextractf128 $0x1,%ymm7,%xmm0
  402d58:	vaddsd %xmm8,%xmm7,%xmm8
  402d5d:	vextractf64x4 $0x1,%zmm7,%ymm7
  402d64:	vaddsd %xmm8,%xmm1,%xmm1
  402d69:	vaddsd %xmm1,%xmm0,%xmm1
  402d6d:	vunpckhpd %xmm0,%xmm0,%xmm0
  402d71:	vaddsd %xmm1,%xmm0,%xmm0
  402d75:	vunpckhpd %xmm7,%xmm7,%xmm1
  402d79:	vaddsd %xmm0,%xmm7,%xmm0
  402d7d:	vextractf128 $0x1,%ymm7,%xmm7
  402d83:	vaddsd %xmm0,%xmm1,%xmm1
  402d87:	vaddsd %xmm1,%xmm7,%xmm0
  402d8b:	vunpckhpd %xmm7,%xmm7,%xmm7
  402d8f:	vunpckhpd %xmm6,%xmm6,%xmm1
  402d93:	vaddsd %xmm0,%xmm7,%xmm7
  402d97:	vextractf128 $0x1,%ymm6,%xmm0
  402d9d:	vaddsd %xmm7,%xmm6,%xmm7
  402da1:	vextractf64x4 $0x1,%zmm6,%ymm6
  402da8:	vaddsd %xmm7,%xmm1,%xmm1
  402dac:	vaddsd %xmm1,%xmm0,%xmm1
  402db0:	vunpckhpd %xmm0,%xmm0,%xmm0
  402db4:	vaddsd %xmm1,%xmm0,%xmm0
  402db8:	vunpckhpd %xmm6,%xmm6,%xmm1
  402dbc:	vaddsd %xmm0,%xmm6,%xmm0
  402dc0:	vextractf128 $0x1,%ymm6,%xmm6
  402dc6:	vaddsd %xmm0,%xmm1,%xmm1
  402dca:	vaddsd %xmm1,%xmm6,%xmm0
  402dce:	vunpckhpd %xmm6,%xmm6,%xmm6
  402dd2:	vunpckhpd %xmm5,%xmm5,%xmm1
  402dd6:	vaddsd %xmm0,%xmm6,%xmm6
  402dda:	vextractf128 $0x1,%ymm5,%xmm0
  402de0:	vaddsd %xmm6,%xmm5,%xmm6
  402de4:	vextractf64x4 $0x1,%zmm5,%ymm5
  402deb:	vaddsd %xmm6,%xmm1,%xmm1
  402def:	vaddsd %xmm1,%xmm0,%xmm1
  402df3:	vunpckhpd %xmm0,%xmm0,%xmm0
  402df7:	vaddsd %xmm1,%xmm0,%xmm0
  402dfb:	vunpckhpd %xmm5,%xmm5,%xmm1
  402dff:	vaddsd %xmm0,%xmm5,%xmm0
  402e03:	vextractf128 $0x1,%ymm5,%xmm5
  402e09:	vaddsd %xmm0,%xmm1,%xmm1
  402e0d:	vaddsd %xmm1,%xmm5,%xmm0
  402e11:	vunpckhpd %xmm5,%xmm5,%xmm5
  402e15:	vunpckhpd %xmm4,%xmm4,%xmm1
  402e19:	vaddsd %xmm0,%xmm5,%xmm5
  402e1d:	vextractf128 $0x1,%ymm4,%xmm0
  402e23:	vaddsd %xmm5,%xmm4,%xmm5
  402e27:	vextractf64x4 $0x1,%zmm4,%ymm4
  402e2e:	vaddsd %xmm5,%xmm1,%xmm1
  402e32:	vaddsd %xmm1,%xmm0,%xmm1
  402e36:	vunpckhpd %xmm0,%xmm0,%xmm0
  402e3a:	vaddsd %xmm1,%xmm0,%xmm0
  402e3e:	vunpckhpd %xmm4,%xmm4,%xmm1
  402e42:	vaddsd %xmm0,%xmm4,%xmm0
  402e46:	vextractf128 $0x1,%ymm4,%xmm4
  402e4c:	vaddsd %xmm0,%xmm1,%xmm1
  402e50:	vaddsd %xmm1,%xmm4,%xmm0
  402e54:	vunpckhpd %xmm4,%xmm4,%xmm4
  402e58:	vunpckhpd %xmm3,%xmm3,%xmm1
  402e5c:	vaddsd %xmm0,%xmm4,%xmm4
  402e60:	vextractf128 $0x1,%ymm3,%xmm0
  402e66:	vaddsd %xmm4,%xmm3,%xmm4
  402e6a:	vextractf64x4 $0x1,%zmm3,%ymm3
  402e71:	vaddsd %xmm4,%xmm1,%xmm1
  402e75:	vaddsd %xmm1,%xmm0,%xmm1
  402e79:	vunpckhpd %xmm0,%xmm0,%xmm0
  402e7d:	vaddsd %xmm1,%xmm0,%xmm0
  402e81:	vunpckhpd %xmm3,%xmm3,%xmm1
  402e85:	vaddsd %xmm0,%xmm3,%xmm0
  402e89:	vextractf128 $0x1,%ymm3,%xmm3
  402e8f:	vaddsd %xmm0,%xmm1,%xmm1
  402e93:	vaddsd %xmm1,%xmm3,%xmm0
  402e97:	vunpckhpd %xmm3,%xmm3,%xmm3
  402e9b:	vunpckhpd %xmm2,%xmm2,%xmm1
  402e9f:	vaddsd %xmm0,%xmm3,%xmm3
  402ea3:	vextractf128 $0x1,%ymm2,%xmm0
  402ea9:	vaddsd %xmm3,%xmm2,%xmm3
  402ead:	vextractf64x4 $0x1,%zmm2,%ymm2
  402eb4:	vaddsd %xmm3,%xmm1,%xmm1
  402eb8:	vaddsd %xmm1,%xmm0,%xmm1
  402ebc:	vunpckhpd %xmm0,%xmm0,%xmm0
  402ec0:	vaddsd %xmm1,%xmm0,%xmm0
  402ec4:	vunpckhpd %xmm2,%xmm2,%xmm1
  402ec8:	vaddsd %xmm0,%xmm2,%xmm0
  402ecc:	vextractf128 $0x1,%ymm2,%xmm2
  402ed2:	vaddsd %xmm0,%xmm1,%xmm1
  402ed6:	vaddsd %xmm1,%xmm2,%xmm0
  402eda:	vunpckhpd %xmm2,%xmm2,%xmm2
  402ede:	vaddsd %xmm0,%xmm2,%xmm0
  402ee2:	vdivsd 0x127e(%rip),%xmm0,%xmm0        # 404168 <__dso_handle+0x160>
  402eea:	vzeroupper
  402eed:	ret

Disassembly of section .fini:
