
/tmp/topic45-edc75b26-xxl-a05/binary/width_bench:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004025b0 <kernel_scalar>:
  4025b0:	vmovsd 0x1c68(%rip),%xmm1        # 404220 <__dso_handle+0x218>
  4025b8:	vmovsd 0x1c80(%rip),%xmm0        # 404240 <__dso_handle+0x238>
  4025c0:	xor    %edx,%edx
  4025c2:	vxorpd %xmm4,%xmm4,%xmm4
  4025c6:	cs nopw 0x0(%rax,%rax,1)
  4025d0:	vmovsd 0x4060c0(,%rdx,8),%xmm2
  4025d9:	lea    0x1(%rdx),%rax
  4025dd:	vmovsd 0x4060c0(,%rax,8),%xmm14
  4025e6:	lea    0x2(%rdx),%rax
  4025ea:	vmovsd 0x4060c0(,%rax,8),%xmm13
  4025f3:	lea    0x3(%rdx),%rax
  4025f7:	vmovsd 0x4060c0(,%rax,8),%xmm12
  402600:	lea    0x4(%rdx),%rax
  402604:	vmovsd 0x4060c0(,%rax,8),%xmm11
  40260d:	lea    0x5(%rdx),%rax
  402611:	vmovsd 0x4060c0(,%rax,8),%xmm10
  40261a:	lea    0x6(%rdx),%rax
  40261e:	vmovsd 0x4060c0(,%rax,8),%xmm9
  402627:	lea    0x7(%rdx),%rax
  40262b:	vmovsd 0x4060c0(,%rax,8),%xmm8
  402634:	lea    0x8(%rdx),%rax
  402638:	vmovsd 0x4060c0(,%rax,8),%xmm7
  402641:	lea    0x9(%rdx),%rax
  402645:	vmovsd 0x4060c0(,%rax,8),%xmm6
  40264e:	lea    0xa(%rdx),%rax
  402652:	vmovsd 0x4060c0(,%rax,8),%xmm5
  40265b:	lea    0xb(%rdx),%rax
  40265f:	vmovsd 0x4060c0(,%rax,8),%xmm3
  402668:	test   %rdi,%rdi
  40266b:	je     4026b5 <kernel_scalar+0x105>
  40266d:	xor    %eax,%eax
  40266f:	nop
  402670:	vfmadd231sd %xmm0,%xmm1,%xmm2
  402675:	vfmadd231sd %xmm0,%xmm1,%xmm14
  40267a:	add    $0x1,%rax
  40267e:	vfmadd231sd %xmm0,%xmm1,%xmm13
  402683:	vfmadd231sd %xmm0,%xmm1,%xmm12
  402688:	vfmadd231sd %xmm0,%xmm1,%xmm11
  40268d:	vfmadd231sd %xmm0,%xmm1,%xmm10
  402692:	vfmadd231sd %xmm0,%xmm1,%xmm9
  402697:	vfmadd231sd %xmm0,%xmm1,%xmm8
  40269c:	vfmadd231sd %xmm0,%xmm1,%xmm7
  4026a1:	vfmadd231sd %xmm0,%xmm1,%xmm6
  4026a6:	vfmadd231sd %xmm0,%xmm1,%xmm5
  4026ab:	vfmadd231sd %xmm0,%xmm1,%xmm3
  4026b0:	cmp    %rax,%rdi
  4026b3:	jne    402670 <kernel_scalar+0xc0>
  4026b5:	vaddsd %xmm14,%xmm2,%xmm2
  4026ba:	add    $0xc,%rdx
  4026be:	vaddsd %xmm13,%xmm2,%xmm2
  4026c3:	vaddsd %xmm12,%xmm2,%xmm2
  4026c8:	vaddsd %xmm11,%xmm2,%xmm2
  4026cd:	vaddsd %xmm10,%xmm2,%xmm2
  4026d2:	vaddsd %xmm9,%xmm2,%xmm2
  4026d7:	vaddsd %xmm8,%xmm2,%xmm2
  4026dc:	vaddsd %xmm7,%xmm2,%xmm2
  4026e0:	vaddsd %xmm6,%xmm2,%xmm2
  4026e4:	vaddsd %xmm5,%xmm2,%xmm2
  4026e8:	vaddsd %xmm3,%xmm2,%xmm2
  4026ec:	vaddsd %xmm2,%xmm4,%xmm4
  4026f0:	cmp    $0x60,%rdx
  4026f4:	jne    4025d0 <kernel_scalar+0x20>
  4026fa:	vdivsd 0x1a66(%rip),%xmm4,%xmm0        # 404168 <__dso_handle+0x160>
  402702:	ret

Disassembly of section .fini:
