
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000015980 <topic43_barrier_lookup>:
   15980:	cmp	x2, x1
   15984:	b.cs	15998 <topic43_barrier_lookup+0x18>  // b.hs, b.nlast
   15988:	dsb	nsh
   1598c:	isb
   15990:	ldr	x0, [x0, x2, lsl #3]
   15994:	ret
   15998:	mov	x0, xzr
   1599c:	ret

Disassembly of section .fini:
