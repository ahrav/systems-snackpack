
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000000159f0 <topic43_plain_lookup>:
   159f0:	cmp	x2, x1
   159f4:	b.cs	15a00 <topic43_plain_lookup+0x10>  // b.hs, b.nlast
   159f8:	ldr	x0, [x0, x2, lsl #3]
   159fc:	ret
   15a00:	mov	x0, xzr
   15a04:	ret

Disassembly of section .fini:
