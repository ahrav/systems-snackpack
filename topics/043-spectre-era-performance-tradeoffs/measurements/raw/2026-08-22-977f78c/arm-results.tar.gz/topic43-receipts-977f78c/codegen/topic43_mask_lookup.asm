
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000000159a0 <topic43_mask_lookup>:
   159a0:	cbz	x1, 159c8 <topic43_mask_lookup+0x28>
   159a4:	cmp	x2, x1
   159a8:	ngc	x9, xzr
   159ac:	csdb
   159b0:	and	x8, x9, x2
   159b4:	cmp	x8, x1
   159b8:	b.cs	159d0 <topic43_mask_lookup+0x30>  // b.hs, b.nlast
   159bc:	ldr	x8, [x0, x8, lsl #3]
   159c0:	and	x0, x8, x9
   159c4:	ret
   159c8:	mov	x0, xzr
   159cc:	ret
   159d0:	stp	x29, x30, [sp, #-16]!
   159d4:	mov	x29, sp
   159d8:	adrp	x2, 7d000 <GCC_except_table0+0x1c6bc>
   159dc:	add	x2, x2, #0xc58
   159e0:	mov	x0, x8
   159e4:	bl	146b8 <_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check>

Disassembly of section .fini:
