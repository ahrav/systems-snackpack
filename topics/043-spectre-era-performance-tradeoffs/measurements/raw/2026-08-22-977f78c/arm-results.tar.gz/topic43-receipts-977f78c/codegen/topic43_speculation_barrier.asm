
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000015a10 <topic43_speculation_barrier>:
   15a10:	dsb	nsh
   15a14:	isb
   15a18:	ret

Disassembly of section .fini:
