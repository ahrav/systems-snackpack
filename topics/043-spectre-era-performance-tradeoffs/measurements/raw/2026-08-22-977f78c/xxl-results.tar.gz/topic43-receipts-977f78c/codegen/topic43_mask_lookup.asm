
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000000164a0 <topic43_mask_lookup>:
   164a0:	test   %rsi,%rsi
   164a3:	je     164b8 <topic43_mask_lookup+0x18>
   164a5:	cmp    %rsi,%rdx
   164a8:	sbb    %rax,%rax
   164ab:	and    %rax,%rdx
   164ae:	cmp    %rsi,%rdx
   164b1:	jae    164bb <topic43_mask_lookup+0x1b>
   164b3:	and    (%rdi,%rdx,8),%rax
   164b7:	ret
   164b8:	xor    %eax,%eax
   164ba:	ret
   164bb:	push   %rax
   164bc:	lea    0x3feb5(%rip),%rax        # 56378 <__dso_handle+0x38>
   164c3:	mov    %rdx,%rdi
   164c6:	mov    %rax,%rdx
   164c9:	call   *0x41fb1(%rip)        # 58480 <_DYNAMIC+0x2e0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
