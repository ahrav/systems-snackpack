
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000000164d0 <topic43_plain_lookup>:
   164d0:	cmp    %rsi,%rdx
   164d3:	jae    164da <topic43_plain_lookup+0xa>
   164d5:	mov    (%rdi,%rdx,8),%rax
   164d9:	ret
   164da:	xor    %eax,%eax
   164dc:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
