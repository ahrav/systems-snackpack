
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000016490 <topic43_barrier_lookup>:
   16490:	cmp    %rsi,%rdx
   16493:	jae    1649d <topic43_barrier_lookup+0xd>
   16495:	lfence
   16498:	mov    (%rdi,%rdx,8),%rax
   1649c:	ret
   1649d:	xor    %eax,%eax
   1649f:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
