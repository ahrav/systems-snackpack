
/tmp/topic43-extract-977f78c/systems-snackpack-977f78c/target/release/spectre-tradeoff-probe:     file format elf64-x86-64


Disassembly of section .text:

00000000000164e0 <topic43_speculation_barrier>:
   164e0:	lfence
   164e3:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
