000000000001b4b0 <topic47_cas_increment>:
   1b4b0:	push   %rax
   1b4b1:	mov    (%rdi),%r9
   1b4b4:	xor    %ecx,%ecx
   1b4b6:	test   %rsi,%rsi
   1b4b9:	je     1b506 <topic47_cas_increment+0x56>
   1b4bb:	mov    %rsp,%rdx
   1b4be:	xor    %r8d,%r8d
   1b4c1:	jmp    1b4db <topic47_cas_increment+0x2b>
   1b4c3:	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   1b4d0:	neg    %rcx
   1b4d3:	inc    %r8
   1b4d6:	cmp    %rsi,%r8
   1b4d9:	je     1b506 <topic47_cas_increment+0x56>
   1b4db:	mov    %r9,%rax
   1b4de:	mov    %r8,(%rsp)
   1b4e2:	inc    %r9
   1b4e5:	lock cmpxchg %r9,(%rdi)
   1b4ea:	je     1b4d3 <topic47_cas_increment+0x23>
   1b4ec:	neg    %rcx
   1b4ef:	nop
   1b4f0:	cmp    $0x1,%rcx
   1b4f4:	je     1b50b <topic47_cas_increment+0x5b>
   1b4f6:	lea    0x1(%rax),%r9
   1b4fa:	dec    %rcx
   1b4fd:	lock cmpxchg %r9,(%rdi)
   1b502:	jne    1b4f0 <topic47_cas_increment+0x40>
   1b504:	jmp    1b4d0 <topic47_cas_increment+0x20>
   1b506:	mov    %rcx,%rax
   1b509:	pop    %rcx
   1b50a:	ret
   1b50b:	lea    -0x1250b(%rip),%rdi        # 9007 <GCC_except_table555+0x3e57>
   1b512:	lea    0x40627(%rip),%rdx        # 5bb40 <__dso_handle+0x330>
   1b519:	mov    $0x18,%esi
   1b51e:	call   1fea0 <core::option::expect_failed>
   1b523:	ud2
   1b525:	call   1ffb3 <core::panicking::panic_cannot_unwind>
   1b52a:	int3
   1b52b:	int3
   1b52c:	int3
   1b52d:	int3
   1b52e:	int3
   1b52f:	int3

