000000000001b480 <topic47_shared_fetch_add>:
   1b480:	test   %rsi,%rsi
   1b483:	je     1b4a1 <topic47_shared_fetch_add+0x21>
   1b485:	xor    %eax,%eax
   1b487:	lea    -0x8(%rsp),%rcx
   1b48c:	nopl   0x0(%rax)
   1b490:	mov    %rax,-0x8(%rsp)
   1b495:	inc    %rax
   1b498:	lock incq (%rdi)
   1b49c:	cmp    %rax,%rsi
   1b49f:	jne    1b490 <topic47_shared_fetch_add+0x10>
   1b4a1:	ret
   1b4a2:	int3
   1b4a3:	int3
   1b4a4:	int3
   1b4a5:	int3
   1b4a6:	int3
   1b4a7:	int3
   1b4a8:	int3
   1b4a9:	int3
   1b4aa:	int3
   1b4ab:	int3
   1b4ac:	int3
   1b4ad:	int3
   1b4ae:	int3
   1b4af:	int3

