000000000001b530 <topic47_batched_fetch_add>:
   1b530:	push   %r15
   1b532:	push   %r14
   1b534:	push   %rbx
   1b535:	sub    $0x10,%rsp
   1b539:	test   %rdx,%rdx
   1b53c:	je     1b5c4 <topic47_batched_fetch_add+0x94>
   1b542:	test   %rsi,%rsi
   1b545:	je     1b5b8 <topic47_batched_fetch_add+0x88>
   1b547:	lea    -0x1(%rdx),%r8
   1b54b:	mov    %rsi,%r9
   1b54e:	neg    %r9
   1b551:	xor    %eax,%eax
   1b553:	lea    0x8(%rsp),%r10
   1b558:	lea    0x405c9(%rip),%rcx        # 5bb28 <__dso_handle+0x318>
   1b55f:	xor    %r11d,%r11d
   1b562:	lea    (%r9,%r11,1),%r14
   1b566:	xor    %ebx,%ebx
   1b568:	nopl   0x0(%rax,%rax,1)
   1b570:	lea    (%r11,%rbx,1),%r15
   1b574:	mov    %r15,0x8(%rsp)
   1b579:	cmp    %rbx,%r8
   1b57c:	je     1b590 <topic47_batched_fetch_add+0x60>
   1b57e:	inc    %rbx
   1b581:	mov    %r14,%r15
   1b584:	add    %rbx,%r15
   1b587:	jne    1b570 <topic47_batched_fetch_add+0x40>
   1b589:	jmp    1b5a9 <topic47_batched_fetch_add+0x79>
   1b58b:	nopl   0x0(%rax,%rax,1)
   1b590:	lock add %rdx,(%rdi)
   1b594:	cmp    $0xffffffffffffffff,%rax
   1b598:	je     1b5e5 <topic47_batched_fetch_add+0xb5>
   1b59a:	lea    0x1(%r11,%rbx,1),%r11
   1b59f:	inc    %rax
   1b5a2:	cmp    %rsi,%r11
   1b5a5:	jne    1b562 <topic47_batched_fetch_add+0x32>
   1b5a7:	jmp    1b5ba <topic47_batched_fetch_add+0x8a>
   1b5a9:	lock add %rbx,(%rdi)
   1b5ad:	cmp    $0xffffffffffffffff,%rax
   1b5b1:	je     1b5de <topic47_batched_fetch_add+0xae>
   1b5b3:	inc    %rax
   1b5b6:	jmp    1b5ba <topic47_batched_fetch_add+0x8a>
   1b5b8:	xor    %eax,%eax
   1b5ba:	add    $0x10,%rsp
   1b5be:	pop    %rbx
   1b5bf:	pop    %r14
   1b5c1:	pop    %r15
   1b5c3:	ret
   1b5c4:	lea    -0x129a2(%rip),%rdi        # 8c29 <GCC_except_table555+0x3a79>
   1b5cb:	lea    0x40526(%rip),%rdx        # 5baf8 <__dso_handle+0x2e8>
   1b5d2:	mov    $0x35,%esi
   1b5d7:	call   1d240 <core::panicking::panic_fmt>
   1b5dc:	jmp    1b5f9 <topic47_batched_fetch_add+0xc9>
   1b5de:	lea    0x4052b(%rip),%rcx        # 5bb10 <__dso_handle+0x300>
   1b5e5:	lea    -0x125ff(%rip),%rdi        # 8fed <GCC_except_table555+0x3e3d>
   1b5ec:	mov    $0x1a,%esi
   1b5f1:	mov    %rcx,%rdx
   1b5f4:	call   1fea0 <core::option::expect_failed>
   1b5f9:	ud2
   1b5fb:	call   1ffb3 <core::panicking::panic_cannot_unwind>

