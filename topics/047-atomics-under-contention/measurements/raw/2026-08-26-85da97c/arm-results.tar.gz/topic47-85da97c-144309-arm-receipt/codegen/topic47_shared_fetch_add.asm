000000000001ae20 <topic47_shared_fetch_add>:
   1ae20:	cbz	x1, 1ae58 <topic47_shared_fetch_add+0x38>
   1ae24:	sub	sp, sp, #0x10
   1ae28:	mov	x9, xzr
   1ae2c:	add	x8, sp, #0x8
   1ae30:	mov	w10, #0x1                   	// #1
   1ae34:	nop
   1ae38:	nop
   1ae3c:	nop
   1ae40:	str	x9, [sp, #8]
   1ae44:	add	x9, x9, #0x1
   1ae48:	cmp	x1, x9
   1ae4c:	ldadd	x10, x11, [x0]
   1ae50:	b.ne	1ae40 <topic47_shared_fetch_add+0x20>  // b.any
   1ae54:	add	sp, sp, #0x10
   1ae58:	ret
   1ae5c:	nop

