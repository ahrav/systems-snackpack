000000000001ae60 <topic47_cas_increment>:
   1ae60:	sub	sp, sp, #0x20
   1ae64:	stp	x29, x30, [sp, #16]
   1ae68:	add	x29, sp, #0x10
   1ae6c:	ldr	x11, [x0]
   1ae70:	mov	x8, xzr
   1ae74:	cbz	x1, 1aee4 <topic47_cas_increment+0x84>
   1ae78:	mov	x9, xzr
   1ae7c:	add	x10, sp, #0x8
   1ae80:	b	1ae94 <topic47_cas_increment+0x34>
   1ae84:	neg	x8, x8
   1ae88:	add	x9, x9, #0x1
   1ae8c:	cmp	x9, x1
   1ae90:	b.eq	1aee4 <topic47_cas_increment+0x84>  // b.none
   1ae94:	mov	x13, x11
   1ae98:	str	x9, [sp, #8]
   1ae9c:	add	x11, x11, #0x1
   1aea0:	mov	x12, x13
   1aea4:	cas	x12, x11, [x0]
   1aea8:	cmp	x12, x13
   1aeac:	b.eq	1ae88 <topic47_cas_increment+0x28>  // b.none
   1aeb0:	neg	x8, x8
   1aeb4:	nop
   1aeb8:	nop
   1aebc:	nop
   1aec0:	subs	x8, x8, #0x1
   1aec4:	b.eq	1aef4 <topic47_cas_increment+0x94>  // b.none
   1aec8:	add	x11, x12, #0x1
   1aecc:	mov	x13, x12
   1aed0:	cas	x13, x11, [x0]
   1aed4:	cmp	x13, x12
   1aed8:	mov	x12, x13
   1aedc:	b.ne	1aec0 <topic47_cas_increment+0x60>  // b.any
   1aee0:	b	1ae84 <topic47_cas_increment+0x24>
   1aee4:	mov	x0, x8
   1aee8:	ldp	x29, x30, [sp, #16]
   1aeec:	add	sp, sp, #0x20
   1aef0:	ret
   1aef4:	adrp	x0, 52000 <_fini+0x3958>
   1aef8:	add	x0, x0, #0x445
   1aefc:	adrp	x2, 7e000 <__dso_handle+0xe8>
   1af00:	add	x2, x2, #0x250
   1af04:	mov	w1, #0x18                  	// #24
   1af08:	bl	10d14 <core::option::expect_failed>
   1af0c:	brk	#0x1
   1af10:	bl	10df8 <core::panicking::panic_cannot_unwind>
   1af14:	nop
   1af18:	nop
   1af1c:	nop

