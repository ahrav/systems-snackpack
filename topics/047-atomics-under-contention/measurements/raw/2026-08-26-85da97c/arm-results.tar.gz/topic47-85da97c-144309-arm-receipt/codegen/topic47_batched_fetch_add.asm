000000000001af20 <topic47_batched_fetch_add>:
   1af20:	sub	sp, sp, #0x20
   1af24:	stp	x29, x30, [sp, #16]
   1af28:	add	x29, sp, #0x10
   1af2c:	cbz	x2, 1afcc <topic47_batched_fetch_add+0xac>
   1af30:	cbz	x1, 1afbc <topic47_batched_fetch_add+0x9c>
   1af34:	mov	x8, x2
   1af38:	mov	x9, x0
   1af3c:	mov	x0, xzr
   1af40:	mov	x13, xzr
   1af44:	sub	x10, x2, #0x1
   1af48:	neg	x11, x1
   1af4c:	add	x12, sp, #0x8
   1af50:	adrp	x2, 7e000 <__dso_handle+0xe8>
   1af54:	add	x2, x2, #0x238
   1af58:	mov	x14, xzr
   1af5c:	add	x15, x11, x13
   1af60:	add	x16, x13, x14
   1af64:	cmp	x10, x14
   1af68:	str	x16, [sp, #8]
   1af6c:	b.eq	1af80 <topic47_batched_fetch_add+0x60>  // b.none
   1af70:	add	x14, x14, #0x1
   1af74:	cmn	x15, x14
   1af78:	b.ne	1af60 <topic47_batched_fetch_add+0x40>  // b.any
   1af7c:	b	1afa0 <topic47_batched_fetch_add+0x80>
   1af80:	ldadd	x8, x13, [x9]
   1af84:	cmn	x0, #0x1
   1af88:	b.eq	1aff0 <topic47_batched_fetch_add+0xd0>  // b.none
   1af8c:	add	x13, x16, #0x1
   1af90:	add	x0, x0, #0x1
   1af94:	cmp	x13, x1
   1af98:	b.ne	1af58 <topic47_batched_fetch_add+0x38>  // b.any
   1af9c:	b	1afb0 <topic47_batched_fetch_add+0x90>
   1afa0:	ldadd	x14, x8, [x9]
   1afa4:	cmn	x0, #0x1
   1afa8:	b.eq	1afe8 <topic47_batched_fetch_add+0xc8>  // b.none
   1afac:	add	x0, x0, #0x1
   1afb0:	ldp	x29, x30, [sp, #16]
   1afb4:	add	sp, sp, #0x20
   1afb8:	ret
   1afbc:	mov	x0, xzr
   1afc0:	ldp	x29, x30, [sp, #16]
   1afc4:	add	sp, sp, #0x20
   1afc8:	ret
   1afcc:	adrp	x0, 51000 <_fini+0x2958>
   1afd0:	add	x0, x0, #0xffa
   1afd4:	adrp	x2, 7e000 <__dso_handle+0xe8>
   1afd8:	add	x2, x2, #0x208
   1afdc:	mov	w1, #0x35                  	// #53
   1afe0:	bl	10b5c <core::panicking::panic_fmt>
   1afe4:	b	1b000 <topic47_batched_fetch_add+0xe0>
   1afe8:	adrp	x2, 7e000 <__dso_handle+0xe8>
   1afec:	add	x2, x2, #0x220
   1aff0:	adrp	x0, 52000 <_fini+0x3958>
   1aff4:	add	x0, x0, #0x42b
   1aff8:	mov	w1, #0x1a                  	// #26
   1affc:	bl	10d14 <core::option::expect_failed>
   1b000:	brk	#0x1
   1b004:	bl	10df8 <core::panicking::panic_cannot_unwind>
   1b008:	nop
   1b00c:	nop

