
/tmp/topic35-exact-20260815-7c9a4c3/results.work/native-target/release/dictionary-probe:     file format elf64-x86-64


Disassembly of section .text:

0000000000021c00 <topic035_flat_contains>:
   21c00:	push   %r14
   21c02:	push   %rbx
   21c03:	push   %rax
   21c04:	mov    %rsi,%rax
   21c07:	mov    0x30(%rdi),%r8d
   21c0b:	mov    0x10(%rdi),%rsi
   21c0f:	test   %rdx,%rdx
   21c12:	je     21c8a <topic035_flat_contains+0x8a>
   21c14:	add    %rax,%rdx
   21c17:	mov    0x8(%rdi),%r9
   21c1b:	mov    0x20(%rdi),%r10
   21c1f:	mov    0x28(%rdi),%rcx
   21c23:	cmp    %r8,%rsi
   21c26:	jbe    21cc1 <topic035_flat_contains+0xc1>
   21c2c:	movzwl 0x4(%r9,%r8,8),%r11d
   21c32:	test   %r11,%r11
   21c35:	je     21ca4 <topic035_flat_contains+0xa4>
   21c37:	movzbl (%rax),%ebx
   21c3a:	inc    %rax
   21c3d:	mov    (%r9,%r8,8),%r14d
   21c41:	add    %r14,%r11
   21c44:	jmp    21c5b <topic035_flat_contains+0x5b>
   21c46:	cs nopw 0x0(%rax,%rax,1)
   21c50:	inc    %r8
   21c53:	mov    %r8,%r14
   21c56:	cmp    %r11,%r14
   21c59:	jae    21ca4 <topic035_flat_contains+0xa4>
   21c5b:	mov    %r11,%r8
   21c5e:	sub    %r14,%r8
   21c61:	shr    $1,%r8
   21c64:	add    %r14,%r8
   21c67:	cmp    %rcx,%r8
   21c6a:	jae    21cae <topic035_flat_contains+0xae>
   21c6c:	cmp    %bl,(%r10,%r8,8)
   21c70:	jb     21c50 <topic035_flat_contains+0x50>
   21c72:	jbe    21c80 <topic035_flat_contains+0x80>
   21c74:	mov    %r8,%r11
   21c77:	cmp    %r11,%r14
   21c7a:	jb     21c5b <topic035_flat_contains+0x5b>
   21c7c:	jmp    21ca4 <topic035_flat_contains+0xa4>
   21c7e:	xchg   %ax,%ax
   21c80:	mov    0x4(%r10,%r8,8),%r8d
   21c85:	cmp    %rdx,%rax
   21c88:	jne    21c23 <topic035_flat_contains+0x23>
   21c8a:	cmp    %r8,%rsi
   21c8d:	jbe    21cd1 <topic035_flat_contains+0xd1>
   21c8f:	mov    0x8(%rdi),%rax
   21c93:	cmpb   $0x0,0x6(%rax,%r8,8)
   21c99:	setne  %al
   21c9c:	add    $0x8,%rsp
   21ca0:	pop    %rbx
   21ca1:	pop    %r14
   21ca3:	ret
   21ca4:	xor    %eax,%eax
   21ca6:	add    $0x8,%rsp
   21caa:	pop    %rbx
   21cab:	pop    %r14
   21cad:	ret
   21cae:	lea    0x4a9d3(%rip),%rdx        # 6c688 <anon.a052cc0d0832b1125005740e3e54bbc5.0.llvm.8957055914452380842+0x1a8>
   21cb5:	mov    %r8,%rdi
   21cb8:	mov    %rcx,%rsi
   21cbb:	call   *0x4d237(%rip)        # 6eef8 <_DYNAMIC+0x318>
   21cc1:	lea    0x4a9a8(%rip),%rdx        # 6c670 <anon.a052cc0d0832b1125005740e3e54bbc5.0.llvm.8957055914452380842+0x190>
   21cc8:	mov    %r8,%rdi
   21ccb:	call   *0x4d227(%rip)        # 6eef8 <_DYNAMIC+0x318>
   21cd1:	lea    0x4a9c8(%rip),%rdx        # 6c6a0 <anon.a052cc0d0832b1125005740e3e54bbc5.0.llvm.8957055914452380842+0x1c0>
   21cd8:	mov    %r8,%rdi
   21cdb:	call   *0x4d217(%rip)        # 6eef8 <_DYNAMIC+0x318>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
