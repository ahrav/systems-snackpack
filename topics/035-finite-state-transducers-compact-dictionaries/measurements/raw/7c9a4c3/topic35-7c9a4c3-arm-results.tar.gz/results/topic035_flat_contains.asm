
/tmp/topic35-exact-20260815-7c9a4c3/results.work/native-target/release/dictionary-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000001c9e0 <topic035_flat_contains>:
   1c9e0:	stp	x29, x30, [sp, #-16]!
   1c9e4:	mov	x29, sp
   1c9e8:	mov	x8, x1
   1c9ec:	ldr	w10, [x0, #48]
   1c9f0:	ldr	x1, [x0, #16]
   1c9f4:	cbz	x2, 1ca70 <topic035_flat_contains+0x90>
   1c9f8:	ldp	x13, x9, [x0, #32]
   1c9fc:	ldr	x12, [x0, #8]
   1ca00:	add	x11, x8, x2
   1ca04:	add	x14, x13, #0x4
   1ca08:	cmp	x1, x10
   1ca0c:	b.ls	1cab4 <topic035_flat_contains+0xd4>  // b.plast
   1ca10:	add	x16, x12, x10, lsl #3
   1ca14:	ldrh	w10, [x16, #4]
   1ca18:	cbz	x10, 1ca94 <topic035_flat_contains+0xb4>
   1ca1c:	ldr	w16, [x16]
   1ca20:	ldrb	w15, [x8], #1
   1ca24:	add	x17, x16, x10
   1ca28:	b	1ca40 <topic035_flat_contains+0x60>
   1ca2c:	add	x16, x10, #0x1
   1ca30:	mov	x10, x17
   1ca34:	cmp	x16, x10
   1ca38:	mov	x17, x10
   1ca3c:	b.cs	1ca94 <topic035_flat_contains+0xb4>  // b.hs, b.nlast
   1ca40:	sub	x10, x17, x16
   1ca44:	add	x10, x16, x10, lsr #1
   1ca48:	cmp	x10, x9
   1ca4c:	b.cs	1caa0 <topic035_flat_contains+0xc0>  // b.hs, b.nlast
   1ca50:	lsl	x18, x10, #3
   1ca54:	ldrb	w2, [x13, x18]
   1ca58:	cmp	w2, w15
   1ca5c:	b.cc	1ca2c <topic035_flat_contains+0x4c>  // b.lo, b.ul, b.last
   1ca60:	b.hi	1ca34 <topic035_flat_contains+0x54>  // b.pmore
   1ca64:	ldr	w10, [x14, x18]
   1ca68:	cmp	x8, x11
   1ca6c:	b.ne	1ca08 <topic035_flat_contains+0x28>  // b.any
   1ca70:	cmp	x1, x10
   1ca74:	b.ls	1cac4 <topic035_flat_contains+0xe4>  // b.plast
   1ca78:	ldr	x8, [x0, #8]
   1ca7c:	add	x8, x8, x10, lsl #3
   1ca80:	ldrb	w8, [x8, #6]
   1ca84:	cmp	w8, #0x0
   1ca88:	cset	w0, ne	// ne = any
   1ca8c:	ldp	x29, x30, [sp], #16
   1ca90:	ret
   1ca94:	mov	w0, wzr
   1ca98:	ldp	x29, x30, [sp], #16
   1ca9c:	ret
   1caa0:	adrp	x2, 8d000 <GCC_except_table0+0x19e98>
   1caa4:	add	x2, x2, #0x5e8
   1caa8:	mov	x0, x10
   1caac:	mov	x1, x9
   1cab0:	bl	157f4 <_ZN4core9panicking18panic_bounds_check17hb2e5aecf3acac563E>
   1cab4:	adrp	x2, 8d000 <GCC_except_table0+0x19e98>
   1cab8:	add	x2, x2, #0x5d0
   1cabc:	mov	x0, x10
   1cac0:	bl	157f4 <_ZN4core9panicking18panic_bounds_check17hb2e5aecf3acac563E>
   1cac4:	adrp	x2, 8d000 <GCC_except_table0+0x19e98>
   1cac8:	add	x2, x2, #0x600
   1cacc:	mov	x0, x10
   1cad0:	bl	157f4 <_ZN4core9panicking18panic_bounds_check17hb2e5aecf3acac563E>

Disassembly of section .fini:
