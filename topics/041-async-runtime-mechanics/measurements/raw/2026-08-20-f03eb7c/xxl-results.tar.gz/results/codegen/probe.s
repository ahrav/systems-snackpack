	.file	"state_and_cancellation.4b0d11c6b942fbcb-cgu.0"
	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_,"ax",@progbits
	.p2align	4
	.type	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_,@function
_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_:
.Lfunc_begin0:
	.file	1 "/tmp/topic41-async-T3xlijHO" "results.work/archive/systems-snackpack-f03eb7c/topics/041-async-runtime-mechanics/examples/state_and_cancellation.rs"
	.loc	1 198 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
.Ltmp0:
	.loc	1 101 58 prologue_end
	movzbl	(%rdi), %eax
	testl	%eax, %eax
	je	.LBB0_3
	cmpl	$3, %eax
	jne	.LBB0_2
.Ltmp1:
	.loc	1 105 22
	leaq	4098(%rbx), %rdi
	callq	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	testb	%al, %al
	je	.LBB0_6
.LBB0_5:
	.loc	1 0 22 is_stmt 0
	movl	$1, %eax
	movb	$3, %cl
	.loc	1 105 22
	jmp	.LBB0_7
.Ltmp2:
.LBB0_3:
	.loc	1 102 21 is_stmt 1
	leaq	2(%rbx), %r14
.Ltmp3:
	.loc	1 103 5
	movzbl	1(%rbx), %ebp
.Ltmp4:
	.loc	1 102 21
	movl	$4096, %edx
	movq	%r14, %rdi
	movq	%rsi, %r15
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
.Ltmp5:
	.loc	1 103 5
	movq	%r14, %rdi
	movl	%ebp, %esi
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes
	movq	%r15, %rsi
.Ltmp6:
	.file	2 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src" "hint.rs"
	.loc	2 491 5
	movq	%r14, (%rsp)
	movq	%rsp, %rax
	#APP
	#NO_APP
.Ltmp7:
	.loc	1 105 5
	movb	$0, 4098(%rbx)
.Ltmp8:
	.loc	1 105 22 is_stmt 0
	leaq	4098(%rbx), %rdi
	callq	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	testb	%al, %al
	jne	.LBB0_5
.Ltmp9:
.LBB0_6:
	.loc	1 106 24 is_stmt 1
	leaq	2(%rbx), %rax
.Ltmp10:
	.loc	2 491 5
	movq	%rax, (%rsp)
	movq	%rsp, %rax
	#APP
	#NO_APP
	movq	(%rsp), %rdi
.Ltmp11:
	.loc	1 106 5
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum
	movq	%rax, %rdx
	movb	$1, %cl
	xorl	%eax, %eax
.Ltmp12:
.LBB0_7:
	.loc	1 0 0 is_stmt 0
	movb	%cl, (%rbx)
.Ltmp13:
	.loc	1 200 2 epilogue_begin is_stmt 1
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB0_2:
	.cfi_def_cfa_offset 48
.Ltmp14:
	.loc	1 101 58
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.4(%rip), %rdi
	callq	*_RNvNtNtCs4NRVxsYgnAr_4core9panicking11panic_const28panic_const_async_fn_resumed@GOTPCREL(%rip)
.Ltmp15:
.Lfunc_end0:
	.size	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_, .Lfunc_end0-_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_
	.cfi_endproc

	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_,"ax",@progbits
	.p2align	4
	.type	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_,@function
_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_:
.Lfunc_begin1:
	.loc	1 198 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	subq	$4096, %rsp
	.cfi_adjust_cfa_offset 4096
	movq	$0, (%rsp)
	pushq	%rax
	.cfi_def_cfa_offset 4144
	.cfi_offset %rbx, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
.Ltmp16:
	.loc	1 111 61 prologue_end
	movzbl	10(%rdi), %eax
	testl	%eax, %eax
	je	.LBB1_3
	cmpl	$3, %eax
	jne	.LBB1_2
.Ltmp17:
	.loc	1 118 22
	leaq	9(%rbx), %rdi
	callq	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	testb	%al, %al
	je	.LBB1_6
.LBB1_5:
	.loc	1 0 22 is_stmt 0
	movl	$1, %eax
	movb	$3, %cl
	.loc	1 118 22
	jmp	.LBB1_7
.Ltmp18:
.LBB1_3:
	.loc	1 114 9 is_stmt 1
	movl	8(%rbx), %ebp
	leaq	8(%rsp), %r14
.Ltmp19:
	.loc	1 113 25
	movl	$4096, %edx
	movq	%r14, %rdi
	movq	%rsi, %r15
	xorl	%esi, %esi
	callq	*memset@GOTPCREL(%rip)
.Ltmp20:
	.loc	1 114 9
	movq	%r14, %rdi
	movl	%ebp, %esi
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes
.Ltmp21:
	.loc	2 491 5
	movq	%r14, (%rsp)
	movq	%rsp, %rax
	#APP
	#NO_APP
.Ltmp22:
	.loc	2 491 5 is_stmt 0
	movq	%r14, (%rsp)
	#APP
	#NO_APP
	movq	(%rsp), %rdi
.Ltmp23:
	.loc	1 116 9 is_stmt 1
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum
	movq	%r15, %rsi
	movq	%rax, (%rbx)
.Ltmp24:
	.loc	1 118 5
	movb	$0, 9(%rbx)
.Ltmp25:
	.loc	1 118 22 is_stmt 0
	leaq	9(%rbx), %rdi
	callq	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	testb	%al, %al
	jne	.LBB1_5
.Ltmp26:
.LBB1_6:
	.loc	1 119 5 is_stmt 1
	movq	(%rbx), %rdx
	movb	$1, %cl
	xorl	%eax, %eax
.Ltmp27:
.LBB1_7:
	.loc	1 0 0 is_stmt 0
	movb	%cl, 10(%rbx)
.Ltmp28:
	.loc	1 200 2 epilogue_begin is_stmt 1
	addq	$4104, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB1_2:
	.cfi_def_cfa_offset 4144
.Ltmp29:
	.loc	1 111 61
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.5(%rip), %rdi
	callq	*_RNvNtNtCs4NRVxsYgnAr_4core9panicking11panic_const28panic_const_async_fn_resumed@GOTPCREL(%rip)
.Ltmp30:
.Lfunc_end1:
	.size	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_, .Lfunc_end1-_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_
	.cfi_endproc

	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_,"ax",@progbits
	.p2align	4
	.type	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_,@function
_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_:
.Lfunc_begin2:
	.cfi_startproc
	.loc	1 199 12 prologue_end
	jmp	_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
.Ltmp31:
.Lfunc_end2:
	.size	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_, .Lfunc_end2-_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_
	.cfi_endproc

	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_,"ax",@progbits
	.p2align	4
	.type	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_,@function
_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_:
.Lfunc_begin3:
	.cfi_startproc
	.loc	1 199 12 prologue_end
	jmp	_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
.Ltmp32:
.Lfunc_end3:
	.size	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_, .Lfunc_end3-_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_
	.cfi_endproc

	.section	.text._RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.hidden	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation
	.globl	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation
	.p2align	4
	.type	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation,@function
_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin4:
	.file	3 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/std/src" "rt.rs"
	.loc	3 199 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movl	%ecx, %r8d
	movq	%rdx, %rcx
	movq	%rsi, %rdx
.Ltmp33:
	.loc	3 206 10 prologue_end
	movq	%rdi, (%rsp)
	.loc	3 205 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.0(%rip), %rsi
	movq	%rsp, %rdi
	callq	*_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal@GOTPCREL(%rip)
	.loc	3 211 2 epilogue_begin
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Ltmp34:
.Lfunc_end4:
	.size	_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end4-_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc

	.section	.text.unlikely._RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_,"ax",@progbits
	.type	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_,@function
_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_:
.Lfunc_begin5:
	.file	4 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src" "panicking.rs"
	.loc	4 384 0
	.cfi_startproc
	subq	$40, %rsp
	.cfi_def_cfa_offset 48
	leaq	24(%rsp), %rax
	movq	%rdi, (%rax)
	leaq	32(%rsp), %rcx
	movq	%rsi, (%rcx)
.Ltmp35:
	.loc	4 394 5 prologue_end
	movq	%rdx, 8(%rsp)
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.1(%rip), %rdx
	xorl	%edi, %edi
	movq	%rax, %rsi
	movq	%rdx, %r8
	xorl	%r9d, %r9d
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking19assert_failed_inner@GOTPCREL(%rip)
.Ltmp36:
.Lfunc_end5:
	.size	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_, .Lfunc_end5-_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_
	.cfi_endproc

	.section	.text._RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.p2align	4
	.type	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation,@function
_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin6:
	.file	5 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/std/src/sys" "backtrace.rs"
	.loc	5 162 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp37:
	.file	6 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ops" "function.rs"
	.loc	6 250 5 prologue_end
	callq	*%rdi
.Ltmp38:
	.loc	2 491 5
	#APP
	#NO_APP
.Ltmp39:
	.loc	5 172 2 epilogue_begin
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Ltmp40:
.Lfunc_end6:
	.size	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end6-_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc

	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_,"ax",@progbits
	.p2align	4
	.type	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_,@function
_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_:
.Lfunc_begin7:
	.file	7 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src" "task.rs"
	.loc	7 208 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp41:
	.file	8 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr" "const_ptr.rs"
	.loc	8 974 22 prologue_end
	leaq	-16(%rdi), %rax
.Ltmp42:
	.file	9 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src" "sync.rs"
	.loc	9 2117 23
	movq	%rax, (%rsp)
.Ltmp43:
	.file	10 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/sync" "atomic.rs"
	.loc	10 3956 24
	lock		decq	-16(%rdi)
.Ltmp44:
	.loc	9 2831 12
	jne	.LBB7_2
	#MEMBARRIER
	.loc	9 0 12 is_stmt 0
	movq	%rsp, %rdi
	.loc	9 2874 18 is_stmt 1
	callq	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_
.Ltmp45:
.LBB7_2:
	.loc	7 210 6 epilogue_begin
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Ltmp46:
.Lfunc_end7:
	.size	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_, .Lfunc_end7-_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_
	.cfi_endproc
	.file	11 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr" "mod.rs"
	.file	12 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem" "mod.rs"

	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,"ax",@progbits
	.p2align	4
	.type	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,@function
_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_:
.Lfunc_begin8:
	.cfi_startproc
	.loc	10 3937 24 prologue_end
	lock		incq	-16(%rdi)
.Ltmp47:
	.loc	9 2428 12
	jle	.LBB8_1
.Ltmp48:
	.loc	7 193 6
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.2(%rip), %rax
	movq	%rdi, %rdx
	retq
.LBB8_1:
.Ltmp49:
	.loc	9 2429 13
	ud2
.Ltmp50:
.Lfunc_end8:
	.size	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_, .Lfunc_end8-_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_
	.cfi_endproc
	.file	13 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem" "maybe_dangling.rs"
	.file	14 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/mem" "manually_drop.rs"

	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,"ax",@progbits
	.p2align	4
	.type	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,@function
_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_:
.Lfunc_begin9:
	.cfi_startproc
	.loc	10 3937 24 prologue_end
	lock		incq	(%rdi)
.Ltmp51:
	.loc	7 205 6
	retq
.Ltmp52:
.Lfunc_end9:
	.size	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_, .Lfunc_end9-_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_
	.cfi_endproc

	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_,"ax",@progbits
	.p2align	4
	.type	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_,@function
_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_:
.Lfunc_begin10:
	.loc	7 196 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp53:
	.loc	8 974 22 prologue_end
	leaq	-16(%rdi), %rax
	movq	%rax, (%rsp)
.Ltmp54:
	.loc	10 3937 24
	lock		incq	(%rdi)
.Ltmp55:
	.loc	10 3956 24
	lock		decq	-16(%rdi)
.Ltmp56:
	.loc	9 2831 12
	jne	.LBB10_2
	#MEMBARRIER
	.loc	9 0 12 is_stmt 0
	movq	%rsp, %rdi
	.loc	9 2874 18 is_stmt 1
	callq	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_
.Ltmp57:
.LBB10_2:
	.loc	7 199 6 epilogue_begin
	popq	%rax
	.cfi_def_cfa_offset 8
	retq
.Ltmp58:
.Lfunc_end10:
	.size	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_, .Lfunc_end10-_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_
	.cfi_endproc

	.section	.text._RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.p2align	4
	.type	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation,@function
_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin11:
	.loc	3 206 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp59:
	.loc	3 206 70 prologue_end
	movq	(%rdi), %rdi
	.loc	3 206 18 is_stmt 0
	callq	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation
	.loc	3 206 93
	xorl	%eax, %eax
	.loc	3 206 93 epilogue_begin
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Ltmp60:
.Lfunc_end11:
	.size	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end11-_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc

	.section	.text._RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.p2align	4
	.type	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation,@function
_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin12:
	.loc	6 250 0 is_stmt 1
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp61:
	.loc	6 250 5 prologue_end
	movq	(%rdi), %rdi
.Ltmp62:
	.loc	3 206 18
	callq	_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation
.Ltmp63:
	.loc	6 250 5
	xorl	%eax, %eax
	.loc	6 250 5 epilogue_begin is_stmt 0
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Ltmp64:
.Lfunc_end12:
	.size	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end12-_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI13_0:
	.zero	32,32
.LCPI13_1:
	.zero	32,64
.LCPI13_2:
	.zero	32,96
.LCPI13_3:
	.byte	0
	.byte	1
	.byte	2
	.byte	3
	.byte	4
	.byte	5
	.byte	6
	.byte	7
	.byte	8
	.byte	9
	.byte	10
	.byte	11
	.byte	12
	.byte	13
	.byte	14
	.byte	15
	.byte	16
	.byte	17
	.byte	18
	.byte	19
	.byte	20
	.byte	21
	.byte	22
	.byte	23
	.byte	24
	.byte	25
	.byte	26
	.byte	27
	.byte	28
	.byte	29
	.byte	30
	.byte	31
.LCPI13_4:
	.byte	8
	.byte	4
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.byte	4
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.byte	4
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.byte	4
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.LCPI13_5:
	.zero	32,128
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.LCPI13_6:
	.byte	8
	.byte	4
	.byte	2
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.section	.rodata.cst4,"aM",@progbits,4
	.p2align	2, 0x0
.LCPI13_7:
	.zero	4,128
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes,"ax",@progbits
	.p2align	4
	.type	_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes,@function
_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes:
.Lfunc_begin13:
	.loc	1 84 0 is_stmt 1
	.cfi_startproc
	vpbroadcastb	%esi, %ymm0
.Ltmp65:
	.file	15 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/slice/iter" "macros.rs"
	.loc	15 180 28 prologue_end
	vpaddb	.LCPI13_0(%rip), %ymm0, %ymm1
	vpaddb	.LCPI13_1(%rip), %ymm0, %ymm2
	vpaddb	.LCPI13_2(%rip), %ymm0, %ymm3
	vmovdqa	.LCPI13_3(%rip), %ymm4
	xorl	%eax, %eax
	vpbroadcastq	.LCPI13_6(%rip), %ymm5
	vpbroadcastd	.LCPI13_7(%rip), %ymm6
.Ltmp66:
	.loc	15 0 28 is_stmt 0
.Ltmp67:
	.p2align	4
.LBB13_1:
	.file	16 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num" "uint_macros.rs"
	.loc	16 2660 13 is_stmt 1
	vgf2p8affineqb	$0, %ymm5, %ymm4, %ymm7
	vpaddb	%ymm4, %ymm7, %ymm7
.Ltmp68:
	.loc	16 2584 13
	vpaddb	%ymm0, %ymm7, %ymm8
	vpaddb	%ymm1, %ymm7, %ymm9
	vpaddb	%ymm2, %ymm7, %ymm10
.Ltmp69:
	.loc	1 86 9
	vmovdqu	%ymm8, (%rdi,%rax)
	vmovdqu	%ymm9, 32(%rdi,%rax)
	vmovdqu	%ymm10, 64(%rdi,%rax)
	vpaddb	%ymm3, %ymm7, %ymm7
	vmovdqu	%ymm7, 96(%rdi,%rax)
.Ltmp70:
	.file	17 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/ptr" "non_null.rs"
	.loc	17 656 28
	subq	$-128, %rax
	vpxor	%ymm6, %ymm4, %ymm4
.Ltmp71:
	.loc	15 180 28
	cmpq	$4096, %rax
	jne	.LBB13_1
.Ltmp72:
	.loc	1 88 2
	vzeroupper
	retq
.Ltmp73:
.Lfunc_end13:
	.size	_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes, .Lfunc_end13-_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes
	.cfi_endproc
	.file	18 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/iter/adapters" "enumerate.rs"

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI14_0:
	.quad	1
	.quad	1
	.quad	0
	.quad	1
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race,"ax",@progbits
	.p2align	4
	.type	_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race,@function
_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race:
.Lfunc_begin14:
	.loc	1 245 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r12
	movq	%rdi, %r14
.Ltmp74:
	.file	19 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src" "alloc.rs"
	.loc	19 99 9 prologue_end
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp75:
	.file	20 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/raw_vec" "mod.rs"
	.loc	20 469 25
	testq	%rax, %rax
.Ltmp76:
	.loc	20 434 9
	je	.LBB14_22
.Ltmp77:
	.file	21 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src/collections/vec_deque" "mod.rs"
	.loc	21 0 0 is_stmt 0
	movq	%rax, %r15
.Ltmp78:
	.loc	11 551 14 is_stmt 1
	movq	$11, (%rax)
.Ltmp79:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$56, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp80:
	.file	22 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src" "boxed.rs"
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB14_23
.Ltmp81:
	.loc	22 0 0
	movq	%rax, %rbx
.Ltmp82:
	.loc	22 289 56 is_stmt 1
	vmovaps	.LCPI14_0(%rip), %ymm0
	vmovups	%ymm0, (%rax)
	movq	%r15, 32(%rax)
	movq	$0, 40(%rax)
	movq	$1, 48(%rax)
.Ltmp83:
	.file	23 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src" "rc.rs"
	.loc	23 383 9
	movq	%rax, 8(%rsp)
.Ltmp84:
	.loc	19 99 9
	vzeroupper
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp85:
	.loc	20 469 25
	testq	%rax, %rax
.Ltmp86:
	.loc	20 434 9
	je	.LBB14_22
.Ltmp87:
	.loc	21 0 0 is_stmt 0
	movq	%rax, %r13
.Ltmp88:
	.loc	11 551 14 is_stmt 1
	movq	$22, (%rax)
.Ltmp89:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$56, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp90:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB14_23
.Ltmp91:
	.loc	22 0 0
	movq	%rax, %r15
.Ltmp92:
	.loc	22 289 56 is_stmt 1
	vmovaps	.LCPI14_0(%rip), %ymm0
	vmovups	%ymm0, (%rax)
	movq	%r13, 32(%rax)
	movq	$0, 40(%rax)
	movq	$1, 48(%rax)
.Ltmp93:
	.loc	23 383 9
	movq	%rax, 16(%rsp)
.Ltmp94:
	.loc	12 931 49
	incq	(%rbx)
.Ltmp95:
	.file	24 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/intrinsics" "mod.rs"
	.loc	24 459 8
	je	.LBB14_24
.Ltmp96:
	.loc	19 99 9
	vzeroupper
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$16, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp97:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB14_25
.Ltmp98:
	.loc	22 0 0
	movq	%rax, %r13
.Ltmp99:
	.loc	22 289 56 is_stmt 1
	movq	%rbx, (%rax)
	movb	$0, 8(%rax)
.Ltmp100:
	.loc	12 931 49
	incq	(%r15)
.Ltmp101:
	.loc	24 459 8
	je	.LBB14_24
.Ltmp102:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$16, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp103:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB14_25
.Ltmp104:
	.loc	22 0 0
	movq	%rax, %rbp
.Ltmp105:
	.loc	22 289 56 is_stmt 1
	movq	%r15, (%rax)
	movb	$0, 8(%rax)
.Ltmp106:
	.loc	1 251 13
	movq	%r13, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_
.Ltmp107:
	.file	25 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/macros" "mod.rs"
	.loc	25 430 9
	testq	%rax, %rax
.Ltmp108:
	.loc	1 251 13
	je	.LBB14_26
	.loc	1 252 13
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_
.Ltmp109:
	.loc	25 430 9
	testq	%rax, %rax
.Ltmp110:
	.loc	1 252 13
	je	.LBB14_27
	.loc	1 253 24
	movq	%r13, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_
	.loc	1 253 18 is_stmt 0
	cmpq	$1, %rax
	je	.LBB14_28
	.loc	1 0 18
	movq	%rdx, (%rsp)
	movq	%r14, %r12
.Ltmp111:
	.loc	17 441 20 is_stmt 1
	movq	(%rbp), %rax
.Ltmp112:
	.loc	12 931 49
	decq	(%rax)
.Ltmp113:
	.loc	23 2493 16
	jne	.LBB14_13
	.loc	23 2494 22
	movq	%rbp, %rdi
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp114:
.LBB14_13:
	.loc	23 0 22 is_stmt 0
	movabsq	$9223372036854775807, %r14
.Ltmp115:
	.loc	19 128 14 is_stmt 1
	movl	$16, %esi
	movl	$8, %edx
	movq	%rbp, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp116:
	.file	26 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src" "cell.rs"
	.loc	26 555 18
	movq	16(%rbx), %rax
.Ltmp117:
	.loc	26 955 5
	cmpq	%r14, %rax
.Ltmp118:
	.loc	26 1560 13
	jae	.LBB14_29
.Ltmp119:
	.file	27 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/num" "int_macros.rs"
	.loc	27 2166 13
	leaq	1(%rax), %rcx
.Ltmp120:
	.loc	12 931 49
	movq	%rcx, 16(%rbx)
.Ltmp121:
	.loc	26 555 18
	movq	16(%r15), %rcx
.Ltmp122:
	.loc	26 955 5
	cmpq	%r14, %rcx
.Ltmp123:
	.loc	26 1560 13
	jae	.LBB14_30
.Ltmp124:
	.loc	21 1706 9
	movq	48(%rbx), %rdx
.Ltmp125:
	.loc	21 1706 9 is_stmt 0
	movq	48(%r15), %rsi
	movq	(%rsp), %rdi
.Ltmp126:
	.loc	1 259 5 is_stmt 1
	movq	%rdi, (%r12)
	movq	%rdx, 8(%r12)
	movq	%rsi, 16(%r12)
.Ltmp127:
	.loc	12 931 49
	movq	%rcx, 16(%r15)
.Ltmp128:
	.loc	12 931 49 is_stmt 0
	movq	%rax, 16(%rbx)
.Ltmp129:
	.loc	17 441 20 is_stmt 1
	movq	(%r13), %rax
.Ltmp130:
	.loc	12 931 49
	decq	(%rax)
.Ltmp131:
	.loc	23 2493 16
	jne	.LBB14_17
	.loc	23 2494 22
	movq	%r13, %rdi
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp132:
.LBB14_17:
	.loc	19 128 14
	movl	$16, %esi
	movl	$8, %edx
	movq	%r13, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp133:
	.loc	12 931 49
	decq	(%r15)
.Ltmp134:
	.loc	23 2493 16
	je	.LBB14_18
.Ltmp135:
	.loc	12 931 49
	decq	(%rbx)
.Ltmp136:
	.loc	23 2493 16
	je	.LBB14_20
.Ltmp137:
.LBB14_21:
	.loc	1 264 2 epilogue_begin
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB14_18:
	.cfi_def_cfa_offset 80
	.loc	1 0 2 is_stmt 0
	leaq	16(%rsp), %rdi
.Ltmp138:
	.loc	23 2494 22 is_stmt 1
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp139:
	.loc	12 931 49
	decq	(%rbx)
.Ltmp140:
	.loc	23 2493 16
	jne	.LBB14_21
.LBB14_20:
	.loc	23 0 16 is_stmt 0
	leaq	8(%rsp), %rdi
	.loc	23 2494 22 is_stmt 1
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
	jmp	.LBB14_21
.Ltmp141:
.LBB14_22:
	.loc	20 442 25
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp142:
.LBB14_23:
	.loc	22 250 19
	movl	$8, %edi
	movl	$56, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp143:
.LBB14_24:
	.loc	23 3781 13
	ud2
.Ltmp144:
.LBB14_25:
	.loc	22 250 19
	movl	$8, %edi
	movl	$16, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp145:
.LBB14_26:
	.loc	1 251 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.6(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.7(%rip), %rdx
	movl	$66, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking5panic@GOTPCREL(%rip)
.LBB14_27:
	.loc	1 252 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.8(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.9(%rip), %rdx
	movl	$67, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking5panic@GOTPCREL(%rip)
.LBB14_28:
	.loc	1 255 26
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.12(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.13(%rip), %rdx
	movl	$73, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB14_29:
.Ltmp146:
	.loc	26 1124 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.10(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell30panic_already_mutably_borrowed@GOTPCREL(%rip)
.Ltmp147:
.LBB14_30:
	.loc	26 1124 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.11(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell30panic_already_mutably_borrowed@GOTPCREL(%rip)
.Ltmp148:
.Lfunc_end14:
	.size	_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race, .Lfunc_end14-_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race
	.cfi_endproc
	.file	28 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/task" "poll.rs"

	.section	.rodata.cst32,"aM",@progbits,32
	.p2align	5, 0x0
.LCPI15_0:
	.quad	1
	.quad	1
	.quad	0
	.quad	1
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race,"ax",@progbits
	.p2align	4
	.type	_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race,@function
_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race:
.Lfunc_begin15:
	.loc	1 223 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$24, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rsi, %r12
	movq	%rdi, %r14
.Ltmp149:
	.loc	19 99 9 prologue_end
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp150:
	.loc	20 469 25
	testq	%rax, %rax
.Ltmp151:
	.loc	20 434 9
	je	.LBB15_22
.Ltmp152:
	.loc	21 0 0 is_stmt 0
	movq	%rax, %r15
.Ltmp153:
	.loc	11 551 14 is_stmt 1
	movq	$11, (%rax)
.Ltmp154:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$56, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp155:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB15_23
.Ltmp156:
	.loc	22 0 0
	movq	%rax, %rbx
.Ltmp157:
	.loc	22 289 56 is_stmt 1
	vmovaps	.LCPI15_0(%rip), %ymm0
	vmovups	%ymm0, (%rax)
	movq	%r15, 32(%rax)
	movq	$0, 40(%rax)
	movq	$1, 48(%rax)
.Ltmp158:
	.loc	23 383 9
	movq	%rax, 8(%rsp)
.Ltmp159:
	.loc	19 99 9
	vzeroupper
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp160:
	.loc	20 469 25
	testq	%rax, %rax
.Ltmp161:
	.loc	20 434 9
	je	.LBB15_22
.Ltmp162:
	.loc	21 0 0 is_stmt 0
	movq	%rax, %r13
.Ltmp163:
	.loc	11 551 14 is_stmt 1
	movq	$22, (%rax)
.Ltmp164:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$56, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp165:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB15_23
.Ltmp166:
	.loc	22 0 0
	movq	%rax, %r15
.Ltmp167:
	.loc	22 289 56 is_stmt 1
	vmovaps	.LCPI15_0(%rip), %ymm0
	vmovups	%ymm0, (%rax)
	movq	%r13, 32(%rax)
	movq	$0, 40(%rax)
	movq	$1, 48(%rax)
.Ltmp168:
	.loc	23 383 9
	movq	%rax, 16(%rsp)
.Ltmp169:
	.loc	12 931 49
	incq	(%rbx)
.Ltmp170:
	.loc	24 459 8
	je	.LBB15_24
.Ltmp171:
	.loc	19 99 9
	vzeroupper
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$32, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp172:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB15_25
.Ltmp173:
	.loc	22 0 0
	movq	%rax, %r13
.Ltmp174:
	.loc	22 289 56 is_stmt 1
	movq	$0, (%rax)
	movq	%rbx, 16(%rax)
	movb	$0, 24(%rax)
.Ltmp175:
	.loc	12 931 49
	incq	(%r15)
.Ltmp176:
	.loc	24 459 8
	je	.LBB15_24
.Ltmp177:
	.loc	19 99 9
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$32, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp178:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB15_25
.Ltmp179:
	.loc	22 0 0
	movq	%rax, %rbp
.Ltmp180:
	.loc	22 289 56 is_stmt 1
	movq	$0, (%rax)
	movq	%r15, 16(%rax)
	movb	$0, 24(%rax)
.Ltmp181:
	.loc	1 229 13
	movq	%r13, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_
.Ltmp182:
	.loc	25 430 9
	testq	%rax, %rax
.Ltmp183:
	.loc	1 229 13
	je	.LBB15_26
	.loc	1 230 13
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_
.Ltmp184:
	.loc	25 430 9
	testq	%rax, %rax
.Ltmp185:
	.loc	1 230 13
	je	.LBB15_27
	.loc	1 231 24
	movq	%r13, %rdi
	movq	%r12, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_
	.loc	1 231 18 is_stmt 0
	cmpq	$1, %rax
	je	.LBB15_28
.Ltmp186:
	.loc	1 0 18
	movq	%rdx, (%rsp)
	movq	%r14, %r12
	movq	%rbp, %rdi
	addq	$16, %rdi
.Ltmp187:
	.loc	17 441 20 is_stmt 1
	movq	(%rdi), %rax
.Ltmp188:
	.loc	12 931 49
	decq	(%rax)
.Ltmp189:
	.loc	23 2493 16
	jne	.LBB15_13
	.loc	23 2494 22
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp190:
.LBB15_13:
	.loc	23 0 22 is_stmt 0
	movabsq	$9223372036854775807, %r14
.Ltmp191:
	.loc	19 128 14 is_stmt 1
	movl	$32, %esi
	movl	$8, %edx
	movq	%rbp, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp192:
	.loc	26 555 18
	movq	16(%rbx), %rax
.Ltmp193:
	.loc	26 955 5
	cmpq	%r14, %rax
.Ltmp194:
	.loc	26 1560 13
	jae	.LBB15_29
.Ltmp195:
	.loc	27 2166 13
	leaq	1(%rax), %rcx
.Ltmp196:
	.loc	12 931 49
	movq	%rcx, 16(%rbx)
.Ltmp197:
	.loc	26 555 18
	movq	16(%r15), %rcx
.Ltmp198:
	.loc	26 955 5
	cmpq	%r14, %rcx
.Ltmp199:
	.loc	26 1560 13
	jae	.LBB15_30
.Ltmp200:
	.loc	26 0 13 is_stmt 0
	movq	%r13, %rdi
.Ltmp201:
	.loc	21 1706 9 is_stmt 1
	movq	48(%rbx), %rdx
.Ltmp202:
	.loc	21 1706 9 is_stmt 0
	movq	48(%r15), %rsi
	movq	(%rsp), %r8
.Ltmp203:
	.loc	1 237 5 is_stmt 1
	movq	%r8, (%r12)
	movq	%rdx, 8(%r12)
	movq	%rsi, 16(%r12)
.Ltmp204:
	.loc	12 931 49
	movq	%rcx, 16(%r15)
.Ltmp205:
	.loc	12 931 49 is_stmt 0
	movq	%rax, 16(%rbx)
	addq	$16, %rdi
.Ltmp206:
	.loc	17 441 20 is_stmt 1
	movq	(%rdi), %rax
.Ltmp207:
	.loc	12 931 49
	decq	(%rax)
.Ltmp208:
	.loc	23 2493 16
	jne	.LBB15_17
	.loc	23 2494 22
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp209:
.LBB15_17:
	.loc	19 128 14
	movl	$32, %esi
	movl	$8, %edx
	movq	%r13, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp210:
	.loc	12 931 49
	decq	(%r15)
.Ltmp211:
	.loc	23 2493 16
	je	.LBB15_18
.Ltmp212:
	.loc	12 931 49
	decq	(%rbx)
.Ltmp213:
	.loc	23 2493 16
	je	.LBB15_20
.Ltmp214:
.LBB15_21:
	.loc	1 242 2 epilogue_begin
	addq	$24, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB15_18:
	.cfi_def_cfa_offset 80
	.loc	1 0 2 is_stmt 0
	leaq	16(%rsp), %rdi
.Ltmp215:
	.loc	23 2494 22 is_stmt 1
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
.Ltmp216:
	.loc	12 931 49
	decq	(%rbx)
.Ltmp217:
	.loc	23 2493 16
	jne	.LBB15_21
.LBB15_20:
	.loc	23 0 16 is_stmt 0
	leaq	8(%rsp), %rdi
	.loc	23 2494 22 is_stmt 1
	callq	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
	jmp	.LBB15_21
.Ltmp218:
.LBB15_22:
	.loc	20 442 25
	movl	$8, %edi
	movl	$8, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Ltmp219:
.LBB15_23:
	.loc	22 250 19
	movl	$8, %edi
	movl	$56, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp220:
.LBB15_24:
	.loc	23 3781 13
	ud2
.Ltmp221:
.LBB15_25:
	.loc	22 250 19
	movl	$8, %edi
	movl	$32, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp222:
.LBB15_26:
	.loc	1 229 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.6(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.14(%rip), %rdx
	movl	$66, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking5panic@GOTPCREL(%rip)
.LBB15_27:
	.loc	1 230 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.8(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.15(%rip), %rdx
	movl	$67, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking5panic@GOTPCREL(%rip)
.LBB15_28:
	.loc	1 233 26
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.18(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.19(%rip), %rdx
	movl	$77, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking9panic_fmt@GOTPCREL(%rip)
.LBB15_29:
.Ltmp223:
	.loc	26 1124 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.16(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell30panic_already_mutably_borrowed@GOTPCREL(%rip)
.Ltmp224:
.LBB15_30:
	.loc	26 1124 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.17(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell30panic_already_mutably_borrowed@GOTPCREL(%rip)
.Ltmp225:
.Lfunc_end15:
	.size	_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race, .Lfunc_end15-_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race
	.cfi_endproc

	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation4main,"ax",@progbits
	.hidden	_RNvCs6ruGKiyv7y9_22state_and_cancellation4main
	.globl	_RNvCs6ruGKiyv7y9_22state_and_cancellation4main
	.p2align	4
	.type	_RNvCs6ruGKiyv7y9_22state_and_cancellation4main,@function
_RNvCs6ruGKiyv7y9_22state_and_cancellation4main:
.Lfunc_begin16:
	.loc	1 266 0
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$184, %rsp
	.cfi_def_cfa_offset 240
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	.loc	19 99 9 prologue_end
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$24, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp226:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB16_33
.Ltmp227:
	.loc	22 0 0
	movq	%rax, %rbx
.Ltmp228:
	.loc	22 289 56 is_stmt 1
	movq	$1, (%rax)
	movq	$1, 8(%rax)
	movq	$0, 16(%rax)
.Ltmp229:
	.loc	1 267 16
	movq	%rax, 152(%rsp)
.Ltmp230:
	.loc	10 3937 24
	lock		incq	(%rax)
.Ltmp231:
	.loc	9 2428 12
	jle	.LBB16_36
.Ltmp232:
	.loc	1 0 0 is_stmt 0
	movq	%rbx, %rax
	addq	$16, %rax
.Ltmp233:
	.file	29 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/task" "wake.rs"
	.loc	29 533 9 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.2(%rip), %rcx
	movq	%rcx, 112(%rsp)
	movq	%rax, 120(%rsp)
.Ltmp234:
	.loc	12 403 14
	movq	$4099, 160(%rsp)
.Ltmp235:
	.loc	12 403 14 is_stmt 0
	movq	$16, 168(%rsp)
.Ltmp236:
	.loc	19 99 9 is_stmt 1
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$4099, %edi
	movl	$1, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp237:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB16_34
.Ltmp238:
	.loc	22 0 0
	movq	%rax, %r14
.Ltmp239:
	.loc	22 289 56 is_stmt 1
	movw	$768, (%rax)
	xorl	%r12d, %r12d
	leaq	112(%rsp), %r15
.Ltmp240:
	.loc	22 0 56 is_stmt 0
.Ltmp241:
	.p2align	4
.LBB16_4:
	.loc	1 207 9 is_stmt 1
	incq	%r12
	.loc	1 208 15
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_
	.loc	1 208 9 is_stmt 0
	testb	$1, %al
	jne	.LBB16_4
.Ltmp242:
	.loc	19 128 14 is_stmt 1
	movl	$4099, %esi
	movq	%rdx, %r15
	movl	$1, %edx
	movq	%r14, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r15, %r13
.Ltmp243:
	.loc	1 276 10
	movq	%r15, 56(%rsp)
	.loc	1 276 21 is_stmt 0
	movq	%r12, 64(%rsp)
.Ltmp244:
	.loc	19 99 9 is_stmt 1
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	.loc	19 101 9
	movl	$16, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
.Ltmp245:
	.loc	22 248 11
	testq	%rax, %rax
	.loc	22 248 5 is_stmt 0
	je	.LBB16_35
.Ltmp246:
	.loc	22 0 0
	movq	%rax, %r14
.Ltmp247:
	.loc	22 289 56 is_stmt 1
	movb	$3, 8(%rax)
	movb	$0, 10(%rax)
	xorl	%ebp, %ebp
	leaq	112(%rsp), %r15
.Ltmp248:
	.loc	22 0 56 is_stmt 0
.Ltmp249:
	.p2align	4
.LBB16_7:
	.loc	1 207 9 is_stmt 1
	incq	%rbp
	.loc	1 208 15
	movq	%r14, %rdi
	movq	%r15, %rsi
	callq	_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_
	.loc	1 208 9 is_stmt 0
	testb	$1, %al
	jne	.LBB16_7
.Ltmp250:
	.loc	19 128 14 is_stmt 1
	movl	$16, %esi
	movq	%rdx, %r15
	movl	$8, %edx
	movq	%r14, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp251:
	.loc	1 277 10
	movq	%r15, 176(%rsp)
	.loc	1 277 21 is_stmt 0
	movq	%rbp, 72(%rsp)
.Ltmp252:
	.loc	1 278 5 is_stmt 1
	cmpq	%r15, %r13
	jne	.LBB16_9
.Ltmp253:
	.loc	1 279 5
	cmpq	$522240, %r13
	jne	.LBB16_37
.Ltmp254:
	.loc	1 280 5
	cmpq	$2, %r12
	jne	.LBB16_20
.Ltmp255:
	.loc	1 281 5
	cmpq	$2, %rbp
	jne	.LBB16_22
.Ltmp256:
	.loc	1 0 5 is_stmt 0
	leaq	128(%rsp), %rbp
	leaq	112(%rsp), %r12
	.loc	1 285 25 is_stmt 1
	movq	%rbp, %rdi
	movq	%r12, %rsi
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race
	leaq	88(%rsp), %rdi
.Ltmp257:
	.loc	1 286 23
	movq	%r12, %rsi
	callq	_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race
.Ltmp258:
	.loc	1 215 17
	cmpq	$0, 136(%rsp)
	sete	%al
	cmpq	$11, 128(%rsp)
	jne	.LBB16_15
	cmpq	$0, 144(%rsp)
	sete	%cl
	testb	%al, %al
	je	.LBB16_17
.LBB16_18:
	testb	%cl, %cl
	je	.LBB16_19
.Ltmp259:
.LBB16_23:
	.loc	1 215 17 is_stmt 0
	cmpq	$0, 96(%rsp)
	sete	%al
	cmpq	$11, 88(%rsp)
	jne	.LBB16_24
	cmpq	$1, 104(%rsp)
	sete	%cl
	testb	%al, %al
	je	.LBB16_26
.LBB16_27:
	testb	%cl, %cl
	je	.LBB16_38
.Ltmp260:
.LBB16_28:
	.loc	1 304 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.25(%rip), %rdi
	movq	_RNvNtNtCs2AWtUsOyxgP_3std2io5stdio6__print@GOTPCREL(%rip), %r12
	movl	$97, %esi
	callq	*%r12
.Ltmp261:
	.loc	1 305 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.26(%rip), %rax
	movq	%rax, 8(%rsp)
	movq	_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip), %r13
	movq	%r13, 16(%rsp)
.Ltmp262:
	.loc	1 305 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.27(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	leaq	160(%rsp), %rax
.Ltmp263:
	.loc	1 306 5 is_stmt 1
	movq	%rax, 8(%rsp)
	movq	%r13, 16(%rsp)
.Ltmp264:
	.loc	1 306 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.28(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	leaq	168(%rsp), %rax
.Ltmp265:
	.loc	1 307 5 is_stmt 1
	movq	%rax, 8(%rsp)
	movq	%r13, 16(%rsp)
.Ltmp266:
	.loc	1 307 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.29(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	.loc	1 308 44 is_stmt 1
	movq	$4083, 80(%rsp)
	leaq	80(%rsp), %r15
.Ltmp267:
	.loc	1 308 5 is_stmt 0
	movq	%r15, 8(%rsp)
	movq	%r13, 16(%rsp)
.Ltmp268:
	.loc	1 308 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.30(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	leaq	56(%rsp), %rax
.Ltmp269:
	.loc	1 309 5 is_stmt 1
	movq	%rax, 8(%rsp)
	movq	_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt@GOTPCREL(%rip), %r14
	movq	%r14, 16(%rsp)
.Ltmp270:
	.loc	1 309 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.31(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	leaq	64(%rsp), %rax
.Ltmp271:
	.loc	1 310 5 is_stmt 1
	movq	%rax, 8(%rsp)
	movq	%r13, 16(%rsp)
	leaq	72(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	%r13, 32(%rsp)
.Ltmp272:
	.loc	1 310 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.32(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
.Ltmp273:
	.loc	1 311 5 is_stmt 1
	movq	%rbp, 8(%rsp)
	movq	%r14, 16(%rsp)
	leaq	136(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	%r13, 32(%rsp)
	leaq	144(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	%r13, 48(%rsp)
.Ltmp274:
	.loc	1 311 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.33(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
.Ltmp275:
	.loc	1 315 5 is_stmt 1
	leaq	88(%rsp), %rax
	movq	%rax, 8(%rsp)
	movq	%r14, 16(%rsp)
	leaq	96(%rsp), %rax
	movq	%rax, 24(%rsp)
	movq	%r13, 32(%rsp)
	leaq	104(%rsp), %rax
	movq	%rax, 40(%rsp)
	movq	%r13, 48(%rsp)
.Ltmp276:
	.loc	1 315 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.34(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
.Ltmp277:
	.loc	10 3904 24 is_stmt 1
	movq	16(%rbx), %rax
.Ltmp278:
	.loc	10 2870 26
	movq	%rax, 80(%rsp)
.Ltmp279:
	.loc	1 319 5
	movq	%r15, 8(%rsp)
	movq	%r13, 16(%rsp)
.Ltmp280:
	.loc	1 319 5 is_stmt 0
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.35(%rip), %rdi
	leaq	8(%rsp), %rsi
	callq	*%r12
	.loc	1 320 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.36(%rip), %rdi
	movl	$27, %esi
	callq	*%r12
.Ltmp281:
	.loc	9 2117 23
	movq	%rbx, 8(%rsp)
.Ltmp282:
	.loc	10 3956 24
	lock		decq	(%rbx)
.Ltmp283:
	.loc	9 2831 12
	jne	.LBB16_30
	#MEMBARRIER
	.loc	9 0 12 is_stmt 0
	leaq	8(%rsp), %rdi
	.loc	9 2874 18 is_stmt 1
	callq	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_
.Ltmp284:
.LBB16_30:
	.loc	10 3956 24
	lock		decq	(%rbx)
.Ltmp285:
	.loc	9 2831 12
	jne	.LBB16_32
	#MEMBARRIER
	.loc	9 0 12 is_stmt 0
	leaq	152(%rsp), %rdi
	.loc	9 2874 18 is_stmt 1
	callq	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_
.Ltmp286:
.LBB16_32:
	.loc	1 321 2 epilogue_begin
	addq	$184, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB16_15:
	.cfi_def_cfa_offset 240
	.loc	1 0 2 is_stmt 0
	xorl	%eax, %eax
.Ltmp287:
	.loc	1 215 17 is_stmt 1
	cmpq	$0, 144(%rsp)
	sete	%cl
	testb	%al, %al
	jne	.LBB16_18
.LBB16_17:
	.loc	1 0 17 is_stmt 0
	xorl	%ecx, %ecx
	.loc	1 215 17
	testb	%cl, %cl
	jne	.LBB16_23
.Ltmp288:
.LBB16_19:
	.loc	1 287 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.23(%rip), %rsi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.38(%rip), %rdx
	leaq	128(%rsp), %rdi
	callq	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_
.Ltmp289:
.LBB16_24:
	.loc	1 0 5 is_stmt 0
	xorl	%eax, %eax
.Ltmp290:
	.loc	1 215 17 is_stmt 1
	cmpq	$1, 104(%rsp)
	sete	%cl
	testb	%al, %al
	jne	.LBB16_27
.LBB16_26:
	.loc	1 0 17 is_stmt 0
	xorl	%ecx, %ecx
	.loc	1 215 17
	testb	%cl, %cl
	jne	.LBB16_28
.Ltmp291:
.LBB16_38:
	.loc	1 295 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.24(%rip), %rsi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.37(%rip), %rdx
	leaq	88(%rsp), %rdi
	callq	_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_
.Ltmp292:
.LBB16_33:
	.loc	22 250 19
	movl	$8, %edi
	movl	$24, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp293:
.LBB16_34:
	.loc	22 250 19
	movl	$1, %edi
	movl	$4099, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp294:
.LBB16_35:
	.loc	22 250 19
	movl	$8, %edi
	movl	$16, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc5alloc18handle_alloc_error@GOTPCREL(%rip)
.Ltmp295:
.LBB16_9:
	.loc	1 278 5
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.20(%rip), %r9
	leaq	56(%rsp), %rsi
	leaq	176(%rsp), %rdx
.Ltmp296:
	.loc	1 0 0 is_stmt 0
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedyyEB4_@GOTPCREL(%rip)
.LBB16_37:
.Ltmp297:
	.loc	1 279 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.21(%rip), %rdx
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.41(%rip), %r9
	leaq	56(%rsp), %rsi
.Ltmp298:
	.loc	1 0 0 is_stmt 0
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedyyEB4_@GOTPCREL(%rip)
.LBB16_20:
.Ltmp299:
	.loc	1 280 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.22(%rip), %rdx
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.40(%rip), %r9
	leaq	64(%rsp), %rsi
.Ltmp300:
	.loc	1 0 0 is_stmt 0
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip)
.LBB16_22:
.Ltmp301:
	.loc	1 281 5 is_stmt 1
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.22(%rip), %rdx
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.39(%rip), %r9
	leaq	72(%rsp), %rsi
.Ltmp302:
	.loc	1 0 0 is_stmt 0
	xorl	%edi, %edi
	xorl	%ecx, %ecx
	callq	*_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedjjEB4_@GOTPCREL(%rip)
.Ltmp303:
.LBB16_36:
	.loc	9 2429 13 is_stmt 1
	ud2
.Ltmp304:
.Lfunc_end16:
	.size	_RNvCs6ruGKiyv7y9_22state_and_cancellation4main, .Lfunc_end16-_RNvCs6ruGKiyv7y9_22state_and_cancellation4main
	.cfi_endproc

	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum,"ax",@progbits
	.p2align	4
	.type	_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum,@function
_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum:
.Lfunc_begin17:
	.loc	1 91 0
	.cfi_startproc
	xorl	%eax, %eax
	leaq	-9(%rsp), %rcx
	xorl	%edx, %edx
	.loc	1 0 0 is_stmt 0
.Ltmp305:
	.p2align	4
.LBB17_1:
.Ltmp306:
	.loc	1 95 52 prologue_end is_stmt 1
	movzbl	(%rdi,%rdx), %esi
.Ltmp307:
	.loc	17 656 28
	incq	%rdx
.Ltmp308:
	.loc	2 491 5
	movb	%sil, -9(%rsp)
	#APP
	#NO_APP
	movzbl	-9(%rsp), %esi
.Ltmp309:
	.loc	16 2584 13
	addq	%rsi, %rax
.Ltmp310:
	.loc	17 1714 9
	cmpq	$4096, %rdx
.Ltmp311:
	.loc	15 180 28
	jne	.LBB17_1
.Ltmp312:
	.loc	2 491 5
	movq	%rax, -8(%rsp)
	leaq	-8(%rsp), %rax
	#APP
	#NO_APP
	movq	-8(%rsp), %rax
.Ltmp313:
	.loc	1 98 2
	retq
.Ltmp314:
.Lfunc_end17:
	.size	_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum, .Lfunc_end17-_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum
	.cfi_endproc

	.section	.text._RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.p2align	4
	.type	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation,@function
_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin18:
	.loc	23 393 0
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	.loc	23 397 33 prologue_end
	movq	(%rdi), %rbx
.Ltmp315:
	.loc	11 820 14
	movq	24(%rbx), %rsi
.Ltmp316:
	.loc	20 634 39
	testq	%rsi, %rsi
	je	.LBB18_2
.Ltmp317:
	.loc	11 820 14
	movq	32(%rbx), %rdi
.Ltmp318:
	.loc	16 1359 17
	shlq	$3, %rsi
.Ltmp319:
	.loc	19 128 14
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp320:
.LBB18_2:
	.loc	23 3591 12
	cmpq	$-1, %rbx
	je	.LBB18_4
.Ltmp321:
	.loc	12 931 49
	decq	8(%rbx)
.Ltmp322:
	.loc	23 3683 12
	je	.LBB18_5
.Ltmp323:
.LBB18_4:
	.loc	23 404 6 epilogue_begin
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB18_5:
	.cfi_def_cfa_offset 16
.Ltmp324:
	.loc	19 128 14
	movl	$56, %esi
	movl	$8, %edx
	movq	%rbx, %rdi
	.loc	19 128 14 epilogue_begin is_stmt 0
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmpq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp325:
.Lfunc_end18:
	.size	_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end18-_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc
	.file	30 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/alloc" "mod.rs"

	.section	.text._RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_,"ax",@progbits
	.p2align	4
	.type	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_,@function
_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_:
.Lfunc_begin19:
	.cfi_startproc
	.loc	9 2138 33 prologue_end is_stmt 1
	movq	(%rdi), %rdi
.Ltmp326:
	.loc	9 3353 12
	cmpq	$-1, %rdi
	je	.LBB19_2
.Ltmp327:
	.loc	10 3956 24
	lock		decq	8(%rdi)
.Ltmp328:
	.loc	9 3505 12
	jne	.LBB19_2
	#MEMBARRIER
.Ltmp329:
	.loc	19 128 14
	movl	$24, %esi
	movl	$8, %edx
	jmpq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.Ltmp330:
.LBB19_2:
	.loc	9 2144 6
	retq
.Ltmp331:
.Lfunc_end19:
	.size	_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_, .Lfunc_end19-_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_
	.cfi_endproc

	.section	.text._RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
	.p2align	4
	.type	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,@function
_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll:
.Lfunc_begin20:
	.loc	1 72 0
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	.loc	1 73 12 prologue_end
	movzbl	(%rdi), %ebx
	testb	%bl, %bl
	jne	.LBB20_2
	.loc	1 76 13
	movb	$1, (%rdi)
.Ltmp332:
	.loc	29 463 18
	movq	(%rsi), %rax
	.loc	29 463 50 is_stmt 0
	movq	8(%rsi), %rdi
	.loc	29 463 18
	callq	*16(%rax)
.Ltmp333:
.LBB20_2:
	.loc	1 80 6 is_stmt 1
	xorb	$1, %bl
	movl	%ebx, %eax
	.loc	1 80 6 epilogue_begin is_stmt 0
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Ltmp334:
.Lfunc_end20:
	.size	_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll, .Lfunc_end20-_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_:
.Lfunc_begin21:
	.file	31 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/fmt" "mod.rs"
	.loc	31 2872 0 is_stmt 1
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r13
	.cfi_def_cfa_offset 32
	pushq	%r12
	.cfi_def_cfa_offset 40
	pushq	%rbx
	.cfi_def_cfa_offset 48
	subq	$16, %rsp
	.cfi_def_cfa_offset 64
	.cfi_offset %rbx, -48
	.cfi_offset %r12, -40
	.cfi_offset %r13, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %rax
.Ltmp335:
	.loc	31 2872 71 prologue_end
	movq	(%rdi), %r9
.Ltmp336:
	.loc	1 218 5
	leaq	8(%r9), %r10
	.loc	1 219 5
	leaq	16(%r9), %rcx
	movq	%rcx, 8(%rsp)
	.loc	1 215 10
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.50(%rip), %r11
	leaq	16(%rsp), %rbx
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.54(%rip), %r14
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.49(%rip), %r15
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.53(%rip), %r12
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.48(%rip), %r13
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.51(%rip), %rsi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.52(%rip), %rcx
	movl	$10, %edx
	movl	$6, %r8d
	movq	%rax, %rdi
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	$15
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	pushq	%r15
	.cfi_adjust_cfa_offset 8
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	$14
	.cfi_adjust_cfa_offset 8
	pushq	%r12
	.cfi_adjust_cfa_offset 8
	pushq	%r13
	.cfi_adjust_cfa_offset 8
	callq	*_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter26debug_struct_field3_finish@GOTPCREL(%rip)
	addq	$96, %rsp
.Ltmp337:
	.cfi_adjust_cfa_offset -96
	.loc	31 2872 84 epilogue_begin
	popq	%rbx
	.cfi_def_cfa_offset 40
	popq	%r12
	.cfi_def_cfa_offset 32
	popq	%r13
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Ltmp338:
.Lfunc_end21:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_, .Lfunc_end21-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation:
.Lfunc_begin22:
	.cfi_startproc
	.loc	31 2872 71 prologue_end
	movq	(%rdi), %rdi
.Ltmp339:
	.loc	31 2405 9
	movl	16(%rsi), %eax
.Ltmp340:
	.file	32 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src/fmt" "num.rs"
	.loc	32 86 24
	testl	$33554432, %eax
	jne	.LBB22_3
	.loc	32 88 31
	testl	$67108864, %eax
	jne	.LBB22_2
	.loc	32 91 25
	jmpq	*_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB22_3:
	.loc	32 87 25
	jmpq	*_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB22_2:
	.loc	32 89 25
	jmpq	*_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Ltmp341:
.Lfunc_end22:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation, .Lfunc_end22-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation
	.cfi_endproc

	.section	.text._RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
	.p2align	4
	.type	_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,@function
_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll:
.Lfunc_begin23:
	.loc	1 145 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp342:
	.loc	1 146 13 prologue_end
	cmpb	$0, 24(%rdi)
	je	.LBB23_1
.Ltmp343:
	.loc	12 930 22
	movq	8(%rdi), %rdx
.Ltmp344:
	.file	33 "/local/home/ahrav/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/core/src" "option.rs"
	.loc	33 966 9
	cmpb	$0, (%rdi)
.Ltmp345:
	.loc	12 931 49
	movq	$0, (%rdi)
.Ltmp346:
	.loc	33 966 9
	je	.LBB23_9
.Ltmp347:
	.loc	33 0 9 is_stmt 0
	xorl	%eax, %eax
	.loc	1 157 6 epilogue_begin is_stmt 1
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB23_1:
	.cfi_def_cfa_offset 16
.Ltmp348:
	.loc	17 441 20
	movq	16(%rdi), %rax
.Ltmp349:
	.loc	26 2066 9
	cmpq	$0, 16(%rax)
	jne	.LBB23_10
.Ltmp350:
	.loc	12 931 49
	movq	$-1, 16(%rax)
.Ltmp351:
	.loc	21 1723 9
	movq	48(%rax), %rcx
.Ltmp352:
	.loc	21 2137 12
	testq	%rcx, %rcx
	je	.LBB23_3
	.loc	21 2140 28
	movq	40(%rax), %rdx
.Ltmp353:
	.loc	16 2584 13
	leaq	1(%rdx), %r8
.Ltmp354:
	.loc	20 619 49
	movq	24(%rax), %r9
.Ltmp355:
	.loc	20 614 9
	movq	32(%rax), %r10
	xorl	%r11d, %r11d
.Ltmp356:
	.loc	21 3639 12
	cmpq	%r9, %r8
	cmovaeq	%r9, %r11
	negq	%r11
	leaq	1(%rdx,%r11), %r8
.Ltmp357:
	.loc	21 2141 13
	movq	%r8, 40(%rax)
	.loc	21 2142 13
	decq	%rcx
	movq	%rcx, 48(%rax)
.Ltmp358:
	.loc	11 1733 9
	movq	(%r10,%rdx,8), %rcx
	movl	$1, %edx
	jmp	.LBB23_7
.Ltmp359:
.LBB23_3:
	.loc	11 0 9 is_stmt 0
	xorl	%edx, %edx
.LBB23_7:
.Ltmp360:
	.loc	12 931 49 is_stmt 1
	movq	$0, 16(%rax)
.Ltmp361:
	.loc	1 150 13
	movq	%rdx, (%rdi)
	movq	%rcx, 8(%rdi)
	.loc	1 151 13
	movb	$1, 24(%rdi)
.Ltmp362:
	.loc	29 463 18
	movq	(%rsi), %rax
	.loc	29 463 50 is_stmt 0
	movq	8(%rsi), %rdi
	.loc	29 463 18
	callq	*16(%rax)
	movl	$1, %eax
.Ltmp363:
	.loc	1 157 6 epilogue_begin is_stmt 1
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB23_9:
	.cfi_def_cfa_offset 16
.Ltmp364:
	.loc	33 968 21
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.43(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.44(%rip), %rdx
	movl	$25, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core6option13expect_failed@GOTPCREL(%rip)
.Ltmp365:
.LBB23_10:
	.loc	26 1224 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.42(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell22panic_already_borrowed@GOTPCREL(%rip)
.Ltmp366:
.Lfunc_end23:
	.size	_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll, .Lfunc_end23-_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	.cfi_endproc

	.section	.text._RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
	.p2align	4
	.type	_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,@function
_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll:
.Lfunc_begin24:
	.loc	1 179 0
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
.Ltmp367:
	.loc	1 180 13 prologue_end
	cmpb	$0, 8(%rdi)
	je	.LBB24_1
.Ltmp368:
	.loc	17 441 20
	movq	(%rdi), %rcx
.Ltmp369:
	.loc	26 2066 9
	cmpq	$0, 16(%rcx)
	jne	.LBB24_7
.Ltmp370:
	.loc	12 931 49
	movq	$-1, 16(%rcx)
.Ltmp371:
	.loc	21 1723 9
	movq	48(%rcx), %rdx
.Ltmp372:
	.loc	21 2137 12
	testq	%rdx, %rdx
	je	.LBB24_6
	.loc	21 2140 28
	movq	40(%rcx), %rsi
.Ltmp373:
	.loc	16 2584 13
	leaq	1(%rsi), %rdi
.Ltmp374:
	.loc	20 619 49
	movq	24(%rcx), %r8
.Ltmp375:
	.loc	20 614 9
	movq	32(%rcx), %r9
	xorl	%eax, %eax
.Ltmp376:
	.loc	21 3639 12
	cmpq	%r8, %rdi
	cmovbq	%rax, %r8
	negq	%r8
	leaq	1(%rsi,%r8), %rdi
.Ltmp377:
	.loc	21 2141 13
	movq	%rdi, 40(%rcx)
	.loc	21 2142 13
	decq	%rdx
	movq	%rdx, 48(%rcx)
.Ltmp378:
	.loc	11 1733 9
	movq	(%r9,%rsi,8), %rdx
.Ltmp379:
	.loc	12 931 49
	movq	$0, 16(%rcx)
.Ltmp380:
	.loc	1 194 6 epilogue_begin
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB24_1:
	.cfi_def_cfa_offset 16
	.loc	1 183 13
	movb	$1, 8(%rdi)
.Ltmp381:
	.loc	29 463 18
	movq	(%rsi), %rax
	.loc	29 463 50 is_stmt 0
	movq	8(%rsi), %rdi
	.loc	29 463 18
	callq	*16(%rax)
	movl	$1, %eax
.Ltmp382:
	.loc	1 194 6 epilogue_begin is_stmt 1
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB24_7:
	.cfi_def_cfa_offset 16
.Ltmp383:
	.loc	26 1224 25
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.47(%rip), %rdi
	callq	*_RNvNtCs4NRVxsYgnAr_4core4cell22panic_already_borrowed@GOTPCREL(%rip)
.Ltmp384:
.LBB24_6:
	.loc	33 968 21
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.45(%rip), %rdi
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.46(%rip), %rdx
	movl	$23, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core6option13expect_failed@GOTPCREL(%rip)
.Ltmp385:
.Lfunc_end24:
	.size	_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll, .Lfunc_end24-_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll
	.cfi_endproc

	.section	.text._RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt,@function
_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt:
.Lfunc_begin25:
	.cfi_startproc
	.loc	31 2405 9 prologue_end
	movl	16(%rsi), %eax
.Ltmp386:
	.loc	32 86 24
	testl	$33554432, %eax
	jne	.LBB25_3
	.loc	32 88 31
	testl	$67108864, %eax
	jne	.LBB25_2
	.loc	32 91 25
	jmpq	*_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB25_3:
	.loc	32 87 25
	jmpq	*_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB25_2:
	.loc	32 89 25
	jmpq	*_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Ltmp387:
.Lfunc_end25:
	.size	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt, .Lfunc_end25-_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text._RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt,@function
_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt:
.Lfunc_begin26:
	.cfi_startproc
	.loc	31 2405 9 prologue_end
	movl	16(%rsi), %eax
.Ltmp388:
	.loc	32 86 24
	testl	$33554432, %eax
	jne	.LBB26_3
	.loc	32 88 31
	testl	$67108864, %eax
	jne	.LBB26_2
	.loc	32 91 25
	jmpq	*_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB26_3:
	.loc	32 87 25
	jmpq	*_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB26_2:
	.loc	32 89 25
	jmpq	*_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Ltmp389:
.Lfunc_end26:
	.size	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt, .Lfunc_end26-_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text.main,"ax",@progbits
	.globl	main
	.p2align	4
	.type	main,@function
main:
.Lfunc_begin27:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	%rsi, %rcx
	movq	__rustc_debug_gdb_scripts_section__@GOTPCREL(%rip), %rax
	movzbl	(%rax), %eax
	movslq	%edi, %rdx
	leaq	_RNvCs6ruGKiyv7y9_22state_and_cancellation4main(%rip), %rax
	movq	%rax, (%rsp)
	leaq	.Lanon.f1f70e95970d5e61890f9e957ef4f787.0(%rip), %rsi
	movq	%rsp, %rdi
	xorl	%r8d, %r8d
	callq	*_RNvNtCs2AWtUsOyxgP_3std2rt19lang_start_internal@GOTPCREL(%rip)
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end27:
	.size	main, .Lfunc_end27-main
	.cfi_endproc

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.0,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.0,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation
	.quad	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation
	.quad	_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.0, 48

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.1,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.1,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.1, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.2,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.2,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.2:
	.quad	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_
	.quad	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_
	.quad	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_
	.quad	_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.2, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f1f70e95970d5e61890f9e957ef4f787.3:
	.asciz	"/tmp/topic41-async-T3xlijHO/results.work/archive/systems-snackpack-f03eb7c/topics/041-async-runtime-mechanics/examples/state_and_cancellation.rs"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3, 145

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.4,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.4,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.4:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000e\000\000\000:\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.4, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.5,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.5,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.5:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000o\000\000\000=\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.5, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.6,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.6,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.6:
	.ascii	"assertion failed: poll_once(left_future.as_mut(), cx).is_pending()"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.6, 66

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.7,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.7,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.7:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\373\000\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.7, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.8,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.8,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.8:
	.ascii	"assertion failed: poll_once(right_future.as_mut(), cx).is_pending()"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.8, 67

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.9,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.9,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.9:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\374\000\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.9, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.10,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.10,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.10:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\005\001\000\000\036\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.10, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.11,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.11,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.11:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\006\001\000\000 \000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.11, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.12,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.12,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.12:
	.ascii	"left safe future should now be ready"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.12, 36

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.13,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.13,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.13:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\377\000\000\000\032\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.13, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.14,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.14,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.14:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\345\000\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.14, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.15,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.15,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.15:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\346\000\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.15, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.16,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.16,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.16:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\357\000\000\000\036\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.16, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.17,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.17,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.17:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\360\000\000\000 \000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.17, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.18,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.18,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.18:
	.ascii	"left unsafe future should now be ready"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.18, 38

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.19,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.19,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.19:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\351\000\000\000\032\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.19, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.20,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.20,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.20:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\026\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.20, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.21,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.21:
	.asciz	"\000\370\007\000\000\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.21, 8

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.22,@object
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.22:
	.asciz	"\002\000\000\000\000\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.22, 8

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.23,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.23,"a",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.23:
	.asciz	"\013\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.23, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.24,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.24,"a",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.24:
	.asciz	"\013\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\001\000\000\000\000\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.24, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.25,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.25,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.25:
	.ascii	"experiment=topic41-async-state-and-cancellation\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.25, 48

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.26,@object
	.section	.rodata.cst8,"aM",@progbits,8
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.26:
	.asciz	"\000\020\000\000\000\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.26, 8

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.27,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lanon.f1f70e95970d5e61890f9e957ef4f787.27:
	.asciz	"\rbuffer_bytes=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.27, 18

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.28,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.28:
	.asciz	"\023future_large_bytes=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.28, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.29,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.29:
	.asciz	"\023future_small_bytes=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.29, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.30,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.30:
	.asciz	"\030future_size_delta_bytes=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.30, 29

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.31,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.31:
	.asciz	"\tchecksum=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.31, 14

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.32,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.32:
	.asciz	"\flarge_polls=\300\r small_polls=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.32, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.33,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.33:
	.asciz	"\023unsafe_race=winner:\300\020 left_remaining:\300\021 right_remaining:\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.33, 61

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.34,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.34:
	.asciz	"\021safe_race=winner:\300\020 left_remaining:\300\021 right_remaining:\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.34, 59

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.35,@object
.Lanon.f1f70e95970d5e61890f9e957ef4f787.35:
	.asciz	"\022wake_by_ref_calls=\300\001\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.35, 23

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.36,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.36,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.36:
	.ascii	"outcome=PASS\n"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.36, 13

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.37,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.37,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.37:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000'\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.37, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.38,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.38,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.38:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\037\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.38, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.39,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.39,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.39:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\031\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.39, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.40,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.40,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.40:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\030\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.40, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.41,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.41,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.41:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\027\001\000\000\005\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.41, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.42,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.42,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.42:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\225\000\000\000%\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.42, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.43,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.43,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.43:
	.ascii	"unsafe queue had one item"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.43, 25

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.44,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.44,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.44:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\234\000\000\000(\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.44, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.45,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.45,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.45:
	.ascii	"safe queue had one item"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.45, 23

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.46,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.46,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.46:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\300\000\000\000\022\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.46, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.47,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.47,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.47:
	.quad	.Lanon.f1f70e95970d5e61890f9e957ef4f787.3
	.asciz	"\220\000\000\000\000\000\000\000\276\000\000\000\022\000\000"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.47, 24

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.48,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.48,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.48:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.48, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.49,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.49,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.49:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.49, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.50,@object
	.section	.data.rel.ro..Lanon.f1f70e95970d5e61890f9e957ef4f787.50,"aw",@progbits
	.p2align	3, 0x0
.Lanon.f1f70e95970d5e61890f9e957ef4f787.50:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.50, 32

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.51,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.51,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.51:
	.ascii	"RaceResult"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.51, 10

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.52,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.52,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.52:
	.ascii	"winner"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.52, 6

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.53,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.53,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.53:
	.ascii	"left_remaining"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.53, 14

	.type	.Lanon.f1f70e95970d5e61890f9e957ef4f787.54,@object
	.section	.rodata..Lanon.f1f70e95970d5e61890f9e957ef4f787.54,"a",@progbits
.Lanon.f1f70e95970d5e61890f9e957ef4f787.54:
	.ascii	"right_remaining"
	.size	.Lanon.f1f70e95970d5e61890f9e957ef4f787.54, 15

	.type	__rustc_debug_gdb_scripts_section__,@object
	.section	.debug_gdb_scripts,"aMS",@progbits,1,unique,1
	.weak	__rustc_debug_gdb_scripts_section__
__rustc_debug_gdb_scripts_section__:
	.asciz	"\001gdb_load_rust_pretty_printers.py"
	.size	__rustc_debug_gdb_scripts_section__, 34

	.section	.debug_abbrev,"",@progbits
	.byte	1
	.byte	17
	.byte	1
	.byte	37
	.byte	14
	.byte	19
	.byte	5
	.byte	3
	.byte	14
	.byte	16
	.byte	23
	.byte	27
	.byte	14
	.byte	17
	.byte	1
	.byte	85
	.byte	23
	.byte	0
	.byte	0
	.byte	2
	.byte	57
	.byte	1
	.byte	3
	.byte	14
	.byte	0
	.byte	0
	.byte	3
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	4
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	0
	.byte	0
	.byte	5
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	6
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	7
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	11
	.byte	0
	.byte	0
	.byte	8
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	9
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	10
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	11
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	12
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	13
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	14
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	15
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	0
	.byte	0
	.byte	16
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	5
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	17
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	106
	.byte	25
	.byte	0
	.byte	0
	.byte	18
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	19
	.byte	29
	.byte	0
	.byte	49
	.byte	19
	.byte	85
	.byte	23
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.byte	0
	.byte	0
	.byte	20
	.byte	29
	.byte	1
	.byte	49
	.byte	19
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	88
	.byte	11
	.byte	89
	.byte	11
	.byte	87
	.byte	11
	.ascii	"\266B"
	.byte	11
	.byte	0
	.byte	0
	.byte	21
	.byte	46
	.byte	0
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	32
	.byte	11
	.byte	0
	.byte	0
	.byte	22
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	54
	.byte	11
	.ascii	"\207\001"
	.byte	25
	.byte	0
	.byte	0
	.byte	23
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	110
	.byte	14
	.byte	3
	.byte	14
	.byte	58
	.byte	11
	.byte	59
	.byte	5
	.byte	0
	.byte	0
	.byte	24
	.byte	46
	.byte	1
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	25
	.byte	46
	.byte	0
	.byte	17
	.byte	1
	.byte	18
	.byte	6
	.byte	64
	.byte	24
	.byte	49
	.byte	19
	.byte	0
	.byte	0
	.byte	0
	.section	.debug_info,"",@progbits
.Lcu_begin0:
	.long	.Ldebug_info_end0-.Ldebug_info_start0
.Ldebug_info_start0:
	.short	4
	.long	.debug_abbrev
	.byte	8
	.byte	1
	.long	.Linfo_string0
	.short	28
	.long	.Linfo_string1
	.long	.Lline_table_start0
	.long	.Linfo_string2
	.quad	0
	.long	.Ldebug_ranges37
	.byte	2
	.long	.Linfo_string3
	.byte	2
	.long	.Linfo_string4
	.byte	3
	.long	.Linfo_string5
	.long	.Linfo_string6
	.byte	1
	.byte	101
	.byte	1
	.byte	0
	.byte	4
	.quad	.Lfunc_begin0
	.long	.Lfunc_end0-.Lfunc_begin0
	.byte	1
	.byte	87
	.long	.Linfo_string408
	.long	.Linfo_string409
	.byte	1
	.byte	198
	.byte	5
	.long	52
	.long	.Ldebug_ranges0
	.byte	1
	.byte	199
	.byte	12
	.byte	6
	.long	9758
	.quad	.Ltmp6
	.long	.Ltmp7-.Ltmp6
	.byte	1
	.byte	104
	.byte	5
	.byte	6
	.long	9771
	.quad	.Ltmp10
	.long	.Ltmp11-.Ltmp10
	.byte	1
	.byte	106
	.byte	14
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string13
	.byte	3
	.long	.Linfo_string14
	.long	.Linfo_string6
	.byte	1
	.byte	111
	.byte	1
	.byte	0
	.byte	4
	.quad	.Lfunc_begin1
	.long	.Lfunc_end1-.Lfunc_begin1
	.byte	5
	.byte	156
	.byte	17
	.ascii	"\320_"
	.byte	34
	.long	.Linfo_string410
	.long	.Linfo_string411
	.byte	1
	.byte	198
	.byte	5
	.long	149
	.long	.Ldebug_ranges1
	.byte	1
	.byte	199
	.byte	12
	.byte	6
	.long	9758
	.quad	.Ltmp21
	.long	.Ltmp22-.Ltmp21
	.byte	1
	.byte	115
	.byte	9
	.byte	6
	.long	9771
	.quad	.Ltmp22
	.long	.Ltmp23-.Ltmp22
	.byte	1
	.byte	116
	.byte	18
	.byte	0
	.byte	0
	.byte	7
	.quad	.Lfunc_begin2
	.long	.Lfunc_end2-.Lfunc_begin2
	.byte	1
	.byte	87
	.long	.Linfo_string412
	.long	.Linfo_string413
	.byte	1
	.byte	198
	.byte	7
	.quad	.Lfunc_begin3
	.long	.Lfunc_end3-.Lfunc_begin3
	.byte	1
	.byte	87
	.long	.Linfo_string414
	.long	.Linfo_string415
	.byte	1
	.byte	198
	.byte	2
	.long	.Linfo_string77
	.byte	3
	.long	.Linfo_string78
	.long	.Linfo_string79
	.byte	1
	.byte	52
	.byte	1
	.byte	3
	.long	.Linfo_string82
	.long	.Linfo_string83
	.byte	1
	.byte	48
	.byte	1
	.byte	0
	.byte	4
	.quad	.Lfunc_begin13
	.long	.Lfunc_end13-.Lfunc_begin13
	.byte	1
	.byte	87
	.long	.Linfo_string429
	.long	.Linfo_string430
	.byte	1
	.byte	84
	.byte	5
	.long	10961
	.long	.Ldebug_ranges3
	.byte	1
	.byte	85
	.byte	26
	.byte	5
	.long	10908
	.long	.Ldebug_ranges3
	.byte	18
	.byte	80
	.byte	27
	.byte	6
	.long	10032
	.quad	.Ltmp70
	.long	.Ltmp71-.Ltmp70
	.byte	15
	.byte	185
	.byte	40
	.byte	0
	.byte	0
	.byte	6
	.long	10987
	.quad	.Ltmp66
	.long	.Ltmp68-.Ltmp66
	.byte	1
	.byte	86
	.byte	49
	.byte	6
	.long	11000
	.quad	.Ltmp68
	.long	.Ltmp69-.Ltmp68
	.byte	1
	.byte	86
	.byte	22
	.byte	0
	.byte	4
	.quad	.Lfunc_begin14
	.long	.Lfunc_end14-.Lfunc_begin14
	.byte	1
	.byte	87
	.long	.Linfo_string431
	.long	.Linfo_string432
	.byte	1
	.byte	245
	.byte	8
	.long	13830
	.quad	.Ltmp74
	.long	.Ltmp79-.Ltmp74
	.byte	1
	.byte	246
	.byte	37
	.byte	9
	.long	13698
	.quad	.Ltmp74
	.long	.Ltmp77-.Ltmp74
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp74
	.long	.Ltmp77-.Ltmp74
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp74
	.long	.Ltmp77-.Ltmp74
	.byte	21
	.short	914
	.byte	18
	.byte	8
	.long	13527
	.quad	.Ltmp74
	.long	.Ltmp77-.Ltmp74
	.byte	20
	.byte	177
	.byte	20
	.byte	9
	.long	13514
	.quad	.Ltmp74
	.long	.Ltmp76-.Ltmp74
	.byte	20
	.short	434
	.byte	15
	.byte	9
	.long	13451
	.quad	.Ltmp74
	.long	.Ltmp75-.Ltmp74
	.byte	20
	.short	465
	.byte	47
	.byte	9
	.long	13394
	.quad	.Ltmp74
	.long	.Ltmp75-.Ltmp74
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp74
	.long	.Ltmp75-.Ltmp74
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp74
	.long	.Ltmp75-.Ltmp74
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.long	10118
	.quad	.Ltmp78
	.long	.Ltmp79-.Ltmp78
	.byte	21
	.short	4008
	.byte	17
	.byte	0
	.byte	8
	.long	14087
	.quad	.Ltmp79
	.long	.Ltmp84-.Ltmp79
	.byte	1
	.byte	246
	.byte	16
	.byte	9
	.long	13887
	.quad	.Ltmp79
	.long	.Ltmp83-.Ltmp79
	.byte	23
	.short	426
	.byte	27
	.byte	9
	.long	13870
	.quad	.Ltmp79
	.long	.Ltmp81-.Ltmp79
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp79
	.long	.Ltmp80-.Ltmp79
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp79
	.long	.Ltmp80-.Ltmp79
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp79
	.long	.Ltmp80-.Ltmp79
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp79
	.long	.Ltmp80-.Ltmp79
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14113
	.quad	.Ltmp83
	.long	.Ltmp84-.Ltmp83
	.byte	23
	.short	425
	.byte	13
	.byte	10
	.long	14100
	.quad	.Ltmp83
	.long	.Ltmp84-.Ltmp83
	.byte	23
	.short	358
	.byte	18
	.byte	0
	.byte	0
	.byte	8
	.long	13830
	.quad	.Ltmp84
	.long	.Ltmp89-.Ltmp84
	.byte	1
	.byte	247
	.byte	38
	.byte	9
	.long	13698
	.quad	.Ltmp84
	.long	.Ltmp87-.Ltmp84
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp84
	.long	.Ltmp87-.Ltmp84
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp84
	.long	.Ltmp87-.Ltmp84
	.byte	21
	.short	914
	.byte	18
	.byte	8
	.long	13527
	.quad	.Ltmp84
	.long	.Ltmp87-.Ltmp84
	.byte	20
	.byte	177
	.byte	20
	.byte	9
	.long	13514
	.quad	.Ltmp84
	.long	.Ltmp86-.Ltmp84
	.byte	20
	.short	434
	.byte	15
	.byte	9
	.long	13451
	.quad	.Ltmp84
	.long	.Ltmp85-.Ltmp84
	.byte	20
	.short	465
	.byte	47
	.byte	9
	.long	13394
	.quad	.Ltmp84
	.long	.Ltmp85-.Ltmp84
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp84
	.long	.Ltmp85-.Ltmp84
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp84
	.long	.Ltmp85-.Ltmp84
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.long	10118
	.quad	.Ltmp88
	.long	.Ltmp89-.Ltmp88
	.byte	21
	.short	4008
	.byte	17
	.byte	0
	.byte	8
	.long	14087
	.quad	.Ltmp89
	.long	.Ltmp94-.Ltmp89
	.byte	1
	.byte	247
	.byte	17
	.byte	9
	.long	13887
	.quad	.Ltmp89
	.long	.Ltmp93-.Ltmp89
	.byte	23
	.short	426
	.byte	27
	.byte	9
	.long	13870
	.quad	.Ltmp89
	.long	.Ltmp91-.Ltmp89
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp89
	.long	.Ltmp90-.Ltmp89
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp89
	.long	.Ltmp90-.Ltmp89
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp89
	.long	.Ltmp90-.Ltmp89
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp89
	.long	.Ltmp90-.Ltmp89
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	11
	.long	14113
	.quad	.Ltmp93
	.long	.Ltmp94-.Ltmp93
	.byte	23
	.short	425
	.byte	13
	.byte	2
	.byte	12
	.long	14100
	.quad	.Ltmp93
	.long	.Ltmp94-.Ltmp93
	.byte	23
	.short	358
	.byte	18
	.byte	2
	.byte	0
	.byte	0
	.byte	8
	.long	14766
	.quad	.Ltmp94
	.long	.Ltmp96-.Ltmp94
	.byte	1
	.byte	248
	.byte	50
	.byte	9
	.long	14708
	.quad	.Ltmp94
	.long	.Ltmp96-.Ltmp94
	.byte	23
	.short	2519
	.byte	26
	.byte	9
	.long	11108
	.quad	.Ltmp94
	.long	.Ltmp95-.Ltmp94
	.byte	23
	.short	3775
	.byte	27
	.byte	9
	.long	11095
	.quad	.Ltmp94
	.long	.Ltmp95-.Ltmp94
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10710
	.quad	.Ltmp94
	.long	.Ltmp95-.Ltmp94
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	10
	.long	11470
	.quad	.Ltmp95
	.long	.Ltmp96-.Ltmp95
	.byte	23
	.short	3780
	.byte	12
	.byte	0
	.byte	0
	.byte	8
	.long	13913
	.quad	.Ltmp96
	.long	.Ltmp100-.Ltmp96
	.byte	1
	.byte	248
	.byte	27
	.byte	9
	.long	13900
	.quad	.Ltmp96
	.long	.Ltmp100-.Ltmp96
	.byte	22
	.short	356
	.byte	9
	.byte	9
	.long	13870
	.quad	.Ltmp96
	.long	.Ltmp98-.Ltmp96
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp96
	.long	.Ltmp97-.Ltmp96
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp96
	.long	.Ltmp97-.Ltmp96
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp96
	.long	.Ltmp97-.Ltmp96
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp96
	.long	.Ltmp97-.Ltmp96
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	14766
	.quad	.Ltmp100
	.long	.Ltmp102-.Ltmp100
	.byte	1
	.byte	249
	.byte	51
	.byte	11
	.long	14708
	.quad	.Ltmp100
	.long	.Ltmp102-.Ltmp100
	.byte	23
	.short	2519
	.byte	26
	.byte	2
	.byte	11
	.long	11108
	.quad	.Ltmp100
	.long	.Ltmp101-.Ltmp100
	.byte	23
	.short	3775
	.byte	27
	.byte	2
	.byte	11
	.long	11095
	.quad	.Ltmp100
	.long	.Ltmp101-.Ltmp100
	.byte	26
	.short	437
	.byte	14
	.byte	2
	.byte	12
	.long	10710
	.quad	.Ltmp100
	.long	.Ltmp101-.Ltmp100
	.byte	26
	.short	513
	.byte	9
	.byte	2
	.byte	0
	.byte	0
	.byte	12
	.long	11470
	.quad	.Ltmp101
	.long	.Ltmp102-.Ltmp101
	.byte	23
	.short	3780
	.byte	12
	.byte	2
	.byte	0
	.byte	0
	.byte	8
	.long	13913
	.quad	.Ltmp102
	.long	.Ltmp106-.Ltmp102
	.byte	1
	.byte	249
	.byte	28
	.byte	9
	.long	13900
	.quad	.Ltmp102
	.long	.Ltmp106-.Ltmp102
	.byte	22
	.short	356
	.byte	9
	.byte	9
	.long	13870
	.quad	.Ltmp102
	.long	.Ltmp104-.Ltmp102
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp102
	.long	.Ltmp103-.Ltmp102
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp102
	.long	.Ltmp103-.Ltmp102
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp102
	.long	.Ltmp103-.Ltmp102
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp102
	.long	.Ltmp103-.Ltmp102
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	11524
	.quad	.Ltmp107
	.long	.Ltmp108-.Ltmp107
	.byte	1
	.byte	251
	.byte	49
	.byte	6
	.long	11512
	.quad	.Ltmp107
	.long	.Ltmp108-.Ltmp107
	.byte	28
	.byte	96
	.byte	15
	.byte	0
	.byte	8
	.long	11524
	.quad	.Ltmp109
	.long	.Ltmp110-.Ltmp109
	.byte	1
	.byte	252
	.byte	50
	.byte	13
	.long	11512
	.quad	.Ltmp109
	.long	.Ltmp110-.Ltmp109
	.byte	28
	.byte	96
	.byte	15
	.byte	2
	.byte	0
	.byte	9
	.long	10723
	.quad	.Ltmp111
	.long	.Ltmp116-.Ltmp111
	.byte	1
	.short	257
	.byte	5
	.byte	9
	.long	10170
	.quad	.Ltmp111
	.long	.Ltmp116-.Ltmp111
	.byte	12
	.short	1004
	.byte	1
	.byte	9
	.long	10157
	.quad	.Ltmp111
	.long	.Ltmp116-.Ltmp111
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10144
	.quad	.Ltmp111
	.long	.Ltmp114-.Ltmp111
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10131
	.quad	.Ltmp111
	.long	.Ltmp114-.Ltmp111
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14798
	.quad	.Ltmp111
	.long	.Ltmp114-.Ltmp111
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14126
	.quad	.Ltmp111
	.long	.Ltmp112-.Ltmp111
	.byte	23
	.short	2492
	.byte	18
	.byte	10
	.long	10045
	.quad	.Ltmp111
	.long	.Ltmp112-.Ltmp111
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	9
	.long	14721
	.quad	.Ltmp112
	.long	.Ltmp113-.Ltmp112
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp112
	.long	.Ltmp113-.Ltmp112
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp112
	.long	.Ltmp113-.Ltmp112
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp112
	.long	.Ltmp113-.Ltmp112
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14023
	.quad	.Ltmp115
	.long	.Ltmp116-.Ltmp115
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp115
	.long	.Ltmp116-.Ltmp115
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp115
	.long	.Ltmp116-.Ltmp115
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp115
	.long	.Ltmp116-.Ltmp115
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp115
	.long	.Ltmp116-.Ltmp115
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	11315
	.long	.Ldebug_ranges4
	.byte	1
	.short	261
	.byte	30
	.byte	9
	.long	11302
	.quad	.Ltmp116
	.long	.Ltmp121-.Ltmp116
	.byte	26
	.short	1122
	.byte	20
	.byte	9
	.long	11283
	.quad	.Ltmp116
	.long	.Ltmp121-.Ltmp116
	.byte	26
	.short	1159
	.byte	15
	.byte	10
	.long	11147
	.quad	.Ltmp116
	.long	.Ltmp117-.Ltmp116
	.byte	26
	.short	1559
	.byte	24
	.byte	10
	.long	11381
	.quad	.Ltmp117
	.long	.Ltmp118-.Ltmp117
	.byte	26
	.short	1560
	.byte	13
	.byte	9
	.long	11160
	.quad	.Ltmp120
	.long	.Ltmp121-.Ltmp120
	.byte	26
	.short	1575
	.byte	20
	.byte	10
	.long	10749
	.quad	.Ltmp120
	.long	.Ltmp121-.Ltmp120
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	10
	.long	11019
	.quad	.Ltmp119
	.long	.Ltmp120-.Ltmp119
	.byte	26
	.short	1559
	.byte	30
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	11315
	.long	.Ldebug_ranges5
	.byte	1
	.short	262
	.byte	32
	.byte	9
	.long	11302
	.quad	.Ltmp121
	.long	.Ltmp124-.Ltmp121
	.byte	26
	.short	1122
	.byte	20
	.byte	9
	.long	11283
	.quad	.Ltmp121
	.long	.Ltmp124-.Ltmp121
	.byte	26
	.short	1159
	.byte	15
	.byte	10
	.long	11147
	.quad	.Ltmp121
	.long	.Ltmp122-.Ltmp121
	.byte	26
	.short	1559
	.byte	24
	.byte	10
	.long	11381
	.quad	.Ltmp122
	.long	.Ltmp123-.Ltmp122
	.byte	26
	.short	1560
	.byte	13
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.long	13711
	.quad	.Ltmp124
	.long	.Ltmp125-.Ltmp124
	.byte	1
	.short	261
	.byte	39
	.byte	10
	.long	13711
	.quad	.Ltmp125
	.long	.Ltmp126-.Ltmp125
	.byte	1
	.short	262
	.byte	41
	.byte	9
	.long	10196
	.quad	.Ltmp127
	.long	.Ltmp128-.Ltmp127
	.byte	1
	.short	263
	.byte	5
	.byte	9
	.long	10183
	.quad	.Ltmp127
	.long	.Ltmp128-.Ltmp127
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11399
	.quad	.Ltmp127
	.long	.Ltmp128-.Ltmp127
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11173
	.quad	.Ltmp127
	.long	.Ltmp128-.Ltmp127
	.byte	26
	.short	1587
	.byte	21
	.byte	10
	.long	10762
	.quad	.Ltmp127
	.long	.Ltmp128-.Ltmp127
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	10196
	.quad	.Ltmp128
	.long	.Ltmp129-.Ltmp128
	.byte	1
	.short	263
	.byte	5
	.byte	9
	.long	10183
	.quad	.Ltmp128
	.long	.Ltmp129-.Ltmp128
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11399
	.quad	.Ltmp128
	.long	.Ltmp129-.Ltmp128
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11173
	.quad	.Ltmp128
	.long	.Ltmp129-.Ltmp128
	.byte	26
	.short	1587
	.byte	21
	.byte	10
	.long	10762
	.quad	.Ltmp128
	.long	.Ltmp129-.Ltmp128
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	10170
	.quad	.Ltmp129
	.long	.Ltmp133-.Ltmp129
	.byte	1
	.short	264
	.byte	1
	.byte	9
	.long	10157
	.quad	.Ltmp129
	.long	.Ltmp133-.Ltmp129
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10144
	.quad	.Ltmp129
	.long	.Ltmp132-.Ltmp129
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10131
	.quad	.Ltmp129
	.long	.Ltmp132-.Ltmp129
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14798
	.quad	.Ltmp129
	.long	.Ltmp132-.Ltmp129
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14126
	.quad	.Ltmp129
	.long	.Ltmp130-.Ltmp129
	.byte	23
	.short	2492
	.byte	18
	.byte	10
	.long	10045
	.quad	.Ltmp129
	.long	.Ltmp130-.Ltmp129
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	9
	.long	14721
	.quad	.Ltmp130
	.long	.Ltmp131-.Ltmp130
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp130
	.long	.Ltmp131-.Ltmp130
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp130
	.long	.Ltmp131-.Ltmp130
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp130
	.long	.Ltmp131-.Ltmp130
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14023
	.quad	.Ltmp132
	.long	.Ltmp133-.Ltmp132
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp132
	.long	.Ltmp133-.Ltmp132
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp132
	.long	.Ltmp133-.Ltmp132
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp132
	.long	.Ltmp133-.Ltmp132
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp132
	.long	.Ltmp133-.Ltmp132
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	14766
	.quad	.Ltmp143
	.long	.Ltmp144-.Ltmp143
	.byte	1
	.byte	0
	.byte	10
	.long	14708
	.quad	.Ltmp143
	.long	.Ltmp144-.Ltmp143
	.byte	23
	.short	2519
	.byte	26
	.byte	0
	.byte	15
	.long	13913
	.quad	.Ltmp144
	.long	.Ltmp145-.Ltmp144
	.byte	1
	.byte	0
	.byte	9
	.long	13900
	.quad	.Ltmp144
	.long	.Ltmp145-.Ltmp144
	.byte	22
	.short	356
	.byte	9
	.byte	10
	.long	13870
	.quad	.Ltmp144
	.long	.Ltmp145-.Ltmp144
	.byte	22
	.short	286
	.byte	19
	.byte	0
	.byte	0
	.byte	14
	.long	10131
	.long	.Ldebug_ranges6
	.byte	1
	.short	264
	.byte	1
	.byte	14
	.long	14798
	.long	.Ldebug_ranges6
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14721
	.quad	.Ltmp133
	.long	.Ltmp134-.Ltmp133
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp133
	.long	.Ltmp134-.Ltmp133
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp133
	.long	.Ltmp134-.Ltmp133
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp133
	.long	.Ltmp134-.Ltmp133
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	10131
	.long	.Ldebug_ranges7
	.byte	1
	.short	264
	.byte	1
	.byte	14
	.long	14798
	.long	.Ldebug_ranges7
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	14721
	.long	.Ldebug_ranges8
	.byte	23
	.short	2492
	.byte	26
	.byte	14
	.long	11134
	.long	.Ldebug_ranges8
	.byte	23
	.short	3787
	.byte	27
	.byte	14
	.long	11121
	.long	.Ldebug_ranges8
	.byte	26
	.short	437
	.byte	14
	.byte	16
	.long	10736
	.long	.Ldebug_ranges8
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	13830
	.quad	.Ltmp141
	.long	.Ltmp142-.Ltmp141
	.byte	1
	.byte	0
	.byte	9
	.long	13698
	.quad	.Ltmp141
	.long	.Ltmp142-.Ltmp141
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp141
	.long	.Ltmp142-.Ltmp141
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp141
	.long	.Ltmp142-.Ltmp141
	.byte	21
	.short	914
	.byte	18
	.byte	6
	.long	13527
	.quad	.Ltmp141
	.long	.Ltmp142-.Ltmp141
	.byte	20
	.byte	177
	.byte	20
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	14087
	.quad	.Ltmp142
	.long	.Ltmp143-.Ltmp142
	.byte	1
	.byte	0
	.byte	9
	.long	13887
	.quad	.Ltmp142
	.long	.Ltmp143-.Ltmp142
	.byte	23
	.short	426
	.byte	27
	.byte	10
	.long	13870
	.quad	.Ltmp142
	.long	.Ltmp143-.Ltmp142
	.byte	22
	.short	286
	.byte	19
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.quad	.Lfunc_begin15
	.long	.Lfunc_end15-.Lfunc_begin15
	.byte	1
	.byte	87
	.long	.Linfo_string433
	.long	.Linfo_string434
	.byte	1
	.byte	223
	.byte	8
	.long	13830
	.quad	.Ltmp149
	.long	.Ltmp154-.Ltmp149
	.byte	1
	.byte	224
	.byte	37
	.byte	9
	.long	13698
	.quad	.Ltmp149
	.long	.Ltmp152-.Ltmp149
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp149
	.long	.Ltmp152-.Ltmp149
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp149
	.long	.Ltmp152-.Ltmp149
	.byte	21
	.short	914
	.byte	18
	.byte	8
	.long	13527
	.quad	.Ltmp149
	.long	.Ltmp152-.Ltmp149
	.byte	20
	.byte	177
	.byte	20
	.byte	9
	.long	13514
	.quad	.Ltmp149
	.long	.Ltmp151-.Ltmp149
	.byte	20
	.short	434
	.byte	15
	.byte	9
	.long	13451
	.quad	.Ltmp149
	.long	.Ltmp150-.Ltmp149
	.byte	20
	.short	465
	.byte	47
	.byte	9
	.long	13394
	.quad	.Ltmp149
	.long	.Ltmp150-.Ltmp149
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp149
	.long	.Ltmp150-.Ltmp149
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp149
	.long	.Ltmp150-.Ltmp149
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.long	10118
	.quad	.Ltmp153
	.long	.Ltmp154-.Ltmp153
	.byte	21
	.short	4008
	.byte	17
	.byte	0
	.byte	8
	.long	14139
	.quad	.Ltmp154
	.long	.Ltmp159-.Ltmp154
	.byte	1
	.byte	224
	.byte	16
	.byte	9
	.long	13887
	.quad	.Ltmp154
	.long	.Ltmp158-.Ltmp154
	.byte	23
	.short	426
	.byte	27
	.byte	9
	.long	13870
	.quad	.Ltmp154
	.long	.Ltmp156-.Ltmp154
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp154
	.long	.Ltmp155-.Ltmp154
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp154
	.long	.Ltmp155-.Ltmp154
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp154
	.long	.Ltmp155-.Ltmp154
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp154
	.long	.Ltmp155-.Ltmp154
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14165
	.quad	.Ltmp158
	.long	.Ltmp159-.Ltmp158
	.byte	23
	.short	425
	.byte	13
	.byte	10
	.long	14152
	.quad	.Ltmp158
	.long	.Ltmp159-.Ltmp158
	.byte	23
	.short	358
	.byte	18
	.byte	0
	.byte	0
	.byte	8
	.long	13830
	.quad	.Ltmp159
	.long	.Ltmp164-.Ltmp159
	.byte	1
	.byte	225
	.byte	38
	.byte	9
	.long	13698
	.quad	.Ltmp159
	.long	.Ltmp162-.Ltmp159
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp159
	.long	.Ltmp162-.Ltmp159
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp159
	.long	.Ltmp162-.Ltmp159
	.byte	21
	.short	914
	.byte	18
	.byte	8
	.long	13527
	.quad	.Ltmp159
	.long	.Ltmp162-.Ltmp159
	.byte	20
	.byte	177
	.byte	20
	.byte	9
	.long	13514
	.quad	.Ltmp159
	.long	.Ltmp161-.Ltmp159
	.byte	20
	.short	434
	.byte	15
	.byte	9
	.long	13451
	.quad	.Ltmp159
	.long	.Ltmp160-.Ltmp159
	.byte	20
	.short	465
	.byte	47
	.byte	9
	.long	13394
	.quad	.Ltmp159
	.long	.Ltmp160-.Ltmp159
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp159
	.long	.Ltmp160-.Ltmp159
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp159
	.long	.Ltmp160-.Ltmp159
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	10
	.long	10118
	.quad	.Ltmp163
	.long	.Ltmp164-.Ltmp163
	.byte	21
	.short	4008
	.byte	17
	.byte	0
	.byte	8
	.long	14139
	.quad	.Ltmp164
	.long	.Ltmp169-.Ltmp164
	.byte	1
	.byte	225
	.byte	17
	.byte	9
	.long	13887
	.quad	.Ltmp164
	.long	.Ltmp168-.Ltmp164
	.byte	23
	.short	426
	.byte	27
	.byte	9
	.long	13870
	.quad	.Ltmp164
	.long	.Ltmp166-.Ltmp164
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp164
	.long	.Ltmp165-.Ltmp164
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp164
	.long	.Ltmp165-.Ltmp164
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp164
	.long	.Ltmp165-.Ltmp164
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp164
	.long	.Ltmp165-.Ltmp164
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	11
	.long	14165
	.quad	.Ltmp168
	.long	.Ltmp169-.Ltmp168
	.byte	23
	.short	425
	.byte	13
	.byte	2
	.byte	12
	.long	14152
	.quad	.Ltmp168
	.long	.Ltmp169-.Ltmp168
	.byte	23
	.short	358
	.byte	18
	.byte	2
	.byte	0
	.byte	0
	.byte	8
	.long	14779
	.quad	.Ltmp169
	.long	.Ltmp171-.Ltmp169
	.byte	1
	.byte	226
	.byte	52
	.byte	9
	.long	14734
	.quad	.Ltmp169
	.long	.Ltmp171-.Ltmp169
	.byte	23
	.short	2519
	.byte	26
	.byte	9
	.long	11199
	.quad	.Ltmp169
	.long	.Ltmp170-.Ltmp169
	.byte	23
	.short	3775
	.byte	27
	.byte	9
	.long	11186
	.quad	.Ltmp169
	.long	.Ltmp170-.Ltmp169
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10775
	.quad	.Ltmp169
	.long	.Ltmp170-.Ltmp169
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	10
	.long	11483
	.quad	.Ltmp170
	.long	.Ltmp171-.Ltmp170
	.byte	23
	.short	3780
	.byte	12
	.byte	0
	.byte	0
	.byte	8
	.long	13939
	.quad	.Ltmp171
	.long	.Ltmp175-.Ltmp171
	.byte	1
	.byte	226
	.byte	27
	.byte	9
	.long	13926
	.quad	.Ltmp171
	.long	.Ltmp175-.Ltmp171
	.byte	22
	.short	356
	.byte	9
	.byte	9
	.long	13870
	.quad	.Ltmp171
	.long	.Ltmp173-.Ltmp171
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp171
	.long	.Ltmp172-.Ltmp171
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp171
	.long	.Ltmp172-.Ltmp171
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp171
	.long	.Ltmp172-.Ltmp171
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp171
	.long	.Ltmp172-.Ltmp171
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	14779
	.quad	.Ltmp175
	.long	.Ltmp177-.Ltmp175
	.byte	1
	.byte	227
	.byte	53
	.byte	11
	.long	14734
	.quad	.Ltmp175
	.long	.Ltmp177-.Ltmp175
	.byte	23
	.short	2519
	.byte	26
	.byte	2
	.byte	11
	.long	11199
	.quad	.Ltmp175
	.long	.Ltmp176-.Ltmp175
	.byte	23
	.short	3775
	.byte	27
	.byte	2
	.byte	11
	.long	11186
	.quad	.Ltmp175
	.long	.Ltmp176-.Ltmp175
	.byte	26
	.short	437
	.byte	14
	.byte	2
	.byte	12
	.long	10775
	.quad	.Ltmp175
	.long	.Ltmp176-.Ltmp175
	.byte	26
	.short	513
	.byte	9
	.byte	2
	.byte	0
	.byte	0
	.byte	12
	.long	11483
	.quad	.Ltmp176
	.long	.Ltmp177-.Ltmp176
	.byte	23
	.short	3780
	.byte	12
	.byte	2
	.byte	0
	.byte	0
	.byte	8
	.long	13939
	.quad	.Ltmp177
	.long	.Ltmp181-.Ltmp177
	.byte	1
	.byte	227
	.byte	28
	.byte	9
	.long	13926
	.quad	.Ltmp177
	.long	.Ltmp181-.Ltmp177
	.byte	22
	.short	356
	.byte	9
	.byte	9
	.long	13870
	.quad	.Ltmp177
	.long	.Ltmp179-.Ltmp177
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp177
	.long	.Ltmp178-.Ltmp177
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp177
	.long	.Ltmp178-.Ltmp177
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp177
	.long	.Ltmp178-.Ltmp177
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp177
	.long	.Ltmp178-.Ltmp177
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	11548
	.quad	.Ltmp182
	.long	.Ltmp183-.Ltmp182
	.byte	1
	.byte	229
	.byte	49
	.byte	6
	.long	11536
	.quad	.Ltmp182
	.long	.Ltmp183-.Ltmp182
	.byte	28
	.byte	96
	.byte	15
	.byte	0
	.byte	8
	.long	11548
	.quad	.Ltmp184
	.long	.Ltmp185-.Ltmp184
	.byte	1
	.byte	230
	.byte	50
	.byte	13
	.long	11536
	.quad	.Ltmp184
	.long	.Ltmp185-.Ltmp184
	.byte	28
	.byte	96
	.byte	15
	.byte	2
	.byte	0
	.byte	8
	.long	10788
	.quad	.Ltmp187
	.long	.Ltmp192-.Ltmp187
	.byte	1
	.byte	235
	.byte	5
	.byte	9
	.long	10235
	.quad	.Ltmp187
	.long	.Ltmp192-.Ltmp187
	.byte	12
	.short	1004
	.byte	1
	.byte	9
	.long	10222
	.quad	.Ltmp187
	.long	.Ltmp192-.Ltmp187
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10209
	.quad	.Ltmp187
	.long	.Ltmp190-.Ltmp187
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10131
	.quad	.Ltmp187
	.long	.Ltmp190-.Ltmp187
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14798
	.quad	.Ltmp187
	.long	.Ltmp190-.Ltmp187
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14126
	.quad	.Ltmp187
	.long	.Ltmp188-.Ltmp187
	.byte	23
	.short	2492
	.byte	18
	.byte	10
	.long	10045
	.quad	.Ltmp187
	.long	.Ltmp188-.Ltmp187
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	9
	.long	14721
	.quad	.Ltmp188
	.long	.Ltmp189-.Ltmp188
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp188
	.long	.Ltmp189-.Ltmp188
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp188
	.long	.Ltmp189-.Ltmp188
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp188
	.long	.Ltmp189-.Ltmp188
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14036
	.quad	.Ltmp191
	.long	.Ltmp192-.Ltmp191
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp191
	.long	.Ltmp192-.Ltmp191
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp191
	.long	.Ltmp192-.Ltmp191
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp191
	.long	.Ltmp192-.Ltmp191
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp191
	.long	.Ltmp192-.Ltmp191
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	5
	.long	11315
	.long	.Ldebug_ranges9
	.byte	1
	.byte	239
	.byte	30
	.byte	9
	.long	11302
	.quad	.Ltmp192
	.long	.Ltmp197-.Ltmp192
	.byte	26
	.short	1122
	.byte	20
	.byte	9
	.long	11283
	.quad	.Ltmp192
	.long	.Ltmp197-.Ltmp192
	.byte	26
	.short	1159
	.byte	15
	.byte	10
	.long	11147
	.quad	.Ltmp192
	.long	.Ltmp193-.Ltmp192
	.byte	26
	.short	1559
	.byte	24
	.byte	10
	.long	11381
	.quad	.Ltmp193
	.long	.Ltmp194-.Ltmp193
	.byte	26
	.short	1560
	.byte	13
	.byte	9
	.long	11160
	.quad	.Ltmp196
	.long	.Ltmp197-.Ltmp196
	.byte	26
	.short	1575
	.byte	20
	.byte	10
	.long	10749
	.quad	.Ltmp196
	.long	.Ltmp197-.Ltmp196
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	10
	.long	11019
	.quad	.Ltmp195
	.long	.Ltmp196-.Ltmp195
	.byte	26
	.short	1559
	.byte	30
	.byte	0
	.byte	0
	.byte	0
	.byte	5
	.long	11315
	.long	.Ldebug_ranges10
	.byte	1
	.byte	240
	.byte	32
	.byte	9
	.long	11302
	.quad	.Ltmp197
	.long	.Ltmp200-.Ltmp197
	.byte	26
	.short	1122
	.byte	20
	.byte	9
	.long	11283
	.quad	.Ltmp197
	.long	.Ltmp200-.Ltmp197
	.byte	26
	.short	1159
	.byte	15
	.byte	10
	.long	11147
	.quad	.Ltmp197
	.long	.Ltmp198-.Ltmp197
	.byte	26
	.short	1559
	.byte	24
	.byte	10
	.long	11381
	.quad	.Ltmp198
	.long	.Ltmp199-.Ltmp198
	.byte	26
	.short	1560
	.byte	13
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.long	13724
	.quad	.Ltmp201
	.long	.Ltmp202-.Ltmp201
	.byte	1
	.byte	239
	.byte	39
	.byte	6
	.long	13724
	.quad	.Ltmp202
	.long	.Ltmp203-.Ltmp202
	.byte	1
	.byte	240
	.byte	41
	.byte	8
	.long	10196
	.quad	.Ltmp204
	.long	.Ltmp205-.Ltmp204
	.byte	1
	.byte	241
	.byte	5
	.byte	9
	.long	10183
	.quad	.Ltmp204
	.long	.Ltmp205-.Ltmp204
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11399
	.quad	.Ltmp204
	.long	.Ltmp205-.Ltmp204
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11173
	.quad	.Ltmp204
	.long	.Ltmp205-.Ltmp204
	.byte	26
	.short	1587
	.byte	21
	.byte	10
	.long	10762
	.quad	.Ltmp204
	.long	.Ltmp205-.Ltmp204
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	10196
	.quad	.Ltmp205
	.long	.Ltmp206-.Ltmp205
	.byte	1
	.byte	241
	.byte	5
	.byte	9
	.long	10183
	.quad	.Ltmp205
	.long	.Ltmp206-.Ltmp205
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11399
	.quad	.Ltmp205
	.long	.Ltmp206-.Ltmp205
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11173
	.quad	.Ltmp205
	.long	.Ltmp206-.Ltmp205
	.byte	26
	.short	1587
	.byte	21
	.byte	10
	.long	10762
	.quad	.Ltmp205
	.long	.Ltmp206-.Ltmp205
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	10235
	.quad	.Ltmp206
	.long	.Ltmp210-.Ltmp206
	.byte	1
	.byte	242
	.byte	1
	.byte	9
	.long	10222
	.quad	.Ltmp206
	.long	.Ltmp210-.Ltmp206
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10209
	.quad	.Ltmp206
	.long	.Ltmp209-.Ltmp206
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10131
	.quad	.Ltmp206
	.long	.Ltmp209-.Ltmp206
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14798
	.quad	.Ltmp206
	.long	.Ltmp209-.Ltmp206
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14126
	.quad	.Ltmp206
	.long	.Ltmp207-.Ltmp206
	.byte	23
	.short	2492
	.byte	18
	.byte	10
	.long	10045
	.quad	.Ltmp206
	.long	.Ltmp207-.Ltmp206
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	9
	.long	14721
	.quad	.Ltmp207
	.long	.Ltmp208-.Ltmp207
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp207
	.long	.Ltmp208-.Ltmp207
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp207
	.long	.Ltmp208-.Ltmp207
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp207
	.long	.Ltmp208-.Ltmp207
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	14036
	.quad	.Ltmp209
	.long	.Ltmp210-.Ltmp209
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp209
	.long	.Ltmp210-.Ltmp209
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp209
	.long	.Ltmp210-.Ltmp209
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp209
	.long	.Ltmp210-.Ltmp209
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp209
	.long	.Ltmp210-.Ltmp209
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	14779
	.quad	.Ltmp220
	.long	.Ltmp221-.Ltmp220
	.byte	1
	.byte	0
	.byte	10
	.long	14734
	.quad	.Ltmp220
	.long	.Ltmp221-.Ltmp220
	.byte	23
	.short	2519
	.byte	26
	.byte	0
	.byte	15
	.long	13939
	.quad	.Ltmp221
	.long	.Ltmp222-.Ltmp221
	.byte	1
	.byte	0
	.byte	9
	.long	13926
	.quad	.Ltmp221
	.long	.Ltmp222-.Ltmp221
	.byte	22
	.short	356
	.byte	9
	.byte	10
	.long	13870
	.quad	.Ltmp221
	.long	.Ltmp222-.Ltmp221
	.byte	22
	.short	286
	.byte	19
	.byte	0
	.byte	0
	.byte	5
	.long	10131
	.long	.Ldebug_ranges11
	.byte	1
	.byte	242
	.byte	1
	.byte	14
	.long	14798
	.long	.Ldebug_ranges11
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14721
	.quad	.Ltmp210
	.long	.Ltmp211-.Ltmp210
	.byte	23
	.short	2492
	.byte	26
	.byte	9
	.long	11134
	.quad	.Ltmp210
	.long	.Ltmp211-.Ltmp210
	.byte	23
	.short	3787
	.byte	27
	.byte	9
	.long	11121
	.quad	.Ltmp210
	.long	.Ltmp211-.Ltmp210
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10736
	.quad	.Ltmp210
	.long	.Ltmp211-.Ltmp210
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	5
	.long	10131
	.long	.Ldebug_ranges12
	.byte	1
	.byte	242
	.byte	1
	.byte	14
	.long	14798
	.long	.Ldebug_ranges12
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	14721
	.long	.Ldebug_ranges13
	.byte	23
	.short	2492
	.byte	26
	.byte	14
	.long	11134
	.long	.Ldebug_ranges13
	.byte	23
	.short	3787
	.byte	27
	.byte	14
	.long	11121
	.long	.Ldebug_ranges13
	.byte	26
	.short	437
	.byte	14
	.byte	16
	.long	10736
	.long	.Ldebug_ranges13
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	13830
	.quad	.Ltmp218
	.long	.Ltmp219-.Ltmp218
	.byte	1
	.byte	0
	.byte	9
	.long	13698
	.quad	.Ltmp218
	.long	.Ltmp219-.Ltmp218
	.byte	21
	.short	4003
	.byte	23
	.byte	9
	.long	13685
	.quad	.Ltmp218
	.long	.Ltmp219-.Ltmp218
	.byte	21
	.short	846
	.byte	9
	.byte	9
	.long	13611
	.quad	.Ltmp218
	.long	.Ltmp219-.Ltmp218
	.byte	21
	.short	914
	.byte	18
	.byte	6
	.long	13527
	.quad	.Ltmp218
	.long	.Ltmp219-.Ltmp218
	.byte	20
	.byte	177
	.byte	20
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	15
	.long	14139
	.quad	.Ltmp219
	.long	.Ltmp220-.Ltmp219
	.byte	1
	.byte	0
	.byte	9
	.long	13887
	.quad	.Ltmp219
	.long	.Ltmp220-.Ltmp219
	.byte	23
	.short	426
	.byte	27
	.byte	10
	.long	13870
	.quad	.Ltmp219
	.long	.Ltmp220-.Ltmp219
	.byte	22
	.short	286
	.byte	19
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string249
	.byte	3
	.long	.Linfo_string250
	.long	.Linfo_string209
	.byte	1
	.byte	40
	.byte	1
	.byte	0
	.byte	3
	.long	.Linfo_string264
	.long	.Linfo_string265
	.byte	1
	.byte	203
	.byte	1
	.byte	3
	.long	.Linfo_string276
	.long	.Linfo_string277
	.byte	1
	.byte	203
	.byte	1
	.byte	2
	.long	.Linfo_string202
	.byte	3
	.long	.Linfo_string284
	.long	.Linfo_string285
	.byte	1
	.byte	215
	.byte	1
	.byte	0
	.byte	17
	.quad	.Lfunc_begin16
	.long	.Lfunc_end16-.Lfunc_begin16
	.byte	1
	.byte	87
	.long	.Linfo_string435
	.long	.Linfo_string436
	.byte	1
	.short	266

	.byte	14
	.long	6926
	.long	.Ldebug_ranges14
	.byte	1
	.short	267
	.byte	16
	.byte	5
	.long	12248
	.long	.Ldebug_ranges14
	.byte	1
	.byte	41
	.byte	9
	.byte	14
	.long	13952
	.long	.Ldebug_ranges14
	.byte	9
	.short	427
	.byte	25
	.byte	14
	.long	13870
	.long	.Ldebug_ranges15
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Lfunc_begin16
	.long	.Ltmp226-.Lfunc_begin16
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Lfunc_begin16
	.long	.Ltmp226-.Lfunc_begin16
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Lfunc_begin16
	.long	.Ltmp226-.Lfunc_begin16
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Lfunc_begin16
	.long	.Ltmp226-.Lfunc_begin16
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	12542
	.long	.Ldebug_ranges16
	.byte	1
	.short	268
	.byte	29
	.byte	9
	.long	10524
	.quad	.Ltmp230
	.long	.Ltmp231-.Ltmp230
	.byte	9
	.short	2411
	.byte	44
	.byte	10
	.long	10603
	.quad	.Ltmp230
	.long	.Ltmp231-.Ltmp230
	.byte	10
	.short	3162
	.byte	26
	.byte	0
	.byte	0
	.byte	9
	.long	13346
	.quad	.Ltmp233
	.long	.Ltmp234-.Ltmp233
	.byte	1
	.short	268
	.byte	17
	.byte	6
	.long	11572
	.quad	.Ltmp233
	.long	.Ltmp234-.Ltmp233
	.byte	7
	.byte	117
	.byte	18
	.byte	0
	.byte	10
	.long	10801
	.quad	.Ltmp234
	.long	.Ltmp235-.Ltmp234
	.byte	1
	.short	273
	.byte	22
	.byte	10
	.long	10814
	.quad	.Ltmp235
	.long	.Ltmp236-.Ltmp235
	.byte	1
	.short	274
	.byte	22
	.byte	14
	.long	6939
	.long	.Ldebug_ranges17
	.byte	1
	.short	276
	.byte	36
	.byte	5
	.long	13978
	.long	.Ldebug_ranges18
	.byte	1
	.byte	204
	.byte	22
	.byte	14
	.long	13965
	.long	.Ldebug_ranges18
	.byte	22
	.short	356
	.byte	9
	.byte	14
	.long	13870
	.long	.Ldebug_ranges19
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp236
	.long	.Ltmp237-.Ltmp236
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp236
	.long	.Ltmp237-.Ltmp236
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp236
	.long	.Ltmp237-.Ltmp236
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp236
	.long	.Ltmp237-.Ltmp236
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	10261
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	1
	.byte	213
	.byte	1
	.byte	9
	.long	10248
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14049
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp242
	.long	.Ltmp243-.Ltmp242
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	6951
	.long	.Ldebug_ranges20
	.byte	1
	.short	277
	.byte	36
	.byte	5
	.long	14004
	.long	.Ldebug_ranges21
	.byte	1
	.byte	204
	.byte	22
	.byte	14
	.long	13991
	.long	.Ldebug_ranges21
	.byte	22
	.short	356
	.byte	9
	.byte	14
	.long	13870
	.long	.Ldebug_ranges22
	.byte	22
	.short	286
	.byte	19
	.byte	8
	.long	13464
	.quad	.Ltmp244
	.long	.Ltmp245-.Ltmp244
	.byte	22
	.byte	248
	.byte	18
	.byte	9
	.long	13407
	.quad	.Ltmp244
	.long	.Ltmp245-.Ltmp244
	.byte	19
	.short	449
	.byte	14
	.byte	9
	.long	13382
	.quad	.Ltmp244
	.long	.Ltmp245-.Ltmp244
	.byte	19
	.short	332
	.byte	9
	.byte	6
	.long	13365
	.quad	.Ltmp244
	.long	.Ltmp245-.Ltmp244
	.byte	19
	.byte	210
	.byte	73
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	10287
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	1
	.byte	213
	.byte	1
	.byte	9
	.long	10274
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	14062
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13477
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	22
	.short	1956
	.byte	24
	.byte	9
	.long	13432
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp250
	.long	.Ltmp251-.Ltmp250
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	16
	.long	6968
	.long	.Ldebug_ranges23
	.byte	1
	.short	287
	.byte	5
	.byte	16
	.long	6968
	.long	.Ldebug_ranges24
	.byte	1
	.short	295
	.byte	5
	.byte	9
	.long	10537
	.quad	.Ltmp277
	.long	.Ltmp279-.Ltmp277
	.byte	1
	.short	319
	.byte	49
	.byte	10
	.long	10616
	.quad	.Ltmp277
	.long	.Ltmp278-.Ltmp277
	.byte	10
	.short	2870
	.byte	26
	.byte	0
	.byte	9
	.long	10300
	.quad	.Ltmp281
	.long	.Ltmp284-.Ltmp281
	.byte	1
	.short	321
	.byte	1
	.byte	9
	.long	11630
	.quad	.Ltmp281
	.long	.Ltmp284-.Ltmp281
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	13328
	.quad	.Ltmp281
	.long	.Ltmp284-.Ltmp281
	.byte	29
	.short	674
	.byte	18
	.byte	8
	.long	12196
	.quad	.Ltmp281
	.long	.Ltmp284-.Ltmp281
	.byte	7
	.byte	209
	.byte	18
	.byte	9
	.long	12183
	.quad	.Ltmp281
	.long	.Ltmp284-.Ltmp281
	.byte	9
	.short	1767
	.byte	18
	.byte	9
	.long	10649
	.quad	.Ltmp282
	.long	.Ltmp284-.Ltmp282
	.byte	9
	.short	2117
	.byte	18
	.byte	9
	.long	10009
	.quad	.Ltmp282
	.long	.Ltmp284-.Ltmp282
	.byte	12
	.short	1004
	.byte	1
	.byte	9
	.long	12510
	.quad	.Ltmp282
	.long	.Ltmp284-.Ltmp282
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10472
	.quad	.Ltmp282
	.long	.Ltmp283-.Ltmp282
	.byte	9
	.short	2831
	.byte	32
	.byte	10
	.long	10454
	.quad	.Ltmp282
	.long	.Ltmp283-.Ltmp282
	.byte	10
	.short	3193
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	10009
	.quad	.Ltmp284
	.long	.Ltmp286-.Ltmp284
	.byte	1
	.short	321
	.byte	1
	.byte	9
	.long	12510
	.quad	.Ltmp284
	.long	.Ltmp286-.Ltmp284
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10472
	.quad	.Ltmp284
	.long	.Ltmp285-.Ltmp284
	.byte	9
	.short	2831
	.byte	32
	.byte	10
	.long	10454
	.quad	.Ltmp284
	.long	.Ltmp285-.Ltmp284
	.byte	10
	.short	3193
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.quad	.Lfunc_begin17
	.long	.Lfunc_end17-.Lfunc_begin17
	.byte	1
	.byte	87
	.long	.Linfo_string437
	.long	.Linfo_string438
	.byte	1
	.byte	91
	.byte	6
	.long	9797
	.quad	.Ltmp308
	.long	.Ltmp309-.Ltmp308
	.byte	1
	.byte	95
	.byte	42
	.byte	6
	.long	11038
	.quad	.Ltmp309
	.long	.Ltmp310-.Ltmp309
	.byte	1
	.byte	95
	.byte	19
	.byte	18
	.long	10926
	.long	.Ldebug_ranges25
	.byte	1
	.byte	94
	.byte	17
	.byte	2
	.byte	6
	.long	10058
	.quad	.Ltmp307
	.long	.Ltmp308-.Ltmp307
	.byte	15
	.byte	185
	.byte	40
	.byte	6
	.long	10103
	.quad	.Ltmp310
	.long	.Ltmp311-.Ltmp310
	.byte	15
	.byte	180
	.byte	28
	.byte	0
	.byte	6
	.long	9810
	.quad	.Ltmp312
	.long	.Ltmp313-.Ltmp312
	.byte	1
	.byte	97
	.byte	5
	.byte	0
	.byte	2
	.long	.Linfo_string312
	.byte	4
	.quad	.Lfunc_begin20
	.long	.Lfunc_end20-.Lfunc_begin20
	.byte	1
	.byte	87
	.long	.Linfo_string443
	.long	.Linfo_string169
	.byte	1
	.byte	72
	.byte	6
	.long	11585
	.quad	.Ltmp332
	.long	.Ltmp333-.Ltmp332
	.byte	1
	.byte	77
	.byte	24
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string346
	.byte	3
	.long	.Linfo_string347
	.long	.Linfo_string348
	.byte	1
	.byte	215
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string217
	.byte	4
	.quad	.Lfunc_begin23
	.long	.Lfunc_end23-.Lfunc_begin23
	.byte	1
	.byte	87
	.long	.Linfo_string448
	.long	.Linfo_string169
	.byte	1
	.byte	145
	.byte	5
	.long	11961
	.long	.Ldebug_ranges29
	.byte	1
	.byte	156
	.byte	33
	.byte	16
	.long	10840
	.long	.Ldebug_ranges29
	.byte	33
	.short	1898
	.byte	9
	.byte	0
	.byte	19
	.long	11974
	.long	.Ldebug_ranges30
	.byte	1
	.byte	156
	.byte	40
	.byte	20
	.long	14855
	.quad	.Ltmp348
	.long	.Ltmp349-.Ltmp348
	.byte	1
	.byte	149
	.byte	26
	.byte	2
	.byte	9
	.long	14676
	.quad	.Ltmp348
	.long	.Ltmp349-.Ltmp348
	.byte	23
	.short	2441
	.byte	15
	.byte	10
	.long	10071
	.quad	.Ltmp348
	.long	.Ltmp349-.Ltmp348
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	0
	.byte	5
	.long	11341
	.long	.Ldebug_ranges31
	.byte	1
	.byte	149
	.byte	37
	.byte	9
	.long	11328
	.quad	.Ltmp349
	.long	.Ltmp351-.Ltmp349
	.byte	26
	.short	1222
	.byte	20
	.byte	9
	.long	11418
	.quad	.Ltmp349
	.long	.Ltmp351-.Ltmp349
	.byte	26
	.short	1256
	.byte	15
	.byte	9
	.long	11238
	.quad	.Ltmp350
	.long	.Ltmp351-.Ltmp350
	.byte	26
	.short	2068
	.byte	24
	.byte	10
	.long	10853
	.quad	.Ltmp350
	.long	.Ltmp351-.Ltmp350
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	13750
	.quad	.Ltmp351
	.long	.Ltmp359-.Ltmp351
	.byte	1
	.byte	149
	.byte	50
	.byte	10
	.long	13737
	.quad	.Ltmp351
	.long	.Ltmp352-.Ltmp351
	.byte	21
	.short	2137
	.byte	17
	.byte	14
	.long	13775
	.long	.Ldebug_ranges32
	.byte	21
	.short	2141
	.byte	30
	.byte	5
	.long	13763
	.long	.Ldebug_ranges32
	.byte	21
	.byte	249
	.byte	14
	.byte	6
	.long	11070
	.quad	.Ltmp353
	.long	.Ltmp354-.Ltmp353
	.byte	21
	.byte	244
	.byte	35
	.byte	8
	.long	13787
	.quad	.Ltmp354
	.long	.Ltmp355-.Ltmp354
	.byte	21
	.byte	244
	.byte	62
	.byte	9
	.long	13623
	.quad	.Ltmp354
	.long	.Ltmp355-.Ltmp354
	.byte	21
	.short	1053
	.byte	53
	.byte	10
	.long	13566
	.quad	.Ltmp354
	.long	.Ltmp355-.Ltmp354
	.byte	20
	.short	309
	.byte	20
	.byte	0
	.byte	0
	.byte	6
	.long	13849
	.quad	.Ltmp356
	.long	.Ltmp357-.Ltmp356
	.byte	21
	.byte	244
	.byte	9
	.byte	0
	.byte	0
	.byte	14
	.long	13812
	.long	.Ldebug_ranges33
	.byte	21
	.short	2145
	.byte	27
	.byte	8
	.long	13800
	.quad	.Ltmp355
	.long	.Ltmp356-.Ltmp355
	.byte	21
	.byte	209
	.byte	33
	.byte	8
	.long	13636
	.quad	.Ltmp355
	.long	.Ltmp356-.Ltmp355
	.byte	21
	.byte	174
	.byte	18
	.byte	9
	.long	13592
	.quad	.Ltmp355
	.long	.Ltmp356-.Ltmp355
	.byte	20
	.short	296
	.byte	20
	.byte	10
	.long	13579
	.quad	.Ltmp355
	.long	.Ltmp356-.Ltmp355
	.byte	20
	.short	609
	.byte	14
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.long	10404
	.quad	.Ltmp358
	.long	.Ltmp359-.Ltmp358
	.byte	21
	.byte	209
	.byte	18
	.byte	0
	.byte	0
	.byte	8
	.long	10430
	.quad	.Ltmp360
	.long	.Ltmp361-.Ltmp360
	.byte	1
	.byte	149
	.byte	61
	.byte	9
	.long	10417
	.quad	.Ltmp360
	.long	.Ltmp361-.Ltmp360
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11450
	.quad	.Ltmp360
	.long	.Ltmp361-.Ltmp360
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11251
	.quad	.Ltmp360
	.long	.Ltmp361-.Ltmp360
	.byte	26
	.short	2055
	.byte	21
	.byte	10
	.long	10866
	.quad	.Ltmp360
	.long	.Ltmp361-.Ltmp360
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.long	11598
	.quad	.Ltmp362
	.long	.Ltmp363-.Ltmp362
	.byte	1
	.byte	152
	.byte	24
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string406
	.byte	4
	.quad	.Lfunc_begin24
	.long	.Lfunc_end24-.Lfunc_begin24
	.byte	1
	.byte	87
	.long	.Linfo_string449
	.long	.Linfo_string169
	.byte	1
	.byte	179
	.byte	20
	.long	14868
	.quad	.Ltmp368
	.long	.Ltmp369-.Ltmp368
	.byte	1
	.byte	189
	.byte	13
	.byte	2
	.byte	9
	.long	14689
	.quad	.Ltmp368
	.long	.Ltmp369-.Ltmp368
	.byte	23
	.short	2441
	.byte	15
	.byte	10
	.long	10084
	.quad	.Ltmp368
	.long	.Ltmp369-.Ltmp368
	.byte	23
	.short	372
	.byte	27
	.byte	0
	.byte	0
	.byte	5
	.long	11367
	.long	.Ldebug_ranges34
	.byte	1
	.byte	190
	.byte	18
	.byte	9
	.long	11354
	.quad	.Ltmp369
	.long	.Ltmp371-.Ltmp369
	.byte	26
	.short	1222
	.byte	20
	.byte	9
	.long	11431
	.quad	.Ltmp369
	.long	.Ltmp371-.Ltmp369
	.byte	26
	.short	1256
	.byte	15
	.byte	9
	.long	11264
	.quad	.Ltmp370
	.long	.Ltmp371-.Ltmp370
	.byte	26
	.short	2068
	.byte	24
	.byte	10
	.long	10879
	.quad	.Ltmp370
	.long	.Ltmp371-.Ltmp370
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	13750
	.quad	.Ltmp371
	.long	.Ltmp379-.Ltmp371
	.byte	1
	.byte	191
	.byte	18
	.byte	10
	.long	13737
	.quad	.Ltmp371
	.long	.Ltmp372-.Ltmp371
	.byte	21
	.short	2137
	.byte	17
	.byte	14
	.long	13775
	.long	.Ldebug_ranges35
	.byte	21
	.short	2141
	.byte	30
	.byte	5
	.long	13763
	.long	.Ldebug_ranges35
	.byte	21
	.byte	249
	.byte	14
	.byte	6
	.long	11070
	.quad	.Ltmp373
	.long	.Ltmp374-.Ltmp373
	.byte	21
	.byte	244
	.byte	35
	.byte	8
	.long	13787
	.quad	.Ltmp374
	.long	.Ltmp375-.Ltmp374
	.byte	21
	.byte	244
	.byte	62
	.byte	9
	.long	13623
	.quad	.Ltmp374
	.long	.Ltmp375-.Ltmp374
	.byte	21
	.short	1053
	.byte	53
	.byte	10
	.long	13566
	.quad	.Ltmp374
	.long	.Ltmp375-.Ltmp374
	.byte	20
	.short	309
	.byte	20
	.byte	0
	.byte	0
	.byte	6
	.long	13849
	.quad	.Ltmp376
	.long	.Ltmp377-.Ltmp376
	.byte	21
	.byte	244
	.byte	9
	.byte	0
	.byte	0
	.byte	14
	.long	13812
	.long	.Ldebug_ranges36
	.byte	21
	.short	2145
	.byte	27
	.byte	8
	.long	13800
	.quad	.Ltmp375
	.long	.Ltmp376-.Ltmp375
	.byte	21
	.byte	209
	.byte	33
	.byte	8
	.long	13636
	.quad	.Ltmp375
	.long	.Ltmp376-.Ltmp375
	.byte	21
	.byte	174
	.byte	18
	.byte	9
	.long	13592
	.quad	.Ltmp375
	.long	.Ltmp376-.Ltmp375
	.byte	20
	.short	296
	.byte	20
	.byte	10
	.long	13579
	.quad	.Ltmp375
	.long	.Ltmp376-.Ltmp375
	.byte	20
	.short	609
	.byte	14
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.long	10404
	.quad	.Ltmp378
	.long	.Ltmp379-.Ltmp378
	.byte	21
	.byte	209
	.byte	18
	.byte	0
	.byte	0
	.byte	8
	.long	10430
	.quad	.Ltmp379
	.long	.Ltmp380-.Ltmp379
	.byte	1
	.byte	193
	.byte	9
	.byte	9
	.long	10417
	.quad	.Ltmp379
	.long	.Ltmp380-.Ltmp379
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11450
	.quad	.Ltmp379
	.long	.Ltmp380-.Ltmp379
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	11251
	.quad	.Ltmp379
	.long	.Ltmp380-.Ltmp379
	.byte	26
	.short	2055
	.byte	21
	.byte	10
	.long	10866
	.quad	.Ltmp379
	.long	.Ltmp380-.Ltmp379
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	6
	.long	11611
	.quad	.Ltmp381
	.long	.Ltmp382-.Ltmp381
	.byte	1
	.byte	184
	.byte	24
	.byte	6
	.long	11987
	.quad	.Ltmp384
	.long	.Ltmp385-.Ltmp384
	.byte	1
	.byte	192
	.byte	18
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string7
	.byte	2
	.long	.Linfo_string8
	.byte	21
	.long	.Linfo_string9
	.long	.Linfo_string10
	.byte	2
	.short	490
	.byte	1
	.byte	21
	.long	.Linfo_string11
	.long	.Linfo_string12
	.byte	2
	.short	490
	.byte	1
	.byte	21
	.long	.Linfo_string23
	.long	.Linfo_string24
	.byte	2
	.short	490
	.byte	1
	.byte	21
	.long	.Linfo_string297
	.long	.Linfo_string298
	.byte	2
	.short	490
	.byte	1
	.byte	21
	.long	.Linfo_string304
	.long	.Linfo_string305
	.byte	2
	.short	490
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string17
	.byte	22
	.quad	.Lfunc_begin5
	.long	.Lfunc_end5-.Lfunc_begin5
	.byte	1
	.byte	87
	.long	.Linfo_string418
	.long	.Linfo_string419
	.byte	4
	.short	384
	.byte	3

	.byte	0
	.byte	2
	.long	.Linfo_string18
	.byte	2
	.long	.Linfo_string19
	.byte	2
	.long	.Linfo_string20
	.byte	3
	.long	.Linfo_string21
	.long	.Linfo_string22
	.byte	6
	.byte	250
	.byte	1
	.byte	3
	.long	.Linfo_string87
	.long	.Linfo_string88
	.byte	6
	.byte	250
	.byte	1
	.byte	4
	.quad	.Lfunc_begin12
	.long	.Lfunc_end12-.Lfunc_begin12
	.byte	1
	.byte	87
	.long	.Linfo_string428
	.long	.Linfo_string88
	.byte	6
	.byte	250
	.byte	8
	.long	9884
	.quad	.Ltmp62
	.long	.Ltmp63-.Ltmp62
	.byte	6
	.byte	250
	.byte	5
	.byte	6
	.long	12062
	.quad	.Ltmp62
	.long	.Ltmp63-.Ltmp62
	.byte	6
	.byte	250
	.byte	5
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string27
	.byte	2
	.long	.Linfo_string28
	.byte	2
	.long	.Linfo_string29
	.byte	21
	.long	.Linfo_string30
	.long	.Linfo_string31
	.byte	8
	.short	935
	.byte	1
	.byte	21
	.long	.Linfo_string32
	.long	.Linfo_string33
	.byte	8
	.short	993
	.byte	1
	.byte	0
	.byte	0
	.byte	21
	.long	.Linfo_string52
	.long	.Linfo_string53
	.byte	11
	.short	825
	.byte	1
	.byte	2
	.long	.Linfo_string104
	.byte	2
	.long	.Linfo_string105
	.byte	21
	.long	.Linfo_string106
	.long	.Linfo_string107
	.byte	17
	.short	648
	.byte	1
	.byte	21
	.long	.Linfo_string175
	.long	.Linfo_string176
	.byte	17
	.short	437
	.byte	1
	.byte	21
	.long	.Linfo_string106
	.long	.Linfo_string107
	.byte	17
	.short	648
	.byte	1
	.byte	21
	.long	.Linfo_string175
	.long	.Linfo_string176
	.byte	17
	.short	437
	.byte	1
	.byte	21
	.long	.Linfo_string175
	.long	.Linfo_string176
	.byte	17
	.short	437
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string301
	.byte	21
	.long	.Linfo_string302
	.long	.Linfo_string303
	.byte	17
	.short	1713
	.byte	1
	.byte	0
	.byte	0
	.byte	21
	.long	.Linfo_string134
	.long	.Linfo_string135
	.byte	11
	.short	530
	.byte	1
	.byte	21
	.long	.Linfo_string182
	.long	.Linfo_string183
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string184
	.long	.Linfo_string185
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string186
	.long	.Linfo_string187
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string188
	.long	.Linfo_string189
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string227
	.long	.Linfo_string228
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string229
	.long	.Linfo_string230
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string235
	.long	.Linfo_string236
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string237
	.long	.Linfo_string238
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string239
	.long	.Linfo_string240
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string268
	.long	.Linfo_string269
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string270
	.long	.Linfo_string271
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string280
	.long	.Linfo_string281
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string282
	.long	.Linfo_string283
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string293
	.long	.Linfo_string294
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string306
	.long	.Linfo_string307
	.byte	11
	.short	808
	.byte	1
	.byte	21
	.long	.Linfo_string315
	.long	.Linfo_string316
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string317
	.long	.Linfo_string318
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string319
	.long	.Linfo_string320
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string321
	.long	.Linfo_string322
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string332
	.long	.Linfo_string333
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string343
	.long	.Linfo_string344
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string398
	.long	.Linfo_string399
	.byte	11
	.short	1694
	.byte	1
	.byte	21
	.long	.Linfo_string402
	.long	.Linfo_string403
	.byte	11
	.short	825
	.byte	1
	.byte	21
	.long	.Linfo_string404
	.long	.Linfo_string405
	.byte	11
	.short	825
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string35
	.byte	2
	.long	.Linfo_string43
	.byte	21
	.long	.Linfo_string44
	.long	.Linfo_string45
	.byte	10
	.short	3950
	.byte	1
	.byte	2
	.long	.Linfo_string46
	.byte	21
	.long	.Linfo_string47
	.long	.Linfo_string48
	.byte	10
	.short	3191
	.byte	1
	.byte	21
	.long	.Linfo_string61
	.long	.Linfo_string62
	.byte	10
	.short	3160
	.byte	1
	.byte	21
	.long	.Linfo_string61
	.long	.Linfo_string62
	.byte	10
	.short	3160
	.byte	1
	.byte	21
	.long	.Linfo_string61
	.long	.Linfo_string62
	.byte	10
	.short	3160
	.byte	1
	.byte	21
	.long	.Linfo_string61
	.long	.Linfo_string62
	.byte	10
	.short	3160
	.byte	1
	.byte	21
	.long	.Linfo_string288
	.long	.Linfo_string289
	.byte	10
	.short	2868
	.byte	1
	.byte	21
	.long	.Linfo_string47
	.long	.Linfo_string48
	.byte	10
	.short	3191
	.byte	1
	.byte	0
	.byte	21
	.long	.Linfo_string59
	.long	.Linfo_string60
	.byte	10
	.short	3933
	.byte	1
	.byte	21
	.long	.Linfo_string59
	.long	.Linfo_string60
	.byte	10
	.short	3933
	.byte	1
	.byte	21
	.long	.Linfo_string59
	.long	.Linfo_string60
	.byte	10
	.short	3933
	.byte	1
	.byte	21
	.long	.Linfo_string59
	.long	.Linfo_string60
	.byte	10
	.short	3933
	.byte	1
	.byte	21
	.long	.Linfo_string286
	.long	.Linfo_string287
	.byte	10
	.short	3900
	.byte	1
	.byte	21
	.long	.Linfo_string44
	.long	.Linfo_string45
	.byte	10
	.short	3950
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string54
	.byte	21
	.long	.Linfo_string55
	.long	.Linfo_string56
	.byte	12
	.short	1000
	.byte	1
	.byte	2
	.long	.Linfo_string66
	.byte	2
	.long	.Linfo_string67
	.byte	3
	.long	.Linfo_string68
	.long	.Linfo_string69
	.byte	13
	.byte	72
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string70
	.byte	2
	.long	.Linfo_string71
	.byte	3
	.long	.Linfo_string72
	.long	.Linfo_string69
	.byte	14
	.byte	158
	.byte	1
	.byte	0
	.byte	0
	.byte	21
	.long	.Linfo_string149
	.long	.Linfo_string150
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string190
	.long	.Linfo_string191
	.byte	12
	.short	1000
	.byte	1
	.byte	21
	.long	.Linfo_string149
	.long	.Linfo_string150
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string219
	.long	.Linfo_string220
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string219
	.long	.Linfo_string220
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string149
	.long	.Linfo_string150
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string241
	.long	.Linfo_string242
	.byte	12
	.short	1000
	.byte	1
	.byte	21
	.long	.Linfo_string256
	.long	.Linfo_string257
	.byte	12
	.short	401
	.byte	1
	.byte	21
	.long	.Linfo_string258
	.long	.Linfo_string259
	.byte	12
	.short	401
	.byte	1
	.byte	21
	.long	.Linfo_string149
	.long	.Linfo_string150
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string355
	.long	.Linfo_string356
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string219
	.long	.Linfo_string220
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string219
	.long	.Linfo_string220
	.byte	12
	.short	916
	.byte	1
	.byte	21
	.long	.Linfo_string219
	.long	.Linfo_string220
	.byte	12
	.short	916
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string89
	.byte	2
	.long	.Linfo_string90
	.byte	2
	.long	.Linfo_string91
	.byte	3
	.long	.Linfo_string92
	.long	.Linfo_string93
	.byte	15
	.byte	157
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string295
	.byte	3
	.long	.Linfo_string296
	.long	.Linfo_string93
	.byte	15
	.byte	157
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string90
	.byte	2
	.long	.Linfo_string94
	.byte	2
	.long	.Linfo_string95
	.byte	2
	.long	.Linfo_string77
	.byte	3
	.long	.Linfo_string96
	.long	.Linfo_string97
	.byte	18
	.byte	79
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string98
	.byte	2
	.long	.Linfo_string99
	.byte	21
	.long	.Linfo_string100
	.long	.Linfo_string101
	.byte	16
	.short	2659
	.byte	1
	.byte	21
	.long	.Linfo_string102
	.long	.Linfo_string103
	.byte	16
	.short	2583
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string217
	.byte	21
	.long	.Linfo_string218
	.long	.Linfo_string103
	.byte	27
	.short	2165
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string299
	.byte	21
	.long	.Linfo_string300
	.long	.Linfo_string103
	.byte	16
	.short	2583
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string323
	.byte	21
	.long	.Linfo_string324
	.long	.Linfo_string325
	.byte	16
	.short	1347
	.byte	1
	.byte	21
	.long	.Linfo_string376
	.long	.Linfo_string103
	.byte	16
	.short	2583
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string151
	.byte	2
	.long	.Linfo_string152
	.byte	21
	.long	.Linfo_string153
	.long	.Linfo_string150
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string154
	.long	.Linfo_string155
	.byte	26
	.short	433
	.byte	1
	.byte	21
	.long	.Linfo_string153
	.long	.Linfo_string150
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string154
	.long	.Linfo_string155
	.byte	26
	.short	433
	.byte	1
	.byte	21
	.long	.Linfo_string205
	.long	.Linfo_string206
	.byte	26
	.short	552
	.byte	1
	.byte	21
	.long	.Linfo_string221
	.long	.Linfo_string220
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string221
	.long	.Linfo_string220
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string153
	.long	.Linfo_string150
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string154
	.long	.Linfo_string155
	.byte	26
	.short	433
	.byte	1
	.byte	21
	.long	.Linfo_string153
	.long	.Linfo_string150
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string154
	.long	.Linfo_string155
	.byte	26
	.short	433
	.byte	1
	.byte	21
	.long	.Linfo_string221
	.long	.Linfo_string220
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string221
	.long	.Linfo_string220
	.byte	26
	.short	510
	.byte	1
	.byte	21
	.long	.Linfo_string221
	.long	.Linfo_string220
	.byte	26
	.short	510
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string207
	.byte	21
	.long	.Linfo_string208
	.long	.Linfo_string209
	.byte	26
	.short	1558
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string210
	.byte	21
	.long	.Linfo_string211
	.long	.Linfo_string212
	.byte	26
	.short	1158
	.byte	1
	.byte	21
	.long	.Linfo_string213
	.long	.Linfo_string214
	.byte	26
	.short	1121
	.byte	1
	.byte	21
	.long	.Linfo_string368
	.long	.Linfo_string369
	.byte	26
	.short	1255
	.byte	1
	.byte	21
	.long	.Linfo_string370
	.long	.Linfo_string371
	.byte	26
	.short	1221
	.byte	1
	.byte	21
	.long	.Linfo_string368
	.long	.Linfo_string369
	.byte	26
	.short	1255
	.byte	1
	.byte	21
	.long	.Linfo_string370
	.long	.Linfo_string371
	.byte	26
	.short	1221
	.byte	1
	.byte	0
	.byte	21
	.long	.Linfo_string215
	.long	.Linfo_string216
	.byte	26
	.short	954
	.byte	1
	.byte	2
	.long	.Linfo_string224
	.byte	21
	.long	.Linfo_string225
	.long	.Linfo_string226
	.byte	26
	.short	1584
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string366
	.byte	21
	.long	.Linfo_string367
	.long	.Linfo_string209
	.byte	26
	.short	2061
	.byte	1
	.byte	21
	.long	.Linfo_string367
	.long	.Linfo_string209
	.byte	26
	.short	2061
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string400
	.byte	21
	.long	.Linfo_string401
	.long	.Linfo_string226
	.byte	26
	.short	2052
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string162
	.byte	21
	.long	.Linfo_string163
	.long	.Linfo_string164
	.byte	24
	.short	458
	.byte	1
	.byte	21
	.long	.Linfo_string163
	.long	.Linfo_string164
	.byte	24
	.short	458
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string57
	.byte	2
	.long	.Linfo_string169
	.byte	2
	.long	.Linfo_string170
	.byte	3
	.long	.Linfo_string171
	.long	.Linfo_string172
	.byte	28
	.byte	74
	.byte	1
	.byte	3
	.long	.Linfo_string173
	.long	.Linfo_string174
	.byte	28
	.byte	95
	.byte	1
	.byte	3
	.long	.Linfo_string171
	.long	.Linfo_string172
	.byte	28
	.byte	74
	.byte	1
	.byte	3
	.long	.Linfo_string173
	.long	.Linfo_string174
	.byte	28
	.byte	95
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string83
	.byte	2
	.long	.Linfo_string251
	.byte	21
	.long	.Linfo_string252
	.long	.Linfo_string253
	.byte	29
	.short	532
	.byte	1
	.byte	21
	.long	.Linfo_string345
	.long	.Linfo_string79
	.byte	29
	.short	458
	.byte	1
	.byte	21
	.long	.Linfo_string345
	.long	.Linfo_string79
	.byte	29
	.short	458
	.byte	1
	.byte	21
	.long	.Linfo_string345
	.long	.Linfo_string79
	.byte	29
	.short	458
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string202
	.byte	21
	.long	.Linfo_string292
	.long	.Linfo_string226
	.byte	29
	.short	670
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string34
	.byte	2
	.long	.Linfo_string336
	.byte	21
	.long	.Linfo_string337
	.long	.Linfo_string311
	.byte	30
	.short	395
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string348
	.byte	2
	.long	.Linfo_string349
	.byte	23
	.quad	.Lfunc_begin21
	.long	.Lfunc_end21-.Lfunc_begin21
	.byte	4
	.byte	156
	.byte	17
	.byte	64
	.byte	34
	.long	.Linfo_string444
	.long	.Linfo_string445
	.byte	31
	.short	2872
	.byte	10
	.long	8442
	.quad	.Ltmp336
	.long	.Ltmp337-.Ltmp336
	.byte	31
	.short	2872
	.byte	62
	.byte	0
	.byte	23
	.quad	.Lfunc_begin22
	.long	.Lfunc_end22-.Lfunc_begin22
	.byte	1
	.byte	87
	.long	.Linfo_string446
	.long	.Linfo_string447
	.byte	31
	.short	2872
	.byte	9
	.long	11844
	.quad	.Ltmp339
	.long	.Ltmp341-.Ltmp339
	.byte	31
	.short	2872
	.byte	62
	.byte	6
	.long	11807
	.quad	.Ltmp339
	.long	.Ltmp340-.Ltmp339
	.byte	32
	.byte	86
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string350
	.byte	21
	.long	.Linfo_string351
	.long	.Linfo_string352
	.byte	31
	.short	2404
	.byte	1
	.byte	21
	.long	.Linfo_string351
	.long	.Linfo_string352
	.byte	31
	.short	2404
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string98
	.byte	2
	.long	.Linfo_string353
	.byte	3
	.long	.Linfo_string354
	.long	.Linfo_string348
	.byte	32
	.byte	85
	.byte	1
	.byte	24
	.quad	.Lfunc_begin26
	.long	.Lfunc_end26-.Lfunc_begin26
	.byte	1
	.byte	87
	.long	11844
	.byte	6
	.long	11807
	.quad	.Lfunc_begin26
	.long	.Ltmp388-.Lfunc_begin26
	.byte	32
	.byte	86
	.byte	26
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string407
	.byte	4
	.quad	.Lfunc_begin25
	.long	.Lfunc_end25-.Lfunc_begin25
	.byte	1
	.byte	87
	.long	.Linfo_string450
	.long	.Linfo_string348
	.byte	32
	.byte	85
	.byte	6
	.long	11820
	.quad	.Lfunc_begin25
	.long	.Ltmp386-.Lfunc_begin25
	.byte	32
	.byte	86
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string357
	.byte	2
	.long	.Linfo_string358
	.byte	21
	.long	.Linfo_string359
	.long	.Linfo_string360
	.byte	33
	.short	1896
	.byte	1
	.byte	21
	.long	.Linfo_string361
	.long	.Linfo_string362
	.byte	33
	.short	965
	.byte	1
	.byte	21
	.long	.Linfo_string361
	.long	.Linfo_string362
	.byte	33
	.short	965
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string15
	.byte	2
	.long	.Linfo_string16
	.byte	7
	.quad	.Lfunc_begin4
	.long	.Lfunc_end4-.Lfunc_begin4
	.byte	1
	.byte	87
	.long	.Linfo_string416
	.long	.Linfo_string417
	.byte	3
	.byte	199
	.byte	2
	.long	.Linfo_string84
	.byte	25
	.quad	.Lfunc_begin11
	.long	.Lfunc_end11-.Lfunc_begin11
	.byte	1
	.byte	87
	.long	12062
	.byte	3
	.long	.Linfo_string85
	.long	.Linfo_string86
	.byte	3
	.byte	206
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string25
	.byte	2
	.long	.Linfo_string26
	.byte	4
	.quad	.Lfunc_begin6
	.long	.Lfunc_end6-.Lfunc_begin6
	.byte	1
	.byte	87
	.long	.Linfo_string420
	.long	.Linfo_string421
	.byte	5
	.byte	162
	.byte	6
	.long	9872
	.quad	.Ltmp37
	.long	.Ltmp38-.Ltmp37
	.byte	5
	.byte	166
	.byte	18
	.byte	6
	.long	9784
	.quad	.Ltmp38
	.long	.Ltmp39-.Ltmp38
	.byte	5
	.byte	169
	.byte	5
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string34
	.byte	2
	.long	.Linfo_string35
	.byte	2
	.long	.Linfo_string36
	.byte	21
	.long	.Linfo_string37
	.long	.Linfo_string38
	.byte	9
	.short	1911
	.byte	1
	.byte	21
	.long	.Linfo_string39
	.long	.Linfo_string40
	.byte	9
	.short	2116
	.byte	1
	.byte	21
	.long	.Linfo_string41
	.long	.Linfo_string42
	.byte	9
	.short	1766
	.byte	1
	.byte	21
	.long	.Linfo_string73
	.long	.Linfo_string74
	.byte	9
	.short	2067
	.byte	1
	.byte	21
	.long	.Linfo_string75
	.long	.Linfo_string76
	.byte	9
	.short	1726
	.byte	1
	.byte	21
	.long	.Linfo_string80
	.long	.Linfo_string81
	.byte	9
	.short	1664
	.byte	1
	.byte	21
	.long	.Linfo_string247
	.long	.Linfo_string248
	.byte	9
	.short	424
	.byte	1
	.byte	23
	.quad	.Lfunc_begin19
	.long	.Lfunc_end19-.Lfunc_begin19
	.byte	1
	.byte	87
	.long	.Linfo_string441
	.long	.Linfo_string442
	.byte	9
	.short	2132
	.byte	9
	.long	10391
	.quad	.Ltmp326
	.long	.Ltmp330-.Ltmp326
	.byte	9
	.short	2144
	.byte	5
	.byte	9
	.long	12580
	.quad	.Ltmp326
	.long	.Ltmp330-.Ltmp326
	.byte	11
	.short	825
	.byte	1
	.byte	10
	.long	12561
	.quad	.Ltmp326
	.long	.Ltmp327-.Ltmp326
	.byte	9
	.short	3503
	.byte	47
	.byte	9
	.long	10550
	.quad	.Ltmp327
	.long	.Ltmp328-.Ltmp327
	.byte	9
	.short	3505
	.byte	23
	.byte	10
	.long	10629
	.quad	.Ltmp327
	.long	.Ltmp328-.Ltmp327
	.byte	10
	.short	3193
	.byte	26
	.byte	0
	.byte	9
	.long	11656
	.quad	.Ltmp329
	.long	.Ltmp330-.Ltmp329
	.byte	9
	.short	3517
	.byte	28
	.byte	9
	.long	13477
	.quad	.Ltmp329
	.long	.Ltmp330-.Ltmp329
	.byte	30
	.short	397
	.byte	27
	.byte	9
	.long	13432
	.quad	.Ltmp329
	.long	.Ltmp330-.Ltmp329
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp329
	.long	.Ltmp330-.Ltmp329
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp329
	.long	.Ltmp330-.Ltmp329
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string49
	.byte	21
	.long	.Linfo_string50
	.long	.Linfo_string51
	.byte	9
	.short	2827
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string63
	.byte	21
	.long	.Linfo_string64
	.long	.Linfo_string65
	.byte	9
	.short	2399
	.byte	1
	.byte	21
	.long	.Linfo_string64
	.long	.Linfo_string65
	.byte	9
	.short	2399
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string326
	.byte	21
	.long	.Linfo_string338
	.long	.Linfo_string339
	.byte	9
	.short	3351
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string340
	.byte	21
	.long	.Linfo_string341
	.long	.Linfo_string342
	.byte	9
	.short	3494
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string57
	.byte	2
	.long	.Linfo_string58
	.byte	24
	.quad	.Lfunc_begin7
	.long	.Lfunc_end7-.Lfunc_begin7
	.byte	1
	.byte	87
	.long	13328
	.byte	8
	.long	12196
	.quad	.Ltmp41
	.long	.Ltmp45-.Ltmp41
	.byte	7
	.byte	209
	.byte	18
	.byte	9
	.long	12183
	.quad	.Ltmp41
	.long	.Ltmp45-.Ltmp41
	.byte	9
	.short	1767
	.byte	18
	.byte	9
	.long	12170
	.quad	.Ltmp41
	.long	.Ltmp42-.Ltmp41
	.byte	9
	.short	2117
	.byte	23
	.byte	9
	.long	9994
	.quad	.Ltmp41
	.long	.Ltmp42-.Ltmp41
	.byte	9
	.short	1916
	.byte	31
	.byte	10
	.long	9981
	.quad	.Ltmp41
	.long	.Ltmp42-.Ltmp41
	.byte	8
	.short	995
	.byte	36
	.byte	0
	.byte	0
	.byte	9
	.long	10649
	.quad	.Ltmp43
	.long	.Ltmp45-.Ltmp43
	.byte	9
	.short	2117
	.byte	18
	.byte	9
	.long	10009
	.quad	.Ltmp43
	.long	.Ltmp45-.Ltmp43
	.byte	12
	.short	1004
	.byte	1
	.byte	9
	.long	12510
	.quad	.Ltmp43
	.long	.Ltmp45-.Ltmp43
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10472
	.quad	.Ltmp43
	.long	.Ltmp44-.Ltmp43
	.byte	9
	.short	2831
	.byte	32
	.byte	10
	.long	10454
	.quad	.Ltmp43
	.long	.Ltmp44-.Ltmp43
	.byte	10
	.short	3193
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.quad	.Lfunc_begin8
	.long	.Lfunc_end8-.Lfunc_begin8
	.byte	1
	.byte	87
	.long	.Linfo_string422
	.long	.Linfo_string423
	.byte	7
	.byte	187
	.byte	5
	.long	12222
	.long	.Ldebug_ranges2
	.byte	7
	.byte	188
	.byte	18
	.byte	14
	.long	12209
	.long	.Ldebug_ranges2
	.byte	9
	.short	1727
	.byte	18
	.byte	14
	.long	10696
	.long	.Ldebug_ranges2
	.byte	9
	.short	2074
	.byte	52
	.byte	5
	.long	10672
	.long	.Ldebug_ranges2
	.byte	14
	.byte	158
	.byte	16
	.byte	5
	.long	12529
	.long	.Ldebug_ranges2
	.byte	13
	.byte	72
	.byte	23
	.byte	9
	.long	10485
	.quad	.Lfunc_begin8
	.long	.Ltmp47-.Lfunc_begin8
	.byte	9
	.short	2411
	.byte	44
	.byte	10
	.long	10564
	.quad	.Lfunc_begin8
	.long	.Ltmp47-.Lfunc_begin8
	.byte	10
	.short	3162
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.quad	.Lfunc_begin9
	.long	.Lfunc_end9-.Lfunc_begin9
	.byte	1
	.byte	87
	.long	.Linfo_string424
	.long	.Linfo_string425
	.byte	7
	.byte	202
	.byte	8
	.long	300
	.quad	.Lfunc_begin9
	.long	.Ltmp51-.Lfunc_begin9
	.byte	7
	.byte	204
	.byte	9
	.byte	8
	.long	10498
	.quad	.Lfunc_begin9
	.long	.Ltmp51-.Lfunc_begin9
	.byte	1
	.byte	53
	.byte	20
	.byte	10
	.long	10577
	.quad	.Lfunc_begin9
	.long	.Ltmp51-.Lfunc_begin9
	.byte	10
	.short	3162
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	4
	.quad	.Lfunc_begin10
	.long	.Lfunc_end10-.Lfunc_begin10
	.byte	1
	.byte	87
	.long	.Linfo_string426
	.long	.Linfo_string427
	.byte	7
	.byte	196
	.byte	8
	.long	12235
	.quad	.Ltmp53
	.long	.Ltmp54-.Ltmp53
	.byte	7
	.byte	197
	.byte	30
	.byte	9
	.long	12170
	.quad	.Ltmp53
	.long	.Ltmp54-.Ltmp53
	.byte	9
	.short	1665
	.byte	18
	.byte	9
	.long	9994
	.quad	.Ltmp53
	.long	.Ltmp54-.Ltmp53
	.byte	9
	.short	1916
	.byte	31
	.byte	10
	.long	9981
	.quad	.Ltmp53
	.long	.Ltmp54-.Ltmp53
	.byte	8
	.short	995
	.byte	36
	.byte	0
	.byte	0
	.byte	0
	.byte	8
	.long	312
	.quad	.Ltmp54
	.long	.Ltmp57-.Ltmp54
	.byte	7
	.byte	198
	.byte	9
	.byte	8
	.long	10511
	.quad	.Ltmp54
	.long	.Ltmp55-.Ltmp54
	.byte	1
	.byte	49
	.byte	20
	.byte	10
	.long	10590
	.quad	.Ltmp54
	.long	.Ltmp55-.Ltmp54
	.byte	10
	.short	3162
	.byte	26
	.byte	0
	.byte	8
	.long	10009
	.quad	.Ltmp55
	.long	.Ltmp57-.Ltmp55
	.byte	1
	.byte	50
	.byte	5
	.byte	9
	.long	12510
	.quad	.Ltmp55
	.long	.Ltmp57-.Ltmp55
	.byte	11
	.short	825
	.byte	1
	.byte	9
	.long	10472
	.quad	.Ltmp55
	.long	.Ltmp56-.Ltmp55
	.byte	9
	.short	2831
	.byte	32
	.byte	10
	.long	10454
	.quad	.Ltmp55
	.long	.Ltmp56-.Ltmp55
	.byte	10
	.short	3193
	.byte	26
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	3
	.long	.Linfo_string290
	.long	.Linfo_string291
	.byte	7
	.byte	208
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string29
	.byte	3
	.long	.Linfo_string254
	.long	.Linfo_string255
	.byte	7
	.byte	114
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string34
	.byte	3
	.long	.Linfo_string108
	.long	.Linfo_string34
	.byte	19
	.byte	95
	.byte	1
	.byte	2
	.long	.Linfo_string109
	.byte	3
	.long	.Linfo_string110
	.long	.Linfo_string111
	.byte	19
	.byte	205
	.byte	1
	.byte	21
	.long	.Linfo_string112
	.long	.Linfo_string113
	.byte	19
	.short	331
	.byte	1
	.byte	21
	.long	.Linfo_string112
	.long	.Linfo_string113
	.byte	19
	.short	331
	.byte	1
	.byte	3
	.long	.Linfo_string196
	.long	.Linfo_string197
	.byte	19
	.byte	219
	.byte	1
	.byte	21
	.long	.Linfo_string198
	.long	.Linfo_string199
	.byte	19
	.short	343
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string77
	.byte	21
	.long	.Linfo_string114
	.long	.Linfo_string115
	.byte	19
	.short	448
	.byte	1
	.byte	21
	.long	.Linfo_string114
	.long	.Linfo_string115
	.byte	19
	.short	448
	.byte	1
	.byte	21
	.long	.Linfo_string200
	.long	.Linfo_string201
	.byte	19
	.short	460
	.byte	1
	.byte	0
	.byte	3
	.long	.Linfo_string194
	.long	.Linfo_string195
	.byte	19
	.byte	127
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string116
	.byte	2
	.long	.Linfo_string117
	.byte	21
	.long	.Linfo_string118
	.long	.Linfo_string119
	.byte	20
	.short	446
	.byte	1
	.byte	21
	.long	.Linfo_string120
	.long	.Linfo_string121
	.byte	20
	.short	433
	.byte	1
	.byte	21
	.long	.Linfo_string308
	.long	.Linfo_string309
	.byte	20
	.short	633
	.byte	1
	.byte	21
	.long	.Linfo_string310
	.long	.Linfo_string311
	.byte	20
	.short	872
	.byte	1
	.byte	21
	.long	.Linfo_string381
	.long	.Linfo_string382
	.byte	20
	.short	618
	.byte	1
	.byte	21
	.long	.Linfo_string386
	.long	.Linfo_string387
	.byte	20
	.short	613
	.byte	1
	.byte	21
	.long	.Linfo_string388
	.long	.Linfo_string389
	.byte	20
	.short	608
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string122
	.byte	3
	.long	.Linfo_string123
	.long	.Linfo_string124
	.byte	20
	.byte	175
	.byte	1
	.byte	21
	.long	.Linfo_string383
	.long	.Linfo_string384
	.byte	20
	.short	308
	.byte	1
	.byte	21
	.long	.Linfo_string390
	.long	.Linfo_string391
	.byte	20
	.short	295
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string312
	.byte	21
	.long	.Linfo_string313
	.long	.Linfo_string314
	.byte	20
	.short	422
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string125
	.byte	2
	.long	.Linfo_string126
	.byte	2
	.long	.Linfo_string127
	.byte	21
	.long	.Linfo_string128
	.long	.Linfo_string124
	.byte	21
	.short	910
	.byte	1
	.byte	21
	.long	.Linfo_string129
	.long	.Linfo_string130
	.byte	21
	.short	845
	.byte	1
	.byte	21
	.long	.Linfo_string222
	.long	.Linfo_string223
	.byte	21
	.short	1705
	.byte	1
	.byte	21
	.long	.Linfo_string222
	.long	.Linfo_string223
	.byte	21
	.short	1705
	.byte	1
	.byte	21
	.long	.Linfo_string372
	.long	.Linfo_string373
	.byte	21
	.short	1722
	.byte	1
	.byte	21
	.long	.Linfo_string374
	.long	.Linfo_string375
	.byte	21
	.short	2136
	.byte	1
	.byte	3
	.long	.Linfo_string377
	.long	.Linfo_string378
	.byte	21
	.byte	243
	.byte	1
	.byte	3
	.long	.Linfo_string379
	.long	.Linfo_string380
	.byte	21
	.byte	248
	.byte	1
	.byte	21
	.long	.Linfo_string385
	.long	.Linfo_string384
	.byte	21
	.short	1052
	.byte	1
	.byte	3
	.long	.Linfo_string392
	.long	.Linfo_string391
	.byte	21
	.byte	173
	.byte	1
	.byte	3
	.long	.Linfo_string393
	.long	.Linfo_string394
	.byte	21
	.byte	208
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string131
	.byte	21
	.long	.Linfo_string132
	.long	.Linfo_string133
	.byte	21
	.short	4002
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string395
	.byte	21
	.long	.Linfo_string396
	.long	.Linfo_string397
	.byte	21
	.short	3633
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string136
	.byte	3
	.long	.Linfo_string137
	.long	.Linfo_string138
	.byte	22
	.byte	247
	.byte	1
	.byte	2
	.long	.Linfo_string29
	.byte	21
	.long	.Linfo_string139
	.long	.Linfo_string140
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string165
	.long	.Linfo_string166
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string167
	.long	.Linfo_string168
	.byte	22
	.short	355
	.byte	1
	.byte	21
	.long	.Linfo_string231
	.long	.Linfo_string232
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string233
	.long	.Linfo_string234
	.byte	22
	.short	355
	.byte	1
	.byte	21
	.long	.Linfo_string245
	.long	.Linfo_string246
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string260
	.long	.Linfo_string261
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string262
	.long	.Linfo_string263
	.byte	22
	.short	355
	.byte	1
	.byte	21
	.long	.Linfo_string272
	.long	.Linfo_string273
	.byte	22
	.short	284
	.byte	1
	.byte	21
	.long	.Linfo_string274
	.long	.Linfo_string275
	.byte	22
	.short	355
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string202
	.byte	21
	.long	.Linfo_string203
	.long	.Linfo_string204
	.byte	22
	.short	1948
	.byte	1
	.byte	21
	.long	.Linfo_string243
	.long	.Linfo_string244
	.byte	22
	.short	1948
	.byte	1
	.byte	21
	.long	.Linfo_string266
	.long	.Linfo_string267
	.byte	22
	.short	1948
	.byte	1
	.byte	21
	.long	.Linfo_string278
	.long	.Linfo_string279
	.byte	22
	.short	1948
	.byte	1
	.byte	0
	.byte	0
	.byte	2
	.long	.Linfo_string141
	.byte	2
	.long	.Linfo_string142
	.byte	21
	.long	.Linfo_string143
	.long	.Linfo_string144
	.byte	23
	.short	419
	.byte	1
	.byte	21
	.long	.Linfo_string145
	.long	.Linfo_string146
	.byte	23
	.short	382
	.byte	1
	.byte	21
	.long	.Linfo_string147
	.long	.Linfo_string148
	.byte	23
	.short	357
	.byte	1
	.byte	21
	.long	.Linfo_string177
	.long	.Linfo_string178
	.byte	23
	.short	369
	.byte	1
	.byte	21
	.long	.Linfo_string143
	.long	.Linfo_string144
	.byte	23
	.short	419
	.byte	1
	.byte	21
	.long	.Linfo_string145
	.long	.Linfo_string146
	.byte	23
	.short	382
	.byte	1
	.byte	21
	.long	.Linfo_string147
	.long	.Linfo_string148
	.byte	23
	.short	357
	.byte	1
	.byte	23
	.quad	.Lfunc_begin18
	.long	.Lfunc_end18-.Lfunc_begin18
	.byte	1
	.byte	87
	.long	.Linfo_string439
	.long	.Linfo_string440
	.byte	23
	.short	393
	.byte	9
	.long	10313
	.quad	.Ltmp315
	.long	.Ltmp320-.Ltmp315
	.byte	23
	.short	402
	.byte	13
	.byte	14
	.long	10365
	.long	.Ldebug_ranges26
	.byte	11
	.short	820
	.byte	14
	.byte	14
	.long	10352
	.long	.Ldebug_ranges26
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	10339
	.long	.Ldebug_ranges26
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	10326
	.long	.Ldebug_ranges26
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	13655
	.long	.Ldebug_ranges26
	.byte	11
	.short	825
	.byte	1
	.byte	14
	.long	13553
	.long	.Ldebug_ranges26
	.byte	20
	.short	424
	.byte	29
	.byte	14
	.long	13540
	.long	.Ldebug_ranges27
	.byte	20
	.short	874
	.byte	52
	.byte	10
	.long	11057
	.quad	.Ltmp318
	.long	.Ltmp319-.Ltmp318
	.byte	20
	.short	642
	.byte	53
	.byte	0
	.byte	9
	.long	13477
	.quad	.Ltmp319
	.long	.Ltmp320-.Ltmp319
	.byte	20
	.short	876
	.byte	28
	.byte	9
	.long	13432
	.quad	.Ltmp319
	.long	.Ltmp320-.Ltmp319
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp319
	.long	.Ltmp320-.Ltmp319
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp319
	.long	.Ltmp320-.Ltmp319
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	14
	.long	10378
	.long	.Ldebug_ranges28
	.byte	23
	.short	404
	.byte	5
	.byte	14
	.long	14836
	.long	.Ldebug_ranges28
	.byte	11
	.short	825
	.byte	1
	.byte	10
	.long	14817
	.quad	.Ltmp320
	.long	.Ltmp321-.Ltmp320
	.byte	23
	.short	3678
	.byte	47
	.byte	9
	.long	14747
	.quad	.Ltmp321
	.long	.Ltmp322-.Ltmp321
	.byte	23
	.short	3680
	.byte	15
	.byte	9
	.long	11225
	.quad	.Ltmp321
	.long	.Ltmp322-.Ltmp321
	.byte	23
	.short	3820
	.byte	25
	.byte	9
	.long	11212
	.quad	.Ltmp321
	.long	.Ltmp322-.Ltmp321
	.byte	26
	.short	437
	.byte	14
	.byte	10
	.long	10827
	.quad	.Ltmp321
	.long	.Ltmp322-.Ltmp321
	.byte	26
	.short	513
	.byte	9
	.byte	0
	.byte	0
	.byte	0
	.byte	9
	.long	11656
	.quad	.Ltmp324
	.long	.Ltmp325-.Ltmp324
	.byte	23
	.short	3685
	.byte	28
	.byte	9
	.long	13477
	.quad	.Ltmp324
	.long	.Ltmp325-.Ltmp324
	.byte	30
	.short	397
	.byte	27
	.byte	9
	.long	13432
	.quad	.Ltmp324
	.long	.Ltmp325-.Ltmp324
	.byte	19
	.short	462
	.byte	23
	.byte	9
	.long	13420
	.quad	.Ltmp324
	.long	.Ltmp325-.Ltmp324
	.byte	19
	.short	344
	.byte	9
	.byte	6
	.long	13491
	.quad	.Ltmp324
	.long	.Ltmp325-.Ltmp324
	.byte	19
	.byte	229
	.byte	22
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	0
	.byte	21
	.long	.Linfo_string177
	.long	.Linfo_string178
	.byte	23
	.short	369
	.byte	1
	.byte	21
	.long	.Linfo_string177
	.long	.Linfo_string178
	.byte	23
	.short	369
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string156
	.byte	21
	.long	.Linfo_string157
	.long	.Linfo_string158
	.byte	23
	.short	3763
	.byte	1
	.byte	21
	.long	.Linfo_string192
	.long	.Linfo_string193
	.byte	23
	.short	3786
	.byte	1
	.byte	21
	.long	.Linfo_string157
	.long	.Linfo_string158
	.byte	23
	.short	3763
	.byte	1
	.byte	21
	.long	.Linfo_string334
	.long	.Linfo_string335
	.byte	23
	.short	3819
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string159
	.byte	21
	.long	.Linfo_string160
	.long	.Linfo_string161
	.byte	23
	.short	2517
	.byte	1
	.byte	21
	.long	.Linfo_string160
	.long	.Linfo_string161
	.byte	23
	.short	2517
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string179
	.byte	21
	.long	.Linfo_string180
	.long	.Linfo_string181
	.byte	23
	.short	2490
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string326
	.byte	21
	.long	.Linfo_string327
	.long	.Linfo_string328
	.byte	23
	.short	3590
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string329
	.byte	21
	.long	.Linfo_string330
	.long	.Linfo_string331
	.byte	23
	.short	3677
	.byte	1
	.byte	0
	.byte	2
	.long	.Linfo_string363
	.byte	21
	.long	.Linfo_string364
	.long	.Linfo_string365
	.byte	23
	.short	2440
	.byte	1
	.byte	21
	.long	.Linfo_string364
	.long	.Linfo_string365
	.byte	23
	.short	2440
	.byte	1
	.byte	0
	.byte	0
	.byte	0
	.byte	0
.Ldebug_info_end0:
	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_,"ax",@progbits
.Lsec_end0:
	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_,"ax",@progbits
.Lsec_end1:
	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_,"ax",@progbits
.Lsec_end2:
	.section	.text._RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_,"ax",@progbits
.Lsec_end3:
	.section	.text._RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end4:
	.section	.text.unlikely._RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_,"ax",@progbits
.Lsec_end5:
	.section	.text._RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end6:
	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_,"ax",@progbits
.Lsec_end7:
	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,"ax",@progbits
.Lsec_end8:
	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_,"ax",@progbits
.Lsec_end9:
	.section	.text._RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_,"ax",@progbits
.Lsec_end10:
	.section	.text._RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end11:
	.section	.text._RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end12:
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes,"ax",@progbits
.Lsec_end13:
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race,"ax",@progbits
.Lsec_end14:
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race,"ax",@progbits
.Lsec_end15:
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation4main,"ax",@progbits
.Lsec_end16:
	.section	.text._RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum,"ax",@progbits
.Lsec_end17:
	.section	.text._RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end18:
	.section	.text._RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_,"ax",@progbits
.Lsec_end19:
	.section	.text._RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
.Lsec_end20:
	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_,"ax",@progbits
.Lsec_end21:
	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation,"ax",@progbits
.Lsec_end22:
	.section	.text._RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
.Lsec_end23:
	.section	.text._RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll,"ax",@progbits
.Lsec_end24:
	.section	.text._RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt,"ax",@progbits
.Lsec_end25:
	.section	.text._RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt,"ax",@progbits
.Lsec_end26:
	.section	.debug_aranges,"",@progbits
	.long	460
	.short	2
	.long	.Lcu_begin0
	.byte	8
	.byte	0
	.zero	4,255
	.quad	.Lfunc_begin0
	.quad	.Lsec_end0-.Lfunc_begin0
	.quad	.Lfunc_begin1
	.quad	.Lsec_end1-.Lfunc_begin1
	.quad	.Lfunc_begin2
	.quad	.Lsec_end2-.Lfunc_begin2
	.quad	.Lfunc_begin3
	.quad	.Lsec_end3-.Lfunc_begin3
	.quad	.Lfunc_begin4
	.quad	.Lsec_end4-.Lfunc_begin4
	.quad	.Lfunc_begin5
	.quad	.Lsec_end5-.Lfunc_begin5
	.quad	.Lfunc_begin6
	.quad	.Lsec_end6-.Lfunc_begin6
	.quad	.Lfunc_begin7
	.quad	.Lsec_end7-.Lfunc_begin7
	.quad	.Lfunc_begin8
	.quad	.Lsec_end8-.Lfunc_begin8
	.quad	.Lfunc_begin9
	.quad	.Lsec_end9-.Lfunc_begin9
	.quad	.Lfunc_begin10
	.quad	.Lsec_end10-.Lfunc_begin10
	.quad	.Lfunc_begin11
	.quad	.Lsec_end11-.Lfunc_begin11
	.quad	.Lfunc_begin12
	.quad	.Lsec_end12-.Lfunc_begin12
	.quad	.Lfunc_begin13
	.quad	.Lsec_end13-.Lfunc_begin13
	.quad	.Lfunc_begin14
	.quad	.Lsec_end14-.Lfunc_begin14
	.quad	.Lfunc_begin15
	.quad	.Lsec_end15-.Lfunc_begin15
	.quad	.Lfunc_begin16
	.quad	.Lsec_end16-.Lfunc_begin16
	.quad	.Lfunc_begin17
	.quad	.Lsec_end17-.Lfunc_begin17
	.quad	.Lfunc_begin18
	.quad	.Lsec_end18-.Lfunc_begin18
	.quad	.Lfunc_begin19
	.quad	.Lsec_end19-.Lfunc_begin19
	.quad	.Lfunc_begin20
	.quad	.Lsec_end20-.Lfunc_begin20
	.quad	.Lfunc_begin21
	.quad	.Lsec_end21-.Lfunc_begin21
	.quad	.Lfunc_begin22
	.quad	.Lsec_end22-.Lfunc_begin22
	.quad	.Lfunc_begin23
	.quad	.Lsec_end23-.Lfunc_begin23
	.quad	.Lfunc_begin24
	.quad	.Lsec_end24-.Lfunc_begin24
	.quad	.Lfunc_begin25
	.quad	.Lsec_end25-.Lfunc_begin25
	.quad	.Lfunc_begin26
	.quad	.Lsec_end26-.Lfunc_begin26
	.quad	0
	.quad	0
	.section	.debug_ranges,"",@progbits
.Ldebug_ranges0:
	.quad	.Ltmp0
	.quad	.Ltmp13
	.quad	.Ltmp14
	.quad	.Ltmp15
	.quad	0
	.quad	0
.Ldebug_ranges1:
	.quad	.Ltmp16
	.quad	.Ltmp28
	.quad	.Ltmp29
	.quad	.Ltmp30
	.quad	0
	.quad	0
.Ldebug_ranges2:
	.quad	.Lfunc_begin8
	.quad	.Ltmp48
	.quad	.Ltmp49
	.quad	.Ltmp50
	.quad	0
	.quad	0
.Ldebug_ranges3:
	.quad	.Ltmp65
	.quad	.Ltmp66
	.quad	.Ltmp70
	.quad	.Ltmp72
	.quad	0
	.quad	0
.Ldebug_ranges4:
	.quad	.Ltmp116
	.quad	.Ltmp121
	.quad	.Ltmp146
	.quad	.Ltmp147
	.quad	0
	.quad	0
.Ldebug_ranges5:
	.quad	.Ltmp121
	.quad	.Ltmp124
	.quad	.Ltmp147
	.quad	.Ltmp148
	.quad	0
	.quad	0
.Ldebug_ranges6:
	.quad	.Ltmp133
	.quad	.Ltmp135
	.quad	.Ltmp138
	.quad	.Ltmp139
	.quad	0
	.quad	0
.Ldebug_ranges7:
	.quad	.Ltmp135
	.quad	.Ltmp137
	.quad	.Ltmp139
	.quad	.Ltmp141
	.quad	0
	.quad	0
.Ldebug_ranges8:
	.quad	.Ltmp135
	.quad	.Ltmp136
	.quad	.Ltmp139
	.quad	.Ltmp140
	.quad	0
	.quad	0
.Ldebug_ranges9:
	.quad	.Ltmp192
	.quad	.Ltmp197
	.quad	.Ltmp223
	.quad	.Ltmp224
	.quad	0
	.quad	0
.Ldebug_ranges10:
	.quad	.Ltmp197
	.quad	.Ltmp200
	.quad	.Ltmp224
	.quad	.Ltmp225
	.quad	0
	.quad	0
.Ldebug_ranges11:
	.quad	.Ltmp210
	.quad	.Ltmp212
	.quad	.Ltmp215
	.quad	.Ltmp216
	.quad	0
	.quad	0
.Ldebug_ranges12:
	.quad	.Ltmp212
	.quad	.Ltmp214
	.quad	.Ltmp216
	.quad	.Ltmp218
	.quad	0
	.quad	0
.Ldebug_ranges13:
	.quad	.Ltmp212
	.quad	.Ltmp213
	.quad	.Ltmp216
	.quad	.Ltmp217
	.quad	0
	.quad	0
.Ldebug_ranges14:
	.quad	.Lfunc_begin16
	.quad	.Ltmp229
	.quad	.Ltmp292
	.quad	.Ltmp293
	.quad	0
	.quad	0
.Ldebug_ranges15:
	.quad	.Lfunc_begin16
	.quad	.Ltmp227
	.quad	.Ltmp292
	.quad	.Ltmp293
	.quad	0
	.quad	0
.Ldebug_ranges16:
	.quad	.Ltmp230
	.quad	.Ltmp232
	.quad	.Ltmp303
	.quad	.Ltmp304
	.quad	0
	.quad	0
.Ldebug_ranges17:
	.quad	.Ltmp236
	.quad	.Ltmp243
	.quad	.Ltmp293
	.quad	.Ltmp294
	.quad	0
	.quad	0
.Ldebug_ranges18:
	.quad	.Ltmp236
	.quad	.Ltmp240
	.quad	.Ltmp293
	.quad	.Ltmp294
	.quad	0
	.quad	0
.Ldebug_ranges19:
	.quad	.Ltmp236
	.quad	.Ltmp238
	.quad	.Ltmp293
	.quad	.Ltmp294
	.quad	0
	.quad	0
.Ldebug_ranges20:
	.quad	.Ltmp244
	.quad	.Ltmp251
	.quad	.Ltmp294
	.quad	.Ltmp295
	.quad	0
	.quad	0
.Ldebug_ranges21:
	.quad	.Ltmp244
	.quad	.Ltmp248
	.quad	.Ltmp294
	.quad	.Ltmp295
	.quad	0
	.quad	0
.Ldebug_ranges22:
	.quad	.Ltmp244
	.quad	.Ltmp246
	.quad	.Ltmp294
	.quad	.Ltmp295
	.quad	0
	.quad	0
.Ldebug_ranges23:
	.quad	.Ltmp258
	.quad	.Ltmp259
	.quad	.Ltmp287
	.quad	.Ltmp288
	.quad	0
	.quad	0
.Ldebug_ranges24:
	.quad	.Ltmp259
	.quad	.Ltmp260
	.quad	.Ltmp290
	.quad	.Ltmp291
	.quad	0
	.quad	0
.Ldebug_ranges25:
	.quad	.Ltmp307
	.quad	.Ltmp308
	.quad	.Ltmp310
	.quad	.Ltmp312
	.quad	0
	.quad	0
.Ldebug_ranges26:
	.quad	.Ltmp316
	.quad	.Ltmp317
	.quad	.Ltmp318
	.quad	.Ltmp320
	.quad	0
	.quad	0
.Ldebug_ranges27:
	.quad	.Ltmp316
	.quad	.Ltmp317
	.quad	.Ltmp318
	.quad	.Ltmp319
	.quad	0
	.quad	0
.Ldebug_ranges28:
	.quad	.Ltmp320
	.quad	.Ltmp323
	.quad	.Ltmp324
	.quad	.Ltmp325
	.quad	0
	.quad	0
.Ldebug_ranges29:
	.quad	.Ltmp343
	.quad	.Ltmp344
	.quad	.Ltmp345
	.quad	.Ltmp346
	.quad	0
	.quad	0
.Ldebug_ranges30:
	.quad	.Ltmp344
	.quad	.Ltmp345
	.quad	.Ltmp346
	.quad	.Ltmp347
	.quad	.Ltmp364
	.quad	.Ltmp365
	.quad	0
	.quad	0
.Ldebug_ranges31:
	.quad	.Ltmp349
	.quad	.Ltmp351
	.quad	.Ltmp365
	.quad	.Ltmp366
	.quad	0
	.quad	0
.Ldebug_ranges32:
	.quad	.Ltmp353
	.quad	.Ltmp355
	.quad	.Ltmp356
	.quad	.Ltmp357
	.quad	0
	.quad	0
.Ldebug_ranges33:
	.quad	.Ltmp355
	.quad	.Ltmp356
	.quad	.Ltmp358
	.quad	.Ltmp359
	.quad	0
	.quad	0
.Ldebug_ranges34:
	.quad	.Ltmp369
	.quad	.Ltmp371
	.quad	.Ltmp383
	.quad	.Ltmp384
	.quad	0
	.quad	0
.Ldebug_ranges35:
	.quad	.Ltmp373
	.quad	.Ltmp375
	.quad	.Ltmp376
	.quad	.Ltmp377
	.quad	0
	.quad	0
.Ldebug_ranges36:
	.quad	.Ltmp375
	.quad	.Ltmp376
	.quad	.Ltmp378
	.quad	.Ltmp379
	.quad	0
	.quad	0
.Ldebug_ranges37:
	.quad	.Lfunc_begin0
	.quad	.Lfunc_end0
	.quad	.Lfunc_begin1
	.quad	.Lfunc_end1
	.quad	.Lfunc_begin2
	.quad	.Lfunc_end2
	.quad	.Lfunc_begin3
	.quad	.Lfunc_end3
	.quad	.Lfunc_begin4
	.quad	.Lfunc_end4
	.quad	.Lfunc_begin5
	.quad	.Lfunc_end5
	.quad	.Lfunc_begin6
	.quad	.Lfunc_end6
	.quad	.Lfunc_begin7
	.quad	.Lfunc_end7
	.quad	.Lfunc_begin8
	.quad	.Lfunc_end8
	.quad	.Lfunc_begin9
	.quad	.Lfunc_end9
	.quad	.Lfunc_begin10
	.quad	.Lfunc_end10
	.quad	.Lfunc_begin11
	.quad	.Lfunc_end11
	.quad	.Lfunc_begin12
	.quad	.Lfunc_end12
	.quad	.Lfunc_begin13
	.quad	.Lfunc_end13
	.quad	.Lfunc_begin14
	.quad	.Lfunc_end14
	.quad	.Lfunc_begin15
	.quad	.Lfunc_end15
	.quad	.Lfunc_begin16
	.quad	.Lfunc_end16
	.quad	.Lfunc_begin17
	.quad	.Lfunc_end17
	.quad	.Lfunc_begin18
	.quad	.Lfunc_end18
	.quad	.Lfunc_begin19
	.quad	.Lfunc_end19
	.quad	.Lfunc_begin20
	.quad	.Lfunc_end20
	.quad	.Lfunc_begin21
	.quad	.Lfunc_end21
	.quad	.Lfunc_begin22
	.quad	.Lfunc_end22
	.quad	.Lfunc_begin23
	.quad	.Lfunc_end23
	.quad	.Lfunc_begin24
	.quad	.Lfunc_end24
	.quad	.Lfunc_begin25
	.quad	.Lfunc_end25
	.quad	.Lfunc_begin26
	.quad	.Lfunc_end26
	.quad	0
	.quad	0
	.section	.debug_str,"MS",@progbits,1
.Linfo_string0:
	.asciz	"clang LLVM (rustc version 1.97.1 (8bab26f4f 2026-07-14))"
.Linfo_string1:
	.asciz	"/tmp/topic41-async-T3xlijHO/results.work/archive/systems-snackpack-f03eb7c/topics/041-async-runtime-mechanics/examples/state_and_cancellation.rs/@/state_and_cancellation.4b0d11c6b942fbcb-cgu.0"
.Linfo_string2:
	.asciz	"/tmp/topic41-async-T3xlijHO"
.Linfo_string3:
	.asciz	"state_and_cancellation"
.Linfo_string4:
	.asciz	"holds_large_value_across_yield"
.Linfo_string5:
	.asciz	"_RNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0B3_"
.Linfo_string6:
	.asciz	"{async_fn#0}"
.Linfo_string7:
	.asciz	"core"
.Linfo_string8:
	.asciz	"hint"
.Linfo_string9:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxQAhj1000_ECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string10:
	.asciz	"black_box<&mut [u8; 4096]>"
.Linfo_string11:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxRAhj1000_ECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string12:
	.asciz	"black_box<&[u8; 4096]>"
.Linfo_string13:
	.asciz	"finishes_large_value_before_yield"
.Linfo_string14:
	.asciz	"_RNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0B3_"
.Linfo_string15:
	.asciz	"std"
.Linfo_string16:
	.asciz	"rt"
.Linfo_string17:
	.asciz	"panicking"
.Linfo_string18:
	.asciz	"ops"
.Linfo_string19:
	.asciz	"function"
.Linfo_string20:
	.asciz	"FnOnce"
.Linfo_string21:
	.asciz	"_RNvYFEuINtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string22:
	.asciz	"call_once<fn(), ()>"
.Linfo_string23:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxuECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string24:
	.asciz	"black_box<()>"
.Linfo_string25:
	.asciz	"sys"
.Linfo_string26:
	.asciz	"backtrace"
.Linfo_string27:
	.asciz	"ptr"
.Linfo_string28:
	.asciz	"const_ptr"
.Linfo_string29:
	.asciz	"{impl#0}"
.Linfo_string30:
	.asciz	"_RNvMNtNtCs4NRVxsYgnAr_4core3ptr9const_ptrPh3subCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string31:
	.asciz	"sub<u8>"
.Linfo_string32:
	.asciz	"_RNvMNtNtCs4NRVxsYgnAr_4core3ptr9const_ptrPNtCs6ruGKiyv7y9_22state_and_cancellation9CountWake8byte_subBG_"
.Linfo_string33:
	.asciz	"byte_sub<state_and_cancellation::CountWake>"
.Linfo_string34:
	.asciz	"alloc"
.Linfo_string35:
	.asciz	"sync"
.Linfo_string36:
	.asciz	"Arc"
.Linfo_string37:
	.asciz	"_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE11from_raw_inBH_"
.Linfo_string38:
	.asciz	"from_raw_in<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string39:
	.asciz	"_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE25decrement_strong_count_inBH_"
.Linfo_string40:
	.asciz	"decrement_strong_count_in<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string41:
	.asciz	"_RNvMsm_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE22decrement_strong_countBH_"
.Linfo_string42:
	.asciz	"decrement_strong_count<state_and_cancellation::CountWake>"
.Linfo_string43:
	.asciz	"atomic"
.Linfo_string44:
	.asciz	"_RINvNtNtCs4NRVxsYgnAr_4core4sync6atomic10atomic_subjjECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string45:
	.asciz	"atomic_sub<usize, usize>"
.Linfo_string46:
	.asciz	"Atomic"
.Linfo_string47:
	.asciz	"_RNvMs1k_NtNtCs4NRVxsYgnAr_4core4sync6atomicINtB6_6AtomicjE9fetch_sub"
.Linfo_string48:
	.asciz	"fetch_sub"
.Linfo_string49:
	.asciz	"{impl#41}"
.Linfo_string50:
	.asciz	"_RNvXsD_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBH_"
.Linfo_string51:
	.asciz	"drop<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string52:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEEB1a_"
.Linfo_string53:
	.asciz	"drop_glue<alloc::sync::Arc<state_and_cancellation::CountWake, alloc::alloc::Global>>"
.Linfo_string54:
	.asciz	"mem"
.Linfo_string55:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem4dropINtNtCscdodAO9FK5_5alloc4sync3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEEB15_"
.Linfo_string56:
	.asciz	"drop<alloc::sync::Arc<state_and_cancellation::CountWake, alloc::alloc::Global>>"
.Linfo_string57:
	.asciz	"task"
.Linfo_string58:
	.asciz	"raw_waker"
.Linfo_string59:
	.asciz	"_RINvNtNtCs4NRVxsYgnAr_4core4sync6atomic10atomic_addjjECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string60:
	.asciz	"atomic_add<usize, usize>"
.Linfo_string61:
	.asciz	"_RNvMs1k_NtNtCs4NRVxsYgnAr_4core4sync6atomicINtB6_6AtomicjE9fetch_add"
.Linfo_string62:
	.asciz	"fetch_add"
.Linfo_string63:
	.asciz	"{impl#32}"
.Linfo_string64:
	.asciz	"_RNvXsu_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneBH_"
.Linfo_string65:
	.asciz	"clone<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string66:
	.asciz	"maybe_dangling"
.Linfo_string67:
	.asciz	"{impl#4}"
.Linfo_string68:
	.asciz	"_RNvXs2_NtNtCs4NRVxsYgnAr_4core3mem14maybe_danglingINtB5_13MaybeDanglingINtNtCscdodAO9FK5_5alloc4sync3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEENtNtB9_5clone5Clone5cloneB1G_"
.Linfo_string69:
	.asciz	"clone<alloc::sync::Arc<state_and_cancellation::CountWake, alloc::alloc::Global>>"
.Linfo_string70:
	.asciz	"manually_drop"
.Linfo_string71:
	.asciz	"{impl#12}"
.Linfo_string72:
	.asciz	"_RNvXsa_NtNtCs4NRVxsYgnAr_4core3mem13manually_dropINtB5_12ManuallyDropINtNtCscdodAO9FK5_5alloc4sync3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEENtNtB9_5clone5Clone5cloneB1E_"
.Linfo_string73:
	.asciz	"_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE25increment_strong_count_inBH_"
.Linfo_string74:
	.asciz	"increment_strong_count_in<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string75:
	.asciz	"_RNvMsm_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE22increment_strong_countBH_"
.Linfo_string76:
	.asciz	"increment_strong_count<state_and_cancellation::CountWake>"
.Linfo_string77:
	.asciz	"{impl#1}"
.Linfo_string78:
	.asciz	"_RNvXs_Cs6ruGKiyv7y9_22state_and_cancellationNtB4_9CountWakeNtNtCscdodAO9FK5_5alloc4task4Wake11wake_by_ref"
.Linfo_string79:
	.asciz	"wake_by_ref"
.Linfo_string80:
	.asciz	"_RNvMsm_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE8from_rawBH_"
.Linfo_string81:
	.asciz	"from_raw<state_and_cancellation::CountWake>"
.Linfo_string82:
	.asciz	"_RNvXs_Cs6ruGKiyv7y9_22state_and_cancellationNtB4_9CountWakeNtNtCscdodAO9FK5_5alloc4task4Wake4wake"
.Linfo_string83:
	.asciz	"wake"
.Linfo_string84:
	.asciz	"lang_start"
.Linfo_string85:
	.asciz	"_RNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0Cs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string86:
	.asciz	"{closure#0}<()>"
.Linfo_string87:
	.asciz	"_RNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_onceCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string88:
	.asciz	"call_once<std::rt::lang_start::{closure_env#0}<()>, ()>"
.Linfo_string89:
	.asciz	"slice"
.Linfo_string90:
	.asciz	"iter"
.Linfo_string91:
	.asciz	"{impl#178}"
.Linfo_string92:
	.asciz	"_RNvXs2Q_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB6_7IterMuthENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string93:
	.asciz	"next<u8>"
.Linfo_string94:
	.asciz	"adapters"
.Linfo_string95:
	.asciz	"enumerate"
.Linfo_string96:
	.asciz	"_RNvXs_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters9enumerateINtB4_9EnumerateINtNtNtBa_5slice4iter7IterMuthEENtNtNtB8_6traits8iterator8Iterator4nextCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string97:
	.asciz	"next<core::slice::iter::IterMut<u8>>"
.Linfo_string98:
	.asciz	"num"
.Linfo_string99:
	.asciz	"{impl#6}"
.Linfo_string100:
	.asciz	"_RNvMs4_NtCs4NRVxsYgnAr_4core3numh12wrapping_mul"
.Linfo_string101:
	.asciz	"wrapping_mul"
.Linfo_string102:
	.asciz	"_RNvMs4_NtCs4NRVxsYgnAr_4core3numh12wrapping_add"
.Linfo_string103:
	.asciz	"wrapping_add"
.Linfo_string104:
	.asciz	"non_null"
.Linfo_string105:
	.asciz	"NonNull"
.Linfo_string106:
	.asciz	"_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullhE3addCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string107:
	.asciz	"add<u8>"
.Linfo_string108:
	.asciz	"_RNvNtCscdodAO9FK5_5alloc5alloc5alloc"
.Linfo_string109:
	.asciz	"Global"
.Linfo_string110:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5allocNtB2_6Global18alloc_impl_runtime"
.Linfo_string111:
	.asciz	"alloc_impl_runtime"
.Linfo_string112:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5allocNtB2_6Global10alloc_impl"
.Linfo_string113:
	.asciz	"alloc_impl"
.Linfo_string114:
	.asciz	"_RNvXs_NtCscdodAO9FK5_5alloc5allocNtB4_6GlobalNtNtCs4NRVxsYgnAr_4core5alloc9Allocator8allocate"
.Linfo_string115:
	.asciz	"allocate"
.Linfo_string116:
	.asciz	"raw_vec"
.Linfo_string117:
	.asciz	"RawVecInner"
.Linfo_string118:
	.asciz	"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string119:
	.asciz	"try_allocate_in<alloc::alloc::Global>"
.Linfo_string120:
	.asciz	"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string121:
	.asciz	"with_capacity_in<alloc::alloc::Global>"
.Linfo_string122:
	.asciz	"RawVec"
.Linfo_string123:
	.asciz	"_RNvMs3_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecyE16with_capacity_inCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string124:
	.asciz	"with_capacity_in<u64, alloc::alloc::Global>"
.Linfo_string125:
	.asciz	"collections"
.Linfo_string126:
	.asciz	"vec_deque"
.Linfo_string127:
	.asciz	"VecDeque"
.Linfo_string128:
	.asciz	"_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE16with_capacity_inCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string129:
	.asciz	"_RNvMs2_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE13with_capacityCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string130:
	.asciz	"with_capacity<u64>"
.Linfo_string131:
	.asciz	"{impl#25}"
.Linfo_string132:
	.asciz	"_RNvXsn_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyEINtNtCs4NRVxsYgnAr_4core7convert4FromAyj1_E4fromCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string133:
	.asciz	"from<u64, 1>"
.Linfo_string134:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr19copy_nonoverlappingyECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string135:
	.asciz	"copy_nonoverlapping<u64>"
.Linfo_string136:
	.asciz	"boxed"
.Linfo_string137:
	.asciz	"_RNvNtCscdodAO9FK5_5alloc5boxed14box_new_uninit"
.Linfo_string138:
	.asciz	"box_new_uninit"
.Linfo_string139:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxINtNtB4_2rc7RcInnerINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB4_11collections9vec_deque8VecDequeyEEEE3newCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string140:
	.asciz	"new<alloc::rc::RcInner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>>"
.Linfo_string141:
	.asciz	"rc"
.Linfo_string142:
	.asciz	"Rc"
.Linfo_string143:
	.asciz	"_RNvMs7_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE3newCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string144:
	.asciz	"new<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string145:
	.asciz	"_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE13from_inner_inCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string146:
	.asciz	"from_inner_in<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string147:
	.asciz	"_RNvMs5_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE10from_innerCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string148:
	.asciz	"from_inner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string149:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem7replacejECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string150:
	.asciz	"replace<usize>"
.Linfo_string151:
	.asciz	"cell"
.Linfo_string152:
	.asciz	"Cell"
.Linfo_string153:
	.asciz	"_RNvMs7_NtCs4NRVxsYgnAr_4core4cellINtB5_4CelljE7replaceCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string154:
	.asciz	"_RNvMs7_NtCs4NRVxsYgnAr_4core4cellINtB5_4CelljE3setCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string155:
	.asciz	"set<usize>"
.Linfo_string156:
	.asciz	"RcInnerPtr"
.Linfo_string157:
	.asciz	"_RNvYINtNtCscdodAO9FK5_5alloc2rc7RcInnerINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEENtB5_10RcInnerPtr10inc_strongCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string158:
	.asciz	"inc_strong<alloc::rc::RcInner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>>"
.Linfo_string159:
	.asciz	"{impl#35}"
.Linfo_string160:
	.asciz	"_RNvXsx_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEENtNtBH_5clone5Clone5cloneCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string161:
	.asciz	"clone<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string162:
	.asciz	"intrinsics"
.Linfo_string163:
	.asciz	"_RNvNtCs4NRVxsYgnAr_4core10intrinsics8unlikely"
.Linfo_string164:
	.asciz	"unlikely"
.Linfo_string165:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeE3newBF_"
.Linfo_string166:
	.asciz	"new<state_and_cancellation::SafeTake>"
.Linfo_string167:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeE3pinBF_"
.Linfo_string168:
	.asciz	"pin<state_and_cancellation::SafeTake>"
.Linfo_string169:
	.asciz	"poll"
.Linfo_string170:
	.asciz	"Poll"
.Linfo_string171:
	.asciz	"_RNvMNtNtCs4NRVxsYgnAr_4core4task4pollINtB2_4PollyE8is_readyCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string172:
	.asciz	"is_ready<u64>"
.Linfo_string173:
	.asciz	"_RNvMNtNtCs4NRVxsYgnAr_4core4task4pollINtB2_4PollyE10is_pendingCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string174:
	.asciz	"is_pending<u64>"
.Linfo_string175:
	.asciz	"_RNvMs1_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullINtNtCscdodAO9FK5_5alloc2rc7RcInnerINtNtB9_4cell7RefCellINtNtNtBY_11collections9vec_deque8VecDequeyEEEE6as_refCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string176:
	.asciz	"as_ref<alloc::rc::RcInner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>>"
.Linfo_string177:
	.asciz	"_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE5innerCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string178:
	.asciz	"inner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string179:
	.asciz	"{impl#34}"
.Linfo_string180:
	.asciz	"_RNvXsw_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEENtNtNtBH_3ops4drop4Drop4dropCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string181:
	.asciz	"drop<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string182:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc2rc2RcINtNtB4_4cell7RefCellINtNtNtBG_11collections9vec_deque8VecDequeyEEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string183:
	.asciz	"drop_glue<alloc::rc::Rc<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>>"
.Linfo_string184:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeEBD_"
.Linfo_string185:
	.asciz	"drop_glue<state_and_cancellation::SafeTake>"
.Linfo_string186:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeEEB1b_"
.Linfo_string187:
	.asciz	"drop_glue<alloc::boxed::Box<state_and_cancellation::SafeTake, alloc::alloc::Global>>"
.Linfo_string188:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeEEEB1r_"
.Linfo_string189:
	.asciz	"drop_glue<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::SafeTake, alloc::alloc::Global>>>"
.Linfo_string190:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem4dropINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeEEEB1m_"
.Linfo_string191:
	.asciz	"drop<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::SafeTake, alloc::alloc::Global>>>"
.Linfo_string192:
	.asciz	"_RNvYINtNtCscdodAO9FK5_5alloc2rc7RcInnerINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEENtB5_10RcInnerPtr10dec_strongCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string193:
	.asciz	"dec_strong<alloc::rc::RcInner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>>"
.Linfo_string194:
	.asciz	"_RNvNtCscdodAO9FK5_5alloc5alloc15dealloc_nonnull"
.Linfo_string195:
	.asciz	"dealloc_nonnull"
.Linfo_string196:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5allocNtB2_6Global23deallocate_impl_runtime"
.Linfo_string197:
	.asciz	"deallocate_impl_runtime"
.Linfo_string198:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5allocNtB2_6Global15deallocate_impl"
.Linfo_string199:
	.asciz	"deallocate_impl"
.Linfo_string200:
	.asciz	"_RNvXs_NtCscdodAO9FK5_5alloc5allocNtB4_6GlobalNtNtCs4NRVxsYgnAr_4core5alloc9Allocator10deallocate"
.Linfo_string201:
	.asciz	"deallocate"
.Linfo_string202:
	.asciz	"{impl#10}"
.Linfo_string203:
	.asciz	"_RNvXs8_NtCscdodAO9FK5_5alloc5boxedINtB5_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation8SafeTakeENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBI_"
.Linfo_string204:
	.asciz	"drop<state_and_cancellation::SafeTake, alloc::alloc::Global>"
.Linfo_string205:
	.asciz	"_RNvMs8_NtCs4NRVxsYgnAr_4core4cellINtB5_4CelliE3getCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string206:
	.asciz	"get<isize>"
.Linfo_string207:
	.asciz	"BorrowRef"
.Linfo_string208:
	.asciz	"_RNvMsF_NtCs4NRVxsYgnAr_4core4cellNtB5_9BorrowRef3new"
.Linfo_string209:
	.asciz	"new"
.Linfo_string210:
	.asciz	"RefCell"
.Linfo_string211:
	.asciz	"_RNvMst_NtCs4NRVxsYgnAr_4core4cellINtB5_7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEE10try_borrowCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string212:
	.asciz	"try_borrow<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>"
.Linfo_string213:
	.asciz	"_RNvMst_NtCs4NRVxsYgnAr_4core4cellINtB5_7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEE6borrowCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string214:
	.asciz	"borrow<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>"
.Linfo_string215:
	.asciz	"_RNvNtCs4NRVxsYgnAr_4core4cell10is_reading"
.Linfo_string216:
	.asciz	"is_reading"
.Linfo_string217:
	.asciz	"{impl#5}"
.Linfo_string218:
	.asciz	"_RNvMs3_NtCs4NRVxsYgnAr_4core3numi12wrapping_add"
.Linfo_string219:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem7replaceiECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string220:
	.asciz	"replace<isize>"
.Linfo_string221:
	.asciz	"_RNvMs7_NtCs4NRVxsYgnAr_4core4cellINtB5_4CelliE7replaceCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string222:
	.asciz	"_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE3lenCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string223:
	.asciz	"len<u64, alloc::alloc::Global>"
.Linfo_string224:
	.asciz	"{impl#44}"
.Linfo_string225:
	.asciz	"_RNvXsG_NtCs4NRVxsYgnAr_4core4cellNtB5_9BorrowRefNtNtNtB7_3ops4drop4Drop4drop"
.Linfo_string226:
	.asciz	"drop"
.Linfo_string227:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtB4_4cell9BorrowRefECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string228:
	.asciz	"drop_glue<core::cell::BorrowRef>"
.Linfo_string229:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_4cell3RefINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string230:
	.asciz	"drop_glue<core::cell::Ref<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string231:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeE3newBF_"
.Linfo_string232:
	.asciz	"new<state_and_cancellation::UnsafeTake>"
.Linfo_string233:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeE3pinBF_"
.Linfo_string234:
	.asciz	"pin<state_and_cancellation::UnsafeTake>"
.Linfo_string235:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeEBD_"
.Linfo_string236:
	.asciz	"drop_glue<state_and_cancellation::UnsafeTake>"
.Linfo_string237:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeEEB1b_"
.Linfo_string238:
	.asciz	"drop_glue<alloc::boxed::Box<state_and_cancellation::UnsafeTake, alloc::alloc::Global>>"
.Linfo_string239:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeEEEB1r_"
.Linfo_string240:
	.asciz	"drop_glue<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::UnsafeTake, alloc::alloc::Global>>>"
.Linfo_string241:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem4dropINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeEEEB1m_"
.Linfo_string242:
	.asciz	"drop<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::UnsafeTake, alloc::alloc::Global>>>"
.Linfo_string243:
	.asciz	"_RNvXs8_NtCscdodAO9FK5_5alloc5boxedINtB5_3BoxNtCs6ruGKiyv7y9_22state_and_cancellation10UnsafeTakeENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBI_"
.Linfo_string244:
	.asciz	"drop<state_and_cancellation::UnsafeTake, alloc::alloc::Global>"
.Linfo_string245:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxINtNtB4_4sync8ArcInnerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEE3newB11_"
.Linfo_string246:
	.asciz	"new<alloc::sync::ArcInner<state_and_cancellation::CountWake>>"
.Linfo_string247:
	.asciz	"_RNvMse_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE3newBH_"
.Linfo_string248:
	.asciz	"new<state_and_cancellation::CountWake>"
.Linfo_string249:
	.asciz	"CountWake"
.Linfo_string250:
	.asciz	"_RNvMCs6ruGKiyv7y9_22state_and_cancellationNtB2_9CountWake3new"
.Linfo_string251:
	.asciz	"Waker"
.Linfo_string252:
	.asciz	"_RNvMs6_NtNtCs4NRVxsYgnAr_4core4task4wakeNtB5_5Waker8from_raw"
.Linfo_string253:
	.asciz	"from_raw"
.Linfo_string254:
	.asciz	"_RNvXNtCscdodAO9FK5_5alloc4taskNtNtNtCs4NRVxsYgnAr_4core4task4wake5WakerINtNtBy_7convert4FromINtNtB4_4sync3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEE4fromB1L_"
.Linfo_string255:
	.asciz	"from<state_and_cancellation::CountWake>"
.Linfo_string256:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem11size_of_valNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0EBI_"
.Linfo_string257:
	.asciz	"size_of_val<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}>"
.Linfo_string258:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem11size_of_valNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0EBI_"
.Linfo_string259:
	.asciz	"size_of_val<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}>"
.Linfo_string260:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0E3newBH_"
.Linfo_string261:
	.asciz	"new<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}>"
.Linfo_string262:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0E3pinBH_"
.Linfo_string263:
	.asciz	"pin<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}>"
.Linfo_string264:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9drive_u64NCNvB2_30holds_large_value_across_yield0EB2_"
.Linfo_string265:
	.asciz	"drive_u64<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}>"
.Linfo_string266:
	.asciz	"_RNvXs8_NtCscdodAO9FK5_5alloc5boxedINtB5_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0ENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBK_"
.Linfo_string267:
	.asciz	"drop<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}, alloc::alloc::Global>"
.Linfo_string268:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0EEB1d_"
.Linfo_string269:
	.asciz	"drop_glue<alloc::boxed::Box<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}, alloc::alloc::Global>>"
.Linfo_string270:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation30holds_large_value_across_yield0EEEB1t_"
.Linfo_string271:
	.asciz	"drop_glue<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}, alloc::alloc::Global>>>"
.Linfo_string272:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0E3newBH_"
.Linfo_string273:
	.asciz	"new<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}>"
.Linfo_string274:
	.asciz	"_RNvMNtCscdodAO9FK5_5alloc5boxedINtB2_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0E3pinBH_"
.Linfo_string275:
	.asciz	"pin<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}>"
.Linfo_string276:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9drive_u64NCNvB2_33finishes_large_value_before_yield0EB2_"
.Linfo_string277:
	.asciz	"drive_u64<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}>"
.Linfo_string278:
	.asciz	"_RNvXs8_NtCscdodAO9FK5_5alloc5boxedINtB5_3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0ENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBK_"
.Linfo_string279:
	.asciz	"drop<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}, alloc::alloc::Global>"
.Linfo_string280:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc5boxed3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0EEB1d_"
.Linfo_string281:
	.asciz	"drop_glue<alloc::boxed::Box<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}, alloc::alloc::Global>>"
.Linfo_string282:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_3pin3PinINtNtCscdodAO9FK5_5alloc5boxed3BoxNCNvCs6ruGKiyv7y9_22state_and_cancellation33finishes_large_value_before_yield0EEEB1t_"
.Linfo_string283:
	.asciz	"drop_glue<core::pin::Pin<alloc::boxed::Box<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}, alloc::alloc::Global>>>"
.Linfo_string284:
	.asciz	"_RNvXs8_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10RaceResultNtNtCs4NRVxsYgnAr_4core3cmp9PartialEq2eq"
.Linfo_string285:
	.asciz	"eq"
.Linfo_string286:
	.asciz	"_RINvNtNtCs4NRVxsYgnAr_4core4sync6atomic11atomic_loadjECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string287:
	.asciz	"atomic_load<usize>"
.Linfo_string288:
	.asciz	"_RNvMs1k_NtNtCs4NRVxsYgnAr_4core4sync6atomicINtB6_6AtomicjE4load"
.Linfo_string289:
	.asciz	"load"
.Linfo_string290:
	.asciz	"_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker10drop_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBS_"
.Linfo_string291:
	.asciz	"drop_waker<state_and_cancellation::CountWake>"
.Linfo_string292:
	.asciz	"_RNvXs8_NtNtCs4NRVxsYgnAr_4core4task4wakeNtB5_5WakerNtNtNtB9_3ops4drop4Drop4drop"
.Linfo_string293:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtNtB4_4task4wake5WakerECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string294:
	.asciz	"drop_glue<core::task::wake::Waker>"
.Linfo_string295:
	.asciz	"{impl#171}"
.Linfo_string296:
	.asciz	"_RNvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB6_4IterhENtNtNtNtBa_4iter6traits8iterator8Iterator4nextCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string297:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxhECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string298:
	.asciz	"black_box<u8>"
.Linfo_string299:
	.asciz	"{impl#9}"
.Linfo_string300:
	.asciz	"_RNvMs7_NtCs4NRVxsYgnAr_4core3numy12wrapping_add"
.Linfo_string301:
	.asciz	"{impl#15}"
.Linfo_string302:
	.asciz	"_RNvXsd_NtNtCs4NRVxsYgnAr_4core3ptr8non_nullINtB5_7NonNullhENtNtB9_3cmp9PartialEq2eqCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string303:
	.asciz	"eq<u8>"
.Linfo_string304:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core4hint9black_boxyECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string305:
	.asciz	"black_box<u64>"
.Linfo_string306:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr13drop_in_placeINtNtB4_4cell7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string307:
	.asciz	"drop_in_place<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string308:
	.asciz	"_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14current_memoryCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string309:
	.asciz	"current_memory<alloc::alloc::Global>"
.Linfo_string310:
	.asciz	"_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner10deallocateCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string311:
	.asciz	"deallocate<alloc::alloc::Global>"
.Linfo_string312:
	.asciz	"{impl#3}"
.Linfo_string313:
	.asciz	"_RNvXs1_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecyENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string314:
	.asciz	"drop<u64, alloc::alloc::Global>"
.Linfo_string315:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc7raw_vec6RawVecyEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string316:
	.asciz	"drop_glue<alloc::raw_vec::RawVec<u64, alloc::alloc::Global>>"
.Linfo_string317:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string318:
	.asciz	"drop_glue<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>"
.Linfo_string319:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_4cell10UnsafeCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string320:
	.asciz	"drop_glue<core::cell::UnsafeCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string321:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_4cell7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string322:
	.asciz	"drop_glue<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string323:
	.asciz	"{impl#11}"
.Linfo_string324:
	.asciz	"_RNvMs9_NtCs4NRVxsYgnAr_4core3numj13unchecked_mul"
.Linfo_string325:
	.asciz	"unchecked_mul"
.Linfo_string326:
	.asciz	"Weak"
.Linfo_string327:
	.asciz	"_RNvMs1b_NtCscdodAO9FK5_5alloc2rcINtB6_4WeakINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB8_11collections9vec_deque8VecDequeyEERNtNtB8_5alloc6GlobalE5innerCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string328:
	.asciz	"inner<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, &alloc::alloc::Global>"
.Linfo_string329:
	.asciz	"{impl#76}"
.Linfo_string330:
	.asciz	"_RNvXs1c_NtCscdodAO9FK5_5alloc2rcINtB6_4WeakINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB8_11collections9vec_deque8VecDequeyEERNtNtB8_5alloc6GlobalENtNtNtBK_3ops4drop4Drop4dropCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string331:
	.asciz	"drop<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, &alloc::alloc::Global>"
.Linfo_string332:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc2rc4WeakINtNtB4_4cell7RefCellINtNtNtBG_11collections9vec_deque8VecDequeyEERNtNtBG_5alloc6GlobalEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string333:
	.asciz	"drop_glue<alloc::rc::Weak<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, &alloc::alloc::Global>>"
.Linfo_string334:
	.asciz	"_RNvYNtNtCscdodAO9FK5_5alloc2rc9WeakInnerNtB4_10RcInnerPtr8dec_weakCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string335:
	.asciz	"dec_weak<alloc::rc::WeakInner>"
.Linfo_string336:
	.asciz	"{impl#2}"
.Linfo_string337:
	.asciz	"_RNvXs0_NtCs4NRVxsYgnAr_4core5allocRNtNtCscdodAO9FK5_5alloc5alloc6GlobalNtB5_9Allocator10deallocateCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string338:
	.asciz	"_RNvMsJ_NtCscdodAO9FK5_5alloc4syncINtB5_4WeakNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeRNtNtB7_5alloc6GlobalE5innerBI_"
.Linfo_string339:
	.asciz	"inner<state_and_cancellation::CountWake, &alloc::alloc::Global>"
.Linfo_string340:
	.asciz	"{impl#51}"
.Linfo_string341:
	.asciz	"_RNvXsN_NtCscdodAO9FK5_5alloc4syncINtB5_4WeakNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeRNtNtB7_5alloc6GlobalENtNtNtCs4NRVxsYgnAr_4core3ops4drop4Drop4dropBI_"
.Linfo_string342:
	.asciz	"drop<state_and_cancellation::CountWake, &alloc::alloc::Global>"
.Linfo_string343:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc4sync4WeakNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeRNtNtBG_5alloc6GlobalEEB1b_"
.Linfo_string344:
	.asciz	"drop_glue<alloc::sync::Weak<state_and_cancellation::CountWake, &alloc::alloc::Global>>"
.Linfo_string345:
	.asciz	"_RNvMs6_NtNtCs4NRVxsYgnAr_4core4task4wakeNtB5_5Waker11wake_by_ref"
.Linfo_string346:
	.asciz	"{impl#8}"
.Linfo_string347:
	.asciz	"_RNvXs6_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10RaceResultNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt"
.Linfo_string348:
	.asciz	"fmt"
.Linfo_string349:
	.asciz	"{impl#80}"
.Linfo_string350:
	.asciz	"Formatter"
.Linfo_string351:
	.asciz	"_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter15debug_lower_hex"
.Linfo_string352:
	.asciz	"debug_lower_hex"
.Linfo_string353:
	.asciz	"{impl#63}"
.Linfo_string354:
	.asciz	"_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt"
.Linfo_string355:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3mem7replaceINtNtB4_6option6OptionyEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string356:
	.asciz	"replace<core::option::Option<u64>>"
.Linfo_string357:
	.asciz	"option"
.Linfo_string358:
	.asciz	"Option"
.Linfo_string359:
	.asciz	"_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionyE4takeCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string360:
	.asciz	"take<u64>"
.Linfo_string361:
	.asciz	"_RNvMNtCs4NRVxsYgnAr_4core6optionINtB2_6OptionyE6expectCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string362:
	.asciz	"expect<u64>"
.Linfo_string363:
	.asciz	"{impl#28}"
.Linfo_string364:
	.asciz	"_RNvXsq_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEENtNtNtBH_3ops5deref5Deref5derefCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string365:
	.asciz	"deref<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string366:
	.asciz	"BorrowRefMut"
.Linfo_string367:
	.asciz	"_RNvMsP_NtCs4NRVxsYgnAr_4core4cellNtB5_12BorrowRefMut3new"
.Linfo_string368:
	.asciz	"_RNvMst_NtCs4NRVxsYgnAr_4core4cellINtB5_7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEE14try_borrow_mutCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string369:
	.asciz	"try_borrow_mut<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>"
.Linfo_string370:
	.asciz	"_RNvMst_NtCs4NRVxsYgnAr_4core4cellINtB5_7RefCellINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEE10borrow_mutCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string371:
	.asciz	"borrow_mut<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>"
.Linfo_string372:
	.asciz	"_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE8is_emptyCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string373:
	.asciz	"is_empty<u64, alloc::alloc::Global>"
.Linfo_string374:
	.asciz	"_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE9pop_frontCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string375:
	.asciz	"pop_front<u64, alloc::alloc::Global>"
.Linfo_string376:
	.asciz	"_RNvMs9_NtCs4NRVxsYgnAr_4core3numj12wrapping_add"
.Linfo_string377:
	.asciz	"_RNvMs1_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE8wrap_addCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string378:
	.asciz	"wrap_add<u64, alloc::alloc::Global>"
.Linfo_string379:
	.asciz	"_RNvMs1_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE16to_wrapped_indexCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string380:
	.asciz	"to_wrapped_index<u64, alloc::alloc::Global>"
.Linfo_string381:
	.asciz	"_RNvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner8capacityCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string382:
	.asciz	"capacity<alloc::alloc::Global>"
.Linfo_string383:
	.asciz	"_RNvMs0_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecyE8capacityCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string384:
	.asciz	"capacity<u64, alloc::alloc::Global>"
.Linfo_string385:
	.asciz	"_RNvMs3_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE8capacityCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string386:
	.asciz	"_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner8non_nullyECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string387:
	.asciz	"non_null<alloc::alloc::Global, u64>"
.Linfo_string388:
	.asciz	"_RINvMs2_NtCscdodAO9FK5_5alloc7raw_vecNtB6_11RawVecInner3ptryECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string389:
	.asciz	"ptr<alloc::alloc::Global, u64>"
.Linfo_string390:
	.asciz	"_RNvMs0_NtCscdodAO9FK5_5alloc7raw_vecINtB5_6RawVecyE3ptrCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string391:
	.asciz	"ptr<u64, alloc::alloc::Global>"
.Linfo_string392:
	.asciz	"_RNvMs1_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE3ptrCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string393:
	.asciz	"_RNvMs1_NtNtCscdodAO9FK5_5alloc11collections9vec_dequeINtB5_8VecDequeyE11buffer_readCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string394:
	.asciz	"buffer_read<u64, alloc::alloc::Global>"
.Linfo_string395:
	.asciz	"index"
.Linfo_string396:
	.asciz	"_RNvNtNtNtCscdodAO9FK5_5alloc11collections9vec_deque5index10wrap_index"
.Linfo_string397:
	.asciz	"wrap_index"
.Linfo_string398:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr4readyECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string399:
	.asciz	"read<u64>"
.Linfo_string400:
	.asciz	"{impl#52}"
.Linfo_string401:
	.asciz	"_RNvXsO_NtCs4NRVxsYgnAr_4core4cellNtB5_12BorrowRefMutNtNtNtB7_3ops4drop4Drop4drop"
.Linfo_string402:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtNtB4_4cell12BorrowRefMutECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string403:
	.asciz	"drop_glue<core::cell::BorrowRefMut>"
.Linfo_string404:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtB4_4cell6RefMutINtNtNtCscdodAO9FK5_5alloc11collections9vec_deque8VecDequeyEEECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string405:
	.asciz	"drop_glue<core::cell::RefMut<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>>"
.Linfo_string406:
	.asciz	"{impl#7}"
.Linfo_string407:
	.asciz	"{impl#61}"
.Linfo_string408:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_30holds_large_value_across_yield0EB2_"
.Linfo_string409:
	.asciz	"poll_once<state_and_cancellation::holds_large_value_across_yield::{async_fn_env#0}>"
.Linfo_string410:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNCNvB2_33finishes_large_value_before_yield0EB2_"
.Linfo_string411:
	.asciz	"poll_once<state_and_cancellation::finishes_large_value_before_yield::{async_fn_env#0}>"
.Linfo_string412:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_10UnsafeTakeEB2_"
.Linfo_string413:
	.asciz	"poll_once<state_and_cancellation::UnsafeTake>"
.Linfo_string414:
	.asciz	"_RINvCs6ruGKiyv7y9_22state_and_cancellation9poll_onceNtB2_8SafeTakeEB2_"
.Linfo_string415:
	.asciz	"poll_once<state_and_cancellation::SafeTake>"
.Linfo_string416:
	.asciz	"_RINvNtCs2AWtUsOyxgP_3std2rt10lang_startuECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string417:
	.asciz	"lang_start<()>"
.Linfo_string418:
	.asciz	"_RINvNtCs4NRVxsYgnAr_4core9panicking13assert_failedNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultBM_EBO_"
.Linfo_string419:
	.asciz	"assert_failed<state_and_cancellation::RaceResult, state_and_cancellation::RaceResult>"
.Linfo_string420:
	.asciz	"_RINvNtNtCs2AWtUsOyxgP_3std3sys9backtrace28___rust_begin_short_backtraceFEuuECs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string421:
	.asciz	"__rust_begin_short_backtrace<fn(), ()>"
.Linfo_string422:
	.asciz	"_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11clone_wakerNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_"
.Linfo_string423:
	.asciz	"clone_waker<state_and_cancellation::CountWake>"
.Linfo_string424:
	.asciz	"_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker11wake_by_refNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBT_"
.Linfo_string425:
	.asciz	"wake_by_ref<state_and_cancellation::CountWake>"
.Linfo_string426:
	.asciz	"_RINvNvNtCscdodAO9FK5_5alloc4task9raw_waker4wakeNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeEBL_"
.Linfo_string427:
	.asciz	"wake<state_and_cancellation::CountWake>"
.Linfo_string428:
	.asciz	"_RNSNvYNCINvNtCs2AWtUsOyxgP_3std2rt10lang_startuE0INtNtNtCs4NRVxsYgnAr_4core3ops8function6FnOnceuE9call_once6vtableCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string429:
	.asciz	"_RNvCs6ruGKiyv7y9_22state_and_cancellation10fill_bytes"
.Linfo_string430:
	.asciz	"fill_bytes"
.Linfo_string431:
	.asciz	"_RNvCs6ruGKiyv7y9_22state_and_cancellation13run_safe_race"
.Linfo_string432:
	.asciz	"run_safe_race"
.Linfo_string433:
	.asciz	"_RNvCs6ruGKiyv7y9_22state_and_cancellation15run_unsafe_race"
.Linfo_string434:
	.asciz	"run_unsafe_race"
.Linfo_string435:
	.asciz	"_RNvCs6ruGKiyv7y9_22state_and_cancellation4main"
.Linfo_string436:
	.asciz	"main"
.Linfo_string437:
	.asciz	"_RNvCs6ruGKiyv7y9_22state_and_cancellation8checksum"
.Linfo_string438:
	.asciz	"checksum"
.Linfo_string439:
	.asciz	"_RNvMs6_NtCscdodAO9FK5_5alloc2rcINtB5_2RcINtNtCs4NRVxsYgnAr_4core4cell7RefCellINtNtNtB7_11collections9vec_deque8VecDequeyEEE9drop_slowCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string440:
	.asciz	"drop_slow<core::cell::RefCell<alloc::collections::vec_deque::VecDeque<u64, alloc::alloc::Global>>, alloc::alloc::Global>"
.Linfo_string441:
	.asciz	"_RNvMsn_NtCscdodAO9FK5_5alloc4syncINtB5_3ArcNtCs6ruGKiyv7y9_22state_and_cancellation9CountWakeE9drop_slowBH_"
.Linfo_string442:
	.asciz	"drop_slow<state_and_cancellation::CountWake, alloc::alloc::Global>"
.Linfo_string443:
	.asciz	"_RNvXs1_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_9YieldOnceNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll"
.Linfo_string444:
	.asciz	"_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCs6ruGKiyv7y9_22state_and_cancellation10RaceResultNtB6_5Debug3fmtBy_"
.Linfo_string445:
	.asciz	"fmt<state_and_cancellation::RaceResult>"
.Linfo_string446:
	.asciz	"_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCs6ruGKiyv7y9_22state_and_cancellation"
.Linfo_string447:
	.asciz	"fmt<usize>"
.Linfo_string448:
	.asciz	"_RNvXs3_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_10UnsafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll"
.Linfo_string449:
	.asciz	"_RNvXs5_Cs6ruGKiyv7y9_22state_and_cancellationNtB5_8SafeTakeNtNtNtCs4NRVxsYgnAr_4core6future6future6Future4poll"
.Linfo_string450:
	.asciz	"_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt"
	.ident	"rustc version 1.97.1 (8bab26f4f 2026-07-14)"
	.section	".note.GNU-stack","",@progbits
	.section	.debug_line,"",@progbits
.Lline_table_start0:
