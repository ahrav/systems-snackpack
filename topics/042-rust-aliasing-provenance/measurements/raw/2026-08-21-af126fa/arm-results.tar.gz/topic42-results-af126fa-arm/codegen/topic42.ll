; ModuleID = 'rust_aliasing_provenance.511b75d295427f42-cgu.0'
source_filename = "rust_aliasing_provenance.511b75d295427f42-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

; rust_aliasing_provenance::raw_alias_example
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define void @_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) initializes((0, 24)) %_0) unnamed_addr #0 {
start:
  %value = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %value)
  store i64 7, ptr %value, align 8
  %returned = call noundef i64 @topic42_raw_contract(ptr noundef nonnull %value, ptr noundef nonnull %value) #3
  %_5 = load i64, ptr %value, align 8, !noundef !2
  store i64 %returned, ptr %_0, align 8
  %0 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_5, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_5, ptr %1, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %value)
  ret void
}

; rust_aliasing_provenance::reference_example
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define void @_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) initializes((0, 24)) %_0) unnamed_addr #0 {
start:
  %source = alloca [8 x i8], align 8
  %destination = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %destination)
  store i64 7, ptr %source, align 8
  %returned = call noundef i64 @topic42_reference_contract(ptr noalias noundef nonnull align 8 dereferenceable(8) %destination, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %source) #3
  %_6 = load i64, ptr %destination, align 8, !noundef !2
  store i64 %returned, ptr %_0, align 8
  %0 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 7, ptr %1, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %destination)
  ret void
}

; rust_aliasing_provenance::raw_distinct_example
; Function Attrs: mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define void @_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) initializes((0, 24)) %_0) unnamed_addr #0 {
start:
  %source = alloca [8 x i8], align 8
  %destination = alloca [8 x i8], align 8
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %destination)
  call void @llvm.lifetime.start.p0(i64 8, ptr nonnull %source)
  store i64 7, ptr %source, align 8
  %returned = call noundef i64 @topic42_raw_contract(ptr noundef nonnull %destination, ptr noundef nonnull %source) #3
  %_6 = load i64, ptr %destination, align 8, !noundef !2
  store i64 %returned, ptr %_0, align 8
  %0 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_6, ptr %0, align 8
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 7, ptr %1, align 8
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %source)
  call void @llvm.lifetime.end.p0(i64 8, ptr nonnull %destination)
  ret void
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define noundef i64 @topic42_raw_contract(ptr noundef writeonly captures(none) initializes((0, 8)) %destination, ptr noundef readonly captures(none) %source) unnamed_addr #1 {
start:
  %first = load i64, ptr %source, align 8, !noundef !2
  %_4 = add i64 %first, 1
  store i64 %_4, ptr %destination, align 8
  %_5 = load i64, ptr %source, align 8, !noundef !2
  %_0 = add i64 %_5, %first
  ret i64 %_0
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define noundef range(i64 0, -1) i64 @topic42_reference_contract(ptr noalias noundef writeonly align 8 captures(none) dereferenceable(8) initializes((0, 8)) %destination, ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %source) unnamed_addr #1 {
start:
  %first = load i64, ptr %source, align 8, !noundef !2
  %_4 = add i64 %first, 1
  store i64 %_4, ptr %destination, align 8
  %_0 = shl i64 %first, 1
  ret i64 %_0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(i64 immarg, ptr captures(none)) #2

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(i64 immarg, ptr captures(none)) #2

attributes #0 = { mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+v8a,+outline-atomics" }
attributes #1 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+v8a,+outline-atomics" }
attributes #2 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #3 = { noinline nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{!"rustc version 1.93.1 (01f6ddf75 2026-02-11)"}
!2 = !{}
