	.file	"rust_aliasing_provenance.511b75d295427f42-cgu.0"
	.section	.text._ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E,@function
_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E:
	.cfi_startproc
	stp	x29, x30, [sp, #-32]!
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	x19, x8
	mov	w8, #7
	add	x0, x29, #24
	add	x1, x29, #24
	str	x8, [x29, #24]
	bl	topic42_raw_contract
	ldr	x8, [x29, #24]
	stp	x0, x8, [x19]
	str	x8, [x19, #16]
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]
	ldp	x29, x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end0:
	.size	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E, .Lfunc_end0-_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E
	.cfi_endproc

	.section	.text._ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E,@function
_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]
	stp	x20, x19, [sp, #32]
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	w20, #7
	mov	x0, sp
	add	x1, sp, #8
	mov	x19, x8
	str	x20, [sp, #8]
	bl	topic42_reference_contract
	ldr	x8, [sp]
	stp	x0, x8, [x19]
	str	x20, [x19, #16]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end1:
	.size	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E, .Lfunc_end1-_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E
	.cfi_endproc

	.section	.text._ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E,@function
_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #16]
	stp	x20, x19, [sp, #32]
	add	x29, sp, #16
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	w20, #7
	mov	x0, sp
	add	x1, sp, #8
	mov	x19, x8
	str	x20, [sp, #8]
	bl	topic42_raw_contract
	ldr	x8, [sp]
	stp	x0, x8, [x19]
	str	x20, [x19, #16]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]
	ldp	x29, x30, [sp, #16]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end2:
	.size	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E, .Lfunc_end2-_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E
	.cfi_endproc

	.section	.text.topic42_raw_contract,"ax",@progbits
	.globl	topic42_raw_contract
	.p2align	4
	.type	topic42_raw_contract,@function
topic42_raw_contract:
	.cfi_startproc
	ldr	x8, [x1]
	add	x9, x8, #1
	str	x9, [x0]
	ldr	x9, [x1]
	add	x0, x9, x8
	ret
.Lfunc_end3:
	.size	topic42_raw_contract, .Lfunc_end3-topic42_raw_contract
	.cfi_endproc

	.section	.text.topic42_reference_contract,"ax",@progbits
	.globl	topic42_reference_contract
	.p2align	4
	.type	topic42_reference_contract,@function
topic42_reference_contract:
	.cfi_startproc
	ldr	x8, [x1]
	add	x9, x8, #1
	str	x9, [x0]
	lsl	x0, x8, #1
	ret
.Lfunc_end4:
	.size	topic42_reference_contract, .Lfunc_end4-topic42_reference_contract
	.cfi_endproc

	.ident	"rustc version 1.93.1 (01f6ddf75 2026-02-11)"
	.section	".note.GNU-stack","",@progbits
