	.file	"rust_aliasing_provenance.511b75d295427f42-cgu.0"
	.section	.text._ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E,@function
_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	$7, 8(%rsp)
	leaq	8(%rsp), %rdi
	movq	%rdi, %rsi
	callq	*topic42_raw_contract@GOTPCREL(%rip)
	movq	8(%rsp), %rcx
	movq	%rax, (%rbx)
	movq	%rcx, 8(%rbx)
	movq	%rcx, 16(%rbx)
	movq	%rbx, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E, .Lfunc_end0-_ZN24rust_aliasing_provenance17raw_alias_example17h8382fb6169d0cbe9E
	.cfi_endproc

	.section	.text._ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E,@function
_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	$7, 8(%rsp)
	movq	%rsp, %rdi
	leaq	8(%rsp), %rsi
	callq	*topic42_reference_contract@GOTPCREL(%rip)
	movq	(%rsp), %rcx
	movq	%rax, (%rbx)
	movq	%rcx, 8(%rbx)
	movq	$7, 16(%rbx)
	movq	%rbx, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end1:
	.size	_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E, .Lfunc_end1-_ZN24rust_aliasing_provenance17reference_example17h8b066dce3492e9a0E
	.cfi_endproc

	.section	.text._ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E,"ax",@progbits
	.globl	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E
	.p2align	4
	.type	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E,@function
_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	subq	$16, %rsp
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	$7, 8(%rsp)
	movq	%rsp, %rdi
	leaq	8(%rsp), %rsi
	callq	*topic42_raw_contract@GOTPCREL(%rip)
	movq	(%rsp), %rcx
	movq	%rax, (%rbx)
	movq	%rcx, 8(%rbx)
	movq	$7, 16(%rbx)
	movq	%rbx, %rax
	addq	$16, %rsp
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E, .Lfunc_end2-_ZN24rust_aliasing_provenance20raw_distinct_example17h2867bf717bc8a194E
	.cfi_endproc

	.section	.text.topic42_raw_contract,"ax",@progbits
	.globl	topic42_raw_contract
	.p2align	4
	.type	topic42_raw_contract,@function
topic42_raw_contract:
	.cfi_startproc
	movq	(%rsi), %rax
	leaq	1(%rax), %rcx
	movq	%rcx, (%rdi)
	addq	(%rsi), %rax
	retq
.Lfunc_end3:
	.size	topic42_raw_contract, .Lfunc_end3-topic42_raw_contract
	.cfi_endproc

	.section	.text.topic42_reference_contract,"ax",@progbits
	.globl	topic42_reference_contract
	.p2align	4
	.type	topic42_reference_contract,@function
topic42_reference_contract:
	.cfi_startproc
	movq	(%rsi), %rax
	leaq	1(%rax), %rcx
	movq	%rcx, (%rdi)
	addq	%rax, %rax
	retq
.Lfunc_end4:
	.size	topic42_reference_contract, .Lfunc_end4-topic42_reference_contract
	.cfi_endproc

	.ident	"rustc version 1.93.1 (01f6ddf75 2026-02-11)"
	.section	".note.GNU-stack","",@progbits
