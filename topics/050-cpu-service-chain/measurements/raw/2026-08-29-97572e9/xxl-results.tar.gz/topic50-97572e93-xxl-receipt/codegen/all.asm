
/tmp/topic50-97572e93-xxl-receipt/experiment/lock_holder_preemption:     file format elf64-x86-64


Disassembly of section .init:

0000000000401000 <_init>:
  401000:	endbr64
  401004:	sub    $0x8,%rsp
  401008:	mov    0x3fc9(%rip),%rax        # 404fd8 <__gmon_start__@Base>
  40100f:	test   %rax,%rax
  401012:	je     401016 <_init+0x16>
  401014:	call   *%rax
  401016:	add    $0x8,%rsp
  40101a:	ret

Disassembly of section .plt:

0000000000401020 <abort@plt-0x10>:
  401020:	push   0x3fca(%rip)        # 404ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
  401026:	jmp    *0x3fcc(%rip)        # 404ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
  40102c:	nopl   0x0(%rax)

0000000000401030 <abort@plt>:
  401030:	jmp    *0x3fca(%rip)        # 405000 <abort@GLIBC_2.2.5>
  401036:	push   $0x0
  40103b:	jmp    401020 <_init+0x20>

0000000000401040 <__errno_location@plt>:
  401040:	jmp    *0x3fc2(%rip)        # 405008 <__errno_location@GLIBC_2.2.5>
  401046:	push   $0x1
  40104b:	jmp    401020 <_init+0x20>

0000000000401050 <getpriority@plt>:
  401050:	jmp    *0x3fba(%rip)        # 405010 <getpriority@GLIBC_2.2.5>
  401056:	push   $0x2
  40105b:	jmp    401020 <_init+0x20>

0000000000401060 <pthread_barrier_init@plt>:
  401060:	jmp    *0x3fb2(%rip)        # 405018 <pthread_barrier_init@GLIBC_2.34>
  401066:	push   $0x3
  40106b:	jmp    401020 <_init+0x20>

0000000000401070 <pthread_setaffinity_np@plt>:
  401070:	jmp    *0x3faa(%rip)        # 405020 <pthread_setaffinity_np@GLIBC_2.34>
  401076:	push   $0x4
  40107b:	jmp    401020 <_init+0x20>

0000000000401080 <pthread_barrier_wait@plt>:
  401080:	jmp    *0x3fa2(%rip)        # 405028 <pthread_barrier_wait@GLIBC_2.34>
  401086:	push   $0x5
  40108b:	jmp    401020 <_init+0x20>

0000000000401090 <clock_gettime@plt>:
  401090:	jmp    *0x3f9a(%rip)        # 405030 <clock_gettime@GLIBC_2.17>
  401096:	push   $0x6
  40109b:	jmp    401020 <_init+0x20>

00000000004010a0 <getpid@plt>:
  4010a0:	jmp    *0x3f92(%rip)        # 405038 <getpid@GLIBC_2.2.5>
  4010a6:	push   $0x7
  4010ab:	jmp    401020 <_init+0x20>

00000000004010b0 <__sched_cpucount@plt>:
  4010b0:	jmp    *0x3f8a(%rip)        # 405040 <__sched_cpucount@GLIBC_2.6>
  4010b6:	push   $0x8
  4010bb:	jmp    401020 <_init+0x20>

00000000004010c0 <printf@plt>:
  4010c0:	jmp    *0x3f82(%rip)        # 405048 <printf@GLIBC_2.2.5>
  4010c6:	push   $0x9
  4010cb:	jmp    401020 <_init+0x20>

00000000004010d0 <pthread_barrier_destroy@plt>:
  4010d0:	jmp    *0x3f7a(%rip)        # 405050 <pthread_barrier_destroy@GLIBC_2.34>
  4010d6:	push   $0xa
  4010db:	jmp    401020 <_init+0x20>

00000000004010e0 <setpriority@plt>:
  4010e0:	jmp    *0x3f72(%rip)        # 405058 <setpriority@GLIBC_2.2.5>
  4010e6:	push   $0xb
  4010eb:	jmp    401020 <_init+0x20>

00000000004010f0 <fprintf@plt>:
  4010f0:	jmp    *0x3f6a(%rip)        # 405060 <fprintf@GLIBC_2.2.5>
  4010f6:	push   $0xc
  4010fb:	jmp    401020 <_init+0x20>

0000000000401100 <syscall@plt>:
  401100:	jmp    *0x3f62(%rip)        # 405068 <syscall@GLIBC_2.2.5>
  401106:	push   $0xd
  40110b:	jmp    401020 <_init+0x20>

0000000000401110 <strtol@plt>:
  401110:	jmp    *0x3f5a(%rip)        # 405070 <strtol@GLIBC_2.2.5>
  401116:	push   $0xe
  40111b:	jmp    401020 <_init+0x20>

0000000000401120 <pthread_getschedparam@plt>:
  401120:	jmp    *0x3f52(%rip)        # 405078 <pthread_getschedparam@GLIBC_2.2.5>
  401126:	push   $0xf
  40112b:	jmp    401020 <_init+0x20>

0000000000401130 <pthread_mutex_unlock@plt>:
  401130:	jmp    *0x3f4a(%rip)        # 405080 <pthread_mutex_unlock@GLIBC_2.2.5>
  401136:	push   $0x10
  40113b:	jmp    401020 <_init+0x20>

0000000000401140 <pthread_create@plt>:
  401140:	jmp    *0x3f42(%rip)        # 405088 <pthread_create@GLIBC_2.34>
  401146:	push   $0x11
  40114b:	jmp    401020 <_init+0x20>

0000000000401150 <pthread_self@plt>:
  401150:	jmp    *0x3f3a(%rip)        # 405090 <pthread_self@GLIBC_2.2.5>
  401156:	push   $0x12
  40115b:	jmp    401020 <_init+0x20>

0000000000401160 <getrusage@plt>:
  401160:	jmp    *0x3f32(%rip)        # 405098 <getrusage@GLIBC_2.2.5>
  401166:	push   $0x13
  40116b:	jmp    401020 <_init+0x20>

0000000000401170 <perror@plt>:
  401170:	jmp    *0x3f2a(%rip)        # 4050a0 <perror@GLIBC_2.2.5>
  401176:	push   $0x14
  40117b:	jmp    401020 <_init+0x20>

0000000000401180 <sched_getcpu@plt>:
  401180:	jmp    *0x3f22(%rip)        # 4050a8 <sched_getcpu@GLIBC_2.6>
  401186:	push   $0x15
  40118b:	jmp    401020 <_init+0x20>

0000000000401190 <exit@plt>:
  401190:	jmp    *0x3f1a(%rip)        # 4050b0 <exit@GLIBC_2.2.5>
  401196:	push   $0x16
  40119b:	jmp    401020 <_init+0x20>

00000000004011a0 <fwrite@plt>:
  4011a0:	jmp    *0x3f12(%rip)        # 4050b8 <fwrite@GLIBC_2.2.5>
  4011a6:	push   $0x17
  4011ab:	jmp    401020 <_init+0x20>

00000000004011b0 <sched_getaffinity@plt>:
  4011b0:	jmp    *0x3f0a(%rip)        # 4050c0 <sched_getaffinity@GLIBC_2.3.4>
  4011b6:	push   $0x18
  4011bb:	jmp    401020 <_init+0x20>

00000000004011c0 <pthread_join@plt>:
  4011c0:	jmp    *0x3f02(%rip)        # 4050c8 <pthread_join@GLIBC_2.34>
  4011c6:	push   $0x19
  4011cb:	jmp    401020 <_init+0x20>

00000000004011d0 <strerror@plt>:
  4011d0:	jmp    *0x3efa(%rip)        # 4050d0 <strerror@GLIBC_2.2.5>
  4011d6:	push   $0x1a
  4011db:	jmp    401020 <_init+0x20>

00000000004011e0 <pthread_mutex_lock@plt>:
  4011e0:	jmp    *0x3ef2(%rip)        # 4050d8 <pthread_mutex_lock@GLIBC_2.2.5>
  4011e6:	push   $0x1b
  4011eb:	jmp    401020 <_init+0x20>

Disassembly of section .text:

00000000004011f0 <holder_main.cold>:
  4011f0:	call   401030 <abort@plt>

00000000004011f5 <main.cold>:
  4011f5:	call   401030 <abort@plt>
  4011fa:	nopw   0x0(%rax,%rax,1)

0000000000401200 <main>:
  401200:	push   %r15
  401202:	push   %r14
  401204:	push   %r13
  401206:	push   %r12
  401208:	push   %rbp
  401209:	push   %rbx
  40120a:	mov    %rsi,%rbx
  40120d:	sub    $0x278,%rsp
  401214:	cmp    $0xa,%edi
  401217:	jne    401821 <main+0x621>
  40121d:	mov    0x8(%rsi),%rax
  401221:	mov    0x10(%rsi),%rsi
  401225:	mov    $0x40303a,%edi
  40122a:	mov    %rax,0x8(%rsp)
  40122f:	call   401f80 <parse_long>
  401234:	mov    0x18(%rbx),%rsi
  401238:	mov    $0x403040,%edi
  40123d:	mov    %rax,0x10(%rsp)
  401242:	call   401f80 <parse_long>
  401247:	mov    0x28(%rbx),%rsi
  40124b:	mov    $0x403047,%edi
  401250:	mov    0x20(%rbx),%r14
  401254:	mov    %rax,0x18(%rsp)
  401259:	call   401f80 <parse_long>
  40125e:	mov    0x30(%rbx),%rsi
  401262:	mov    $0x403052,%edi
  401267:	mov    %rax,%r15
  40126a:	call   401f80 <parse_long>
  40126f:	mov    0x38(%rbx),%rsi
  401273:	mov    $0x40305d,%edi
  401278:	mov    %rax,%rbp
  40127b:	call   401f80 <parse_long>
  401280:	mov    0x40(%rbx),%rsi
  401284:	mov    $0x403065,%edi
  401289:	mov    %rax,%r12
  40128c:	call   401f80 <parse_long>
  401291:	mov    0x48(%rbx),%rsi
  401295:	mov    $0x403071,%edi
  40129a:	mov    %rax,%r13
  40129d:	call   401f80 <parse_long>
  4012a2:	mov    %rax,%rdx
  4012a5:	mov    %r15,%rax
  4012a8:	or     %rbp,%rax
  4012ab:	or     %r12,%rax
  4012ae:	cmp    $0x3ff,%rax
  4012b4:	ja     4017fe <main+0x5fe>
  4012ba:	cmp    $0x13,%r13
  4012be:	ja     4017fe <main+0x5fe>
  4012c4:	test   %rdx,%rdx
  4012c7:	jle    4017fe <main+0x5fe>
  4012cd:	xor    %eax,%eax
  4012cf:	lea    0x180(%rsp),%rdi
  4012d7:	pxor   %xmm0,%xmm0
  4012db:	xor    %esi,%esi
  4012dd:	mov    $0x14,%ecx
  4012e2:	movaps %xmm0,0x140(%rsp)
  4012ea:	rep stos %eax,%es:(%rdi)
  4012ec:	lea    0x1d0(%rsp),%rdi
  4012f4:	mov    $0x14,%ecx
  4012f9:	movaps %xmm0,0x160(%rsp)
  401301:	rep stos %eax,%es:(%rdi)
  401303:	lea    0x220(%rsp),%rdi
  40130b:	mov    $0x14,%ecx
  401310:	mov    %r15d,0x120(%rsp)
  401318:	rep stos %eax,%es:(%rdi)
  40131a:	imul   $0x3e8,%rdx,%rax
  401321:	mov    %r13d,0x124(%rsp)
  401329:	mov    $0x3,%edx
  40132e:	mov    %ebp,0x140(%rsp)
  401335:	mov    $0x405140,%edi
  40133a:	mov    %r12d,0x160(%rsp)
  401342:	mov    %rax,0x128(%rsp)
  40134a:	lea    0x180(%rsp),%rax
  401352:	mov    %rax,0x130(%rsp)
  40135a:	lea    0x1d0(%rsp),%rax
  401362:	mov    %rax,0x150(%rsp)
  40136a:	lea    0x220(%rsp),%rax
  401372:	mov    %rax,0x170(%rsp)
  40137a:	movl   $0x0,0x3d9c(%rip)        # 405120 <holder_done>
  401384:	call   401060 <pthread_barrier_init@plt>
  401389:	test   %eax,%eax
  40138b:	jne    4011f5 <main.cold>
  401391:	xor    %edi,%edi
  401393:	lea    0x110(%rsp),%rsi
  40139b:	call   401090 <clock_gettime@plt>
  4013a0:	test   %eax,%eax
  4013a2:	jne    40183f <main+0x63f>
  4013a8:	xor    %esi,%esi
  4013aa:	lea    0x120(%rsp),%rcx
  4013b2:	mov    $0x401e10,%edx
  4013b7:	imul   $0x3b9aca00,0x110(%rsp),%rax
  4013c3:	lea    0x100(%rsp),%rdi
  4013cb:	add    0x118(%rsp),%rax
  4013d3:	mov    %rax,0xc0(%rsp)
  4013db:	call   401140 <pthread_create@plt>
  4013e0:	test   %eax,%eax
  4013e2:	jne    4011f5 <main.cold>
  4013e8:	xor    %esi,%esi
  4013ea:	lea    0x140(%rsp),%rcx
  4013f2:	mov    $0x401c50,%edx
  4013f7:	lea    0x108(%rsp),%rdi
  4013ff:	call   401140 <pthread_create@plt>
  401404:	test   %eax,%eax
  401406:	jne    4011f5 <main.cold>
  40140c:	xor    %esi,%esi
  40140e:	lea    0x160(%rsp),%rcx
  401416:	mov    $0x401ae0,%edx
  40141b:	lea    0x110(%rsp),%rdi
  401423:	call   401140 <pthread_create@plt>
  401428:	test   %eax,%eax
  40142a:	mov    %eax,0xfc(%rsp)
  401431:	jne    4011f5 <main.cold>
  401437:	mov    0x100(%rsp),%rdi
  40143f:	xor    %esi,%esi
  401441:	call   4011c0 <pthread_join@plt>
  401446:	mov    0x108(%rsp),%rdi
  40144e:	xor    %esi,%esi
  401450:	call   4011c0 <pthread_join@plt>
  401455:	mov    0x110(%rsp),%rdi
  40145d:	xor    %esi,%esi
  40145f:	call   4011c0 <pthread_join@plt>
  401464:	mov    $0x405140,%edi
  401469:	call   4010d0 <pthread_barrier_destroy@plt>
  40146e:	mov    0x260(%rsp),%r11
  401476:	mov    0x218(%rsp),%rdx
  40147e:	mov    0x210(%rsp),%r8
  401486:	mov    0x1c8(%rsp),%rdi
  40148e:	mov    0x1c0(%rsp),%rsi
  401496:	movslq 0x230(%rsp),%rcx
  40149e:	mov    %r11,0xf0(%rsp)
  4014a6:	mov    0x250(%rsp),%rbx
  4014ae:	mov    0x200(%rsp),%r11
  4014b6:	mov    %rdx,0x28(%rsp)
  4014bb:	movslq 0x18c(%rsp),%r9
  4014c3:	movslq 0x22c(%rsp),%rdx
  4014cb:	mov    %r8,0xe8(%rsp)
  4014d3:	mov    0x1b8(%rsp),%r10
  4014db:	movslq 0x190(%rsp),%r8
  4014e3:	mov    %rdi,0xe0(%rsp)
  4014eb:	mov    %rsi,0xd8(%rsp)
  4014f3:	movslq 0x1e0(%rsp),%rdi
  4014fb:	movslq 0x1dc(%rsp),%rsi
  401503:	mov    %rcx,0xd0(%rsp)
  40150b:	mov    0x268(%rsp),%rax
  401513:	mov    0x258(%rsp),%rcx
  40151b:	mov    %rbx,0x38(%rsp)
  401520:	mov    %rdx,0xc8(%rsp)
  401528:	mov    %rcx,0x30(%rsp)
  40152d:	mov    %rdi,0x40(%rsp)
  401532:	mov    %rsi,0x48(%rsp)
  401537:	mov    %r11,0x50(%rsp)
  40153c:	mov    %r8,0x58(%rsp)
  401541:	mov    %r9,0x60(%rsp)
  401546:	mov    %r10,0x68(%rsp)
  40154b:	mov    %rax,0x20(%rsp)
  401550:	mov    0x1b0(%rsp),%rax
  401558:	mov    0x188(%rsp),%ebx
  40155f:	mov    0x224(%rsp),%edi
  401566:	mov    0x1d4(%rsp),%esi
  40156d:	mov    %rax,0x70(%rsp)
  401572:	mov    %ebx,0x80(%rsp)
  401579:	mov    0x1f8(%rsp),%eax
  401580:	mov    0x1f4(%rsp),%ebx
  401587:	mov    0x228(%rsp),%edx
  40158e:	mov    %edi,0x84(%rsp)
  401595:	mov    0x1d8(%rsp),%ecx
  40159c:	mov    0x240(%rsp),%r10d
  4015a4:	mov    %esi,0x88(%rsp)
  4015ab:	mov    0x1a4(%rsp),%edi
  4015b2:	mov    0x1a0(%rsp),%esi
  4015b9:	mov    %eax,0x9c(%rsp)
  4015c0:	mov    0x248(%rsp),%r8d
  4015c8:	mov    0x244(%rsp),%r9d
  4015d0:	mov    %ebx,0xa0(%rsp)
  4015d7:	mov    0x1f0(%rsp),%eax
  4015de:	mov    0x1a8(%rsp),%ebx
  4015e5:	mov    %edx,0x78(%rsp)
  4015e9:	mov    0x184(%rsp),%r11d
  4015f1:	mov    %ecx,0x7c(%rsp)
  4015f5:	mov    %r10d,0x98(%rsp)
  4015fd:	mov    %edi,0xac(%rsp)
  401604:	mov    %esi,0xb0(%rsp)
  40160b:	mov    %r8d,0x90(%rsp)
  401613:	mov    %r9d,0x94(%rsp)
  40161b:	mov    %eax,0xa4(%rsp)
  401622:	mov    %ebx,0xa8(%rsp)
  401629:	mov    %r11d,0x8c(%rsp)
  401631:	mov    0x23c(%rsp),%r11d
  401639:	mov    0x19c(%rsp),%r9d
  401641:	mov    0x1ec(%rsp),%r8d
  401649:	mov    %r11d,0xb4(%rsp)
  401651:	mov    0x194(%rsp),%ebx
  401658:	mov    %r9d,0xbc(%rsp)
  401660:	mov    0x198(%rsp),%r9d
  401668:	mov    %r8d,0xb8(%rsp)
  401670:	mov    %r9d,0xf8(%rsp)
  401678:	call   4010a0 <getpid@plt>
  40167d:	push   0x20(%rsp)
  401681:	mov    0xf8(%rsp),%r11
  401689:	push   %r11
  40168b:	push   0x38(%rsp)
  40168f:	mov    0x100(%rsp),%r8
  401697:	push   %r8
  401699:	mov    0x100(%rsp),%rdi
  4016a1:	push   %rdi
  4016a2:	mov    0x100(%rsp),%rsi
  4016aa:	push   %rsi
  4016ab:	mov    0x100(%rsp),%rcx
  4016b3:	push   %rcx
  4016b4:	mov    0x100(%rsp),%rdx
  4016bc:	push   %rdx
  4016bd:	push   0x70(%rsp)
  4016c1:	push   0x80(%rsp)
  4016c8:	push   0x90(%rsp)
  4016cf:	push   0xa0(%rsp)
  4016d6:	push   0xb0(%rsp)
  4016dd:	push   0xc0(%rsp)
  4016e4:	push   0xd0(%rsp)
  4016eb:	push   0xe0(%rsp)
  4016f2:	push   0xf0(%rsp)
  4016f9:	mov    0x100(%rsp),%edx
  401700:	push   %rdx
  401701:	mov    0x10c(%rsp),%ecx
  401708:	push   %rcx
  401709:	mov    0x118(%rsp),%edx
  401710:	push   %rdx
  401711:	mov    0x124(%rsp),%edi
  401718:	push   %rdi
  401719:	mov    0x130(%rsp),%esi
  401720:	push   %rsi
  401721:	mov    0x13c(%rsp),%r11d
  401729:	push   %r11
  40172b:	mov    0x148(%rsp),%r8d
  401733:	push   %r8
  401735:	mov    0x154(%rsp),%r9d
  40173d:	push   %r9
  40173f:	mov    0x160(%rsp),%r10d
  401747:	push   %r10
  401749:	mov    0x16c(%rsp),%edx
  401750:	push   %rdx
  401751:	mov    0x178(%rsp),%edx
  401758:	push   %rdx
  401759:	mov    0x184(%rsp),%ecx
  401760:	push   %rcx
  401761:	mov    0x190(%rsp),%edx
  401768:	push   %rdx
  401769:	mov    0x19c(%rsp),%edi
  401770:	push   %rdi
  401771:	mov    0x1a8(%rsp),%esi
  401778:	mov    $0x403140,%edi
  40177d:	push   %rsi
  40177e:	mov    0x1b4(%rsp),%r11d
  401786:	push   %r11
  401788:	mov    0x1c0(%rsp),%r8d
  401790:	push   %r8
  401792:	mov    0x1cc(%rsp),%r9d
  40179a:	mov    %r14,%r8
  40179d:	push   %r9
  40179f:	mov    0x210(%rsp),%r9d
  4017a7:	push   %r9
  4017a9:	movslq %eax,%r9
  4017ac:	xor    %eax,%eax
  4017ae:	push   %rbx
  4017af:	push   %r13
  4017b1:	push   %r12
  4017b3:	push   %rbp
  4017b4:	push   %r15
  4017b6:	push   0x208(%rsp)
  4017bd:	mov    0x168(%rsp),%rcx
  4017c5:	mov    0x160(%rsp),%rdx
  4017cd:	mov    0x158(%rsp),%rsi
  4017d5:	call   4010c0 <printf@plt>
  4017da:	mov    0x24c(%rsp),%r10d
  4017e2:	add    $0x150,%rsp
  4017e9:	add    $0x278,%rsp
  4017f0:	mov    %r10d,%eax
  4017f3:	pop    %rbx
  4017f4:	pop    %rbp
  4017f5:	pop    %r12
  4017f7:	pop    %r13
  4017f9:	pop    %r14
  4017fb:	pop    %r15
  4017fd:	ret
  4017fe:	mov    $0x16,%edx
  401803:	mov    $0x1,%esi
  401808:	mov    $0x40307d,%edi
  40180d:	mov    0x38ec(%rip),%rcx        # 405100 <stderr@GLIBC_2.2.5>
  401814:	call   4011a0 <fwrite@plt>
  401819:	mov    $0x2,%r10d
  40181f:	jmp    4017e9 <main+0x5e9>
  401821:	mov    (%rsi),%rdx
  401824:	mov    0x38d5(%rip),%rdi        # 405100 <stderr@GLIBC_2.2.5>
  40182b:	mov    $0x4030e0,%esi
  401830:	xor    %eax,%eax
  401832:	call   4010f0 <fprintf@plt>
  401837:	mov    $0x2,%r10d
  40183d:	jmp    4017e9 <main+0x5e9>
  40183f:	mov    $0x403094,%edi
  401844:	call   401170 <perror@plt>
  401849:	mov    $0x2,%edi
  40184e:	call   401190 <exit@plt>
  401853:	cs nopw 0x0(%rax,%rax,1)
  40185d:	nopl   (%rax)

0000000000401860 <_start>:
  401860:	endbr64
  401864:	xor    %ebp,%ebp
  401866:	mov    %rdx,%r9
  401869:	pop    %rsi
  40186a:	mov    %rsp,%rdx
  40186d:	and    $0xfffffffffffffff0,%rsp
  401871:	push   %rax
  401872:	push   %rsp
  401873:	xor    %r8d,%r8d
  401876:	xor    %ecx,%ecx
  401878:	mov    $0x401200,%rdi
  40187f:	call   *0x3743(%rip)        # 404fc8 <__libc_start_main@GLIBC_2.34>
  401885:	hlt
  401886:	cs nopw 0x0(%rax,%rax,1)

0000000000401890 <_dl_relocate_static_pie>:
  401890:	endbr64
  401894:	ret
  401895:	cs nopw 0x0(%rax,%rax,1)
  40189f:	nop

00000000004018a0 <deregister_tm_clones>:
  4018a0:	lea    0x3841(%rip),%rdi        # 4050e8 <__TMC_END__>
  4018a7:	lea    0x383a(%rip),%rax        # 4050e8 <__TMC_END__>
  4018ae:	cmp    %rdi,%rax
  4018b1:	je     4018c8 <deregister_tm_clones+0x28>
  4018b3:	mov    0x3716(%rip),%rax        # 404fd0 <_ITM_deregisterTMCloneTable@Base>
  4018ba:	test   %rax,%rax
  4018bd:	je     4018c8 <deregister_tm_clones+0x28>
  4018bf:	jmp    *%rax
  4018c1:	nopl   0x0(%rax)
  4018c8:	ret
  4018c9:	nopl   0x0(%rax)

00000000004018d0 <register_tm_clones>:
  4018d0:	lea    0x3811(%rip),%rdi        # 4050e8 <__TMC_END__>
  4018d7:	lea    0x380a(%rip),%rsi        # 4050e8 <__TMC_END__>
  4018de:	sub    %rdi,%rsi
  4018e1:	mov    %rsi,%rax
  4018e4:	shr    $0x3f,%rsi
  4018e8:	sar    $0x3,%rax
  4018ec:	add    %rax,%rsi
  4018ef:	sar    $1,%rsi
  4018f2:	je     401908 <register_tm_clones+0x38>
  4018f4:	mov    0x36e5(%rip),%rax        # 404fe0 <_ITM_registerTMCloneTable@Base>
  4018fb:	test   %rax,%rax
  4018fe:	je     401908 <register_tm_clones+0x38>
  401900:	jmp    *%rax
  401902:	nopw   0x0(%rax,%rax,1)
  401908:	ret
  401909:	nopl   0x0(%rax)

0000000000401910 <__do_global_dtors_aux>:
  401910:	endbr64
  401914:	cmpb   $0x0,0x37ed(%rip)        # 405108 <completed.0>
  40191b:	jne    401930 <__do_global_dtors_aux+0x20>
  40191d:	push   %rbp
  40191e:	mov    %rsp,%rbp
  401921:	call   4018a0 <deregister_tm_clones>
  401926:	movb   $0x1,0x37db(%rip)        # 405108 <completed.0>
  40192d:	pop    %rbp
  40192e:	ret
  40192f:	nop
  401930:	ret
  401931:	data16 cs nopw 0x0(%rax,%rax,1)
  40193c:	nopl   0x0(%rax)

0000000000401940 <frame_dummy>:
  401940:	endbr64
  401944:	jmp    4018d0 <register_tm_clones>
  401946:	cs nopw 0x0(%rax,%rax,1)

0000000000401950 <pin_and_verify>:
  401950:	push   %r14
  401952:	mov    $0x10,%ecx
  401957:	movslq %edi,%r14
  40195a:	xor    %eax,%eax
  40195c:	push   %r13
  40195e:	push   %r12
  401960:	push   %rbp
  401961:	mov    %r14,%rbp
  401964:	push   %rbx
  401965:	mov    %rsi,%rbx
  401968:	sub    $0x100,%rsp
  40196f:	mov    %rsp,%r12
  401972:	mov    %r12,%rdi
  401975:	rep stos %rax,%es:(%rdi)
  401978:	cmp    $0x3ff,%r14
  40197f:	ja     401997 <pin_and_verify+0x47>
  401981:	mov    %r14,%rdx
  401984:	mov    $0x1,%eax
  401989:	mov    %r14d,%ecx
  40198c:	shr    $0x6,%rdx
  401990:	shl    %cl,%rax
  401993:	or     %rax,(%r12,%rdx,8)
  401997:	mov    %ebp,(%rbx)
  401999:	lea    0x80(%rsp),%r13
  4019a1:	call   401150 <pthread_self@plt>
  4019a6:	mov    %r12,%rdx
  4019a9:	mov    $0x80,%esi
  4019ae:	mov    %rax,%rdi
  4019b1:	call   401070 <pthread_setaffinity_np@plt>
  4019b6:	mov    $0x10,%ecx
  4019bb:	mov    %r13,%rdi
  4019be:	mov    %r13,%rdx
  4019c1:	mov    %eax,0x4(%rbx)
  4019c4:	xor    %eax,%eax
  4019c6:	mov    $0x80,%esi
  4019cb:	rep stos %rax,%es:(%rdi)
  4019ce:	xor    %edi,%edi
  4019d0:	call   4011b0 <sched_getaffinity@plt>
  4019d5:	mov    %eax,%r12d
  4019d8:	test   %eax,%eax
  4019da:	jne    401a38 <pin_and_verify+0xe8>
  4019dc:	mov    0x4(%rbx),%eax
  4019df:	test   %eax,%eax
  4019e1:	je     401a00 <pin_and_verify+0xb0>
  4019e3:	mov    %r12d,0x8(%rbx)
  4019e7:	add    $0x100,%rsp
  4019ee:	pop    %rbx
  4019ef:	pop    %rbp
  4019f0:	pop    %r12
  4019f2:	pop    %r13
  4019f4:	pop    %r14
  4019f6:	ret
  4019f7:	nopw   0x0(%rax,%rax,1)
  401a00:	mov    %r13,%rsi
  401a03:	mov    $0x80,%edi
  401a08:	call   4010b0 <__sched_cpucount@plt>
  401a0d:	cmp    $0x3ff,%r14
  401a14:	ja     4019e3 <pin_and_verify+0x93>
  401a16:	cmp    $0x1,%eax
  401a19:	jne    4019e3 <pin_and_verify+0x93>
  401a1b:	shr    $0x6,%r14
  401a1f:	mov    %ebp,%ecx
  401a21:	mov    0x80(%rsp,%r14,8),%r12
  401a29:	shr    %cl,%r12
  401a2c:	and    $0x1,%r12d
  401a30:	jmp    4019e3 <pin_and_verify+0x93>
  401a32:	nopw   0x0(%rax,%rax,1)
  401a38:	xor    %r12d,%r12d
  401a3b:	jmp    4019e3 <pin_and_verify+0x93>
  401a3d:	nopl   (%rax)

0000000000401a40 <observe_scheduling>:
  401a40:	push   %rbx
  401a41:	xor    %eax,%eax
  401a43:	mov    %rdi,%rbx
  401a46:	mov    $0xba,%edi
  401a4b:	sub    $0x10,%rsp
  401a4f:	movl   $0x0,0xc(%rsp)
  401a57:	call   401100 <syscall@plt>
  401a5c:	xor    %edi,%edi
  401a5e:	mov    %eax,%esi
  401a60:	call   401050 <getpriority@plt>
  401a65:	mov    %eax,0x1c(%rbx)
  401a68:	call   401150 <pthread_self@plt>
  401a6d:	lea    0x24(%rbx),%rsi
  401a71:	lea    0xc(%rsp),%rdx
  401a76:	mov    %rax,%rdi
  401a79:	call   401120 <pthread_getschedparam@plt>
  401a7e:	mov    %eax,0x20(%rbx)
  401a81:	mov    0xc(%rsp),%eax
  401a85:	mov    %eax,0x28(%rbx)
  401a88:	add    $0x10,%rsp
  401a8c:	pop    %rbx
  401a8d:	ret
  401a8e:	xchg   %ax,%ax

0000000000401a90 <barrier_wait_checked>:
  401a90:	sub    $0x8,%rsp
  401a94:	mov    $0x405140,%edi
  401a99:	call   401080 <pthread_barrier_wait@plt>
  401a9e:	lea    0x1(%rax),%edx
  401aa1:	cmp    $0x1,%edx
  401aa4:	ja     401aab <barrier_wait_checked+0x1b>
  401aa6:	add    $0x8,%rsp
  401aaa:	ret
  401aab:	mov    %eax,%edi
  401aad:	call   4011d0 <strerror@plt>
  401ab2:	mov    0x3647(%rip),%rdi        # 405100 <stderr@GLIBC_2.2.5>
  401ab9:	mov    $0x403010,%esi
  401abe:	mov    %rax,%rdx
  401ac1:	xor    %eax,%eax
  401ac3:	call   4010f0 <fprintf@plt>
  401ac8:	mov    $0x2,%edi
  401acd:	call   401190 <exit@plt>
  401ad2:	data16 cs nopw 0x0(%rax,%rax,1)
  401add:	nopl   (%rax)

0000000000401ae0 <hog_main>:
  401ae0:	movabs $0x94d049bb133111eb,%rax
  401aea:	push   %rbx
  401aeb:	sub    $0x170,%rsp
  401af2:	mov    0x10(%rdi),%rbx
  401af6:	mov    (%rdi),%edi
  401af8:	mov    %rax,0x8(%rsp)
  401afd:	mov    %rbx,%rsi
  401b00:	call   401950 <pin_and_verify>
  401b05:	mov    %rbx,%rdi
  401b08:	call   401a40 <observe_scheduling>
  401b0d:	call   401a90 <barrier_wait_checked>
  401b12:	call   401180 <sched_getcpu@plt>
  401b17:	lea    0x10(%rsp),%rsi
  401b1c:	mov    $0x4,%edi
  401b21:	mov    %eax,0xc(%rbx)
  401b24:	call   401090 <clock_gettime@plt>
  401b29:	lea    0x30(%rsp),%rsi
  401b2e:	mov    $0x3,%edi
  401b33:	call   401090 <clock_gettime@plt>
  401b38:	lea    0x50(%rsp),%rsi
  401b3d:	mov    $0x1,%edi
  401b42:	call   401160 <getrusage@plt>
  401b47:	jmp    401b92 <hog_main+0xb2>
  401b49:	nopl   0x0(%rax)
  401b50:	mov    0x8(%rsp),%rax
  401b55:	mov    0x8(%rsp),%rdx
  401b5a:	shl    $0xd,%rax
  401b5e:	xor    %rdx,%rax
  401b61:	mov    %rax,0x8(%rsp)
  401b66:	mov    0x8(%rsp),%rax
  401b6b:	mov    0x8(%rsp),%rdx
  401b70:	shr    $0x7,%rax
  401b74:	xor    %rdx,%rax
  401b77:	mov    %rax,0x8(%rsp)
  401b7c:	mov    0x8(%rsp),%rax
  401b81:	mov    0x8(%rsp),%rdx
  401b86:	shl    $0x11,%rax
  401b8a:	xor    %rdx,%rax
  401b8d:	mov    %rax,0x8(%rsp)
  401b92:	mov    0x3588(%rip),%eax        # 405120 <holder_done>
  401b98:	test   %eax,%eax
  401b9a:	je     401b50 <hog_main+0x70>
  401b9c:	lea    0xe0(%rsp),%rsi
  401ba4:	mov    $0x1,%edi
  401ba9:	call   401160 <getrusage@plt>
  401bae:	lea    0x40(%rsp),%rsi
  401bb3:	mov    $0x3,%edi
  401bb8:	call   401090 <clock_gettime@plt>
  401bbd:	lea    0x20(%rsp),%rsi
  401bc2:	mov    $0x4,%edi
  401bc7:	call   401090 <clock_gettime@plt>
  401bcc:	call   401180 <sched_getcpu@plt>
  401bd1:	mov    %eax,0x10(%rbx)
  401bd4:	mov    0x20(%rsp),%rax
  401bd9:	sub    0x10(%rsp),%rax
  401bde:	imul   $0x3b9aca00,%rax,%rax
  401be5:	add    0x28(%rsp),%rax
  401bea:	sub    0x18(%rsp),%rax
  401bef:	mov    %rax,0x30(%rbx)
  401bf3:	mov    0x40(%rsp),%rax
  401bf8:	sub    0x30(%rsp),%rax
  401bfd:	imul   $0x3b9aca00,%rax,%rax
  401c04:	add    0x48(%rsp),%rax
  401c09:	sub    0x38(%rsp),%rax
  401c0e:	mov    %rax,0x38(%rbx)
  401c12:	mov    0x160(%rsp),%rax
  401c1a:	sub    0xd0(%rsp),%rax
  401c22:	mov    %rax,0x40(%rbx)
  401c26:	mov    0x168(%rsp),%rax
  401c2e:	sub    0xd8(%rsp),%rax
  401c36:	mov    %rax,0x48(%rbx)
  401c3a:	mov    0x8(%rsp),%rax
  401c3f:	add    $0x170,%rsp
  401c46:	pop    %rbx
  401c47:	and    $0x1,%eax
  401c4a:	ret
  401c4b:	nopl   0x0(%rax,%rax,1)

0000000000401c50 <waiter_main>:
  401c50:	push   %rbx
  401c51:	sub    $0x140,%rsp
  401c58:	mov    0x10(%rdi),%rbx
  401c5c:	mov    (%rdi),%edi
  401c5e:	mov    %rbx,%rsi
  401c61:	call   401950 <pin_and_verify>
  401c66:	mov    %rbx,%rdi
  401c69:	call   401a40 <observe_scheduling>
  401c6e:	call   401a90 <barrier_wait_checked>
  401c73:	call   401180 <sched_getcpu@plt>
  401c78:	mov    %rsp,%rsi
  401c7b:	mov    $0x4,%edi
  401c80:	mov    %eax,0xc(%rbx)
  401c83:	call   401090 <clock_gettime@plt>
  401c88:	lea    0x20(%rsp),%rsi
  401c8d:	mov    $0x1,%edi
  401c92:	call   401160 <getrusage@plt>
  401c97:	mov    $0x405160,%edi
  401c9c:	call   4011e0 <pthread_mutex_lock@plt>
  401ca1:	lea    0xb0(%rsp),%rsi
  401ca9:	mov    $0x1,%edi
  401cae:	call   401160 <getrusage@plt>
  401cb3:	lea    0x10(%rsp),%rsi
  401cb8:	mov    $0x4,%edi
  401cbd:	call   401090 <clock_gettime@plt>
  401cc2:	call   401180 <sched_getcpu@plt>
  401cc7:	mov    $0x405160,%edi
  401ccc:	mov    %eax,0x10(%rbx)
  401ccf:	mov    0x10(%rsp),%rax
  401cd4:	sub    (%rsp),%rax
  401cd8:	imul   $0x3b9aca00,%rax,%rax
  401cdf:	add    0x18(%rsp),%rax
  401ce4:	sub    0x8(%rsp),%rax
  401ce9:	mov    %rax,0x30(%rbx)
  401ced:	mov    0x130(%rsp),%rax
  401cf5:	sub    0xa0(%rsp),%rax
  401cfd:	mov    %rax,0x40(%rbx)
  401d01:	mov    0x138(%rsp),%rax
  401d09:	sub    0xa8(%rsp),%rax
  401d11:	mov    %rax,0x48(%rbx)
  401d15:	call   401130 <pthread_mutex_unlock@plt>
  401d1a:	add    $0x140,%rsp
  401d21:	xor    %eax,%eax
  401d23:	pop    %rbx
  401d24:	ret
  401d25:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000401d30 <burn_thread_cpu>:
  401d30:	movabs $0x9e3779b97f4a7c15,%rax
  401d3a:	push   %rbp
  401d3b:	push   %rbx
  401d3c:	mov    %rdi,%rbx
  401d3f:	mov    $0x3,%edi
  401d44:	sub    $0x38,%rsp
  401d48:	lea    0x10(%rsp),%rsi
  401d4d:	mov    %rax,0x8(%rsp)
  401d52:	call   401090 <clock_gettime@plt>
  401d57:	test   %eax,%eax
  401d59:	jne    401dee <burn_thread_cpu+0xbe>
  401d5f:	movabs $0xbf58476d1ce4e5b9,%rbp
  401d69:	mov    $0x1000,%edx
  401d6e:	xchg   %ax,%ax
  401d70:	mov    0x8(%rsp),%rax
  401d75:	mov    0x8(%rsp),%rcx
  401d7a:	shl    $0x7,%rax
  401d7e:	xor    %rcx,%rax
  401d81:	mov    %rax,0x8(%rsp)
  401d86:	mov    0x8(%rsp),%rax
  401d8b:	mov    0x8(%rsp),%rcx
  401d90:	shr    $0x9,%rax
  401d94:	xor    %rcx,%rax
  401d97:	mov    %rax,0x8(%rsp)
  401d9c:	mov    0x8(%rsp),%rax
  401da1:	imul   %rbp,%rax
  401da5:	mov    %rax,0x8(%rsp)
  401daa:	sub    $0x1,%edx
  401dad:	jne    401d70 <burn_thread_cpu+0x40>
  401daf:	lea    0x20(%rsp),%rsi
  401db4:	mov    $0x3,%edi
  401db9:	call   401090 <clock_gettime@plt>
  401dbe:	test   %eax,%eax
  401dc0:	jne    401dee <burn_thread_cpu+0xbe>
  401dc2:	mov    0x20(%rsp),%rax
  401dc7:	sub    0x10(%rsp),%rax
  401dcc:	imul   $0x3b9aca00,%rax,%rax
  401dd3:	add    0x28(%rsp),%rax
  401dd8:	sub    0x18(%rsp),%rax
  401ddd:	cmp    %rax,%rbx
  401de0:	ja     401d69 <burn_thread_cpu+0x39>
  401de2:	mov    0x8(%rsp),%rax
  401de7:	add    $0x38,%rsp
  401deb:	pop    %rbx
  401dec:	pop    %rbp
  401ded:	ret
  401dee:	mov    $0x4030b8,%edi
  401df3:	call   401170 <perror@plt>
  401df8:	mov    $0x2,%edi
  401dfd:	call   401190 <exit@plt>
  401e02:	data16 cs nopw 0x0(%rax,%rax,1)
  401e0d:	nopl   (%rax)

0000000000401e10 <holder_main>:
  401e10:	push   %r13
  401e12:	push   %r12
  401e14:	push   %rbp
  401e15:	mov    %rdi,%rbp
  401e18:	push   %rbx
  401e19:	sub    $0x168,%rsp
  401e20:	mov    0x10(%rdi),%rbx
  401e24:	mov    (%rdi),%edi
  401e26:	mov    %rbx,%rsi
  401e29:	call   401950 <pin_and_verify>
  401e2e:	call   401040 <__errno_location@plt>
  401e33:	mov    $0xba,%edi
  401e38:	movl   $0x0,(%rax)
  401e3e:	mov    %rax,%r12
  401e41:	mov    0x4(%rbp),%r13d
  401e45:	xor    %eax,%eax
  401e47:	call   401100 <syscall@plt>
  401e4c:	xor    %edi,%edi
  401e4e:	mov    %r13d,%edx
  401e51:	mov    %eax,%esi
  401e53:	call   4010e0 <setpriority@plt>
  401e58:	mov    %rbx,%rdi
  401e5b:	mov    %eax,0x14(%rbx)
  401e5e:	mov    (%r12),%eax
  401e62:	mov    %eax,0x18(%rbx)
  401e65:	call   401a40 <observe_scheduling>
  401e6a:	mov    $0x405160,%edi
  401e6f:	call   4011e0 <pthread_mutex_lock@plt>
  401e74:	test   %eax,%eax
  401e76:	jne    4011f0 <holder_main.cold>
  401e7c:	call   401a90 <barrier_wait_checked>
  401e81:	call   401180 <sched_getcpu@plt>
  401e86:	mov    %rsp,%rsi
  401e89:	mov    $0x4,%edi
  401e8e:	mov    %eax,0xc(%rbx)
  401e91:	call   401090 <clock_gettime@plt>
  401e96:	lea    0x20(%rsp),%rsi
  401e9b:	mov    $0x3,%edi
  401ea0:	call   401090 <clock_gettime@plt>
  401ea5:	lea    0x40(%rsp),%rsi
  401eaa:	mov    $0x1,%edi
  401eaf:	call   401160 <getrusage@plt>
  401eb4:	mov    0x8(%rbp),%rdi
  401eb8:	call   401d30 <burn_thread_cpu>
  401ebd:	lea    0xd0(%rsp),%rsi
  401ec5:	mov    $0x1,%edi
  401eca:	call   401160 <getrusage@plt>
  401ecf:	lea    0x30(%rsp),%rsi
  401ed4:	mov    $0x3,%edi
  401ed9:	call   401090 <clock_gettime@plt>
  401ede:	lea    0x10(%rsp),%rsi
  401ee3:	mov    $0x4,%edi
  401ee8:	call   401090 <clock_gettime@plt>
  401eed:	call   401180 <sched_getcpu@plt>
  401ef2:	mov    $0x405160,%edi
  401ef7:	mov    %eax,0x10(%rbx)
  401efa:	mov    0x10(%rsp),%rax
  401eff:	sub    (%rsp),%rax
  401f03:	imul   $0x3b9aca00,%rax,%rax
  401f0a:	add    0x18(%rsp),%rax
  401f0f:	sub    0x8(%rsp),%rax
  401f14:	mov    %rax,0x30(%rbx)
  401f18:	mov    0x30(%rsp),%rax
  401f1d:	sub    0x20(%rsp),%rax
  401f22:	imul   $0x3b9aca00,%rax,%rax
  401f29:	add    0x38(%rsp),%rax
  401f2e:	sub    0x28(%rsp),%rax
  401f33:	mov    %rax,0x38(%rbx)
  401f37:	mov    0x150(%rsp),%rax
  401f3f:	sub    0xc0(%rsp),%rax
  401f47:	mov    %rax,0x40(%rbx)
  401f4b:	mov    0x158(%rsp),%rax
  401f53:	sub    0xc8(%rsp),%rax
  401f5b:	mov    %rax,0x48(%rbx)
  401f5f:	call   401130 <pthread_mutex_unlock@plt>
  401f64:	xor    %eax,%eax
  401f66:	movl   $0x1,0x31b0(%rip)        # 405120 <holder_done>
  401f70:	add    $0x168,%rsp
  401f77:	pop    %rbx
  401f78:	pop    %rbp
  401f79:	pop    %r12
  401f7b:	pop    %r13
  401f7d:	ret
  401f7e:	xchg   %ax,%ax

0000000000401f80 <parse_long>:
  401f80:	push   %r13
  401f82:	mov    %rdi,%r13
  401f85:	push   %r12
  401f87:	mov    %rsi,%r12
  401f8a:	push   %rbx
  401f8b:	sub    $0x10,%rsp
  401f8f:	movq   $0x0,0x8(%rsp)
  401f98:	call   401040 <__errno_location@plt>
  401f9d:	mov    $0xa,%edx
  401fa2:	lea    0x8(%rsp),%rsi
  401fa7:	mov    %r12,%rdi
  401faa:	movl   $0x0,(%rax)
  401fb0:	mov    %rax,%rbx
  401fb3:	call   401110 <strtol@plt>
  401fb8:	mov    (%rbx),%edx
  401fba:	test   %edx,%edx
  401fbc:	jne    401fd7 <parse_long+0x57>
  401fbe:	mov    0x8(%rsp),%rdx
  401fc3:	cmp    %r12,%rdx
  401fc6:	je     401fd7 <parse_long+0x57>
  401fc8:	cmpb   $0x0,(%rdx)
  401fcb:	jne    401fd7 <parse_long+0x57>
  401fcd:	add    $0x10,%rsp
  401fd1:	pop    %rbx
  401fd2:	pop    %r12
  401fd4:	pop    %r13
  401fd6:	ret
  401fd7:	mov    0x3122(%rip),%rdi        # 405100 <stderr@GLIBC_2.2.5>
  401fde:	mov    %r12,%rcx
  401fe1:	mov    %r13,%rdx
  401fe4:	xor    %eax,%eax
  401fe6:	mov    $0x40302a,%esi
  401feb:	call   4010f0 <fprintf@plt>
  401ff0:	mov    $0x2,%edi
  401ff5:	call   401190 <exit@plt>

Disassembly of section .fini:

0000000000401ffc <_fini>:
  401ffc:	endbr64
  402000:	sub    $0x8,%rsp
  402004:	add    $0x8,%rsp
  402008:	ret
