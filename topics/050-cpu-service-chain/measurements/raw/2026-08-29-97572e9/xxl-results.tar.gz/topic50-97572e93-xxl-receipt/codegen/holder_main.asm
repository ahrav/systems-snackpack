
/tmp/topic50-97572e93-xxl-receipt/experiment/lock_holder_preemption:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <holder_main>:
  401e10:	push   %r13
  401e12:	push   %r12
  401e14:	push   %rbp
  401e15:	mov    %rdi,%rbp
  401e18:	push   %rbx
  401e19:	sub    $0x168,%rsp
  401e20:	mov    0x10(%rdi),%rbx
  401e24:	mov    (%rdi),%edi
  401e26:	mov    %rbx,%rsi
  401e29:	call   401950 <pin_and_verify>
  401e2e:	call   401040 <__errno_location@plt>
  401e33:	mov    $0xba,%edi
  401e38:	movl   $0x0,(%rax)
  401e3e:	mov    %rax,%r12
  401e41:	mov    0x4(%rbp),%r13d
  401e45:	xor    %eax,%eax
  401e47:	call   401100 <syscall@plt>
  401e4c:	xor    %edi,%edi
  401e4e:	mov    %r13d,%edx
  401e51:	mov    %eax,%esi
  401e53:	call   4010e0 <setpriority@plt>
  401e58:	mov    %rbx,%rdi
  401e5b:	mov    %eax,0x14(%rbx)
  401e5e:	mov    (%r12),%eax
  401e62:	mov    %eax,0x18(%rbx)
  401e65:	call   401a40 <observe_scheduling>
  401e6a:	mov    $0x405160,%edi
  401e6f:	call   4011e0 <pthread_mutex_lock@plt>
  401e74:	test   %eax,%eax
  401e76:	jne    4011f0 <holder_main.cold>
  401e7c:	call   401a90 <barrier_wait_checked>
  401e81:	call   401180 <sched_getcpu@plt>
  401e86:	mov    %rsp,%rsi
  401e89:	mov    $0x4,%edi
  401e8e:	mov    %eax,0xc(%rbx)
  401e91:	call   401090 <clock_gettime@plt>
  401e96:	lea    0x20(%rsp),%rsi
  401e9b:	mov    $0x3,%edi
  401ea0:	call   401090 <clock_gettime@plt>
  401ea5:	lea    0x40(%rsp),%rsi
  401eaa:	mov    $0x1,%edi
  401eaf:	call   401160 <getrusage@plt>
  401eb4:	mov    0x8(%rbp),%rdi
  401eb8:	call   401d30 <burn_thread_cpu>
  401ebd:	lea    0xd0(%rsp),%rsi
  401ec5:	mov    $0x1,%edi
  401eca:	call   401160 <getrusage@plt>
  401ecf:	lea    0x30(%rsp),%rsi
  401ed4:	mov    $0x3,%edi
  401ed9:	call   401090 <clock_gettime@plt>
  401ede:	lea    0x10(%rsp),%rsi
  401ee3:	mov    $0x4,%edi
  401ee8:	call   401090 <clock_gettime@plt>
  401eed:	call   401180 <sched_getcpu@plt>
  401ef2:	mov    $0x405160,%edi
  401ef7:	mov    %eax,0x10(%rbx)
  401efa:	mov    0x10(%rsp),%rax
  401eff:	sub    (%rsp),%rax
  401f03:	imul   $0x3b9aca00,%rax,%rax
  401f0a:	add    0x18(%rsp),%rax
  401f0f:	sub    0x8(%rsp),%rax
  401f14:	mov    %rax,0x30(%rbx)
  401f18:	mov    0x30(%rsp),%rax
  401f1d:	sub    0x20(%rsp),%rax
  401f22:	imul   $0x3b9aca00,%rax,%rax
  401f29:	add    0x38(%rsp),%rax
  401f2e:	sub    0x28(%rsp),%rax
  401f33:	mov    %rax,0x38(%rbx)
  401f37:	mov    0x150(%rsp),%rax
  401f3f:	sub    0xc0(%rsp),%rax
  401f47:	mov    %rax,0x40(%rbx)
  401f4b:	mov    0x158(%rsp),%rax
  401f53:	sub    0xc8(%rsp),%rax
  401f5b:	mov    %rax,0x48(%rbx)
  401f5f:	call   401130 <pthread_mutex_unlock@plt>
  401f64:	xor    %eax,%eax
  401f66:	movl   $0x1,0x31b0(%rip)        # 405120 <holder_done>
  401f70:	add    $0x168,%rsp
  401f77:	pop    %rbx
  401f78:	pop    %rbp
  401f79:	pop    %r12
  401f7b:	pop    %r13
  401f7d:	ret

Disassembly of section .fini:
