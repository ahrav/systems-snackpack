
/tmp/topic50-97572e93-xxl-receipt/experiment/lock_holder_preemption:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401d30 <burn_thread_cpu>:
  401d30:	movabs $0x9e3779b97f4a7c15,%rax
  401d3a:	push   %rbp
  401d3b:	push   %rbx
  401d3c:	mov    %rdi,%rbx
  401d3f:	mov    $0x3,%edi
  401d44:	sub    $0x38,%rsp
  401d48:	lea    0x10(%rsp),%rsi
  401d4d:	mov    %rax,0x8(%rsp)
  401d52:	call   401090 <clock_gettime@plt>
  401d57:	test   %eax,%eax
  401d59:	jne    401dee <burn_thread_cpu+0xbe>
  401d5f:	movabs $0xbf58476d1ce4e5b9,%rbp
  401d69:	mov    $0x1000,%edx
  401d6e:	xchg   %ax,%ax
  401d70:	mov    0x8(%rsp),%rax
  401d75:	mov    0x8(%rsp),%rcx
  401d7a:	shl    $0x7,%rax
  401d7e:	xor    %rcx,%rax
  401d81:	mov    %rax,0x8(%rsp)
  401d86:	mov    0x8(%rsp),%rax
  401d8b:	mov    0x8(%rsp),%rcx
  401d90:	shr    $0x9,%rax
  401d94:	xor    %rcx,%rax
  401d97:	mov    %rax,0x8(%rsp)
  401d9c:	mov    0x8(%rsp),%rax
  401da1:	imul   %rbp,%rax
  401da5:	mov    %rax,0x8(%rsp)
  401daa:	sub    $0x1,%edx
  401dad:	jne    401d70 <burn_thread_cpu+0x40>
  401daf:	lea    0x20(%rsp),%rsi
  401db4:	mov    $0x3,%edi
  401db9:	call   401090 <clock_gettime@plt>
  401dbe:	test   %eax,%eax
  401dc0:	jne    401dee <burn_thread_cpu+0xbe>
  401dc2:	mov    0x20(%rsp),%rax
  401dc7:	sub    0x10(%rsp),%rax
  401dcc:	imul   $0x3b9aca00,%rax,%rax
  401dd3:	add    0x28(%rsp),%rax
  401dd8:	sub    0x18(%rsp),%rax
  401ddd:	cmp    %rax,%rbx
  401de0:	ja     401d69 <burn_thread_cpu+0x39>
  401de2:	mov    0x8(%rsp),%rax
  401de7:	add    $0x38,%rsp
  401deb:	pop    %rbx
  401dec:	pop    %rbp
  401ded:	ret
  401dee:	mov    $0x4030b8,%edi
  401df3:	call   401170 <perror@plt>
  401df8:	mov    $0x2,%edi
  401dfd:	call   401190 <exit@plt>

Disassembly of section .fini:
