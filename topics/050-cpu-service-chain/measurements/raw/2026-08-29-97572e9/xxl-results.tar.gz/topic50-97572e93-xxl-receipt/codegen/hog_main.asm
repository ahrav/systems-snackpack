
/tmp/topic50-97572e93-xxl-receipt/experiment/lock_holder_preemption:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ae0 <hog_main>:
  401ae0:	movabs $0x94d049bb133111eb,%rax
  401aea:	push   %rbx
  401aeb:	sub    $0x170,%rsp
  401af2:	mov    0x10(%rdi),%rbx
  401af6:	mov    (%rdi),%edi
  401af8:	mov    %rax,0x8(%rsp)
  401afd:	mov    %rbx,%rsi
  401b00:	call   401950 <pin_and_verify>
  401b05:	mov    %rbx,%rdi
  401b08:	call   401a40 <observe_scheduling>
  401b0d:	call   401a90 <barrier_wait_checked>
  401b12:	call   401180 <sched_getcpu@plt>
  401b17:	lea    0x10(%rsp),%rsi
  401b1c:	mov    $0x4,%edi
  401b21:	mov    %eax,0xc(%rbx)
  401b24:	call   401090 <clock_gettime@plt>
  401b29:	lea    0x30(%rsp),%rsi
  401b2e:	mov    $0x3,%edi
  401b33:	call   401090 <clock_gettime@plt>
  401b38:	lea    0x50(%rsp),%rsi
  401b3d:	mov    $0x1,%edi
  401b42:	call   401160 <getrusage@plt>
  401b47:	jmp    401b92 <hog_main+0xb2>
  401b49:	nopl   0x0(%rax)
  401b50:	mov    0x8(%rsp),%rax
  401b55:	mov    0x8(%rsp),%rdx
  401b5a:	shl    $0xd,%rax
  401b5e:	xor    %rdx,%rax
  401b61:	mov    %rax,0x8(%rsp)
  401b66:	mov    0x8(%rsp),%rax
  401b6b:	mov    0x8(%rsp),%rdx
  401b70:	shr    $0x7,%rax
  401b74:	xor    %rdx,%rax
  401b77:	mov    %rax,0x8(%rsp)
  401b7c:	mov    0x8(%rsp),%rax
  401b81:	mov    0x8(%rsp),%rdx
  401b86:	shl    $0x11,%rax
  401b8a:	xor    %rdx,%rax
  401b8d:	mov    %rax,0x8(%rsp)
  401b92:	mov    0x3588(%rip),%eax        # 405120 <holder_done>
  401b98:	test   %eax,%eax
  401b9a:	je     401b50 <hog_main+0x70>
  401b9c:	lea    0xe0(%rsp),%rsi
  401ba4:	mov    $0x1,%edi
  401ba9:	call   401160 <getrusage@plt>
  401bae:	lea    0x40(%rsp),%rsi
  401bb3:	mov    $0x3,%edi
  401bb8:	call   401090 <clock_gettime@plt>
  401bbd:	lea    0x20(%rsp),%rsi
  401bc2:	mov    $0x4,%edi
  401bc7:	call   401090 <clock_gettime@plt>
  401bcc:	call   401180 <sched_getcpu@plt>
  401bd1:	mov    %eax,0x10(%rbx)
  401bd4:	mov    0x20(%rsp),%rax
  401bd9:	sub    0x10(%rsp),%rax
  401bde:	imul   $0x3b9aca00,%rax,%rax
  401be5:	add    0x28(%rsp),%rax
  401bea:	sub    0x18(%rsp),%rax
  401bef:	mov    %rax,0x30(%rbx)
  401bf3:	mov    0x40(%rsp),%rax
  401bf8:	sub    0x30(%rsp),%rax
  401bfd:	imul   $0x3b9aca00,%rax,%rax
  401c04:	add    0x48(%rsp),%rax
  401c09:	sub    0x38(%rsp),%rax
  401c0e:	mov    %rax,0x38(%rbx)
  401c12:	mov    0x160(%rsp),%rax
  401c1a:	sub    0xd0(%rsp),%rax
  401c22:	mov    %rax,0x40(%rbx)
  401c26:	mov    0x168(%rsp),%rax
  401c2e:	sub    0xd8(%rsp),%rax
  401c36:	mov    %rax,0x48(%rbx)
  401c3a:	mov    0x8(%rsp),%rax
  401c3f:	add    $0x170,%rsp
  401c46:	pop    %rbx
  401c47:	and    $0x1,%eax
  401c4a:	ret

Disassembly of section .fini:
