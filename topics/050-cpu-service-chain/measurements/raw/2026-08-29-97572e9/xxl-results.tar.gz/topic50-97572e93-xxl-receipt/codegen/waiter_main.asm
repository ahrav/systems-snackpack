
/tmp/topic50-97572e93-xxl-receipt/experiment/lock_holder_preemption:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c50 <waiter_main>:
  401c50:	push   %rbx
  401c51:	sub    $0x140,%rsp
  401c58:	mov    0x10(%rdi),%rbx
  401c5c:	mov    (%rdi),%edi
  401c5e:	mov    %rbx,%rsi
  401c61:	call   401950 <pin_and_verify>
  401c66:	mov    %rbx,%rdi
  401c69:	call   401a40 <observe_scheduling>
  401c6e:	call   401a90 <barrier_wait_checked>
  401c73:	call   401180 <sched_getcpu@plt>
  401c78:	mov    %rsp,%rsi
  401c7b:	mov    $0x4,%edi
  401c80:	mov    %eax,0xc(%rbx)
  401c83:	call   401090 <clock_gettime@plt>
  401c88:	lea    0x20(%rsp),%rsi
  401c8d:	mov    $0x1,%edi
  401c92:	call   401160 <getrusage@plt>
  401c97:	mov    $0x405160,%edi
  401c9c:	call   4011e0 <pthread_mutex_lock@plt>
  401ca1:	lea    0xb0(%rsp),%rsi
  401ca9:	mov    $0x1,%edi
  401cae:	call   401160 <getrusage@plt>
  401cb3:	lea    0x10(%rsp),%rsi
  401cb8:	mov    $0x4,%edi
  401cbd:	call   401090 <clock_gettime@plt>
  401cc2:	call   401180 <sched_getcpu@plt>
  401cc7:	mov    $0x405160,%edi
  401ccc:	mov    %eax,0x10(%rbx)
  401ccf:	mov    0x10(%rsp),%rax
  401cd4:	sub    (%rsp),%rax
  401cd8:	imul   $0x3b9aca00,%rax,%rax
  401cdf:	add    0x18(%rsp),%rax
  401ce4:	sub    0x8(%rsp),%rax
  401ce9:	mov    %rax,0x30(%rbx)
  401ced:	mov    0x130(%rsp),%rax
  401cf5:	sub    0xa0(%rsp),%rax
  401cfd:	mov    %rax,0x40(%rbx)
  401d01:	mov    0x138(%rsp),%rax
  401d09:	sub    0xa8(%rsp),%rax
  401d11:	mov    %rax,0x48(%rbx)
  401d15:	call   401130 <pthread_mutex_unlock@plt>
  401d1a:	add    $0x140,%rsp
  401d21:	xor    %eax,%eax
  401d23:	pop    %rbx
  401d24:	ret

Disassembly of section .fini:
