
/tmp/topic50-97572e93-arm-receipt/experiment/lock_holder_preemption:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410b4c <burn_thread_cpu>:
  410b4c:	mov	x2, #0x7c15                	// #31765
  410b50:	stp	x29, x30, [sp, #-96]!
  410b54:	mov	x29, sp
  410b58:	movk	x2, #0x7f4a, lsl #16
  410b5c:	add	x1, sp, #0x40
  410b60:	movk	x2, #0x79b9, lsl #32
  410b64:	movk	x2, #0x9e37, lsl #48
  410b68:	stp	x19, x20, [sp, #16]
  410b6c:	mov	x19, x0
  410b70:	mov	w0, #0x3                   	// #3
  410b74:	str	x21, [sp, #32]
  410b78:	str	x2, [sp, #56]
  410b7c:	bl	4100a0 <clock_gettime@plt>
  410b80:	cbnz	w0, 410c14 <burn_thread_cpu+0xc8>
  410b84:	mov	x21, #0xe5b9                	// #58809
  410b88:	mov	x20, #0xca00                	// #51712
  410b8c:	movk	x21, #0x1ce4, lsl #16
  410b90:	movk	x20, #0x3b9a, lsl #16
  410b94:	movk	x21, #0x476d, lsl #32
  410b98:	movk	x21, #0xbf58, lsl #48
  410b9c:	mov	w1, #0x1000                	// #4096
  410ba0:	ldr	x0, [sp, #56]
  410ba4:	subs	w1, w1, #0x1
  410ba8:	ldr	x2, [sp, #56]
  410bac:	eor	x0, x2, x0, lsl #7
  410bb0:	str	x0, [sp, #56]
  410bb4:	ldr	x0, [sp, #56]
  410bb8:	ldr	x2, [sp, #56]
  410bbc:	eor	x0, x2, x0, lsr #9
  410bc0:	str	x0, [sp, #56]
  410bc4:	ldr	x0, [sp, #56]
  410bc8:	mul	x0, x0, x21
  410bcc:	str	x0, [sp, #56]
  410bd0:	b.ne	410ba0 <burn_thread_cpu+0x54>  // b.any
  410bd4:	add	x1, sp, #0x50
  410bd8:	mov	w0, #0x3                   	// #3
  410bdc:	bl	4100a0 <clock_gettime@plt>
  410be0:	cbnz	w0, 410c14 <burn_thread_cpu+0xc8>
  410be4:	ldp	x3, x2, [sp, #64]
  410be8:	ldp	x0, x1, [sp, #80]
  410bec:	sub	x0, x0, x3
  410bf0:	sub	x1, x1, x2
  410bf4:	madd	x0, x0, x20, x1
  410bf8:	cmp	x19, x0
  410bfc:	b.hi	410b9c <burn_thread_cpu+0x50>  // b.pmore
  410c00:	ldp	x19, x20, [sp, #16]
  410c04:	ldr	x21, [sp, #32]
  410c08:	ldr	x0, [sp, #56]
  410c0c:	ldp	x29, x30, [sp], #96
  410c10:	ret
  410c14:	adrp	x0, 420000 <_IO_stdin_used>
  410c18:	add	x0, x0, #0x30
  410c1c:	bl	410060 <perror@plt>
  410c20:	mov	w0, #0x2                   	// #2
  410c24:	bl	410040 <exit@plt>

Disassembly of section .fini:
