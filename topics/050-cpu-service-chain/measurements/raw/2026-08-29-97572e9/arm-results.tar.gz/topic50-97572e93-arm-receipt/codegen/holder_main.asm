
/tmp/topic50-97572e93-arm-receipt/experiment/lock_holder_preemption:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410c28 <holder_main>:
  410c28:	stp	x29, x30, [sp, #-400]!
  410c2c:	mov	x29, sp
  410c30:	stp	x19, x20, [sp, #16]
  410c34:	ldr	x19, [x0, #16]
  410c38:	stp	x21, x22, [sp, #32]
  410c3c:	mov	x21, x0
  410c40:	ldr	w0, [x0]
  410c44:	mov	x1, x19
  410c48:	bl	410760 <pin_and_verify>
  410c4c:	bl	4101b0 <__errno_location@plt>
  410c50:	mov	x20, x0
  410c54:	mov	x0, #0xb2                  	// #178
  410c58:	str	wzr, [x20]
  410c5c:	bl	4101f0 <syscall@plt>
  410c60:	mov	x1, x0
  410c64:	ldr	w2, [x21, #4]
  410c68:	mov	w0, #0x0                   	// #0
  410c6c:	bl	4101d0 <setpriority@plt>
  410c70:	mov	w1, w0
  410c74:	mov	x0, x19
  410c78:	str	w1, [x19, #20]
  410c7c:	ldr	w1, [x20]
  410c80:	adrp	x20, 440000 <exit@GLIBC_2.17>
  410c84:	add	x20, x20, #0x108
  410c88:	add	x22, x20, #0x28
  410c8c:	str	w1, [x19, #24]
  410c90:	bl	410860 <observe_scheduling>
  410c94:	mov	x0, x22
  410c98:	bl	4101e0 <pthread_mutex_lock@plt>
  410c9c:	cbnz	w0, 410d8c <holder_main+0x164>
  410ca0:	bl	4108c0 <barrier_wait_checked>
  410ca4:	bl	4100b0 <sched_getcpu@plt>
  410ca8:	mov	w2, w0
  410cac:	add	x1, sp, #0x30
  410cb0:	mov	w0, #0x4                   	// #4
  410cb4:	str	w2, [x19, #12]
  410cb8:	bl	4100a0 <clock_gettime@plt>
  410cbc:	add	x1, sp, #0x50
  410cc0:	mov	w0, #0x3                   	// #3
  410cc4:	bl	4100a0 <clock_gettime@plt>
  410cc8:	add	x1, sp, #0x70
  410ccc:	mov	w0, #0x1                   	// #1
  410cd0:	bl	410120 <getrusage@plt>
  410cd4:	ldr	x0, [x21, #8]
  410cd8:	bl	410b4c <burn_thread_cpu>
  410cdc:	add	x1, sp, #0x100
  410ce0:	mov	w0, #0x1                   	// #1
  410ce4:	bl	410120 <getrusage@plt>
  410ce8:	add	x1, sp, #0x60
  410cec:	mov	w0, #0x3                   	// #3
  410cf0:	bl	4100a0 <clock_gettime@plt>
  410cf4:	add	x1, sp, #0x40
  410cf8:	mov	w0, #0x4                   	// #4
  410cfc:	bl	4100a0 <clock_gettime@plt>
  410d00:	bl	4100b0 <sched_getcpu@plt>
  410d04:	ldp	x6, x1, [sp, #48]
  410d08:	mov	w2, w0
  410d0c:	mov	x4, #0xca00                	// #51712
  410d10:	movk	x4, #0x3b9a, lsl #16
  410d14:	mov	x0, x22
  410d18:	ldp	x3, x5, [sp, #72]
  410d1c:	ldr	x7, [sp, #88]
  410d20:	sub	x3, x3, x1
  410d24:	ldr	x1, [sp, #96]
  410d28:	sub	x1, x1, x5
  410d2c:	ldr	x5, [sp, #248]
  410d30:	str	w2, [x19, #16]
  410d34:	ldr	x2, [sp, #64]
  410d38:	sub	x2, x2, x6
  410d3c:	ldr	x6, [sp, #240]
  410d40:	madd	x2, x2, x4, x3
  410d44:	ldr	x3, [sp, #104]
  410d48:	str	x2, [x19, #48]
  410d4c:	sub	x2, x3, x7
  410d50:	madd	x1, x1, x4, x2
  410d54:	ldp	x3, x2, [sp, #384]
  410d58:	sub	x3, x3, x6
  410d5c:	stp	x1, x3, [x19, #56]
  410d60:	sub	x1, x2, x5
  410d64:	str	x1, [x19, #72]
  410d68:	bl	410200 <pthread_mutex_unlock@plt>
  410d6c:	mov	w0, #0x1                   	// #1
  410d70:	add	x20, x20, #0x20
  410d74:	stlr	w0, [x20]
  410d78:	mov	x0, #0x0                   	// #0
  410d7c:	ldp	x19, x20, [sp, #16]
  410d80:	ldp	x21, x22, [sp, #32]
  410d84:	ldp	x29, x30, [sp], #400
  410d88:	ret
  410d8c:	bl	410100 <abort@plt>

Disassembly of section .fini:
