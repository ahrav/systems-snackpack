
/tmp/topic50-97572e93-arm-receipt/experiment/lock_holder_preemption:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410920 <hog_main>:
  410920:	stp	x29, x30, [sp, #-400]!
  410924:	mov	x29, sp
  410928:	mov	x1, #0x11eb                	// #4587
  41092c:	movk	x1, #0x1331, lsl #16
  410930:	str	x19, [sp, #16]
  410934:	movk	x1, #0x49bb, lsl #32
  410938:	ldr	x19, [x0, #16]
  41093c:	movk	x1, #0x94d0, lsl #48
  410940:	ldr	w0, [x0]
  410944:	str	x1, [sp, #40]
  410948:	mov	x1, x19
  41094c:	bl	410760 <pin_and_verify>
  410950:	mov	x0, x19
  410954:	bl	410860 <observe_scheduling>
  410958:	bl	4108c0 <barrier_wait_checked>
  41095c:	bl	4100b0 <sched_getcpu@plt>
  410960:	mov	w2, w0
  410964:	add	x1, sp, #0x30
  410968:	mov	w0, #0x4                   	// #4
  41096c:	str	w2, [x19, #12]
  410970:	bl	4100a0 <clock_gettime@plt>
  410974:	add	x1, sp, #0x50
  410978:	mov	w0, #0x3                   	// #3
  41097c:	bl	4100a0 <clock_gettime@plt>
  410980:	add	x1, sp, #0x70
  410984:	mov	w0, #0x1                   	// #1
  410988:	bl	410120 <getrusage@plt>
  41098c:	adrp	x2, 440000 <exit@GLIBC_2.17>
  410990:	add	x2, x2, #0x108
  410994:	add	x2, x2, #0x20
  410998:	b	4109cc <hog_main+0xac>
  41099c:	ldr	x0, [sp, #40]
  4109a0:	ldr	x1, [sp, #40]
  4109a4:	eor	x0, x1, x0, lsl #13
  4109a8:	str	x0, [sp, #40]
  4109ac:	ldr	x0, [sp, #40]
  4109b0:	ldr	x1, [sp, #40]
  4109b4:	eor	x0, x1, x0, lsr #7
  4109b8:	str	x0, [sp, #40]
  4109bc:	ldr	x0, [sp, #40]
  4109c0:	ldr	x1, [sp, #40]
  4109c4:	eor	x0, x1, x0, lsl #17
  4109c8:	str	x0, [sp, #40]
  4109cc:	ldar	w0, [x2]
  4109d0:	cbz	w0, 41099c <hog_main+0x7c>
  4109d4:	add	x1, sp, #0x100
  4109d8:	mov	w0, #0x1                   	// #1
  4109dc:	bl	410120 <getrusage@plt>
  4109e0:	add	x1, sp, #0x60
  4109e4:	mov	w0, #0x3                   	// #3
  4109e8:	bl	4100a0 <clock_gettime@plt>
  4109ec:	add	x1, sp, #0x40
  4109f0:	mov	w0, #0x4                   	// #4
  4109f4:	bl	4100a0 <clock_gettime@plt>
  4109f8:	bl	4100b0 <sched_getcpu@plt>
  4109fc:	ldp	x3, x1, [sp, #48]
  410a00:	mov	x4, #0xca00                	// #51712
  410a04:	movk	x4, #0x3b9a, lsl #16
  410a08:	ldp	x2, x5, [sp, #72]
  410a0c:	ldr	x6, [sp, #240]
  410a10:	sub	x2, x2, x1
  410a14:	ldr	x1, [sp, #96]
  410a18:	sub	x1, x1, x5
  410a1c:	ldr	x5, [sp, #248]
  410a20:	str	w0, [x19, #16]
  410a24:	ldr	x0, [sp, #64]
  410a28:	sub	x0, x0, x3
  410a2c:	ldr	x3, [sp, #88]
  410a30:	madd	x0, x0, x4, x2
  410a34:	ldr	x2, [sp, #104]
  410a38:	str	x0, [x19, #48]
  410a3c:	sub	x0, x2, x3
  410a40:	ldp	x3, x2, [sp, #384]
  410a44:	madd	x1, x1, x4, x0
  410a48:	ldr	x0, [sp, #40]
  410a4c:	sub	x3, x3, x6
  410a50:	stp	x1, x3, [x19, #56]
  410a54:	sub	x1, x2, x5
  410a58:	and	x0, x0, #0x1
  410a5c:	str	x1, [x19, #72]
  410a60:	ldr	x19, [sp, #16]
  410a64:	ldp	x29, x30, [sp], #400
  410a68:	ret

Disassembly of section .fini:
