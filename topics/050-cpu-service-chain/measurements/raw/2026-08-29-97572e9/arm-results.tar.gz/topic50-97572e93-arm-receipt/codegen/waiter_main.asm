
/tmp/topic50-97572e93-arm-receipt/experiment/lock_holder_preemption:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000410a6c <waiter_main>:
  410a6c:	stp	x29, x30, [sp, #-352]!
  410a70:	mov	x29, sp
  410a74:	stp	x19, x20, [sp, #16]
  410a78:	adrp	x20, 440000 <exit@GLIBC_2.17>
  410a7c:	add	x20, x20, #0x108
  410a80:	add	x20, x20, #0x28
  410a84:	ldr	x19, [x0, #16]
  410a88:	ldr	w0, [x0]
  410a8c:	mov	x1, x19
  410a90:	bl	410760 <pin_and_verify>
  410a94:	mov	x0, x19
  410a98:	bl	410860 <observe_scheduling>
  410a9c:	bl	4108c0 <barrier_wait_checked>
  410aa0:	bl	4100b0 <sched_getcpu@plt>
  410aa4:	mov	w2, w0
  410aa8:	add	x1, sp, #0x20
  410aac:	mov	w0, #0x4                   	// #4
  410ab0:	str	w2, [x19, #12]
  410ab4:	bl	4100a0 <clock_gettime@plt>
  410ab8:	add	x1, sp, #0x40
  410abc:	mov	w0, #0x1                   	// #1
  410ac0:	bl	410120 <getrusage@plt>
  410ac4:	mov	x0, x20
  410ac8:	bl	4101e0 <pthread_mutex_lock@plt>
  410acc:	add	x1, sp, #0xd0
  410ad0:	mov	w0, #0x1                   	// #1
  410ad4:	bl	410120 <getrusage@plt>
  410ad8:	add	x1, sp, #0x30
  410adc:	mov	w0, #0x4                   	// #4
  410ae0:	bl	4100a0 <clock_gettime@plt>
  410ae4:	bl	4100b0 <sched_getcpu@plt>
  410ae8:	ldp	x4, x3, [sp, #32]
  410aec:	mov	w1, w0
  410af0:	mov	x6, #0xca00                	// #51712
  410af4:	movk	x6, #0x3b9a, lsl #16
  410af8:	mov	x0, x20
  410afc:	ldr	x2, [sp, #56]
  410b00:	ldr	x5, [sp, #192]
  410b04:	sub	x2, x2, x3
  410b08:	ldr	x3, [sp, #336]
  410b0c:	str	w1, [x19, #16]
  410b10:	ldr	x1, [sp, #48]
  410b14:	sub	x3, x3, x5
  410b18:	sub	x1, x1, x4
  410b1c:	ldr	x4, [sp, #200]
  410b20:	madd	x1, x1, x6, x2
  410b24:	ldr	x2, [sp, #344]
  410b28:	str	x3, [x19, #64]
  410b2c:	str	x1, [x19, #48]
  410b30:	sub	x1, x2, x4
  410b34:	str	x1, [x19, #72]
  410b38:	bl	410200 <pthread_mutex_unlock@plt>
  410b3c:	mov	x0, #0x0                   	// #0
  410b40:	ldp	x19, x20, [sp, #16]
  410b44:	ldp	x29, x30, [sp], #352
  410b48:	ret

Disassembly of section .fini:
