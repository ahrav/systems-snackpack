
/tmp/topic50-97572e93-arm-receipt/experiment/lock_holder_preemption:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000410000 <_init>:
  410000:	paciasp
  410004:	stp	x29, x30, [sp, #-16]!
  410008:	mov	x29, sp
  41000c:	bl	410688 <call_weak_fn>
  410010:	ldp	x29, x30, [sp], #16
  410014:	autiasp
  410018:	ret

Disassembly of section .plt:

0000000000410020 <.plt>:
  410020:	stp	x16, x30, [sp, #-16]!
  410024:	adrp	x16, 43f000 <__FRAME_END__+0x1eafc>
  410028:	ldr	x17, [x16, #4088]
  41002c:	add	x16, x16, #0xff8
  410030:	br	x17
  410034:	nop
  410038:	nop
  41003c:	nop

0000000000410040 <exit@plt>:
  410040:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410044:	ldr	x17, [x16]
  410048:	add	x16, x16, #0x0
  41004c:	br	x17

0000000000410050 <__libc_start_main@plt>:
  410050:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410054:	ldr	x17, [x16, #8]
  410058:	add	x16, x16, #0x8
  41005c:	br	x17

0000000000410060 <perror@plt>:
  410060:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410064:	ldr	x17, [x16, #16]
  410068:	add	x16, x16, #0x10
  41006c:	br	x17

0000000000410070 <pthread_barrier_init@plt>:
  410070:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410074:	ldr	x17, [x16, #24]
  410078:	add	x16, x16, #0x18
  41007c:	br	x17

0000000000410080 <pthread_setaffinity_np@plt>:
  410080:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410084:	ldr	x17, [x16, #32]
  410088:	add	x16, x16, #0x20
  41008c:	br	x17

0000000000410090 <pthread_barrier_wait@plt>:
  410090:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410094:	ldr	x17, [x16, #40]
  410098:	add	x16, x16, #0x28
  41009c:	br	x17

00000000004100a0 <clock_gettime@plt>:
  4100a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100a4:	ldr	x17, [x16, #48]
  4100a8:	add	x16, x16, #0x30
  4100ac:	br	x17

00000000004100b0 <sched_getcpu@plt>:
  4100b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100b4:	ldr	x17, [x16, #56]
  4100b8:	add	x16, x16, #0x38
  4100bc:	br	x17

00000000004100c0 <getpid@plt>:
  4100c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100c4:	ldr	x17, [x16, #64]
  4100c8:	add	x16, x16, #0x40
  4100cc:	br	x17

00000000004100d0 <pthread_barrier_destroy@plt>:
  4100d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100d4:	ldr	x17, [x16, #72]
  4100d8:	add	x16, x16, #0x48
  4100dc:	br	x17

00000000004100e0 <strerror@plt>:
  4100e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100e4:	ldr	x17, [x16, #80]
  4100e8:	add	x16, x16, #0x50
  4100ec:	br	x17

00000000004100f0 <__gmon_start__@plt>:
  4100f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100f4:	ldr	x17, [x16, #88]
  4100f8:	add	x16, x16, #0x58
  4100fc:	br	x17

0000000000410100 <abort@plt>:
  410100:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410104:	ldr	x17, [x16, #96]
  410108:	add	x16, x16, #0x60
  41010c:	br	x17

0000000000410110 <sched_getaffinity@plt>:
  410110:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410114:	ldr	x17, [x16, #104]
  410118:	add	x16, x16, #0x68
  41011c:	br	x17

0000000000410120 <getrusage@plt>:
  410120:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410124:	ldr	x17, [x16, #112]
  410128:	add	x16, x16, #0x70
  41012c:	br	x17

0000000000410130 <getpriority@plt>:
  410130:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410134:	ldr	x17, [x16, #120]
  410138:	add	x16, x16, #0x78
  41013c:	br	x17

0000000000410140 <strtol@plt>:
  410140:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410144:	ldr	x17, [x16, #128]
  410148:	add	x16, x16, #0x80
  41014c:	br	x17

0000000000410150 <pthread_getschedparam@plt>:
  410150:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410154:	ldr	x17, [x16, #136]
  410158:	add	x16, x16, #0x88
  41015c:	br	x17

0000000000410160 <fwrite@plt>:
  410160:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410164:	ldr	x17, [x16, #144]
  410168:	add	x16, x16, #0x90
  41016c:	br	x17

0000000000410170 <pthread_create@plt>:
  410170:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410174:	ldr	x17, [x16, #152]
  410178:	add	x16, x16, #0x98
  41017c:	br	x17

0000000000410180 <__sched_cpucount@plt>:
  410180:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410184:	ldr	x17, [x16, #160]
  410188:	add	x16, x16, #0xa0
  41018c:	br	x17

0000000000410190 <pthread_self@plt>:
  410190:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410194:	ldr	x17, [x16, #168]
  410198:	add	x16, x16, #0xa8
  41019c:	br	x17

00000000004101a0 <printf@plt>:
  4101a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101a4:	ldr	x17, [x16, #176]
  4101a8:	add	x16, x16, #0xb0
  4101ac:	br	x17

00000000004101b0 <__errno_location@plt>:
  4101b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101b4:	ldr	x17, [x16, #184]
  4101b8:	add	x16, x16, #0xb8
  4101bc:	br	x17

00000000004101c0 <pthread_join@plt>:
  4101c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101c4:	ldr	x17, [x16, #192]
  4101c8:	add	x16, x16, #0xc0
  4101cc:	br	x17

00000000004101d0 <setpriority@plt>:
  4101d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101d4:	ldr	x17, [x16, #200]
  4101d8:	add	x16, x16, #0xc8
  4101dc:	br	x17

00000000004101e0 <pthread_mutex_lock@plt>:
  4101e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101e4:	ldr	x17, [x16, #208]
  4101e8:	add	x16, x16, #0xd0
  4101ec:	br	x17

00000000004101f0 <syscall@plt>:
  4101f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101f4:	ldr	x17, [x16, #216]
  4101f8:	add	x16, x16, #0xd8
  4101fc:	br	x17

0000000000410200 <pthread_mutex_unlock@plt>:
  410200:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410204:	ldr	x17, [x16, #224]
  410208:	add	x16, x16, #0xe0
  41020c:	br	x17

0000000000410210 <fprintf@plt>:
  410210:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410214:	ldr	x17, [x16, #232]
  410218:	add	x16, x16, #0xe8
  41021c:	br	x17

Disassembly of section .text:

0000000000410240 <main>:
  410240:	sub	sp, sp, #0x310
  410244:	stp	x29, x30, [sp, #320]
  410248:	add	x29, sp, #0x140
  41024c:	stp	x19, x20, [sp, #336]
  410250:	mov	x19, x1
  410254:	stp	x27, x28, [sp, #400]
  410258:	cmp	w0, #0xa
  41025c:	b.ne	4105dc <main+0x39c>  // b.any
  410260:	adrp	x0, 420000 <_IO_stdin_used>
  410264:	add	x0, x0, #0xc8
  410268:	stp	x25, x26, [sp, #384]
  41026c:	ldp	x25, x1, [x1, #8]
  410270:	stp	x21, x22, [sp, #352]
  410274:	stp	x23, x24, [sp, #368]
  410278:	bl	410d90 <parse_long>
  41027c:	mov	x23, x0
  410280:	adrp	x0, 420000 <_IO_stdin_used>
  410284:	ldr	x1, [x19, #24]
  410288:	add	x0, x0, #0xd0
  41028c:	bl	410d90 <parse_long>
  410290:	mov	x24, x0
  410294:	adrp	x0, 420000 <_IO_stdin_used>
  410298:	ldp	x26, x1, [x19, #32]
  41029c:	add	x0, x0, #0xd8
  4102a0:	bl	410d90 <parse_long>
  4102a4:	mov	x22, x0
  4102a8:	adrp	x0, 420000 <_IO_stdin_used>
  4102ac:	ldr	x1, [x19, #48]
  4102b0:	add	x0, x0, #0xe8
  4102b4:	bl	410d90 <parse_long>
  4102b8:	mov	x21, x0
  4102bc:	adrp	x0, 420000 <_IO_stdin_used>
  4102c0:	ldr	x1, [x19, #56]
  4102c4:	add	x0, x0, #0xf8
  4102c8:	bl	410d90 <parse_long>
  4102cc:	mov	x20, x0
  4102d0:	adrp	x0, 420000 <_IO_stdin_used>
  4102d4:	ldr	x1, [x19, #64]
  4102d8:	add	x0, x0, #0x100
  4102dc:	bl	410d90 <parse_long>
  4102e0:	mov	x2, x0
  4102e4:	adrp	x0, 420000 <_IO_stdin_used>
  4102e8:	ldr	x1, [x19, #72]
  4102ec:	add	x0, x0, #0x110
  4102f0:	mov	x19, x2
  4102f4:	bl	410d90 <parse_long>
  4102f8:	orr	x1, x22, x21
  4102fc:	orr	x1, x1, x20
  410300:	cmp	x1, #0x3ff
  410304:	b.hi	4105ac <main+0x36c>  // b.pmore
  410308:	cmp	x0, #0x0
  41030c:	ccmp	x19, #0x13, #0x2, gt
  410310:	b.hi	4105ac <main+0x36c>  // b.pmore
  410314:	mov	x4, #0x3e8                 	// #1000
  410318:	movi	v0.4s, #0x0
  41031c:	add	x3, sp, #0x220
  410320:	add	x2, sp, #0x270
  410324:	add	x1, sp, #0x2c0
  410328:	stp	xzr, xzr, [sp, #496]
  41032c:	mul	x0, x0, x4
  410330:	add	x4, sp, #0x210
  410334:	adrp	x27, 440000 <exit@GLIBC_2.17>
  410338:	add	x27, x27, #0x108
  41033c:	stp	xzr, xzr, [x4, #-8]
  410340:	add	x4, x27, #0x20
  410344:	stp	q0, q0, [x3]
  410348:	stp	q0, q0, [x2]
  41034c:	stp	q0, q0, [x1]
  410350:	stp	q0, q0, [x3, #32]
  410354:	stp	q0, q0, [x2, #32]
  410358:	stp	q0, q0, [x1, #32]
  41035c:	str	q0, [x1, #64]
  410360:	str	q0, [x2, #64]
  410364:	str	q0, [x3, #64]
  410368:	str	w22, [sp, #472]
  41036c:	str	w19, [sp, #476]
  410370:	stp	x0, x3, [sp, #480]
  410374:	str	w21, [sp, #496]
  410378:	str	x2, [sp, #512]
  41037c:	str	w20, [sp, #520]
  410380:	str	x1, [sp, #536]
  410384:	str	wzr, [x4]
  410388:	mov	x0, x27
  41038c:	mov	w2, #0x3                   	// #3
  410390:	mov	x1, #0x0                   	// #0
  410394:	bl	410070 <pthread_barrier_init@plt>
  410398:	cbnz	w0, 410610 <main+0x3d0>
  41039c:	add	x1, sp, #0x1c8
  4103a0:	bl	4100a0 <clock_gettime@plt>
  4103a4:	cbnz	w0, 4105fc <main+0x3bc>
  4103a8:	ldp	x28, x4, [sp, #456]
  4103ac:	mov	x5, #0xca00                	// #51712
  4103b0:	adrp	x2, 410000 <_init>
  4103b4:	movk	x5, #0x3b9a, lsl #16
  4103b8:	add	x2, x2, #0xc28
  4103bc:	add	x3, sp, #0x1d8
  4103c0:	mov	x1, #0x0                   	// #0
  4103c4:	add	x0, sp, #0x1b8
  4103c8:	madd	x4, x28, x5, x4
  4103cc:	str	x4, [sp, #424]
  4103d0:	bl	410170 <pthread_create@plt>
  4103d4:	cbnz	w0, 410610 <main+0x3d0>
  4103d8:	adrp	x2, 410000 <_init>
  4103dc:	add	x3, sp, #0x1f0
  4103e0:	add	x2, x2, #0xa6c
  4103e4:	mov	x1, #0x0                   	// #0
  4103e8:	add	x0, sp, #0x1c0
  4103ec:	bl	410170 <pthread_create@plt>
  4103f0:	cbnz	w0, 410610 <main+0x3d0>
  4103f4:	adrp	x2, 410000 <_init>
  4103f8:	add	x0, sp, #0x1c8
  4103fc:	add	x2, x2, #0x920
  410400:	add	x3, sp, #0x208
  410404:	mov	x1, #0x0                   	// #0
  410408:	bl	410170 <pthread_create@plt>
  41040c:	mov	w28, w0
  410410:	cbnz	w0, 410610 <main+0x3d0>
  410414:	mov	x1, #0x0                   	// #0
  410418:	ldr	x0, [sp, #440]
  41041c:	bl	4101c0 <pthread_join@plt>
  410420:	mov	x1, #0x0                   	// #0
  410424:	ldr	x0, [sp, #448]
  410428:	bl	4101c0 <pthread_join@plt>
  41042c:	mov	x1, #0x0                   	// #0
  410430:	ldr	x0, [sp, #456]
  410434:	bl	4101c0 <pthread_join@plt>
  410438:	mov	x0, x27
  41043c:	bl	4100d0 <pthread_barrier_destroy@plt>
  410440:	bl	4100c0 <getpid@plt>
  410444:	ldrsw	x10, [sp, #640]
  410448:	adrp	x12, 420000 <_IO_stdin_used>
  41044c:	sxtw	x5, w0
  410450:	add	x0, x12, #0x158
  410454:	mov	x7, x22
  410458:	ldrsw	x11, [sp, #716]
  41045c:	mov	x4, x26
  410460:	mov	x3, x24
  410464:	mov	x2, x23
  410468:	mov	x1, x25
  41046c:	ldrsw	x9, [sp, #720]
  410470:	str	x10, [sp, #232]
  410474:	ldrsw	x10, [sp, #556]
  410478:	ldr	x6, [sp, #424]
  41047c:	stp	x11, x9, [sp, #256]
  410480:	ldrsw	x11, [sp, #560]
  410484:	ldrsw	x9, [sp, #636]
  410488:	stp	x10, x11, [sp, #200]
  41048c:	str	x9, [sp, #224]
  410490:	ldr	x9, [sp, #600]
  410494:	ldr	x11, [sp, #608]
  410498:	ldr	x10, [sp, #616]
  41049c:	str	x9, [sp, #192]
  4104a0:	ldr	x9, [sp, #672]
  4104a4:	stp	x11, x10, [sp, #272]
  4104a8:	ldr	x11, [sp, #688]
  4104ac:	str	x9, [sp, #216]
  4104b0:	ldr	x10, [sp, #696]
  4104b4:	ldr	x9, [sp, #752]
  4104b8:	stp	x11, x10, [sp, #288]
  4104bc:	ldr	x11, [sp, #760]
  4104c0:	ldr	x10, [sp, #768]
  4104c4:	stp	x9, x11, [sp, #240]
  4104c8:	ldr	x9, [sp, #776]
  4104cc:	str	x10, [sp, #304]
  4104d0:	str	x9, [sp, #312]
  4104d4:	ldr	x9, [sp, #592]
  4104d8:	ldr	w11, [sp, #548]
  4104dc:	ldr	w10, [sp, #552]
  4104e0:	str	x9, [sp, #184]
  4104e4:	ldr	w9, [sp, #576]
  4104e8:	str	w11, [sp, #136]
  4104ec:	ldr	w11, [sp, #580]
  4104f0:	str	w10, [sp, #160]
  4104f4:	ldr	w10, [sp, #584]
  4104f8:	str	w9, [sp, #64]
  4104fc:	ldr	w9, [sp, #628]
  410500:	str	w11, [sp, #72]
  410504:	ldr	w11, [sp, #632]
  410508:	str	w10, [sp, #80]
  41050c:	ldr	w10, [sp, #656]
  410510:	str	w9, [sp, #144]
  410514:	ldr	w9, [sp, #660]
  410518:	str	w11, [sp, #168]
  41051c:	ldr	w11, [sp, #664]
  410520:	str	w10, [sp, #88]
  410524:	ldr	w10, [sp, #708]
  410528:	str	w9, [sp, #96]
  41052c:	ldr	w9, [sp, #712]
  410530:	str	w11, [sp, #104]
  410534:	ldr	w11, [sp, #736]
  410538:	str	w10, [sp, #152]
  41053c:	ldr	w10, [sp, #740]
  410540:	str	w9, [sp, #176]
  410544:	ldr	w9, [sp, #744]
  410548:	str	w11, [sp, #112]
  41054c:	str	w10, [sp, #120]
  410550:	str	w9, [sp, #128]
  410554:	ldr	w11, [sp, #732]
  410558:	stp	x21, x20, [sp]
  41055c:	ldr	w9, [sp, #564]
  410560:	str	x19, [sp, #16]
  410564:	ldr	w10, [sp, #572]
  410568:	str	w11, [sp, #56]
  41056c:	ldr	w12, [sp, #568]
  410570:	str	w9, [sp, #24]
  410574:	ldr	w9, [sp, #652]
  410578:	str	w10, [sp, #40]
  41057c:	str	w12, [sp, #32]
  410580:	str	w9, [sp, #48]
  410584:	bl	4101a0 <printf@plt>
  410588:	ldp	x21, x22, [sp, #352]
  41058c:	ldp	x23, x24, [sp, #368]
  410590:	ldp	x25, x26, [sp, #384]
  410594:	mov	w0, w28
  410598:	ldp	x29, x30, [sp, #320]
  41059c:	ldp	x19, x20, [sp, #336]
  4105a0:	ldp	x27, x28, [sp, #400]
  4105a4:	add	sp, sp, #0x310
  4105a8:	ret
  4105ac:	adrp	x1, 440000 <exit@GLIBC_2.17>
  4105b0:	adrp	x0, 420000 <_IO_stdin_used>
  4105b4:	ldr	x3, [x1, #248]
  4105b8:	add	x0, x0, #0x120
  4105bc:	mov	x2, #0x16                  	// #22
  4105c0:	mov	x1, #0x1                   	// #1
  4105c4:	mov	w28, #0x2                   	// #2
  4105c8:	bl	410160 <fwrite@plt>
  4105cc:	ldp	x21, x22, [sp, #352]
  4105d0:	ldp	x23, x24, [sp, #368]
  4105d4:	ldp	x25, x26, [sp, #384]
  4105d8:	b	410594 <main+0x354>
  4105dc:	adrp	x1, 420000 <_IO_stdin_used>
  4105e0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4105e4:	ldr	x2, [x19]
  4105e8:	add	x1, x1, #0x68
  4105ec:	mov	w28, #0x2                   	// #2
  4105f0:	ldr	x0, [x0, #248]
  4105f4:	bl	410210 <fprintf@plt>
  4105f8:	b	410594 <main+0x354>
  4105fc:	adrp	x0, 420000 <_IO_stdin_used>
  410600:	add	x0, x0, #0x138
  410604:	bl	410060 <perror@plt>
  410608:	mov	w0, #0x2                   	// #2
  41060c:	bl	410040 <exit@plt>
  410610:	bl	410100 <abort@plt>
  410614:	nop
  410618:	nop
  41061c:	nop
  410620:	nop
  410624:	nop
  410628:	nop
  41062c:	nop
  410630:	nop
  410634:	nop
  410638:	nop
  41063c:	nop

0000000000410640 <_start>:
  410640:	bti	c
  410644:	mov	x29, #0x0                   	// #0
  410648:	mov	x30, #0x0                   	// #0
  41064c:	mov	x5, x0
  410650:	ldr	x1, [sp]
  410654:	add	x2, sp, #0x8
  410658:	mov	x6, sp
  41065c:	adrp	x0, 410000 <_init>
  410660:	add	x0, x0, #0x674
  410664:	mov	x3, #0x0                   	// #0
  410668:	mov	x4, #0x0                   	// #0
  41066c:	bl	410050 <__libc_start_main@plt>
  410670:	bl	410100 <abort@plt>

0000000000410674 <__wrap_main>:
  410674:	bti	c
  410678:	b	410240 <main>
  41067c:	nop

0000000000410680 <_dl_relocate_static_pie>:
  410680:	bti	c
  410684:	ret

0000000000410688 <call_weak_fn>:
  410688:	adrp	x0, 43f000 <__FRAME_END__+0x1eafc>
  41068c:	ldr	x0, [x0, #4056]
  410690:	cbz	x0, 410698 <call_weak_fn+0x10>
  410694:	b	4100f0 <__gmon_start__@plt>
  410698:	ret
  41069c:	nop

00000000004106a0 <deregister_tm_clones>:
  4106a0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4106a4:	adrp	x1, 440000 <exit@GLIBC_2.17>
  4106a8:	add	x0, x0, #0xf8
  4106ac:	add	x1, x1, #0xf8
  4106b0:	cmp	x1, x0
  4106b4:	b.eq	4106cc <deregister_tm_clones+0x2c>  // b.none
  4106b8:	adrp	x1, 43f000 <__FRAME_END__+0x1eafc>
  4106bc:	ldr	x1, [x1, #4048]
  4106c0:	cbz	x1, 4106cc <deregister_tm_clones+0x2c>
  4106c4:	mov	x16, x1
  4106c8:	br	x16
  4106cc:	ret

00000000004106d0 <register_tm_clones>:
  4106d0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4106d4:	adrp	x1, 440000 <exit@GLIBC_2.17>
  4106d8:	add	x0, x0, #0xf8
  4106dc:	add	x1, x1, #0xf8
  4106e0:	sub	x1, x1, x0
  4106e4:	lsr	x2, x1, #63
  4106e8:	add	x1, x2, x1, asr #3
  4106ec:	asr	x1, x1, #1
  4106f0:	cbz	x1, 410708 <register_tm_clones+0x38>
  4106f4:	adrp	x2, 43f000 <__FRAME_END__+0x1eafc>
  4106f8:	ldr	x2, [x2, #4064]
  4106fc:	cbz	x2, 410708 <register_tm_clones+0x38>
  410700:	mov	x16, x2
  410704:	br	x16
  410708:	ret

000000000041070c <__do_global_dtors_aux>:
  41070c:	paciasp
  410710:	stp	x29, x30, [sp, #-32]!
  410714:	mov	x29, sp
  410718:	str	x19, [sp, #16]
  41071c:	adrp	x19, 440000 <exit@GLIBC_2.17>
  410720:	ldrb	w0, [x19, #256]
  410724:	cbnz	w0, 410734 <__do_global_dtors_aux+0x28>
  410728:	bl	4106a0 <deregister_tm_clones>
  41072c:	mov	w0, #0x1                   	// #1
  410730:	strb	w0, [x19, #256]
  410734:	ldr	x19, [sp, #16]
  410738:	ldp	x29, x30, [sp], #32
  41073c:	autiasp
  410740:	ret

0000000000410744 <frame_dummy>:
  410744:	bti	c
  410748:	b	4106d0 <register_tm_clones>
  41074c:	nop
  410750:	nop
  410754:	nop
  410758:	nop
  41075c:	nop

0000000000410760 <pin_and_verify>:
  410760:	movi	v0.4s, #0x0
  410764:	stp	x29, x30, [sp, #-304]!
  410768:	mov	x29, sp
  41076c:	stp	x19, x20, [sp, #16]
  410770:	add	x19, sp, #0x30
  410774:	mov	x20, x1
  410778:	stp	x21, x22, [sp, #32]
  41077c:	sxtw	x22, w0
  410780:	mov	x21, x22
  410784:	stp	q0, q0, [x19]
  410788:	stp	q0, q0, [x19, #32]
  41078c:	stp	q0, q0, [x19, #64]
  410790:	stp	q0, q0, [x19, #96]
  410794:	cmp	x22, #0x3ff
  410798:	b.hi	4107b4 <pin_and_verify+0x54>  // b.pmore
  41079c:	lsr	x2, x22, #6
  4107a0:	mov	x1, #0x1                   	// #1
  4107a4:	ldr	x0, [x19, x2, lsl #3]
  4107a8:	lsl	x1, x1, x22
  4107ac:	orr	x0, x0, x1
  4107b0:	str	x0, [x19, x2, lsl #3]
  4107b4:	str	w21, [x20]
  4107b8:	bl	410190 <pthread_self@plt>
  4107bc:	mov	x2, x19
  4107c0:	mov	x1, #0x80                  	// #128
  4107c4:	bl	410080 <pthread_setaffinity_np@plt>
  4107c8:	movi	v0.4s, #0x0
  4107cc:	mov	w3, w0
  4107d0:	add	x2, sp, #0xb0
  4107d4:	mov	x1, #0x80                  	// #128
  4107d8:	mov	w0, #0x0                   	// #0
  4107dc:	str	w3, [x20, #4]
  4107e0:	stp	q0, q0, [sp, #176]
  4107e4:	stp	q0, q0, [sp, #208]
  4107e8:	stp	q0, q0, [sp, #240]
  4107ec:	stp	q0, q0, [sp, #272]
  4107f0:	bl	410110 <sched_getaffinity@plt>
  4107f4:	mov	w19, w0
  4107f8:	cbnz	w0, 410848 <pin_and_verify+0xe8>
  4107fc:	ldr	w0, [x20, #4]
  410800:	cbz	w0, 410818 <pin_and_verify+0xb8>
  410804:	ldp	x21, x22, [sp, #32]
  410808:	str	w19, [x20, #8]
  41080c:	ldp	x19, x20, [sp, #16]
  410810:	ldp	x29, x30, [sp], #304
  410814:	ret
  410818:	add	x1, sp, #0xb0
  41081c:	mov	x0, #0x80                  	// #128
  410820:	bl	410180 <__sched_cpucount@plt>
  410824:	cmp	x22, #0x3ff
  410828:	ccmp	w0, #0x1, #0x0, ls	// ls = plast
  41082c:	b.ne	410804 <pin_and_verify+0xa4>  // b.any
  410830:	lsr	x22, x22, #6
  410834:	add	x0, sp, #0xb0
  410838:	ldr	x19, [x0, x22, lsl #3]
  41083c:	lsr	x19, x19, x21
  410840:	and	w19, w19, #0x1
  410844:	b	410804 <pin_and_verify+0xa4>
  410848:	mov	w19, #0x0                   	// #0
  41084c:	ldp	x21, x22, [sp, #32]
  410850:	str	w19, [x20, #8]
  410854:	ldp	x19, x20, [sp, #16]
  410858:	ldp	x29, x30, [sp], #304
  41085c:	ret

0000000000410860 <observe_scheduling>:
  410860:	stp	x29, x30, [sp, #-48]!
  410864:	mov	x29, sp
  410868:	str	x19, [sp, #16]
  41086c:	mov	x19, x0
  410870:	mov	x0, #0xb2                  	// #178
  410874:	str	wzr, [sp, #40]
  410878:	bl	4101f0 <syscall@plt>
  41087c:	mov	w1, w0
  410880:	mov	w0, #0x0                   	// #0
  410884:	bl	410130 <getpriority@plt>
  410888:	str	w0, [x19, #28]
  41088c:	bl	410190 <pthread_self@plt>
  410890:	add	x1, x19, #0x24
  410894:	add	x2, sp, #0x28
  410898:	bl	410150 <pthread_getschedparam@plt>
  41089c:	ldr	w1, [sp, #40]
  4108a0:	str	w0, [x19, #32]
  4108a4:	str	w1, [x19, #40]
  4108a8:	ldr	x19, [sp, #16]
  4108ac:	ldp	x29, x30, [sp], #48
  4108b0:	ret
  4108b4:	nop
  4108b8:	nop
  4108bc:	nop

00000000004108c0 <barrier_wait_checked>:
  4108c0:	adrp	x0, 440000 <exit@GLIBC_2.17>
  4108c4:	stp	x29, x30, [sp, #-32]!
  4108c8:	mov	x29, sp
  4108cc:	add	x0, x0, #0x108
  4108d0:	bl	410090 <pthread_barrier_wait@plt>
  4108d4:	add	w1, w0, #0x1
  4108d8:	cmp	w1, #0x1
  4108dc:	b.hi	4108e8 <barrier_wait_checked+0x28>  // b.pmore
  4108e0:	ldp	x29, x30, [sp], #32
  4108e4:	ret
  4108e8:	adrp	x1, 440000 <exit@GLIBC_2.17>
  4108ec:	str	x19, [sp, #16]
  4108f0:	ldr	x19, [x1, #248]
  4108f4:	bl	4100e0 <strerror@plt>
  4108f8:	adrp	x1, 420000 <_IO_stdin_used>
  4108fc:	mov	x2, x0
  410900:	add	x1, x1, #0x10
  410904:	mov	x0, x19
  410908:	bl	410210 <fprintf@plt>
  41090c:	mov	w0, #0x2                   	// #2
  410910:	bl	410040 <exit@plt>
  410914:	nop
  410918:	nop
  41091c:	nop

0000000000410920 <hog_main>:
  410920:	stp	x29, x30, [sp, #-400]!
  410924:	mov	x29, sp
  410928:	mov	x1, #0x11eb                	// #4587
  41092c:	movk	x1, #0x1331, lsl #16
  410930:	str	x19, [sp, #16]
  410934:	movk	x1, #0x49bb, lsl #32
  410938:	ldr	x19, [x0, #16]
  41093c:	movk	x1, #0x94d0, lsl #48
  410940:	ldr	w0, [x0]
  410944:	str	x1, [sp, #40]
  410948:	mov	x1, x19
  41094c:	bl	410760 <pin_and_verify>
  410950:	mov	x0, x19
  410954:	bl	410860 <observe_scheduling>
  410958:	bl	4108c0 <barrier_wait_checked>
  41095c:	bl	4100b0 <sched_getcpu@plt>
  410960:	mov	w2, w0
  410964:	add	x1, sp, #0x30
  410968:	mov	w0, #0x4                   	// #4
  41096c:	str	w2, [x19, #12]
  410970:	bl	4100a0 <clock_gettime@plt>
  410974:	add	x1, sp, #0x50
  410978:	mov	w0, #0x3                   	// #3
  41097c:	bl	4100a0 <clock_gettime@plt>
  410980:	add	x1, sp, #0x70
  410984:	mov	w0, #0x1                   	// #1
  410988:	bl	410120 <getrusage@plt>
  41098c:	adrp	x2, 440000 <exit@GLIBC_2.17>
  410990:	add	x2, x2, #0x108
  410994:	add	x2, x2, #0x20
  410998:	b	4109cc <hog_main+0xac>
  41099c:	ldr	x0, [sp, #40]
  4109a0:	ldr	x1, [sp, #40]
  4109a4:	eor	x0, x1, x0, lsl #13
  4109a8:	str	x0, [sp, #40]
  4109ac:	ldr	x0, [sp, #40]
  4109b0:	ldr	x1, [sp, #40]
  4109b4:	eor	x0, x1, x0, lsr #7
  4109b8:	str	x0, [sp, #40]
  4109bc:	ldr	x0, [sp, #40]
  4109c0:	ldr	x1, [sp, #40]
  4109c4:	eor	x0, x1, x0, lsl #17
  4109c8:	str	x0, [sp, #40]
  4109cc:	ldar	w0, [x2]
  4109d0:	cbz	w0, 41099c <hog_main+0x7c>
  4109d4:	add	x1, sp, #0x100
  4109d8:	mov	w0, #0x1                   	// #1
  4109dc:	bl	410120 <getrusage@plt>
  4109e0:	add	x1, sp, #0x60
  4109e4:	mov	w0, #0x3                   	// #3
  4109e8:	bl	4100a0 <clock_gettime@plt>
  4109ec:	add	x1, sp, #0x40
  4109f0:	mov	w0, #0x4                   	// #4
  4109f4:	bl	4100a0 <clock_gettime@plt>
  4109f8:	bl	4100b0 <sched_getcpu@plt>
  4109fc:	ldp	x3, x1, [sp, #48]
  410a00:	mov	x4, #0xca00                	// #51712
  410a04:	movk	x4, #0x3b9a, lsl #16
  410a08:	ldp	x2, x5, [sp, #72]
  410a0c:	ldr	x6, [sp, #240]
  410a10:	sub	x2, x2, x1
  410a14:	ldr	x1, [sp, #96]
  410a18:	sub	x1, x1, x5
  410a1c:	ldr	x5, [sp, #248]
  410a20:	str	w0, [x19, #16]
  410a24:	ldr	x0, [sp, #64]
  410a28:	sub	x0, x0, x3
  410a2c:	ldr	x3, [sp, #88]
  410a30:	madd	x0, x0, x4, x2
  410a34:	ldr	x2, [sp, #104]
  410a38:	str	x0, [x19, #48]
  410a3c:	sub	x0, x2, x3
  410a40:	ldp	x3, x2, [sp, #384]
  410a44:	madd	x1, x1, x4, x0
  410a48:	ldr	x0, [sp, #40]
  410a4c:	sub	x3, x3, x6
  410a50:	stp	x1, x3, [x19, #56]
  410a54:	sub	x1, x2, x5
  410a58:	and	x0, x0, #0x1
  410a5c:	str	x1, [x19, #72]
  410a60:	ldr	x19, [sp, #16]
  410a64:	ldp	x29, x30, [sp], #400
  410a68:	ret

0000000000410a6c <waiter_main>:
  410a6c:	stp	x29, x30, [sp, #-352]!
  410a70:	mov	x29, sp
  410a74:	stp	x19, x20, [sp, #16]
  410a78:	adrp	x20, 440000 <exit@GLIBC_2.17>
  410a7c:	add	x20, x20, #0x108
  410a80:	add	x20, x20, #0x28
  410a84:	ldr	x19, [x0, #16]
  410a88:	ldr	w0, [x0]
  410a8c:	mov	x1, x19
  410a90:	bl	410760 <pin_and_verify>
  410a94:	mov	x0, x19
  410a98:	bl	410860 <observe_scheduling>
  410a9c:	bl	4108c0 <barrier_wait_checked>
  410aa0:	bl	4100b0 <sched_getcpu@plt>
  410aa4:	mov	w2, w0
  410aa8:	add	x1, sp, #0x20
  410aac:	mov	w0, #0x4                   	// #4
  410ab0:	str	w2, [x19, #12]
  410ab4:	bl	4100a0 <clock_gettime@plt>
  410ab8:	add	x1, sp, #0x40
  410abc:	mov	w0, #0x1                   	// #1
  410ac0:	bl	410120 <getrusage@plt>
  410ac4:	mov	x0, x20
  410ac8:	bl	4101e0 <pthread_mutex_lock@plt>
  410acc:	add	x1, sp, #0xd0
  410ad0:	mov	w0, #0x1                   	// #1
  410ad4:	bl	410120 <getrusage@plt>
  410ad8:	add	x1, sp, #0x30
  410adc:	mov	w0, #0x4                   	// #4
  410ae0:	bl	4100a0 <clock_gettime@plt>
  410ae4:	bl	4100b0 <sched_getcpu@plt>
  410ae8:	ldp	x4, x3, [sp, #32]
  410aec:	mov	w1, w0
  410af0:	mov	x6, #0xca00                	// #51712
  410af4:	movk	x6, #0x3b9a, lsl #16
  410af8:	mov	x0, x20
  410afc:	ldr	x2, [sp, #56]
  410b00:	ldr	x5, [sp, #192]
  410b04:	sub	x2, x2, x3
  410b08:	ldr	x3, [sp, #336]
  410b0c:	str	w1, [x19, #16]
  410b10:	ldr	x1, [sp, #48]
  410b14:	sub	x3, x3, x5
  410b18:	sub	x1, x1, x4
  410b1c:	ldr	x4, [sp, #200]
  410b20:	madd	x1, x1, x6, x2
  410b24:	ldr	x2, [sp, #344]
  410b28:	str	x3, [x19, #64]
  410b2c:	str	x1, [x19, #48]
  410b30:	sub	x1, x2, x4
  410b34:	str	x1, [x19, #72]
  410b38:	bl	410200 <pthread_mutex_unlock@plt>
  410b3c:	mov	x0, #0x0                   	// #0
  410b40:	ldp	x19, x20, [sp, #16]
  410b44:	ldp	x29, x30, [sp], #352
  410b48:	ret

0000000000410b4c <burn_thread_cpu>:
  410b4c:	mov	x2, #0x7c15                	// #31765
  410b50:	stp	x29, x30, [sp, #-96]!
  410b54:	mov	x29, sp
  410b58:	movk	x2, #0x7f4a, lsl #16
  410b5c:	add	x1, sp, #0x40
  410b60:	movk	x2, #0x79b9, lsl #32
  410b64:	movk	x2, #0x9e37, lsl #48
  410b68:	stp	x19, x20, [sp, #16]
  410b6c:	mov	x19, x0
  410b70:	mov	w0, #0x3                   	// #3
  410b74:	str	x21, [sp, #32]
  410b78:	str	x2, [sp, #56]
  410b7c:	bl	4100a0 <clock_gettime@plt>
  410b80:	cbnz	w0, 410c14 <burn_thread_cpu+0xc8>
  410b84:	mov	x21, #0xe5b9                	// #58809
  410b88:	mov	x20, #0xca00                	// #51712
  410b8c:	movk	x21, #0x1ce4, lsl #16
  410b90:	movk	x20, #0x3b9a, lsl #16
  410b94:	movk	x21, #0x476d, lsl #32
  410b98:	movk	x21, #0xbf58, lsl #48
  410b9c:	mov	w1, #0x1000                	// #4096
  410ba0:	ldr	x0, [sp, #56]
  410ba4:	subs	w1, w1, #0x1
  410ba8:	ldr	x2, [sp, #56]
  410bac:	eor	x0, x2, x0, lsl #7
  410bb0:	str	x0, [sp, #56]
  410bb4:	ldr	x0, [sp, #56]
  410bb8:	ldr	x2, [sp, #56]
  410bbc:	eor	x0, x2, x0, lsr #9
  410bc0:	str	x0, [sp, #56]
  410bc4:	ldr	x0, [sp, #56]
  410bc8:	mul	x0, x0, x21
  410bcc:	str	x0, [sp, #56]
  410bd0:	b.ne	410ba0 <burn_thread_cpu+0x54>  // b.any
  410bd4:	add	x1, sp, #0x50
  410bd8:	mov	w0, #0x3                   	// #3
  410bdc:	bl	4100a0 <clock_gettime@plt>
  410be0:	cbnz	w0, 410c14 <burn_thread_cpu+0xc8>
  410be4:	ldp	x3, x2, [sp, #64]
  410be8:	ldp	x0, x1, [sp, #80]
  410bec:	sub	x0, x0, x3
  410bf0:	sub	x1, x1, x2
  410bf4:	madd	x0, x0, x20, x1
  410bf8:	cmp	x19, x0
  410bfc:	b.hi	410b9c <burn_thread_cpu+0x50>  // b.pmore
  410c00:	ldp	x19, x20, [sp, #16]
  410c04:	ldr	x21, [sp, #32]
  410c08:	ldr	x0, [sp, #56]
  410c0c:	ldp	x29, x30, [sp], #96
  410c10:	ret
  410c14:	adrp	x0, 420000 <_IO_stdin_used>
  410c18:	add	x0, x0, #0x30
  410c1c:	bl	410060 <perror@plt>
  410c20:	mov	w0, #0x2                   	// #2
  410c24:	bl	410040 <exit@plt>

0000000000410c28 <holder_main>:
  410c28:	stp	x29, x30, [sp, #-400]!
  410c2c:	mov	x29, sp
  410c30:	stp	x19, x20, [sp, #16]
  410c34:	ldr	x19, [x0, #16]
  410c38:	stp	x21, x22, [sp, #32]
  410c3c:	mov	x21, x0
  410c40:	ldr	w0, [x0]
  410c44:	mov	x1, x19
  410c48:	bl	410760 <pin_and_verify>
  410c4c:	bl	4101b0 <__errno_location@plt>
  410c50:	mov	x20, x0
  410c54:	mov	x0, #0xb2                  	// #178
  410c58:	str	wzr, [x20]
  410c5c:	bl	4101f0 <syscall@plt>
  410c60:	mov	x1, x0
  410c64:	ldr	w2, [x21, #4]
  410c68:	mov	w0, #0x0                   	// #0
  410c6c:	bl	4101d0 <setpriority@plt>
  410c70:	mov	w1, w0
  410c74:	mov	x0, x19
  410c78:	str	w1, [x19, #20]
  410c7c:	ldr	w1, [x20]
  410c80:	adrp	x20, 440000 <exit@GLIBC_2.17>
  410c84:	add	x20, x20, #0x108
  410c88:	add	x22, x20, #0x28
  410c8c:	str	w1, [x19, #24]
  410c90:	bl	410860 <observe_scheduling>
  410c94:	mov	x0, x22
  410c98:	bl	4101e0 <pthread_mutex_lock@plt>
  410c9c:	cbnz	w0, 410d8c <holder_main+0x164>
  410ca0:	bl	4108c0 <barrier_wait_checked>
  410ca4:	bl	4100b0 <sched_getcpu@plt>
  410ca8:	mov	w2, w0
  410cac:	add	x1, sp, #0x30
  410cb0:	mov	w0, #0x4                   	// #4
  410cb4:	str	w2, [x19, #12]
  410cb8:	bl	4100a0 <clock_gettime@plt>
  410cbc:	add	x1, sp, #0x50
  410cc0:	mov	w0, #0x3                   	// #3
  410cc4:	bl	4100a0 <clock_gettime@plt>
  410cc8:	add	x1, sp, #0x70
  410ccc:	mov	w0, #0x1                   	// #1
  410cd0:	bl	410120 <getrusage@plt>
  410cd4:	ldr	x0, [x21, #8]
  410cd8:	bl	410b4c <burn_thread_cpu>
  410cdc:	add	x1, sp, #0x100
  410ce0:	mov	w0, #0x1                   	// #1
  410ce4:	bl	410120 <getrusage@plt>
  410ce8:	add	x1, sp, #0x60
  410cec:	mov	w0, #0x3                   	// #3
  410cf0:	bl	4100a0 <clock_gettime@plt>
  410cf4:	add	x1, sp, #0x40
  410cf8:	mov	w0, #0x4                   	// #4
  410cfc:	bl	4100a0 <clock_gettime@plt>
  410d00:	bl	4100b0 <sched_getcpu@plt>
  410d04:	ldp	x6, x1, [sp, #48]
  410d08:	mov	w2, w0
  410d0c:	mov	x4, #0xca00                	// #51712
  410d10:	movk	x4, #0x3b9a, lsl #16
  410d14:	mov	x0, x22
  410d18:	ldp	x3, x5, [sp, #72]
  410d1c:	ldr	x7, [sp, #88]
  410d20:	sub	x3, x3, x1
  410d24:	ldr	x1, [sp, #96]
  410d28:	sub	x1, x1, x5
  410d2c:	ldr	x5, [sp, #248]
  410d30:	str	w2, [x19, #16]
  410d34:	ldr	x2, [sp, #64]
  410d38:	sub	x2, x2, x6
  410d3c:	ldr	x6, [sp, #240]
  410d40:	madd	x2, x2, x4, x3
  410d44:	ldr	x3, [sp, #104]
  410d48:	str	x2, [x19, #48]
  410d4c:	sub	x2, x3, x7
  410d50:	madd	x1, x1, x4, x2
  410d54:	ldp	x3, x2, [sp, #384]
  410d58:	sub	x3, x3, x6
  410d5c:	stp	x1, x3, [x19, #56]
  410d60:	sub	x1, x2, x5
  410d64:	str	x1, [x19, #72]
  410d68:	bl	410200 <pthread_mutex_unlock@plt>
  410d6c:	mov	w0, #0x1                   	// #1
  410d70:	add	x20, x20, #0x20
  410d74:	stlr	w0, [x20]
  410d78:	mov	x0, #0x0                   	// #0
  410d7c:	ldp	x19, x20, [sp, #16]
  410d80:	ldp	x21, x22, [sp, #32]
  410d84:	ldp	x29, x30, [sp], #400
  410d88:	ret
  410d8c:	bl	410100 <abort@plt>

0000000000410d90 <parse_long>:
  410d90:	stp	x29, x30, [sp, #-64]!
  410d94:	mov	x29, sp
  410d98:	stp	x19, x20, [sp, #16]
  410d9c:	mov	x19, x1
  410da0:	str	x21, [sp, #32]
  410da4:	mov	x21, x0
  410da8:	str	xzr, [sp, #56]
  410dac:	bl	4101b0 <__errno_location@plt>
  410db0:	mov	x20, x0
  410db4:	add	x1, sp, #0x38
  410db8:	mov	w2, #0xa                   	// #10
  410dbc:	mov	x0, x19
  410dc0:	str	wzr, [x20]
  410dc4:	bl	410140 <strtol@plt>
  410dc8:	ldr	w1, [x20]
  410dcc:	cbnz	w1, 410df4 <parse_long+0x64>
  410dd0:	ldr	x1, [sp, #56]
  410dd4:	cmp	x1, x19
  410dd8:	b.eq	410df4 <parse_long+0x64>  // b.none
  410ddc:	ldrb	w1, [x1]
  410de0:	cbnz	w1, 410df4 <parse_long+0x64>
  410de4:	ldp	x19, x20, [sp, #16]
  410de8:	ldr	x21, [sp, #32]
  410dec:	ldp	x29, x30, [sp], #64
  410df0:	ret
  410df4:	adrp	x1, 420000 <_IO_stdin_used>
  410df8:	adrp	x0, 440000 <exit@GLIBC_2.17>
  410dfc:	ldr	x0, [x0, #248]
  410e00:	mov	x3, x19
  410e04:	mov	x2, x21
  410e08:	add	x1, x1, #0x58
  410e0c:	bl	410210 <fprintf@plt>
  410e10:	mov	w0, #0x2                   	// #2
  410e14:	bl	410040 <exit@plt>

Disassembly of section .fini:

0000000000410e18 <_fini>:
  410e18:	paciasp
  410e1c:	stp	x29, x30, [sp, #-16]!
  410e20:	mov	x29, sp
  410e24:	ldp	x29, x30, [sp], #16
  410e28:	autiasp
  410e2c:	ret
