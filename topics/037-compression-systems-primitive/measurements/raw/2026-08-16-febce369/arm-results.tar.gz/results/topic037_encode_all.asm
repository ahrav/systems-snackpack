
/tmp/topic37-exact.b9MDaY/results.work/compression-probe-native:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000411ae0 <topic037_encode_all>:
  411ae0:	stp	x29, x30, [sp, #-112]!
  411ae4:	mov	x29, sp
  411ae8:	ldr	w1, [x0]
  411aec:	stp	x19, x20, [sp, #16]
  411af0:	mov	x19, x0
  411af4:	cmp	w1, #0x1
  411af8:	b.eq	411b18 <topic037_encode_all+0x38>  // b.none
  411afc:	cmp	w1, #0x2
  411b00:	b.eq	411d90 <topic037_encode_all+0x2b0>  // b.none
  411b04:	mov	w0, #0xffffffff            	// #-1
  411b08:	cbz	w1, 411cbc <topic037_encode_all+0x1dc>
  411b0c:	ldp	x19, x20, [sp, #16]
  411b10:	ldp	x29, x30, [sp], #112
  411b14:	ret
  411b18:	add	x20, x0, #0x68
  411b1c:	stp	x23, x24, [sp, #48]
  411b20:	stp	xzr, xzr, [x0, #104]
  411b24:	stp	xzr, xzr, [x20, #16]
  411b28:	stp	xzr, xzr, [x20, #32]
  411b2c:	ldr	w0, [x0, #48]
  411b30:	bl	4100a0 <LZ4_compressBound@plt>
  411b34:	mov	w23, w0
  411b38:	cmp	w0, #0x0
  411b3c:	b.le	411ca8 <topic037_encode_all+0x1c8>
  411b40:	stp	x21, x22, [sp, #32]
  411b44:	ldr	x22, [x19, #40]
  411b48:	cbz	x22, 411f68 <topic037_encode_all+0x488>
  411b4c:	sxtw	x0, w0
  411b50:	stp	x25, x26, [sp, #64]
  411b54:	mov	w25, #0x3343                	// #13123
  411b58:	mov	x26, #0x0                   	// #0
  411b5c:	mov	x22, #0x0                   	// #0
  411b60:	mov	x24, #0xffffffff            	// #4294967295
  411b64:	movk	w25, #0x5537, lsl #16
  411b68:	stp	x27, x28, [sp, #80]
  411b6c:	str	x0, [sp, #104]
  411b70:	ldr	x2, [x19, #48]
  411b74:	ldr	x28, [x19, #64]
  411b78:	b	411c2c <topic037_encode_all+0x14c>
  411b7c:	ldr	x0, [x20, #32]
  411b80:	add	x0, x0, #0x1
  411b84:	str	x0, [x20, #32]
  411b88:	fmov	s1, w1
  411b8c:	orr	x3, x1, x21
  411b90:	lsr	w4, w21, #24
  411b94:	mov	v0.b[1], w1
  411b98:	add	x6, x1, #0xd
  411b9c:	add	x26, x26, #0x1
  411ba0:	ldr	x0, [x19, #72]
  411ba4:	add	x2, x0, x22
  411ba8:	ushr	v5.2s, v1.2s, #16
  411bac:	ushr	v4.2s, v1.2s, #24
  411bb0:	fmov	s1, w21
  411bb4:	ushr	v3.2s, v1.2s, #8
  411bb8:	ushr	v2.2s, v1.2s, #16
  411bbc:	fmov	s1, w1
  411bc0:	ushr	v1.2s, v1.2s, #8
  411bc4:	mov	v0.b[2], v1.b[0]
  411bc8:	cmp	x3, x24
  411bcc:	b.hi	411c9c <topic037_encode_all+0x1bc>  // b.pmore
  411bd0:	mov	v0.b[3], v5.b[0]
  411bd4:	str	w25, [x0, x22]
  411bd8:	add	x22, x22, x6
  411bdc:	strb	w4, [x2, #12]
  411be0:	mov	v0.b[4], v4.b[0]
  411be4:	mov	v0.b[5], w21
  411be8:	mov	v0.b[6], v3.b[0]
  411bec:	mov	v0.b[7], v2.b[0]
  411bf0:	stur	d0, [x2, #4]
  411bf4:	ldr	x0, [x20, #8]
  411bf8:	ldr	x2, [x19, #40]
  411bfc:	add	x0, x0, x1
  411c00:	str	x0, [x20, #8]
  411c04:	cmp	x26, x2
  411c08:	b.cs	411f54 <topic037_encode_all+0x474>  // b.hs, b.nlast
  411c0c:	ldp	x2, x4, [x19, #48]
  411c10:	ldr	x0, [sp, #104]
  411c14:	sub	x4, x4, #0xd
  411c18:	ldr	x28, [x19, #64]
  411c1c:	sub	x4, x4, x0
  411c20:	madd	x28, x2, x26, x28
  411c24:	cmp	x4, x22
  411c28:	b.cc	411c9c <topic037_encode_all+0x1bc>  // b.lo, b.ul, b.last
  411c2c:	ldr	x27, [x19, #72]
  411c30:	add	x1, x22, #0xd
  411c34:	mov	w3, w23
  411c38:	mov	x0, x28
  411c3c:	add	x27, x27, x1
  411c40:	mov	x1, x27
  411c44:	bl	410290 <LZ4_compress_default@plt>
  411c48:	movi	v0.2s, #0x1
  411c4c:	sxtw	x1, w0
  411c50:	cmp	w0, #0x0
  411c54:	b.le	411c9c <topic037_encode_all+0x1bc>
  411c58:	ldr	x0, [x20]
  411c5c:	ldr	x21, [x19, #48]
  411c60:	add	x0, x0, x1
  411c64:	str	x0, [x20]
  411c68:	cmp	x1, x21
  411c6c:	b.cc	411b7c <topic037_encode_all+0x9c>  // b.lo, b.ul, b.last
  411c70:	mov	x1, x28
  411c74:	mov	x2, x21
  411c78:	mov	x0, x27
  411c7c:	bl	410040 <memcpy@plt>
  411c80:	ldr	x0, [x20, #40]
  411c84:	mov	x1, x21
  411c88:	fmov	s0, wzr
  411c8c:	ldr	x21, [x19, #48]
  411c90:	add	x0, x0, #0x1
  411c94:	str	x0, [x20, #40]
  411c98:	b	411b88 <topic037_encode_all+0xa8>
  411c9c:	ldp	x21, x22, [sp, #32]
  411ca0:	ldp	x25, x26, [sp, #64]
  411ca4:	ldp	x27, x28, [sp, #80]
  411ca8:	mov	w0, #0xffffffff            	// #-1
  411cac:	ldp	x23, x24, [sp, #48]
  411cb0:	ldp	x19, x20, [sp, #16]
  411cb4:	ldp	x29, x30, [sp], #112
  411cb8:	ret
  411cbc:	add	x20, x19, #0x68
  411cc0:	stp	x21, x22, [sp, #32]
  411cc4:	mov	x1, #0x0                   	// #0
  411cc8:	stp	xzr, xzr, [x19, #104]
  411ccc:	stp	xzr, xzr, [x20, #16]
  411cd0:	stp	xzr, xzr, [x20, #32]
  411cd4:	ldr	x21, [x19, #40]
  411cd8:	cbz	x21, 411f18 <topic037_encode_all+0x438>
  411cdc:	ldr	x2, [x19, #48]
  411ce0:	mov	x21, #0x0                   	// #0
  411ce4:	mov	x22, #0x0                   	// #0
  411ce8:	stp	x23, x24, [sp, #48]
  411cec:	mov	w24, #0x3343                	// #13123
  411cf0:	mov	x23, #0xffffffff            	// #4294967295
  411cf4:	movk	w24, #0x5537, lsl #16
  411cf8:	ldr	x1, [x19, #64]
  411cfc:	nop
  411d00:	add	x0, x21, #0xd
  411d04:	add	x22, x22, #0x1
  411d08:	ldr	x4, [x19, #72]
  411d0c:	add	x3, x4, x21
  411d10:	cmp	x2, x23
  411d14:	b.hi	411d80 <topic037_encode_all+0x2a0>  // b.pmore
  411d18:	str	w24, [x4, x21]
  411d1c:	strb	wzr, [x3, #4]
  411d20:	stur	w2, [x3, #5]
  411d24:	stur	w2, [x3, #9]
  411d28:	ldr	x3, [x19, #72]
  411d2c:	ldr	x2, [x19, #48]
  411d30:	add	x0, x3, x0
  411d34:	bl	410040 <memcpy@plt>
  411d38:	ldp	x1, x0, [x20]
  411d3c:	ldp	x4, x2, [x19, #40]
  411d40:	ldr	x3, [x20, #40]
  411d44:	add	x1, x1, x2
  411d48:	add	x0, x0, x2
  411d4c:	stp	x1, x0, [x20]
  411d50:	add	x3, x3, #0x1
  411d54:	str	x3, [x20, #40]
  411d58:	add	x3, x2, #0xd
  411d5c:	add	x21, x21, x3
  411d60:	cmp	x22, x4
  411d64:	b.cs	411f0c <topic037_encode_all+0x42c>  // b.hs, b.nlast
  411d68:	ldp	x0, x1, [x19, #56]
  411d6c:	sub	x0, x0, #0xd
  411d70:	madd	x1, x2, x22, x1
  411d74:	sub	x0, x0, x2
  411d78:	cmp	x0, x21
  411d7c:	b.cs	411d00 <topic037_encode_all+0x220>  // b.hs, b.nlast
  411d80:	mov	w0, #0xffffffff            	// #-1
  411d84:	ldp	x21, x22, [sp, #32]
  411d88:	ldp	x23, x24, [sp, #48]
  411d8c:	b	411cb0 <topic037_encode_all+0x1d0>
  411d90:	add	x20, x0, #0x68
  411d94:	stp	x23, x24, [sp, #48]
  411d98:	stp	xzr, xzr, [x0, #104]
  411d9c:	stp	xzr, xzr, [x20, #16]
  411da0:	stp	xzr, xzr, [x20, #32]
  411da4:	ldr	x0, [x0, #48]
  411da8:	bl	410240 <ZSTD_compressBound@plt>
  411dac:	mov	x23, x0
  411db0:	bl	410090 <ZSTD_isError@plt>
  411db4:	cbnz	w0, 411ca8 <topic037_encode_all+0x1c8>
  411db8:	stp	x21, x22, [sp, #32]
  411dbc:	ldr	x22, [x19, #40]
  411dc0:	cbz	x22, 411f68 <topic037_encode_all+0x488>
  411dc4:	stp	x25, x26, [sp, #64]
  411dc8:	mov	w25, #0x3343                	// #13123
  411dcc:	mov	x22, #0x0                   	// #0
  411dd0:	mov	x24, #0xffffffff            	// #4294967295
  411dd4:	movk	w25, #0x5537, lsl #16
  411dd8:	stp	x27, x28, [sp, #80]
  411ddc:	mov	x28, #0x0                   	// #0
  411de0:	ldr	x4, [x19, #48]
  411de4:	ldr	x27, [x19, #64]
  411de8:	b	411e98 <topic037_encode_all+0x3b8>
  411dec:	ldr	x0, [x20, #32]
  411df0:	add	x0, x0, #0x1
  411df4:	str	x0, [x20, #32]
  411df8:	fmov	s1, w21
  411dfc:	orr	x3, x21, x2
  411e00:	lsr	w4, w2, #24
  411e04:	mov	v0.b[1], w21
  411e08:	add	x5, x21, #0xd
  411e0c:	add	x28, x28, #0x1
  411e10:	ldr	x0, [x19, #72]
  411e14:	add	x1, x0, x22
  411e18:	ushr	v5.2s, v1.2s, #16
  411e1c:	ushr	v4.2s, v1.2s, #24
  411e20:	fmov	s1, w2
  411e24:	ushr	v3.2s, v1.2s, #8
  411e28:	ushr	v2.2s, v1.2s, #16
  411e2c:	fmov	s1, w21
  411e30:	ushr	v1.2s, v1.2s, #8
  411e34:	mov	v0.b[2], v1.b[0]
  411e38:	cmp	x3, x24
  411e3c:	b.hi	411c9c <topic037_encode_all+0x1bc>  // b.pmore
  411e40:	mov	v0.b[3], v5.b[0]
  411e44:	str	w25, [x0, x22]
  411e48:	add	x22, x22, x5
  411e4c:	strb	w4, [x1, #12]
  411e50:	mov	v0.b[4], v4.b[0]
  411e54:	mov	v0.b[5], w2
  411e58:	mov	v0.b[6], v3.b[0]
  411e5c:	mov	v0.b[7], v2.b[0]
  411e60:	stur	d0, [x1, #4]
  411e64:	ldr	x0, [x20, #8]
  411e68:	ldr	x1, [x19, #40]
  411e6c:	add	x0, x0, x21
  411e70:	str	x0, [x20, #8]
  411e74:	cmp	x28, x1
  411e78:	b.cs	411f28 <topic037_encode_all+0x448>  // b.hs, b.nlast
  411e7c:	ldp	x4, x2, [x19, #48]
  411e80:	ldr	x27, [x19, #64]
  411e84:	sub	x2, x2, #0xd
  411e88:	sub	x2, x2, x23
  411e8c:	madd	x27, x4, x28, x27
  411e90:	cmp	x2, x22
  411e94:	b.cc	411c9c <topic037_encode_all+0x1bc>  // b.lo, b.ul, b.last
  411e98:	ldr	x26, [x19, #72]
  411e9c:	add	x1, x22, #0xd
  411ea0:	mov	w5, #0x1                   	// #1
  411ea4:	mov	x3, x27
  411ea8:	mov	x2, x23
  411eac:	ldr	x0, [x19, #88]
  411eb0:	add	x26, x26, x1
  411eb4:	mov	x1, x26
  411eb8:	bl	410160 <ZSTD_compressCCtx@plt>
  411ebc:	mov	x21, x0
  411ec0:	bl	410090 <ZSTD_isError@plt>
  411ec4:	movi	v0.2s, #0x2
  411ec8:	cbnz	w0, 411c9c <topic037_encode_all+0x1bc>
  411ecc:	ldr	x0, [x20]
  411ed0:	ldr	x2, [x19, #48]
  411ed4:	add	x0, x0, x21
  411ed8:	str	x0, [x20]
  411edc:	cmp	x21, x2
  411ee0:	b.cc	411dec <topic037_encode_all+0x30c>  // b.lo, b.ul, b.last
  411ee4:	mov	x1, x27
  411ee8:	mov	x0, x26
  411eec:	mov	x21, x2
  411ef0:	bl	410040 <memcpy@plt>
  411ef4:	ldr	x0, [x20, #40]
  411ef8:	fmov	s0, wzr
  411efc:	ldr	x2, [x19, #48]
  411f00:	add	x0, x0, #0x1
  411f04:	str	x0, [x20, #40]
  411f08:	b	411df8 <topic037_encode_all+0x318>
  411f0c:	add	x1, x4, x4, lsl #1
  411f10:	ldp	x23, x24, [sp, #48]
  411f14:	add	x1, x4, x1, lsl #2
  411f18:	mov	w0, #0x0                   	// #0
  411f1c:	stp	x1, x21, [x20, #16]
  411f20:	ldp	x21, x22, [sp, #32]
  411f24:	b	411b0c <topic037_encode_all+0x2c>
  411f28:	add	x0, x1, x1, lsl #1
  411f2c:	ldp	x25, x26, [sp, #64]
  411f30:	add	x1, x1, x0, lsl #2
  411f34:	ldp	x27, x28, [sp, #80]
  411f38:	mov	w0, #0x0                   	// #0
  411f3c:	ldp	x23, x24, [sp, #48]
  411f40:	stp	x1, x22, [x20, #16]
  411f44:	ldp	x21, x22, [sp, #32]
  411f48:	ldp	x19, x20, [sp, #16]
  411f4c:	ldp	x29, x30, [sp], #112
  411f50:	ret
  411f54:	add	x1, x2, x2, lsl #1
  411f58:	ldp	x25, x26, [sp, #64]
  411f5c:	add	x1, x2, x1, lsl #2
  411f60:	ldp	x27, x28, [sp, #80]
  411f64:	b	411f38 <topic037_encode_all+0x458>
  411f68:	mov	x1, #0x0                   	// #0
  411f6c:	b	411f38 <topic037_encode_all+0x458>

Disassembly of section .fini:
