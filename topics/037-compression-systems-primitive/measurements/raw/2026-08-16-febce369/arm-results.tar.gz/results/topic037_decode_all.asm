
/tmp/topic37-exact.b9MDaY/results.work/compression-probe-native:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000411f70 <topic037_decode_all>:
  411f70:	stp	x29, x30, [sp, #-96]!
  411f74:	mov	x29, sp
  411f78:	stp	x19, x20, [sp, #16]
  411f7c:	mov	x20, x0
  411f80:	stp	x23, x24, [sp, #48]
  411f84:	stp	x25, x26, [sp, #64]
  411f88:	mov	x25, #0x0                   	// #0
  411f8c:	ldr	x23, [x0, #40]
  411f90:	cbz	x23, 412124 <topic037_decode_all+0x1b4>
  411f94:	ldr	x1, [x0, #128]
  411f98:	mov	x25, #0x0                   	// #0
  411f9c:	mov	x23, #0x0                   	// #0
  411fa0:	stp	x21, x22, [sp, #32]
  411fa4:	mov	w22, #0x3343                	// #13123
  411fa8:	movk	w22, #0x5537, lsl #16
  411fac:	stp	x27, x28, [sp, #80]
  411fb0:	mov	x27, #0x0                   	// #0
  411fb4:	sub	x1, x1, x23
  411fb8:	cmp	x1, #0xc
  411fbc:	b.ls	412060 <topic037_decode_all+0xf0>  // b.plast
  411fc0:	ldr	x3, [x20, #72]
  411fc4:	ldr	w0, [x3, x23]
  411fc8:	add	x3, x3, x23
  411fcc:	cmp	w0, w22
  411fd0:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  411fd4:	ldur	w28, [x3, #9]
  411fd8:	ldur	w2, [x3, #5]
  411fdc:	ldr	x0, [x20, #48]
  411fe0:	mov	w24, w28
  411fe4:	ldrb	w4, [x3, #4]
  411fe8:	mov	w21, w2
  411fec:	cmp	x0, x24
  411ff0:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  411ff4:	sub	x1, x1, #0xd
  411ff8:	cmp	x1, x21
  411ffc:	b.cc	412060 <topic037_decode_all+0xf0>  // b.lo, b.ul, b.last
  412000:	ldr	x0, [x20, #32]
  412004:	sub	x0, x0, x25
  412008:	cmp	x0, x24
  41200c:	b.cc	412060 <topic037_decode_all+0xf0>  // b.lo, b.ul, b.last
  412010:	ldr	x0, [x20, #80]
  412014:	add	x19, x3, #0xd
  412018:	add	x26, x0, x25
  41201c:	cbnz	w4, 412080 <topic037_decode_all+0x110>
  412020:	cmp	x21, x24
  412024:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  412028:	mov	x1, x19
  41202c:	mov	x0, x26
  412030:	mov	x2, x21
  412034:	bl	410040 <memcpy@plt>
  412038:	ldr	x0, [x20, #40]
  41203c:	add	x21, x21, #0xd
  412040:	add	x27, x27, #0x1
  412044:	add	x23, x23, x21
  412048:	add	x25, x25, x24
  41204c:	cmp	x0, x27
  412050:	b.ls	41211c <topic037_decode_all+0x1ac>  // b.plast
  412054:	ldr	x1, [x20, #128]
  412058:	cmp	x1, x23
  41205c:	b.cs	411fb4 <topic037_decode_all+0x44>  // b.hs, b.nlast
  412060:	ldp	x21, x22, [sp, #32]
  412064:	ldp	x27, x28, [sp, #80]
  412068:	mov	w0, #0xffffffff            	// #-1
  41206c:	ldp	x19, x20, [sp, #16]
  412070:	ldp	x23, x24, [sp, #48]
  412074:	ldp	x25, x26, [sp, #64]
  412078:	ldp	x29, x30, [sp], #96
  41207c:	ret
  412080:	cmp	w4, #0x1
  412084:	b.eq	4120ec <topic037_decode_all+0x17c>  // b.none
  412088:	cmp	w4, #0x2
  41208c:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  412090:	ldr	w0, [x20]
  412094:	cmp	w0, #0x2
  412098:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  41209c:	mov	x1, x21
  4120a0:	mov	x0, x19
  4120a4:	bl	410260 <ZSTD_findFrameCompressedSize@plt>
  4120a8:	mov	x28, x0
  4120ac:	bl	410090 <ZSTD_isError@plt>
  4120b0:	cmp	w0, #0x0
  4120b4:	ccmp	x21, x28, #0x0, eq	// eq = none
  4120b8:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  4120bc:	mov	x3, x19
  4120c0:	mov	x1, x26
  4120c4:	ldr	x0, [x20, #96]
  4120c8:	mov	x4, x21
  4120cc:	mov	x2, x24
  4120d0:	bl	410080 <ZSTD_decompressDCtx@plt>
  4120d4:	mov	x19, x0
  4120d8:	bl	410090 <ZSTD_isError@plt>
  4120dc:	cmp	w0, #0x0
  4120e0:	ccmp	x24, x19, #0x0, eq	// eq = none
  4120e4:	b.eq	412038 <topic037_decode_all+0xc8>  // b.none
  4120e8:	b	412060 <topic037_decode_all+0xf0>
  4120ec:	ldr	w0, [x20]
  4120f0:	cmp	w0, #0x1
  4120f4:	b.ne	412060 <topic037_decode_all+0xf0>  // b.any
  4120f8:	orr	w0, w28, w2
  4120fc:	tbnz	w0, #31, 412060 <topic037_decode_all+0xf0>
  412100:	mov	x1, x26
  412104:	mov	x0, x19
  412108:	mov	w3, w28
  41210c:	bl	410200 <LZ4_decompress_safe@plt>
  412110:	cmp	w28, w0
  412114:	b.eq	412038 <topic037_decode_all+0xc8>  // b.none
  412118:	b	412060 <topic037_decode_all+0xf0>
  41211c:	ldp	x21, x22, [sp, #32]
  412120:	ldp	x27, x28, [sp, #80]
  412124:	ldr	x0, [x20, #128]
  412128:	cmp	x0, x23
  41212c:	b.ne	412068 <topic037_decode_all+0xf8>  // b.any
  412130:	ldr	x1, [x20, #32]
  412134:	mov	w0, #0x0                   	// #0
  412138:	cmp	x1, x25
  41213c:	b.eq	41206c <topic037_decode_all+0xfc>  // b.none
  412140:	b	412068 <topic037_decode_all+0xf8>

Disassembly of section .fini:
