
/tmp/topic37-exact.M7ABv6/results.work/compression-probe-native:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004033e0 <topic037_encode_all>:
  4033e0:	push   %rbp
  4033e1:	mov    %rsp,%rbp
  4033e4:	push   %r15
  4033e6:	push   %r14
  4033e8:	push   %r13
  4033ea:	push   %r12
  4033ec:	push   %rbx
  4033ed:	mov    %rdi,%rbx
  4033f0:	sub    $0x18,%rsp
  4033f4:	mov    (%rdi),%eax
  4033f6:	cmp    $0x1,%eax
  4033f9:	je     403428 <topic037_encode_all+0x48>
  4033fb:	cmp    $0x2,%eax
  4033fe:	je     403670 <topic037_encode_all+0x290>
  403404:	mov    $0xffffffff,%r8d
  40340a:	test   %eax,%eax
  40340c:	je     4035b0 <topic037_encode_all+0x1d0>
  403412:	add    $0x18,%rsp
  403416:	pop    %rbx
  403417:	pop    %r12
  403419:	pop    %r13
  40341b:	pop    %r14
  40341d:	pop    %r15
  40341f:	mov    %r8d,%eax
  403422:	pop    %rbp
  403423:	ret
  403424:	nopl   0x0(%rax)
  403428:	vpxor  %xmm0,%xmm0,%xmm0
  40342c:	vmovdqu %xmm0,0x68(%rdi)
  403431:	vmovdqu %xmm0,0x78(%rdi)
  403436:	vmovdqu %xmm0,0x88(%rdi)
  40343e:	mov    0x30(%rdi),%edi
  403441:	call   401070 <LZ4_compressBound@plt>
  403446:	mov    %eax,-0x38(%rbp)
  403449:	test   %eax,%eax
  40344b:	jle    403661 <topic037_encode_all+0x281>
  403451:	mov    0x28(%rbx),%r14
  403455:	test   %r14,%r14
  403458:	je     403846 <topic037_encode_all+0x466>
  40345e:	mov    0x40(%rbx),%r13
  403462:	mov    0x30(%rbx),%rdx
  403466:	xor    %r14d,%r14d
  403469:	xor    %r15d,%r15d
  40346c:	jmp    403551 <topic037_encode_all+0x171>
  403471:	nopl   0x0(%rax)
  403478:	incq   0x88(%rbx)
  40347f:	mov    $0x1,%r11d
  403485:	mov    0x48(%rbx),%rsi
  403489:	mov    %rax,%rdx
  40348c:	or     %rcx,%rdx
  40348f:	mov    $0xffffffff,%edi
  403494:	add    %r14,%rsi
  403497:	cmp    %rdi,%rdx
  40349a:	ja     403661 <topic037_encode_all+0x281>
  4034a0:	mov    %ecx,%edx
  4034a2:	shr    $0x10,%edx
  4034a5:	movzbl %dl,%edx
  4034a8:	movzbl %ch,%edi
  4034ab:	shl    $0x8,%rdx
  4034af:	or     %rdi,%rdx
  4034b2:	mov    %eax,%r9d
  4034b5:	movzbl %cl,%r10d
  4034b9:	shl    $0x8,%rdx
  4034bd:	shr    $0x18,%r9d
  4034c1:	or     %r10,%rdx
  4034c4:	mov    %eax,%r8d
  4034c7:	movzbl %r9b,%r9d
  4034cb:	shl    $0x8,%rdx
  4034cf:	shr    $0x10,%r8d
  4034d3:	or     %r9,%rdx
  4034d6:	movzbl %r8b,%r8d
  4034da:	shl    $0x8,%rdx
  4034de:	or     %r8,%rdx
  4034e1:	movzbl %ah,%edi
  4034e4:	shl    $0x8,%rdx
  4034e8:	or     %rdi,%rdx
  4034eb:	movzbl %al,%r8d
  4034ef:	shl    $0x8,%rdx
  4034f3:	or     %r8,%rdx
  4034f6:	movzbl %r11b,%edi
  4034fa:	shl    $0x8,%rdx
  4034fe:	or     %rdi,%rdx
  403501:	shr    $0x18,%ecx
  403504:	movl   $0x55373343,(%rsi)
  40350a:	mov    %rdx,0x4(%rsi)
  40350e:	mov    %cl,0xc(%rsi)
  403511:	lea    0xd(%rax,%r14,1),%r14
  403516:	inc    %r15
  403519:	add    %rax,0x70(%rbx)
  40351d:	mov    0x28(%rbx),%rax
  403521:	cmp    %rax,%r15
  403524:	jae    403810 <topic037_encode_all+0x430>
  40352a:	mov    0x30(%rbx),%rdx
  40352e:	mov    0x38(%rbx),%rax
  403532:	mov    %rdx,%r13
  403535:	imul   %r15,%r13
  403539:	movslq -0x38(%rbp),%rcx
  40353d:	sub    $0xd,%rax
  403541:	sub    %rcx,%rax
  403544:	add    0x40(%rbx),%r13
  403548:	cmp    %r14,%rax
  40354b:	jb     403661 <topic037_encode_all+0x281>
  403551:	mov    0x48(%rbx),%rax
  403555:	mov    -0x38(%rbp),%ecx
  403558:	lea    0xd(%rax,%r14,1),%r12
  40355d:	mov    %r12,%rsi
  403560:	mov    %r13,%rdi
  403563:	call   401270 <LZ4_compress_default@plt>
  403568:	test   %eax,%eax
  40356a:	jle    403661 <topic037_encode_all+0x281>
  403570:	mov    0x30(%rbx),%rcx
  403574:	cltq
  403576:	add    %rax,0x68(%rbx)
  40357a:	cmp    %rcx,%rax
  40357d:	jb     403478 <topic037_encode_all+0x98>
  403583:	mov    %rcx,%rdx
  403586:	mov    %r13,%rsi
  403589:	mov    %r12,%rdi
  40358c:	mov    %rcx,-0x40(%rbp)
  403590:	call   401190 <memcpy@plt>
  403595:	incq   0x90(%rbx)
  40359c:	mov    -0x40(%rbp),%rax
  4035a0:	mov    0x30(%rbx),%rcx
  4035a4:	xor    %r11d,%r11d
  4035a7:	jmp    403485 <topic037_encode_all+0xa5>
  4035ac:	nopl   0x0(%rax)
  4035b0:	mov    0x28(%rdi),%r13
  4035b4:	vpxor  %xmm0,%xmm0,%xmm0
  4035b8:	vmovdqu %xmm0,0x68(%rdi)
  4035bd:	vmovdqu %xmm0,0x78(%rdi)
  4035c2:	vmovdqu %xmm0,0x88(%rdi)
  4035ca:	xor    %eax,%eax
  4035cc:	test   %r13,%r13
  4035cf:	je     403833 <topic037_encode_all+0x453>
  4035d5:	mov    0x40(%rdi),%rsi
  4035d9:	mov    0x30(%rdi),%rax
  4035dd:	xor    %r13d,%r13d
  4035e0:	xor    %r14d,%r14d
  4035e3:	mov    $0xffffffff,%r12d
  4035e9:	nopl   0x0(%rax)
  4035f0:	mov    0x48(%rbx),%rdx
  4035f4:	add    %r13,%rdx
  4035f7:	cmp    %r12,%rax
  4035fa:	ja     403661 <topic037_encode_all+0x281>
  4035fc:	movl   $0x55373343,(%rdx)
  403602:	movb   $0x0,0x4(%rdx)
  403606:	mov    %eax,0x5(%rdx)
  403609:	mov    %eax,0x9(%rdx)
  40360c:	inc    %r14
  40360f:	mov    0x48(%rbx),%rax
  403613:	mov    0x30(%rbx),%rdx
  403617:	lea    0xd(%rax,%r13,1),%rdi
  40361c:	call   401190 <memcpy@plt>
  403621:	mov    0x30(%rbx),%rax
  403625:	mov    0x28(%rbx),%rdx
  403629:	add    %rax,0x68(%rbx)
  40362d:	add    %rax,0x70(%rbx)
  403631:	incq   0x90(%rbx)
  403638:	lea    0xd(%rax,%r13,1),%r13
  40363d:	cmp    %rdx,%r14
  403640:	jae    40382b <topic037_encode_all+0x44b>
  403646:	mov    0x38(%rbx),%rdi
  40364a:	mov    %rax,%rsi
  40364d:	imul   %r14,%rsi
  403651:	lea    -0xd(%rdi),%rdx
  403655:	sub    %rax,%rdx
  403658:	add    0x40(%rbx),%rsi
  40365c:	cmp    %r13,%rdx
  40365f:	jae    4035f0 <topic037_encode_all+0x210>
  403661:	mov    $0xffffffff,%r8d
  403667:	jmp    403412 <topic037_encode_all+0x32>
  40366c:	nopl   0x0(%rax)
  403670:	vpxor  %xmm0,%xmm0,%xmm0
  403674:	vmovdqu %xmm0,0x68(%rdi)
  403679:	vmovdqu %xmm0,0x78(%rdi)
  40367e:	vmovdqu %xmm0,0x88(%rdi)
  403686:	mov    0x30(%rdi),%rdi
  40368a:	call   4011f0 <ZSTD_compressBound@plt>
  40368f:	mov    %rax,%rdi
  403692:	mov    %rax,%r12
  403695:	call   401060 <ZSTD_isError@plt>
  40369a:	test   %eax,%eax
  40369c:	jne    403661 <topic037_encode_all+0x281>
  40369e:	mov    0x28(%rbx),%r14
  4036a2:	test   %r14,%r14
  4036a5:	je     403846 <topic037_encode_all+0x466>
  4036ab:	mov    0x40(%rbx),%r13
  4036af:	mov    0x30(%rbx),%r8
  4036b3:	xor    %r14d,%r14d
  4036b6:	xor    %r15d,%r15d
  4036b9:	jmp    403795 <topic037_encode_all+0x3b5>
  4036be:	xchg   %ax,%ax
  4036c0:	incq   0x88(%rbx)
  4036c7:	mov    $0x2,%r11d
  4036cd:	mov    0x48(%rbx),%rsi
  4036d1:	mov    %rcx,%rax
  4036d4:	or     %rdx,%rax
  4036d7:	mov    $0xffffffff,%edi
  4036dc:	add    %r14,%rsi
  4036df:	cmp    %rdi,%rax
  4036e2:	ja     403661 <topic037_encode_all+0x281>
  4036e8:	mov    %edx,%eax
  4036ea:	shr    $0x10,%eax
  4036ed:	movzbl %al,%eax
  4036f0:	movzbl %dh,%edi
  4036f3:	shl    $0x8,%rax
  4036f7:	or     %rdi,%rax
  4036fa:	movzbl %dl,%r10d
  4036fe:	mov    %ecx,%r9d
  403701:	shl    $0x8,%rax
  403705:	shr    $0x18,%r9d
  403709:	or     %r10,%rax
  40370c:	mov    %ecx,%r8d
  40370f:	movzbl %r9b,%r9d
  403713:	shl    $0x8,%rax
  403717:	shr    $0x10,%r8d
  40371b:	or     %r9,%rax
  40371e:	movzbl %r8b,%r8d
  403722:	shl    $0x8,%rax
  403726:	or     %r8,%rax
  403729:	movzbl %ch,%edi
  40372c:	shl    $0x8,%rax
  403730:	or     %rdi,%rax
  403733:	movzbl %cl,%r8d
  403737:	shl    $0x8,%rax
  40373b:	or     %r8,%rax
  40373e:	movzbl %r11b,%edi
  403742:	shl    $0x8,%rax
  403746:	or     %rdi,%rax
  403749:	shr    $0x18,%edx
  40374c:	movl   $0x55373343,(%rsi)
  403752:	mov    %rax,0x4(%rsi)
  403756:	mov    %dl,0xc(%rsi)
  403759:	inc    %r15
  40375c:	lea    0xd(%rcx,%r14,1),%r14
  403761:	mov    0x28(%rbx),%rax
  403765:	add    %rcx,0x70(%rbx)
  403769:	cmp    %rax,%r15
  40376c:	jae    403810 <topic037_encode_all+0x430>
  403772:	mov    0x30(%rbx),%r8
  403776:	mov    0x38(%rbx),%rax
  40377a:	mov    %r8,%r13
  40377d:	imul   %r15,%r13
  403781:	sub    $0xd,%rax
  403785:	sub    %r12,%rax
  403788:	add    0x40(%rbx),%r13
  40378c:	cmp    %r14,%rax
  40378f:	jb     403661 <topic037_encode_all+0x281>
  403795:	mov    0x48(%rbx),%rax
  403799:	mov    0x58(%rbx),%rdi
  40379d:	lea    0xd(%rax,%r14,1),%r10
  4037a2:	mov    $0x1,%r9d
  4037a8:	mov    %r13,%rcx
  4037ab:	mov    %r12,%rdx
  4037ae:	mov    %r10,%rsi
  4037b1:	mov    %r10,-0x40(%rbp)
  4037b5:	call   401180 <ZSTD_compressCCtx@plt>
  4037ba:	mov    %rax,%rdi
  4037bd:	mov    %rax,-0x38(%rbp)
  4037c1:	call   401060 <ZSTD_isError@plt>
  4037c6:	test   %eax,%eax
  4037c8:	jne    403661 <topic037_encode_all+0x281>
  4037ce:	mov    -0x38(%rbp),%rcx
  4037d2:	mov    0x30(%rbx),%rdx
  4037d6:	add    %rcx,0x68(%rbx)
  4037da:	cmp    %rdx,%rcx
  4037dd:	mov    -0x40(%rbp),%r10
  4037e1:	jb     4036c0 <topic037_encode_all+0x2e0>
  4037e7:	mov    %r13,%rsi
  4037ea:	mov    %r10,%rdi
  4037ed:	mov    %rdx,-0x38(%rbp)
  4037f1:	call   401190 <memcpy@plt>
  4037f6:	incq   0x90(%rbx)
  4037fd:	mov    -0x38(%rbp),%rcx
  403801:	mov    0x30(%rbx),%rdx
  403805:	xor    %r11d,%r11d
  403808:	jmp    4036cd <topic037_encode_all+0x2ed>
  40380d:	nopl   (%rax)
  403810:	lea    (%rax,%rax,2),%rdx
  403814:	lea    (%rax,%rdx,4),%rax
  403818:	mov    %rax,0x78(%rbx)
  40381c:	mov    %r14,0x80(%rbx)
  403823:	xor    %r8d,%r8d
  403826:	jmp    403412 <topic037_encode_all+0x32>
  40382b:	lea    (%rdx,%rdx,2),%rax
  40382f:	lea    (%rdx,%rax,4),%rax
  403833:	mov    %rax,0x78(%rbx)
  403837:	mov    %r13,0x80(%rbx)
  40383e:	xor    %r8d,%r8d
  403841:	jmp    403412 <topic037_encode_all+0x32>
  403846:	xor    %eax,%eax
  403848:	jmp    403818 <topic037_encode_all+0x438>

Disassembly of section .fini:
