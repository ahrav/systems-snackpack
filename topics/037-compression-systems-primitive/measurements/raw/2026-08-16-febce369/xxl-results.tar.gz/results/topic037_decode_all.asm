
/tmp/topic37-exact.M7ABv6/results.work/compression-probe-native:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403850 <topic037_decode_all>:
  403850:	push   %rbp
  403851:	mov    %rsp,%rbp
  403854:	push   %r15
  403856:	push   %r14
  403858:	push   %r13
  40385a:	push   %r12
  40385c:	push   %rbx
  40385d:	mov    %rdi,%rbx
  403860:	sub    $0x28,%rsp
  403864:	mov    0x28(%rdi),%r14
  403868:	test   %r14,%r14
  40386b:	je     403a08 <topic037_decode_all+0x1b8>
  403871:	movq   $0x0,-0x38(%rbp)
  403879:	mov    0x80(%rdi),%rax
  403880:	xor    %r13d,%r13d
  403883:	xor    %r14d,%r14d
  403886:	sub    %r14,%rax
  403889:	cmp    $0xc,%rax
  40388d:	jbe    403930 <topic037_decode_all+0xe0>
  403893:	mov    0x48(%rbx),%r12
  403897:	add    %r14,%r12
  40389a:	cmpl   $0x55373343,(%r12)
  4038a2:	jne    403930 <topic037_decode_all+0xe0>
  4038a8:	mov    0x5(%r12),%r8d
  4038ad:	mov    0x9(%r12),%r15d
  4038b2:	movzbl 0x4(%r12),%esi
  4038b8:	mov    %r8,%rdx
  4038bb:	mov    %r15,%rcx
  4038be:	cmp    %r15,0x30(%rbx)
  4038c2:	jne    403930 <topic037_decode_all+0xe0>
  4038c4:	sub    $0xd,%rax
  4038c8:	cmp    %r8,%rax
  4038cb:	jb     403930 <topic037_decode_all+0xe0>
  4038cd:	mov    0x20(%rbx),%rax
  4038d1:	sub    %r13,%rax
  4038d4:	cmp    %r15,%rax
  4038d7:	jb     403930 <topic037_decode_all+0xe0>
  4038d9:	mov    0x50(%rbx),%r10
  4038dd:	add    $0xd,%r12
  4038e1:	add    %r13,%r10
  4038e4:	test   %sil,%sil
  4038e7:	jne    403948 <topic037_decode_all+0xf8>
  4038e9:	cmp    %r15,%r8
  4038ec:	jne    403930 <topic037_decode_all+0xe0>
  4038ee:	mov    %r12,%rsi
  4038f1:	mov    %r10,%rdi
  4038f4:	mov    %r8,-0x40(%rbp)
  4038f8:	call   401190 <memcpy@plt>
  4038fd:	mov    -0x40(%rbp),%r8
  403901:	incq   -0x38(%rbp)
  403905:	lea    0xd(%r8,%r14,1),%r14
  40390a:	add    %r15,%r13
  40390d:	mov    -0x38(%rbp),%rax
  403911:	cmp    %rax,0x28(%rbx)
  403915:	jbe    403a0b <topic037_decode_all+0x1bb>
  40391b:	mov    0x80(%rbx),%rax
  403922:	cmp    %r14,%rax
  403925:	jae    403886 <topic037_decode_all+0x36>
  40392b:	nopl   0x0(%rax,%rax,1)
  403930:	mov    $0xffffffff,%eax
  403935:	add    $0x28,%rsp
  403939:	pop    %rbx
  40393a:	pop    %r12
  40393c:	pop    %r13
  40393e:	pop    %r14
  403940:	pop    %r15
  403942:	pop    %rbp
  403943:	ret
  403944:	nopl   0x0(%rax)
  403948:	cmp    $0x1,%sil
  40394c:	je     4039c8 <topic037_decode_all+0x178>
  40394e:	mov    %r10,-0x50(%rbp)
  403952:	cmp    $0x2,%sil
  403956:	jne    403930 <topic037_decode_all+0xe0>
  403958:	cmpl   $0x2,(%rbx)
  40395b:	jne    403930 <topic037_decode_all+0xe0>
  40395d:	mov    %r12,%rdi
  403960:	mov    %r8,%rsi
  403963:	mov    %r8,-0x48(%rbp)
  403967:	call   401250 <ZSTD_findFrameCompressedSize@plt>
  40396c:	mov    %rax,%rdi
  40396f:	mov    %rax,-0x40(%rbp)
  403973:	call   401060 <ZSTD_isError@plt>
  403978:	test   %eax,%eax
  40397a:	jne    403930 <topic037_decode_all+0xe0>
  40397c:	mov    -0x40(%rbp),%rdx
  403980:	mov    -0x48(%rbp),%r8
  403984:	cmp    %rdx,%r8
  403987:	jne    403930 <topic037_decode_all+0xe0>
  403989:	mov    0x60(%rbx),%rdi
  40398d:	mov    -0x50(%rbp),%rsi
  403991:	mov    %r12,%rcx
  403994:	mov    %r15,%rdx
  403997:	mov    %r8,-0x40(%rbp)
  40399b:	call   401050 <ZSTD_decompressDCtx@plt>
  4039a0:	mov    %rax,%rdi
  4039a3:	mov    %rax,%r12
  4039a6:	call   401060 <ZSTD_isError@plt>
  4039ab:	test   %eax,%eax
  4039ad:	jne    403930 <topic037_decode_all+0xe0>
  4039af:	cmp    %r12,%r15
  4039b2:	mov    -0x40(%rbp),%r8
  4039b6:	je     403901 <topic037_decode_all+0xb1>
  4039bc:	jmp    403930 <topic037_decode_all+0xe0>
  4039c1:	nopl   0x0(%rax)
  4039c8:	cmpl   $0x1,(%rbx)
  4039cb:	jne    403930 <topic037_decode_all+0xe0>
  4039d1:	mov    %r15d,%eax
  4039d4:	or     %r8d,%eax
  4039d7:	js     403930 <topic037_decode_all+0xe0>
  4039dd:	mov    %r10,%rsi
  4039e0:	mov    %r12,%rdi
  4039e3:	mov    %r8,-0x48(%rbp)
  4039e7:	mov    %r15d,-0x40(%rbp)
  4039eb:	call   4011e0 <LZ4_decompress_safe@plt>
  4039f0:	mov    -0x40(%rbp),%ecx
  4039f3:	mov    -0x48(%rbp),%r8
  4039f7:	cmp    %eax,%ecx
  4039f9:	je     403901 <topic037_decode_all+0xb1>
  4039ff:	jmp    403930 <topic037_decode_all+0xe0>
  403a04:	nopl   0x0(%rax)
  403a08:	xor    %r13d,%r13d
  403a0b:	cmp    %r14,0x80(%rbx)
  403a12:	jne    403930 <topic037_decode_all+0xe0>
  403a18:	xor    %eax,%eax
  403a1a:	cmp    %r13,0x20(%rbx)
  403a1e:	je     403935 <topic037_decode_all+0xe5>
  403a24:	jmp    403930 <topic037_decode_all+0xe0>

Disassembly of section .fini:
