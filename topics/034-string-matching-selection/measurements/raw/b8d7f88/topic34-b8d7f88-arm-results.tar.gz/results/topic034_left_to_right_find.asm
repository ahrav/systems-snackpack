
/tmp/topic34-b8d7f88-arm-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000001a260 <topic034_left_to_right_find>:
   1a260:	stp	x29, x30, [sp, #-80]!
   1a264:	stp	x26, x25, [sp, #16]
   1a268:	stp	x24, x23, [sp, #32]
   1a26c:	stp	x22, x21, [sp, #48]
   1a270:	stp	x20, x19, [sp, #64]
   1a274:	mov	x29, sp
   1a278:	cbz	x3, 1a290 <topic034_left_to_right_find+0x30>
   1a27c:	mov	x21, x3
   1a280:	subs	x24, x1, x3
   1a284:	b.cs	1a29c <topic034_left_to_right_find+0x3c>  // b.hs, b.nlast
   1a288:	mov	x20, xzr
   1a28c:	b	1a2f8 <topic034_left_to_right_find+0x98>
   1a290:	mov	x19, xzr
   1a294:	mov	w20, #0x1                   	// #1
   1a298:	b	1a2f8 <topic034_left_to_right_find+0x98>
   1a29c:	ldrb	w25, [x2]
   1a2a0:	mov	x22, x2
   1a2a4:	mov	x23, x0
   1a2a8:	mov	x19, xzr
   1a2ac:	add	x26, x24, #0x1
   1a2b0:	mov	w20, #0x1                   	// #1
   1a2b4:	b	1a2cc <topic034_left_to_right_find+0x6c>
   1a2b8:	nop
   1a2bc:	nop
   1a2c0:	add	x19, x19, #0x1
   1a2c4:	cmp	x26, x19
   1a2c8:	b.eq	1a2f0 <topic034_left_to_right_find+0x90>  // b.none
   1a2cc:	ldrb	w8, [x23, x19]
   1a2d0:	cmp	w8, w25
   1a2d4:	b.ne	1a2c0 <topic034_left_to_right_find+0x60>  // b.any
   1a2d8:	add	x0, x23, x19
   1a2dc:	mov	x1, x22
   1a2e0:	mov	x2, x21
   1a2e4:	bl	10270 <bcmp@plt>
   1a2e8:	cbnz	w0, 1a2c0 <topic034_left_to_right_find+0x60>
   1a2ec:	b	1a2f8 <topic034_left_to_right_find+0x98>
   1a2f0:	mov	x20, xzr
   1a2f4:	mov	x19, x24
   1a2f8:	mov	x0, x20
   1a2fc:	mov	x1, x19
   1a300:	ldp	x20, x19, [sp, #64]
   1a304:	ldp	x22, x21, [sp, #48]
   1a308:	ldp	x24, x23, [sp, #32]
   1a30c:	ldp	x26, x25, [sp, #16]
   1a310:	ldp	x29, x30, [sp], #80
   1a314:	ret

Disassembly of section .fini:
