
/tmp/topic34-b8d7f88-arm-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000001a100 <topic034_kmp_find>:
   1a100:	sub	sp, sp, #0x50
   1a104:	stp	x29, x30, [sp, #48]
   1a108:	stp	x20, x19, [sp, #64]
   1a10c:	add	x29, sp, #0x30
   1a110:	mov	x19, x1
   1a114:	mov	x20, x0
   1a118:	add	x8, sp, #0x8
   1a11c:	mov	x0, x2
   1a120:	mov	x1, x3
   1a124:	bl	196c0 <_ZN25string_matching_selection7KmpPlan3new17h4af38e68493d3bdbE>
   1a128:	ldr	x1, [sp, #40]
   1a12c:	cbz	x1, 1a1cc <topic034_kmp_find+0xcc>
   1a130:	cbz	x19, 1a214 <topic034_kmp_find+0x114>
   1a134:	add	x10, x20, x19
   1a138:	ldp	x9, x11, [sp, #24]
   1a13c:	ldr	x19, [sp, #16]
   1a140:	mov	x0, xzr
   1a144:	mov	x8, xzr
   1a148:	adrp	x2, 8d000 <GCC_except_table0+0x1b14c>
   1a14c:	add	x2, x2, #0x700
   1a150:	adrp	x12, 8d000 <GCC_except_table0+0x1b14c>
   1a154:	add	x12, x12, #0x718
   1a158:	b	1a16c <topic034_kmp_find+0x6c>
   1a15c:	nop
   1a160:	add	x8, x8, #0x1
   1a164:	cmp	x20, x10
   1a168:	b.eq	1a1e0 <topic034_kmp_find+0xe0>  // b.none
   1a16c:	ldrb	w13, [x20], #1
   1a170:	cbz	x0, 1a1a8 <topic034_kmp_find+0xa8>
   1a174:	nop
   1a178:	nop
   1a17c:	nop
   1a180:	cmp	x0, x1
   1a184:	b.cs	1a228 <topic034_kmp_find+0x128>  // b.hs, b.nlast
   1a188:	ldrb	w14, [x11, x0]
   1a18c:	cmp	w13, w14
   1a190:	b.eq	1a1a8 <topic034_kmp_find+0xa8>  // b.none
   1a194:	sub	x0, x0, #0x1
   1a198:	cmp	x0, x9
   1a19c:	b.cs	1a220 <topic034_kmp_find+0x120>  // b.hs, b.nlast
   1a1a0:	ldr	x0, [x19, x0, lsl #3]
   1a1a4:	cbnz	x0, 1a180 <topic034_kmp_find+0x80>
   1a1a8:	ldrb	w14, [x11, x0]
   1a1ac:	cmp	w13, w14
   1a1b0:	b.ne	1a160 <topic034_kmp_find+0x60>  // b.any
   1a1b4:	add	x0, x0, #0x1
   1a1b8:	cmp	x0, x1
   1a1bc:	b.ne	1a160 <topic034_kmp_find+0x60>  // b.any
   1a1c0:	sub	x8, x8, x1
   1a1c4:	add	x20, x8, #0x1
   1a1c8:	b	1a1d0 <topic034_kmp_find+0xd0>
   1a1cc:	mov	x20, xzr
   1a1d0:	mov	w19, #0x1                   	// #1
   1a1d4:	ldr	x8, [sp, #8]
   1a1d8:	cbnz	x8, 1a1ec <topic034_kmp_find+0xec>
   1a1dc:	b	1a1fc <topic034_kmp_find+0xfc>
   1a1e0:	mov	x19, xzr
   1a1e4:	ldr	x8, [sp, #8]
   1a1e8:	cbz	x8, 1a1fc <topic034_kmp_find+0xfc>
   1a1ec:	ldr	x0, [sp, #16]
   1a1f0:	lsl	x1, x8, #3
   1a1f4:	mov	w2, #0x8                   	// #8
   1a1f8:	bl	18890 <_RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
   1a1fc:	mov	x0, x19
   1a200:	mov	x1, x20
   1a204:	ldp	x20, x19, [sp, #64]
   1a208:	ldp	x29, x30, [sp, #48]
   1a20c:	add	sp, sp, #0x50
   1a210:	ret
   1a214:	ldr	x8, [sp, #8]
   1a218:	cbnz	x8, 1a1ec <topic034_kmp_find+0xec>
   1a21c:	b	1a1fc <topic034_kmp_find+0xfc>
   1a220:	mov	x1, x9
   1a224:	mov	x2, x12
   1a228:	bl	14a3c <_ZN4core9panicking18panic_bounds_check17hb2e5aecf3acac563E>
   1a22c:	brk	#0x1
   1a230:	ldr	x8, [sp, #8]
   1a234:	cbz	x8, 1a250 <topic034_kmp_find+0x150>
   1a238:	lsl	x1, x8, #3
   1a23c:	mov	x20, x0
   1a240:	mov	x0, x19
   1a244:	mov	w2, #0x8                   	// #8
   1a248:	bl	18890 <_RNvCsdBezzDwma51_7___rustc14___rust_dealloc>
   1a24c:	mov	x0, x20
   1a250:	bl	10430 <_Unwind_Resume@plt>

Disassembly of section .fini:
