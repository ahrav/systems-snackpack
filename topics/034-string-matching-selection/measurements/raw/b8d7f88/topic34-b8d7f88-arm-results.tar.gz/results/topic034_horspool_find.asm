
/tmp/topic34-b8d7f88-arm-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-littleaarch64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000019e80 <topic034_horspool_find>:
   19e80:	stp	x29, x30, [sp, #-64]!
   19e84:	stp	x28, x23, [sp, #16]
   19e88:	stp	x22, x21, [sp, #32]
   19e8c:	stp	x20, x19, [sp, #48]
   19e90:	mov	x29, sp
   19e94:	sub	sp, sp, #0x1, lsl #12
   19e98:	str	xzr, [sp], #-16
   19e9c:	rdvl	x9, #1
   19ea0:	subs	x19, x3, #0x1
   19ea4:	mov	x21, x3
   19ea8:	mov	x23, x2
   19eac:	mov	x20, x1
   19eb0:	mov	x22, x0
   19eb4:	csinc	x8, x3, xzr, hi	// hi = pmore
   19eb8:	lsr	x9, x9, #4
   19ebc:	cmp	x9, #0x40
   19ec0:	b.ls	19ecc <topic034_horspool_find+0x4c>  // b.plast
   19ec4:	mov	x9, xzr
   19ec8:	b	19f04 <topic034_horspool_find+0x84>
   19ecc:	cntw	x10
   19ed0:	add	x12, sp, #0x810
   19ed4:	sub	w9, w10, #0x1
   19ed8:	mov	z0.d, x8
   19edc:	rdvl	x13, #2
   19ee0:	and	x11, x9, #0x100
   19ee4:	eor	x9, x11, #0x100
   19ee8:	mov	x14, x9
   19eec:	str	z0, [x12]
   19ef0:	str	z0, [x12, #1, mul vl]
   19ef4:	subs	x14, x14, x10
   19ef8:	add	x12, x12, x13
   19efc:	b.ne	19eec <topic034_horspool_find+0x6c>  // b.any
   19f00:	cbz	x11, 19f1c <topic034_horspool_find+0x9c>
   19f04:	lsl	x9, x9, #3
   19f08:	add	x10, sp, #0x810
   19f0c:	str	x8, [x10, x9]
   19f10:	add	x9, x9, #0x8
   19f14:	cmp	x9, #0x800
   19f18:	b.ne	19f0c <topic034_horspool_find+0x8c>  // b.any
   19f1c:	cmp	x21, #0x2
   19f20:	b.cc	19f38 <topic034_horspool_find+0xb8>  // b.lo, b.ul, b.last
   19f24:	subs	x10, x21, #0x2
   19f28:	b.ne	19f5c <topic034_horspool_find+0xdc>  // b.any
   19f2c:	mov	x8, xzr
   19f30:	mov	x9, x23
   19f34:	b	19fa8 <topic034_horspool_find+0x128>
   19f38:	mov	x8, sp
   19f3c:	add	x1, sp, #0x810
   19f40:	mov	w2, #0x800                 	// #2048
   19f44:	add	x0, x8, #0x10
   19f48:	bl	10040 <memcpy@plt>
   19f4c:	mov	x19, xzr
   19f50:	cbnz	x21, 1a038 <topic034_horspool_find+0x1b8>
   19f54:	mov	w0, #0x1                   	// #1
   19f58:	b	1a0b4 <topic034_horspool_find+0x234>
   19f5c:	and	x8, x19, #0xfffffffffffffffe
   19f60:	add	x11, x23, #0x1
   19f64:	add	x12, sp, #0x810
   19f68:	add	x9, x23, x8
   19f6c:	mov	x13, x8
   19f70:	nop
   19f74:	nop
   19f78:	nop
   19f7c:	nop
   19f80:	ldurb	w14, [x11, #-1]
   19f84:	ldrb	w15, [x11], #2
   19f88:	add	x16, x10, #0x1
   19f8c:	subs	x13, x13, #0x2
   19f90:	str	x16, [x12, x14, lsl #3]
   19f94:	str	x10, [x12, x15, lsl #3]
   19f98:	sub	x10, x10, #0x2
   19f9c:	b.ne	19f80 <topic034_horspool_find+0x100>  // b.any
   19fa0:	cmp	x19, x8
   19fa4:	b.eq	1a024 <topic034_horspool_find+0x1a4>  // b.none
   19fa8:	add	x10, x21, x23
   19fac:	sub	x11, x10, #0x2
   19fb0:	sub	w10, w9, w10
   19fb4:	tbnz	w10, #0, 19fdc <topic034_horspool_find+0x15c>
   19fb8:	mov	x10, x9
   19fbc:	sub	x13, x19, x8
   19fc0:	orr	x8, x8, #0x1
   19fc4:	add	x14, sp, #0x810
   19fc8:	ldrb	w12, [x10], #1
   19fcc:	str	x13, [x14, x12, lsl #3]
   19fd0:	cmp	x11, x9
   19fd4:	b.ne	19fe8 <topic034_horspool_find+0x168>  // b.any
   19fd8:	b	1a024 <topic034_horspool_find+0x1a4>
   19fdc:	mov	x10, x9
   19fe0:	cmp	x11, x9
   19fe4:	b.eq	1a024 <topic034_horspool_find+0x1a4>  // b.none
   19fe8:	sub	x8, x21, x8
   19fec:	add	x9, x23, x19
   19ff0:	add	x11, sp, #0x810
   19ff4:	sub	x8, x8, #0x2
   19ff8:	nop
   19ffc:	nop
   1a000:	ldrb	w12, [x10]
   1a004:	add	x13, x8, #0x1
   1a008:	str	x13, [x11, x12, lsl #3]
   1a00c:	ldrb	w12, [x10, #1]
   1a010:	add	x10, x10, #0x2
   1a014:	cmp	x10, x9
   1a018:	str	x8, [x11, x12, lsl #3]
   1a01c:	sub	x8, x8, #0x2
   1a020:	b.ne	1a000 <topic034_horspool_find+0x180>  // b.any
   1a024:	mov	x8, sp
   1a028:	add	x1, sp, #0x810
   1a02c:	mov	w2, #0x800                 	// #2048
   1a030:	add	x0, x8, #0x10
   1a034:	bl	10040 <memcpy@plt>
   1a038:	mov	x0, xzr
   1a03c:	cmp	x21, x20
   1a040:	b.hi	1a0b4 <topic034_horspool_find+0x234>  // b.pmore
   1a044:	cmp	x19, x20
   1a048:	b.cs	1a0b4 <topic034_horspool_find+0x234>  // b.hs, b.nlast
   1a04c:	mov	x8, sp
   1a050:	sub	x9, x23, #0x1
   1a054:	add	x8, x8, #0x10
   1a058:	sub	x10, x19, x21
   1a05c:	mov	x0, x19
   1a060:	mov	x11, x21
   1a064:	cbz	x11, 1a0a8 <topic034_horspool_find+0x228>
   1a068:	cmp	x0, x20
   1a06c:	b.cs	1a0d4 <topic034_horspool_find+0x254>  // b.hs, b.nlast
   1a070:	ldrb	w12, [x9, x11]
   1a074:	ldrb	w13, [x22, x0]
   1a078:	sub	x11, x11, #0x1
   1a07c:	sub	x0, x0, #0x1
   1a080:	cmp	w12, w13
   1a084:	b.eq	1a064 <topic034_horspool_find+0x1e4>  // b.none
   1a088:	ldrb	w10, [x22, x19]
   1a08c:	mov	x0, xzr
   1a090:	ldr	x10, [x8, x10, lsl #3]
   1a094:	adds	x10, x19, x10
   1a098:	csinv	x19, x10, xzr, cc	// cc = lo, ul, last
   1a09c:	cmp	x19, x20
   1a0a0:	b.cc	1a058 <topic034_horspool_find+0x1d8>  // b.lo, b.ul, b.last
   1a0a4:	b	1a0b4 <topic034_horspool_find+0x234>
   1a0a8:	add	x19, x10, #0x1
   1a0ac:	mov	w0, #0x1                   	// #1
   1a0b0:	b	1a0b4 <topic034_horspool_find+0x234>
   1a0b4:	mov	x1, x19
   1a0b8:	add	sp, sp, #0x1, lsl #12
   1a0bc:	add	sp, sp, #0x10
   1a0c0:	ldp	x20, x19, [sp, #48]
   1a0c4:	ldp	x22, x21, [sp, #32]
   1a0c8:	ldp	x28, x23, [sp, #16]
   1a0cc:	ldp	x29, x30, [sp], #64
   1a0d0:	ret
   1a0d4:	adrp	x2, 8d000 <GCC_except_table0+0x1b14c>
   1a0d8:	add	x2, x2, #0x6b8
   1a0dc:	mov	x1, x20
   1a0e0:	bl	14a3c <_ZN4core9panicking18panic_bounds_check17hb2e5aecf3acac563E>

Disassembly of section .fini:
