
/tmp/topic34-b8d7f88-xxl-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000001e620 <topic034_left_to_right_find>:
   1e620:	mov    $0x1,%eax
   1e625:	test   %rcx,%rcx
   1e628:	je     1e641 <topic034_left_to_right_find+0x21>
   1e62a:	push   %rbp
   1e62b:	push   %r15
   1e62d:	push   %r14
   1e62f:	push   %r13
   1e631:	push   %r12
   1e633:	push   %rbx
   1e634:	push   %rax
   1e635:	mov    %rcx,%r15
   1e638:	sub    %rcx,%rsi
   1e63b:	jae    1e644 <topic034_left_to_right_find+0x24>
   1e63d:	xor    %eax,%eax
   1e63f:	jmp    1e694 <topic034_left_to_right_find+0x74>
   1e641:	xor    %edx,%edx
   1e643:	ret
   1e644:	mov    %rdx,%r12
   1e647:	mov    %rdi,%r13
   1e64a:	movzbl (%rdx),%ebp
   1e64d:	mov    %rsi,(%rsp)
   1e651:	lea    0x1(%rsi),%r14
   1e655:	xor    %ebx,%ebx
   1e657:	jmp    1e668 <topic034_left_to_right_find+0x48>
   1e659:	nopl   0x0(%rax)
   1e660:	inc    %rbx
   1e663:	cmp    %rbx,%r14
   1e666:	je     1e68e <topic034_left_to_right_find+0x6e>
   1e668:	cmp    %bpl,0x0(%r13,%rbx,1)
   1e66d:	jne    1e660 <topic034_left_to_right_find+0x40>
   1e66f:	lea    0x0(%r13,%rbx,1),%rdi
   1e674:	mov    %r12,%rsi
   1e677:	mov    %r15,%rdx
   1e67a:	call   *0x49078(%rip)        # 676f8 <bcmp@GLIBC_2.2.5>
   1e680:	test   %eax,%eax
   1e682:	jne    1e660 <topic034_left_to_right_find+0x40>
   1e684:	mov    %rbx,%rdx
   1e687:	mov    $0x1,%eax
   1e68c:	jmp    1e694 <topic034_left_to_right_find+0x74>
   1e68e:	xor    %eax,%eax
   1e690:	mov    (%rsp),%rdx
   1e694:	add    $0x8,%rsp
   1e698:	pop    %rbx
   1e699:	pop    %r12
   1e69b:	pop    %r13
   1e69d:	pop    %r14
   1e69f:	pop    %r15
   1e6a1:	pop    %rbp
   1e6a2:	ret

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
