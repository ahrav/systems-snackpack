
/tmp/topic34-b8d7f88-xxl-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000001e4b0 <topic034_kmp_find>:
   1e4b0:	push   %r15
   1e4b2:	push   %r14
   1e4b4:	push   %r13
   1e4b6:	push   %r12
   1e4b8:	push   %rbx
   1e4b9:	sub    $0x30,%rsp
   1e4bd:	mov    %rsi,%r12
   1e4c0:	mov    %rdi,%r13
   1e4c3:	lea    0x8(%rsp),%rdi
   1e4c8:	mov    %rdx,%rsi
   1e4cb:	mov    %rcx,%rdx
   1e4ce:	call   *0x491fc(%rip)        # 676d0 <_DYNAMIC+0x268>
   1e4d4:	mov    0x28(%rsp),%rsi
   1e4d9:	mov    $0x1,%ebx
   1e4de:	test   %rsi,%rsi
   1e4e1:	je     1e594 <topic034_kmp_find+0xe4>
   1e4e7:	test   %r12,%r12
   1e4ea:	je     1e5d7 <topic034_kmp_find+0x127>
   1e4f0:	add    %r13,%r12
   1e4f3:	mov    0x20(%rsp),%rcx
   1e4f8:	mov    0x10(%rsp),%r14
   1e4fd:	mov    0x18(%rsp),%rax
   1e502:	lea    0x46b17(%rip),%rdx        # 65020 <anon.8abce0be2c8421fc697a7a1cb848f769.0.llvm.9761468739924659865+0xa8>
   1e509:	lea    0x46b28(%rip),%r8        # 65038 <anon.8abce0be2c8421fc697a7a1cb848f769.0.llvm.9761468739924659865+0xc0>
   1e510:	xor    %edi,%edi
   1e512:	xor    %r15d,%r15d
   1e515:	movzbl 0x0(%r13),%r9d
   1e51a:	test   %rdi,%rdi
   1e51d:	jne    1e550 <topic034_kmp_find+0xa0>
   1e51f:	jmp    1e572 <topic034_kmp_find+0xc2>
   1e521:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   1e530:	inc    %r13
   1e533:	inc    %r15
   1e536:	cmp    %r12,%r13
   1e539:	je     1e5a3 <topic034_kmp_find+0xf3>
   1e53b:	movzbl 0x0(%r13),%r9d
   1e540:	test   %rdi,%rdi
   1e543:	je     1e572 <topic034_kmp_find+0xc2>
   1e545:	data16 cs nopw 0x0(%rax,%rax,1)
   1e550:	cmp    %rsi,%rdi
   1e553:	jae    1e5ee <topic034_kmp_find+0x13e>
   1e559:	cmp    (%rcx,%rdi,1),%r9b
   1e55d:	je     1e574 <topic034_kmp_find+0xc4>
   1e55f:	lea    -0x1(%rdi),%r10
   1e563:	cmp    %rax,%r10
   1e566:	jae    1e5e5 <topic034_kmp_find+0x135>
   1e568:	mov    -0x8(%r14,%rdi,8),%rdi
   1e56d:	test   %rdi,%rdi
   1e570:	jne    1e550 <topic034_kmp_find+0xa0>
   1e572:	xor    %edi,%edi
   1e574:	cmp    (%rcx,%rdi,1),%r9b
   1e578:	jne    1e530 <topic034_kmp_find+0x80>
   1e57a:	inc    %rdi
   1e57d:	cmp    %rsi,%rdi
   1e580:	jne    1e530 <topic034_kmp_find+0x80>
   1e582:	sub    %rsi,%r15
   1e585:	inc    %r15
   1e588:	mov    0x8(%rsp),%rsi
   1e58d:	test   %rsi,%rsi
   1e590:	jne    1e5af <topic034_kmp_find+0xff>
   1e592:	jmp    1e5c3 <topic034_kmp_find+0x113>
   1e594:	xor    %r15d,%r15d
   1e597:	mov    0x8(%rsp),%rsi
   1e59c:	test   %rsi,%rsi
   1e59f:	jne    1e5af <topic034_kmp_find+0xff>
   1e5a1:	jmp    1e5c3 <topic034_kmp_find+0x113>
   1e5a3:	xor    %ebx,%ebx
   1e5a5:	mov    0x8(%rsp),%rsi
   1e5aa:	test   %rsi,%rsi
   1e5ad:	je     1e5c3 <topic034_kmp_find+0x113>
   1e5af:	mov    0x10(%rsp),%rdi
   1e5b4:	shl    $0x3,%rsi
   1e5b8:	mov    $0x8,%edx
   1e5bd:	call   *0x4911d(%rip)        # 676e0 <_DYNAMIC+0x278>
   1e5c3:	mov    %rbx,%rax
   1e5c6:	mov    %r15,%rdx
   1e5c9:	add    $0x30,%rsp
   1e5cd:	pop    %rbx
   1e5ce:	pop    %r12
   1e5d0:	pop    %r13
   1e5d2:	pop    %r14
   1e5d4:	pop    %r15
   1e5d6:	ret
   1e5d7:	xor    %ebx,%ebx
   1e5d9:	mov    0x8(%rsp),%rsi
   1e5de:	test   %rsi,%rsi
   1e5e1:	jne    1e5af <topic034_kmp_find+0xff>
   1e5e3:	jmp    1e5c3 <topic034_kmp_find+0x113>
   1e5e5:	mov    %r10,%rdi
   1e5e8:	mov    %rax,%rsi
   1e5eb:	mov    %r8,%rdx
   1e5ee:	call   *0x49244(%rip)        # 67838 <_DYNAMIC+0x3d0>
   1e5f4:	ud2
   1e5f6:	mov    %rax,%rbx
   1e5f9:	mov    0x8(%rsp),%rsi
   1e5fe:	test   %rsi,%rsi
   1e601:	je     1e615 <topic034_kmp_find+0x165>
   1e603:	shl    $0x3,%rsi
   1e607:	mov    $0x8,%edx
   1e60c:	mov    %r14,%rdi
   1e60f:	call   *0x490cb(%rip)        # 676e0 <_DYNAMIC+0x278>
   1e615:	mov    %rbx,%rdi
   1e618:	call   63f20 <_Unwind_Resume@plt>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
