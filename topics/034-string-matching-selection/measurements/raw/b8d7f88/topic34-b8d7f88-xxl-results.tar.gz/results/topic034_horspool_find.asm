
/tmp/topic34-b8d7f88-xxl-019ffb52/results.work/native-target/release/string-match-probe:     file format elf64-x86-64


Disassembly of section .text:

000000000001e000 <topic034_horspool_find>:
   1e000:	push   %r15
   1e002:	push   %r14
   1e004:	push   %r13
   1e006:	push   %r12
   1e008:	push   %rbx
   1e009:	sub    $0x1000,%rsp
   1e010:	movq   $0x0,(%rsp)
   1e018:	sub    $0x10,%rsp
   1e01c:	mov    %rcx,%r14
   1e01f:	mov    %rdx,%r15
   1e022:	mov    %rsi,%rbx
   1e025:	mov    %rdi,%r12
   1e028:	cmp    $0x2,%rcx
   1e02c:	mov    $0x1,%eax
   1e031:	cmovae %rcx,%rax
   1e035:	vpbroadcastq %rax,%ymm0
   1e03b:	vmovdqu %ymm0,(%rsp)
   1e040:	vmovdqu %ymm0,0x20(%rsp)
   1e046:	vmovdqu %ymm0,0x40(%rsp)
   1e04c:	vmovdqu %ymm0,0x60(%rsp)
   1e052:	vmovdqu %ymm0,0x80(%rsp)
   1e05b:	vmovdqu %ymm0,0xa0(%rsp)
   1e064:	vmovdqu %ymm0,0xc0(%rsp)
   1e06d:	vmovdqu %ymm0,0xe0(%rsp)
   1e076:	vmovdqu %ymm0,0x100(%rsp)
   1e07f:	vmovdqu %ymm0,0x120(%rsp)
   1e088:	vmovdqu %ymm0,0x140(%rsp)
   1e091:	vmovdqu %ymm0,0x160(%rsp)
   1e09a:	vmovdqu %ymm0,0x180(%rsp)
   1e0a3:	vmovdqu %ymm0,0x1a0(%rsp)
   1e0ac:	vmovdqu %ymm0,0x1c0(%rsp)
   1e0b5:	vmovdqu %ymm0,0x1e0(%rsp)
   1e0be:	vmovdqu %ymm0,0x200(%rsp)
   1e0c7:	vmovdqu %ymm0,0x220(%rsp)
   1e0d0:	vmovdqu %ymm0,0x240(%rsp)
   1e0d9:	vmovdqu %ymm0,0x260(%rsp)
   1e0e2:	vmovdqu %ymm0,0x280(%rsp)
   1e0eb:	vmovdqu %ymm0,0x2a0(%rsp)
   1e0f4:	vmovdqu %ymm0,0x2c0(%rsp)
   1e0fd:	vmovdqu %ymm0,0x2e0(%rsp)
   1e106:	vmovdqu %ymm0,0x300(%rsp)
   1e10f:	vmovdqu %ymm0,0x320(%rsp)
   1e118:	vmovdqu %ymm0,0x340(%rsp)
   1e121:	vmovdqu %ymm0,0x360(%rsp)
   1e12a:	vmovdqu %ymm0,0x380(%rsp)
   1e133:	vmovdqu %ymm0,0x3a0(%rsp)
   1e13c:	vmovdqu %ymm0,0x3c0(%rsp)
   1e145:	vmovdqu %ymm0,0x3e0(%rsp)
   1e14e:	vmovdqu %ymm0,0x400(%rsp)
   1e157:	vmovdqu %ymm0,0x420(%rsp)
   1e160:	vmovdqu %ymm0,0x440(%rsp)
   1e169:	vmovdqu %ymm0,0x460(%rsp)
   1e172:	vmovdqu %ymm0,0x480(%rsp)
   1e17b:	vmovdqu %ymm0,0x4a0(%rsp)
   1e184:	vmovdqu %ymm0,0x4c0(%rsp)
   1e18d:	vmovdqu %ymm0,0x4e0(%rsp)
   1e196:	vmovdqu %ymm0,0x500(%rsp)
   1e19f:	vmovdqu %ymm0,0x520(%rsp)
   1e1a8:	vmovdqu %ymm0,0x540(%rsp)
   1e1b1:	vmovdqu %ymm0,0x560(%rsp)
   1e1ba:	vmovdqu %ymm0,0x580(%rsp)
   1e1c3:	vmovdqu %ymm0,0x5a0(%rsp)
   1e1cc:	vmovdqu %ymm0,0x5c0(%rsp)
   1e1d5:	vmovdqu %ymm0,0x5e0(%rsp)
   1e1de:	vmovdqu %ymm0,0x600(%rsp)
   1e1e7:	vmovdqu %ymm0,0x620(%rsp)
   1e1f0:	vmovdqu %ymm0,0x640(%rsp)
   1e1f9:	vmovdqu %ymm0,0x660(%rsp)
   1e202:	vmovdqu %ymm0,0x680(%rsp)
   1e20b:	vmovdqu %ymm0,0x6a0(%rsp)
   1e214:	vmovdqu %ymm0,0x6c0(%rsp)
   1e21d:	vmovdqu %ymm0,0x6e0(%rsp)
   1e226:	vmovdqu %ymm0,0x700(%rsp)
   1e22f:	vmovdqu %ymm0,0x720(%rsp)
   1e238:	vmovdqu %ymm0,0x740(%rsp)
   1e241:	vmovdqu %ymm0,0x760(%rsp)
   1e24a:	vmovdqu %ymm0,0x780(%rsp)
   1e253:	vmovdqu %ymm0,0x7a0(%rsp)
   1e25c:	vmovdqu %ymm0,0x7c0(%rsp)
   1e265:	vmovdqu %ymm0,0x7e0(%rsp)
   1e26e:	jb     1e284 <topic034_horspool_find+0x284>
   1e270:	lea    -0x1(%r14),%r13
   1e274:	cmp    $0x5,%r14
   1e278:	jae    1e2ae <topic034_horspool_find+0x2ae>
   1e27a:	xor    %eax,%eax
   1e27c:	mov    %r15,%rcx
   1e27f:	jmp    1e3cd <topic034_horspool_find+0x3cd>
   1e284:	lea    0x810(%rsp),%rdi
   1e28c:	mov    %rsp,%rsi
   1e28f:	mov    $0x800,%edx
   1e294:	vzeroupper
   1e297:	call   *0x49483(%rip)        # 67720 <memcpy@GLIBC_2.14>
   1e29d:	xor    %r13d,%r13d
   1e2a0:	test   %r14,%r14
   1e2a3:	jne    1e40b <topic034_horspool_find+0x40b>
   1e2a9:	jmp    1e480 <topic034_horspool_find+0x480>
   1e2ae:	vpbroadcastq %r13,%ymm0
   1e2b4:	cmp    $0x11,%r14
   1e2b8:	jae    1e2c1 <topic034_horspool_find+0x2c1>
   1e2ba:	xor    %eax,%eax
   1e2bc:	jmp    1e373 <topic034_horspool_find+0x373>
   1e2c1:	mov    %r13,%rax
   1e2c4:	and    $0xfffffffffffffff0,%rax
   1e2c8:	vmovdqa -0x14010(%rip),%ymm1        # a2c0 <GCC_except_table386+0x182c>
   1e2d0:	xor    %ecx,%ecx
   1e2d2:	vpbroadcastq -0x157b3(%rip),%ymm2        # 8b28 <GCC_except_table386+0x94>
   1e2db:	vpbroadcastq -0x15824(%rip),%ymm3        # 8ac0 <GCC_except_table386+0x2c>
   1e2e4:	vpbroadcastq -0x15825(%rip),%ymm4        # 8ac8 <GCC_except_table386+0x34>
   1e2ed:	mov    %rsp,%rdx
   1e2f0:	vpbroadcastq -0x157c9(%rip),%ymm5        # 8b30 <GCC_except_table386+0x9c>
   1e2f9:	nopl   0x0(%rax)
   1e300:	vpmovzxbd (%r15,%rcx,1),%xmm6
   1e306:	vpmovzxbd 0x4(%r15,%rcx,1),%xmm7
   1e30d:	vpmovzxbd 0x8(%r15,%rcx,1),%xmm8
   1e314:	vpmovzxbd 0xc(%r15,%rcx,1),%xmm9
   1e31b:	vpsubq %ymm1,%ymm0,%ymm10
   1e31f:	vpsubq %ymm2,%ymm10,%ymm11
   1e323:	vpsubq %ymm3,%ymm10,%ymm12
   1e327:	vpsubq %ymm4,%ymm10,%ymm13
   1e32b:	kxnorw %k0,%k0,%k1
   1e32f:	vpscatterdq %ymm10,(%rdx,%xmm6,8){%k1}
   1e336:	kxnorw %k0,%k0,%k1
   1e33a:	vpscatterdq %ymm11,(%rdx,%xmm7,8){%k1}
   1e341:	kxnorw %k0,%k0,%k1
   1e345:	vpscatterdq %ymm12,(%rdx,%xmm8,8){%k1}
   1e34c:	kxnorw %k0,%k0,%k1
   1e350:	vpscatterdq %ymm13,(%rdx,%xmm9,8){%k1}
   1e357:	add    $0x10,%rcx
   1e35b:	vpaddq %ymm5,%ymm1,%ymm1
   1e35f:	cmp    %rcx,%rax
   1e362:	jne    1e300 <topic034_horspool_find+0x300>
   1e364:	cmp    %rax,%r13
   1e367:	je     1e3f2 <topic034_horspool_find+0x3f2>
   1e36d:	test   $0xc,%r13b
   1e371:	je     1e3c9 <topic034_horspool_find+0x3c9>
   1e373:	mov    %rax,%rdx
   1e376:	mov    %r13,%rax
   1e379:	and    $0xfffffffffffffffc,%rax
   1e37d:	lea    (%r15,%rax,1),%rcx
   1e381:	vpbroadcastq %rdx,%ymm1
   1e387:	vpor   -0x140cf(%rip),%ymm1,%ymm1        # a2c0 <GCC_except_table386+0x182c>
   1e38f:	mov    %rsp,%rsi
   1e392:	vpbroadcastq -0x15873(%rip),%ymm2        # 8b28 <GCC_except_table386+0x94>
   1e39b:	nopl   0x0(%rax,%rax,1)
   1e3a0:	vpmovzxbd (%r15,%rdx,1),%xmm3
   1e3a6:	vpsubq %ymm1,%ymm0,%ymm4
   1e3aa:	kxnorw %k0,%k0,%k1
   1e3ae:	vpscatterdq %ymm4,(%rsi,%xmm3,8){%k1}
   1e3b5:	add    $0x4,%rdx
   1e3b9:	vpaddq %ymm2,%ymm1,%ymm1
   1e3bd:	cmp    %rdx,%rax
   1e3c0:	jne    1e3a0 <topic034_horspool_find+0x3a0>
   1e3c2:	cmp    %rax,%r13
   1e3c5:	jne    1e3cd <topic034_horspool_find+0x3cd>
   1e3c7:	jmp    1e3f2 <topic034_horspool_find+0x3f2>
   1e3c9:	lea    (%r15,%rax,1),%rcx
   1e3cd:	lea    -0x1(%r15,%r14,1),%rdx
   1e3d2:	not    %rax
   1e3d5:	add    %r14,%rax
   1e3d8:	nopl   0x0(%rax,%rax,1)
   1e3e0:	movzbl (%rcx),%esi
   1e3e3:	inc    %rcx
   1e3e6:	mov    %rax,(%rsp,%rsi,8)
   1e3ea:	dec    %rax
   1e3ed:	cmp    %rdx,%rcx
   1e3f0:	jne    1e3e0 <topic034_horspool_find+0x3e0>
   1e3f2:	lea    0x810(%rsp),%rdi
   1e3fa:	mov    %rsp,%rsi
   1e3fd:	mov    $0x800,%edx
   1e402:	vzeroupper
   1e405:	call   *0x49315(%rip)        # 67720 <memcpy@GLIBC_2.14>
   1e40b:	cmp    %rbx,%r14
   1e40e:	setbe  %al
   1e411:	cmp    %rbx,%r13
   1e414:	setb   %cl
   1e417:	and    %al,%cl
   1e419:	cmp    $0x1,%cl
   1e41c:	jne    1e476 <topic034_horspool_find+0x476>
   1e41e:	mov    $0xffffffffffffffff,%rcx
   1e425:	xor    %eax,%eax
   1e427:	mov    %r13,%rdx
   1e42a:	sub    %r14,%rdx
   1e42d:	mov    %r13,%rdi
   1e430:	mov    %r14,%r8
   1e433:	mov    %r14,%rsi
   1e436:	cs nopw 0x0(%rax,%rax,1)
   1e440:	sub    $0x1,%rsi
   1e444:	jb     1e47a <topic034_horspool_find+0x47a>
   1e446:	cmp    %rbx,%rdi
   1e449:	jae    1e499 <topic034_horspool_find+0x499>
   1e44b:	movzbl -0x1(%r15,%r8,1),%r9d
   1e451:	mov    %rsi,%r8
   1e454:	cmp    (%r12,%rdi,1),%r9b
   1e458:	lea    -0x1(%rdi),%rdi
   1e45c:	je     1e440 <topic034_horspool_find+0x440>
   1e45e:	movzbl (%r12,%r13,1),%edx
   1e463:	add    0x810(%rsp,%rdx,8),%r13
   1e46b:	cmovb  %rcx,%r13
   1e46f:	cmp    %rbx,%r13
   1e472:	jb     1e427 <topic034_horspool_find+0x427>
   1e474:	jmp    1e485 <topic034_horspool_find+0x485>
   1e476:	xor    %eax,%eax
   1e478:	jmp    1e485 <topic034_horspool_find+0x485>
   1e47a:	inc    %rdx
   1e47d:	mov    %rdx,%r13
   1e480:	mov    $0x1,%eax
   1e485:	mov    %r13,%rdx
   1e488:	add    $0x1010,%rsp
   1e48f:	pop    %rbx
   1e490:	pop    %r12
   1e492:	pop    %r13
   1e494:	pop    %r14
   1e496:	pop    %r15
   1e498:	ret
   1e499:	lea    0x46b38(%rip),%rdx        # 64fd8 <anon.8abce0be2c8421fc697a7a1cb848f769.0.llvm.9761468739924659865+0x60>
   1e4a0:	mov    %rbx,%rsi
   1e4a3:	call   *0x4938f(%rip)        # 67838 <_DYNAMIC+0x3d0>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
