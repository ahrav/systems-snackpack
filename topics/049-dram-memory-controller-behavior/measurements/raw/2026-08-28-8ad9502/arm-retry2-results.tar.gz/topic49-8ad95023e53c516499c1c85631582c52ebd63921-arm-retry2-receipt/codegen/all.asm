
/tmp/topic49-8ad95023e53c516499c1c85631582c52ebd63921-arm-retry2-receipt/binary/path-a/dram_bench:     file format elf64-littleaarch64


Disassembly of section .init:

0000000000410000 <_init>:
  410000:	paciasp
  410004:	stp	x29, x30, [sp, #-16]!
  410008:	mov	x29, sp
  41000c:	bl	411d08 <call_weak_fn>
  410010:	ldp	x29, x30, [sp], #16
  410014:	autiasp
  410018:	ret

Disassembly of section .plt:

0000000000410020 <.plt>:
  410020:	stp	x16, x30, [sp, #-16]!
  410024:	adrp	x16, 43f000 <__FRAME_END__+0x1d51c>
  410028:	ldr	x17, [x16, #4088]
  41002c:	add	x16, x16, #0xff8
  410030:	br	x17
  410034:	nop
  410038:	nop
  41003c:	nop

0000000000410040 <exit@plt>:
  410040:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410044:	ldr	x17, [x16]
  410048:	add	x16, x16, #0x0
  41004c:	br	x17

0000000000410050 <__libc_start_main@plt>:
  410050:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410054:	ldr	x17, [x16, #8]
  410058:	add	x16, x16, #0x8
  41005c:	br	x17

0000000000410060 <pthread_setaffinity_np@plt>:
  410060:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410064:	ldr	x17, [x16, #16]
  410068:	add	x16, x16, #0x10
  41006c:	br	x17

0000000000410070 <putc@plt>:
  410070:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410074:	ldr	x17, [x16, #24]
  410078:	add	x16, x16, #0x18
  41007c:	br	x17

0000000000410080 <fputc@plt>:
  410080:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410084:	ldr	x17, [x16, #32]
  410088:	add	x16, x16, #0x20
  41008c:	br	x17

0000000000410090 <clock_gettime@plt>:
  410090:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410094:	ldr	x17, [x16, #40]
  410098:	add	x16, x16, #0x28
  41009c:	br	x17

00000000004100a0 <sched_getcpu@plt>:
  4100a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100a4:	ldr	x17, [x16, #48]
  4100a8:	add	x16, x16, #0x30
  4100ac:	br	x17

00000000004100b0 <fclose@plt>:
  4100b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100b4:	ldr	x17, [x16, #56]
  4100b8:	add	x16, x16, #0x38
  4100bc:	br	x17

00000000004100c0 <strtok_r@plt>:
  4100c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100c4:	ldr	x17, [x16, #64]
  4100c8:	add	x16, x16, #0x40
  4100cc:	br	x17

00000000004100d0 <fopen@plt>:
  4100d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100d4:	ldr	x17, [x16, #72]
  4100d8:	add	x16, x16, #0x48
  4100dc:	br	x17

00000000004100e0 <malloc@plt>:
  4100e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100e4:	ldr	x17, [x16, #80]
  4100e8:	add	x16, x16, #0x50
  4100ec:	br	x17

00000000004100f0 <strncmp@plt>:
  4100f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4100f4:	ldr	x17, [x16, #88]
  4100f8:	add	x16, x16, #0x58
  4100fc:	br	x17

0000000000410100 <calloc@plt>:
  410100:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410104:	ldr	x17, [x16, #96]
  410108:	add	x16, x16, #0x60
  41010c:	br	x17

0000000000410110 <pthread_cond_broadcast@plt>:
  410110:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410114:	ldr	x17, [x16, #104]
  410118:	add	x16, x16, #0x68
  41011c:	br	x17

0000000000410120 <realloc@plt>:
  410120:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410124:	ldr	x17, [x16, #112]
  410128:	add	x16, x16, #0x70
  41012c:	br	x17

0000000000410130 <strdup@plt>:
  410130:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410134:	ldr	x17, [x16, #120]
  410138:	add	x16, x16, #0x78
  41013c:	br	x17

0000000000410140 <strerror@plt>:
  410140:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410144:	ldr	x17, [x16, #128]
  410148:	add	x16, x16, #0x80
  41014c:	br	x17

0000000000410150 <pthread_mutex_init@plt>:
  410150:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410154:	ldr	x17, [x16, #136]
  410158:	add	x16, x16, #0x88
  41015c:	br	x17

0000000000410160 <__gmon_start__@plt>:
  410160:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410164:	ldr	x17, [x16, #144]
  410168:	add	x16, x16, #0x90
  41016c:	br	x17

0000000000410170 <abort@plt>:
  410170:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410174:	ldr	x17, [x16, #152]
  410178:	add	x16, x16, #0x98
  41017c:	br	x17

0000000000410180 <getrusage@plt>:
  410180:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410184:	ldr	x17, [x16, #160]
  410188:	add	x16, x16, #0xa0
  41018c:	br	x17

0000000000410190 <strcmp@plt>:
  410190:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410194:	ldr	x17, [x16, #168]
  410198:	add	x16, x16, #0xa8
  41019c:	br	x17

00000000004101a0 <mmap@plt>:
  4101a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101a4:	ldr	x17, [x16, #176]
  4101a8:	add	x16, x16, #0xb0
  4101ac:	br	x17

00000000004101b0 <free@plt>:
  4101b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101b4:	ldr	x17, [x16, #184]
  4101b8:	add	x16, x16, #0xb8
  4101bc:	br	x17

00000000004101c0 <pthread_cond_wait@plt>:
  4101c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101c4:	ldr	x17, [x16, #192]
  4101c8:	add	x16, x16, #0xc0
  4101cc:	br	x17

00000000004101d0 <nanosleep@plt>:
  4101d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101d4:	ldr	x17, [x16, #200]
  4101d8:	add	x16, x16, #0xc8
  4101dc:	br	x17

00000000004101e0 <strtoull@plt>:
  4101e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101e4:	ldr	x17, [x16, #208]
  4101e8:	add	x16, x16, #0xd0
  4101ec:	br	x17

00000000004101f0 <madvise@plt>:
  4101f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4101f4:	ldr	x17, [x16, #216]
  4101f8:	add	x16, x16, #0xd8
  4101fc:	br	x17

0000000000410200 <fwrite@plt>:
  410200:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410204:	ldr	x17, [x16, #224]
  410208:	add	x16, x16, #0xe0
  41020c:	br	x17

0000000000410210 <pthread_create@plt>:
  410210:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410214:	ldr	x17, [x16, #232]
  410218:	add	x16, x16, #0xe8
  41021c:	br	x17

0000000000410220 <__sched_cpucount@plt>:
  410220:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410224:	ldr	x17, [x16, #240]
  410228:	add	x16, x16, #0xf0
  41022c:	br	x17

0000000000410230 <munmap@plt>:
  410230:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410234:	ldr	x17, [x16, #248]
  410238:	add	x16, x16, #0xf8
  41023c:	br	x17

0000000000410240 <pthread_mutex_destroy@plt>:
  410240:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410244:	ldr	x17, [x16, #256]
  410248:	add	x16, x16, #0x100
  41024c:	br	x17

0000000000410250 <pthread_cond_init@plt>:
  410250:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410254:	ldr	x17, [x16, #264]
  410258:	add	x16, x16, #0x108
  41025c:	br	x17

0000000000410260 <sysconf@plt>:
  410260:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410264:	ldr	x17, [x16, #272]
  410268:	add	x16, x16, #0x110
  41026c:	br	x17

0000000000410270 <strstr@plt>:
  410270:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410274:	ldr	x17, [x16, #280]
  410278:	add	x16, x16, #0x118
  41027c:	br	x17

0000000000410280 <__isoc99_sscanf@plt>:
  410280:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410284:	ldr	x17, [x16, #288]
  410288:	add	x16, x16, #0x120
  41028c:	br	x17

0000000000410290 <pthread_self@plt>:
  410290:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410294:	ldr	x17, [x16, #296]
  410298:	add	x16, x16, #0x128
  41029c:	br	x17

00000000004102a0 <pthread_getaffinity_np@plt>:
  4102a0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102a4:	ldr	x17, [x16, #304]
  4102a8:	add	x16, x16, #0x130
  4102ac:	br	x17

00000000004102b0 <pthread_cond_destroy@plt>:
  4102b0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102b4:	ldr	x17, [x16, #312]
  4102b8:	add	x16, x16, #0x138
  4102bc:	br	x17

00000000004102c0 <vfprintf@plt>:
  4102c0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102c4:	ldr	x17, [x16, #320]
  4102c8:	add	x16, x16, #0x140
  4102cc:	br	x17

00000000004102d0 <printf@plt>:
  4102d0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102d4:	ldr	x17, [x16, #328]
  4102d8:	add	x16, x16, #0x148
  4102dc:	br	x17

00000000004102e0 <__errno_location@plt>:
  4102e0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102e4:	ldr	x17, [x16, #336]
  4102e8:	add	x16, x16, #0x150
  4102ec:	br	x17

00000000004102f0 <pthread_join@plt>:
  4102f0:	adrp	x16, 440000 <exit@GLIBC_2.17>
  4102f4:	ldr	x17, [x16, #344]
  4102f8:	add	x16, x16, #0x158
  4102fc:	br	x17

0000000000410300 <getenv@plt>:
  410300:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410304:	ldr	x17, [x16, #352]
  410308:	add	x16, x16, #0x160
  41030c:	br	x17

0000000000410310 <pthread_mutex_lock@plt>:
  410310:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410314:	ldr	x17, [x16, #360]
  410318:	add	x16, x16, #0x168
  41031c:	br	x17

0000000000410320 <syscall@plt>:
  410320:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410324:	ldr	x17, [x16, #368]
  410328:	add	x16, x16, #0x170
  41032c:	br	x17

0000000000410330 <__getdelim@plt>:
  410330:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410334:	ldr	x17, [x16, #376]
  410338:	add	x16, x16, #0x178
  41033c:	br	x17

0000000000410340 <pthread_mutex_unlock@plt>:
  410340:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410344:	ldr	x17, [x16, #384]
  410348:	add	x16, x16, #0x180
  41034c:	br	x17

0000000000410350 <fprintf@plt>:
  410350:	adrp	x16, 440000 <exit@GLIBC_2.17>
  410354:	ldr	x17, [x16, #392]
  410358:	add	x16, x16, #0x188
  41035c:	br	x17

Disassembly of section .text:

0000000000410380 <main>:
  410380:	sub	sp, sp, #0x760
  410384:	stp	x29, x30, [sp, #192]
  410388:	add	x29, sp, #0xc0
  41038c:	stp	x19, x20, [sp, #208]
  410390:	stp	x21, x22, [sp, #224]
  410394:	stp	x23, x24, [sp, #240]
  410398:	stp	x25, x26, [sp, #256]
  41039c:	mov	w25, w0
  4103a0:	stp	x27, x28, [sp, #272]
  4103a4:	stp	d8, d9, [sp, #288]
  4103a8:	stp	d10, d11, [sp, #304]
  4103ac:	str	x1, [sp, #392]
  4103b0:	bl	412588 <now_ns>
  4103b4:	mov	x2, x0
  4103b8:	add	x1, sp, #0x368
  4103bc:	mov	w0, #0x0                   	// #0
  4103c0:	str	x2, [sp, #496]
  4103c4:	bl	410180 <getrusage@plt>
  4103c8:	cbnz	w0, 411990 <main+0x1610>
  4103cc:	cmp	w25, #0x1
  4103d0:	b.le	411bc0 <main+0x1840>
  4103d4:	mov	w0, #0xffffffff            	// #-1
  4103d8:	adrp	x27, 420000 <_IO_stdin_used>
  4103dc:	ldr	x2, [sp, #392]
  4103e0:	mov	w1, w0
  4103e4:	adrp	x0, 420000 <_IO_stdin_used>
  4103e8:	str	wzr, [sp, #344]
  4103ec:	add	x0, x0, #0x3c0
  4103f0:	adrp	x26, 420000 <_IO_stdin_used>
  4103f4:	str	w1, [sp, #320]
  4103f8:	mov	x28, #0x0                   	// #0
  4103fc:	str	x0, [sp, #400]
  410400:	mov	x0, #0x2ee                 	// #750
  410404:	str	w1, [sp, #432]
  410408:	add	x1, x27, #0x2f0
  41040c:	add	x20, x2, #0x8
  410410:	str	x0, [sp, #408]
  410414:	mov	x0, #0x80                  	// #128
  410418:	mov	x27, x28
  41041c:	str	x1, [sp, #352]
  410420:	add	x1, x26, #0x398
  410424:	str	x0, [sp, #384]
  410428:	mov	x0, #0x200                 	// #512
  41042c:	str	x1, [sp, #360]
  410430:	add	x1, x2, #0x18
  410434:	str	x0, [sp, #376]
  410438:	sub	w0, w25, #0x2
  41043c:	sub	w25, w25, #0x1
  410440:	lsr	w0, w0, #1
  410444:	add	x0, x1, w0, uxtw #4
  410448:	lsr	w25, w25, #1
  41044c:	str	x0, [sp, #336]
  410450:	add	x0, x20, w25, uxtw #4
  410454:	str	x0, [sp, #328]
  410458:	b	41049c <main+0x11c>
  41045c:	adrp	x1, 420000 <_IO_stdin_used>
  410460:	mov	x0, x23
  410464:	add	x1, x1, #0x2c0
  410468:	bl	410190 <strcmp@plt>
  41046c:	cbz	w0, 4106dc <main+0x35c>
  410470:	adrp	x1, 420000 <_IO_stdin_used>
  410474:	mov	x0, x23
  410478:	add	x1, x1, #0x2c8
  41047c:	bl	410190 <strcmp@plt>
  410480:	cbnz	w0, 411a5c <main+0x16dc>
  410484:	mov	w0, #0x2                   	// #2
  410488:	str	w0, [sp, #344]
  41048c:	ldr	x0, [sp, #336]
  410490:	add	x20, x20, #0x10
  410494:	cmp	x0, x20
  410498:	b.eq	410640 <main+0x2c0>  // b.none
  41049c:	ldr	x19, [x20]
  4104a0:	ldr	x1, [sp, #352]
  4104a4:	mov	x0, x19
  4104a8:	bl	410190 <strcmp@plt>
  4104ac:	cbz	w0, 410920 <main+0x5a0>
  4104b0:	ldr	x0, [sp, #328]
  4104b4:	cmp	x0, x20
  4104b8:	b.eq	411a6c <main+0x16ec>  // b.none
  4104bc:	mov	x0, x19
  4104c0:	ldr	x1, [sp, #360]
  4104c4:	ldr	x23, [x20, #8]
  4104c8:	bl	410190 <strcmp@plt>
  4104cc:	cbz	w0, 41045c <main+0xdc>
  4104d0:	mov	x0, x19
  4104d4:	ldr	x1, [sp, #400]
  4104d8:	bl	410190 <strcmp@plt>
  4104dc:	cbz	w0, 410750 <main+0x3d0>
  4104e0:	adrp	x0, 420000 <_IO_stdin_used>
  4104e4:	add	x1, x0, #0x408
  4104e8:	mov	x0, x19
  4104ec:	bl	410190 <strcmp@plt>
  4104f0:	cbnz	w0, 4106e8 <main+0x368>
  4104f4:	cbnz	x27, 411bb4 <main+0x1834>
  4104f8:	mov	x0, x23
  4104fc:	bl	410130 <strdup@plt>
  410500:	str	x0, [sp, #368]
  410504:	cbz	x0, 411ae8 <main+0x1768>
  410508:	mov	x0, #0x10                  	// #16
  41050c:	bl	4100e0 <malloc@plt>
  410510:	mov	x27, x0
  410514:	cbz	x0, 411ac4 <main+0x1744>
  410518:	adrp	x21, 420000 <_IO_stdin_used>
  41051c:	add	x22, sp, #0x638
  410520:	ldr	x0, [sp, #368]
  410524:	add	x21, x21, #0x488
  410528:	mov	x2, x22
  41052c:	str	xzr, [sp, #1592]
  410530:	mov	x1, x21
  410534:	bl	4100c0 <strtok_r@plt>
  410538:	mov	x26, x0
  41053c:	cbz	x0, 4119cc <main+0x164c>
  410540:	mov	x19, #0x4                   	// #4
  410544:	mov	x28, #0x0                   	// #0
  410548:	ldrb	w0, [x26]
  41054c:	cbz	w0, 4119ac <main+0x162c>
  410550:	str	xzr, [sp, #1736]
  410554:	bl	4102e0 <__errno_location@plt>
  410558:	mov	x25, x0
  41055c:	add	x1, sp, #0x6c8
  410560:	mov	w2, #0xa                   	// #10
  410564:	mov	x0, x26
  410568:	str	wzr, [x25]
  41056c:	bl	4101e0 <strtoull@plt>
  410570:	ldrb	w1, [x26]
  410574:	mov	x24, x0
  410578:	sub	w1, w1, #0x30
  41057c:	and	w1, w1, #0xff
  410580:	cmp	w1, #0x9
  410584:	b.hi	410944 <main+0x5c4>  // b.pmore
  410588:	ldr	w0, [x25]
  41058c:	cbnz	w0, 410944 <main+0x5c4>
  410590:	ldr	x0, [sp, #1736]
  410594:	cmp	x26, x0
  410598:	b.eq	410944 <main+0x5c4>  // b.none
  41059c:	ldrb	w0, [x0]
  4105a0:	cbnz	w0, 410944 <main+0x5c4>
  4105a4:	cmp	x24, #0x3ff
  4105a8:	b.hi	411a9c <main+0x171c>  // b.pmore
  4105ac:	mov	w1, w24
  4105b0:	cbz	x28, 4105d8 <main+0x258>
  4105b4:	mov	x2, #0x0                   	// #0
  4105b8:	nop
  4105bc:	nop
  4105c0:	ldr	w0, [x27, x2, lsl #2]
  4105c4:	cmp	w0, w1
  4105c8:	b.eq	41081c <main+0x49c>  // b.none
  4105cc:	add	x2, x2, #0x1
  4105d0:	cmp	x28, x2
  4105d4:	b.ne	4105c0 <main+0x240>  // b.any
  4105d8:	cmp	x28, x19
  4105dc:	b.ne	410604 <main+0x284>  // b.any
  4105e0:	mov	x0, #0x1fffffffffffffff    	// #2305843009213693951
  4105e4:	cmp	x28, x0
  4105e8:	b.hi	411a10 <main+0x1690>  // b.pmore
  4105ec:	lsl	x1, x28, #3
  4105f0:	mov	x0, x27
  4105f4:	bl	410120 <realloc@plt>
  4105f8:	lsl	x19, x28, #1
  4105fc:	cbz	x0, 4119e8 <main+0x1668>
  410600:	mov	x27, x0
  410604:	add	x28, x28, #0x1
  410608:	mov	x2, x22
  41060c:	add	x3, x27, x28, lsl #2
  410610:	mov	x1, x21
  410614:	mov	x0, #0x0                   	// #0
  410618:	stur	w24, [x3, #-4]
  41061c:	bl	4100c0 <strtok_r@plt>
  410620:	mov	x26, x0
  410624:	cbnz	x0, 410548 <main+0x1c8>
  410628:	ldr	x0, [sp, #368]
  41062c:	add	x20, x20, #0x10
  410630:	bl	4101b0 <free@plt>
  410634:	ldr	x0, [sp, #336]
  410638:	cmp	x0, x20
  41063c:	b.ne	41049c <main+0x11c>  // b.any
  410640:	ldr	w0, [sp, #344]
  410644:	mov	x26, x28
  410648:	mov	x28, x27
  41064c:	cbz	w0, 411bc0 <main+0x1840>
  410650:	cbz	x27, 411bc0 <main+0x1840>
  410654:	ldr	w1, [sp, #320]
  410658:	ldr	w0, [sp, #432]
  41065c:	orr	w0, w0, w1
  410660:	tbnz	w0, #31, 411bc0 <main+0x1840>
  410664:	ldr	x0, [sp, #376]
  410668:	cbz	x0, 411b04 <main+0x1784>
  41066c:	ldr	x0, [sp, #384]
  410670:	cbz	x0, 411b04 <main+0x1784>
  410674:	ldp	x0, x1, [sp, #376]
  410678:	orr	x1, x0, x1
  41067c:	mov	x0, #0xfffffffffff         	// #17592186044415
  410680:	cmp	x1, x0
  410684:	b.hi	411b10 <main+0x1790>  // b.pmore
  410688:	ldr	w2, [sp, #320]
  41068c:	mov	x0, #0x0                   	// #0
  410690:	cbz	x26, 4106ac <main+0x32c>
  410694:	ldr	w1, [x28, x0, lsl #2]
  410698:	cmp	w2, w1
  41069c:	b.eq	411ab4 <main+0x1734>  // b.none
  4106a0:	add	x0, x0, #0x1
  4106a4:	cmp	x26, x0
  4106a8:	b.ne	410694 <main+0x314>  // b.any
  4106ac:	mov	w0, #0x1e                  	// #30
  4106b0:	bl	410260 <sysconf@plt>
  4106b4:	str	x0, [sp, #600]
  4106b8:	cmp	x0, #0x0
  4106bc:	b.gt	410870 <main+0x4f0>
  4106c0:	bl	4102e0 <__errno_location@plt>
  4106c4:	ldr	w0, [x0]
  4106c8:	bl	410140 <strerror@plt>
  4106cc:	adrp	x2, 420000 <_IO_stdin_used>
  4106d0:	mov	x1, x0
  4106d4:	add	x0, x2, #0x708
  4106d8:	bl	411de0 <failf>
  4106dc:	mov	w0, #0x1                   	// #1
  4106e0:	str	w0, [sp, #344]
  4106e4:	b	41048c <main+0x10c>
  4106e8:	adrp	x1, 420000 <_IO_stdin_used>
  4106ec:	mov	x0, x19
  4106f0:	add	x1, x1, #0x570
  4106f4:	bl	410190 <strcmp@plt>
  4106f8:	cbz	w0, 4107b4 <main+0x434>
  4106fc:	adrp	x1, 420000 <_IO_stdin_used>
  410700:	mov	x0, x19
  410704:	add	x1, x1, #0x5b0
  410708:	bl	410190 <strcmp@plt>
  41070c:	cbz	w0, 410840 <main+0x4c0>
  410710:	adrp	x1, 420000 <_IO_stdin_used>
  410714:	mov	x0, x19
  410718:	add	x1, x1, #0x5d0
  41071c:	bl	410190 <strcmp@plt>
  410720:	cbz	w0, 410858 <main+0x4d8>
  410724:	adrp	x1, 420000 <_IO_stdin_used>
  410728:	mov	x0, x19
  41072c:	add	x1, x1, #0x5f0
  410730:	bl	410190 <strcmp@plt>
  410734:	cbnz	w0, 411b88 <main+0x1808>
  410738:	adrp	x1, 420000 <_IO_stdin_used>
  41073c:	mov	x0, x23
  410740:	add	x1, x1, #0x600
  410744:	bl	412040 <parse_u64>
  410748:	str	x0, [sp, #408]
  41074c:	b	41048c <main+0x10c>
  410750:	str	xzr, [sp, #1736]
  410754:	bl	4102e0 <__errno_location@plt>
  410758:	mov	x19, x0
  41075c:	mov	w2, #0xa                   	// #10
  410760:	add	x1, sp, #0x6c8
  410764:	mov	x0, x23
  410768:	str	wzr, [x19]
  41076c:	bl	4101e0 <strtoull@plt>
  410770:	ldrb	w1, [x23]
  410774:	mov	x2, x0
  410778:	sub	w0, w1, #0x30
  41077c:	and	w0, w0, #0xff
  410780:	cmp	w0, #0x9
  410784:	b.hi	411b70 <main+0x17f0>  // b.pmore
  410788:	ldr	w0, [x19]
  41078c:	cbnz	w0, 411b70 <main+0x17f0>
  410790:	ldr	x0, [sp, #1736]
  410794:	cmp	x23, x0
  410798:	b.eq	411b70 <main+0x17f0>  // b.none
  41079c:	ldrb	w0, [x0]
  4107a0:	cbnz	w0, 411b70 <main+0x17f0>
  4107a4:	cmp	x2, #0x3ff
  4107a8:	b.hi	411a44 <main+0x16c4>  // b.pmore
  4107ac:	str	w2, [sp, #320]
  4107b0:	b	41048c <main+0x10c>
  4107b4:	str	xzr, [sp, #1736]
  4107b8:	bl	4102e0 <__errno_location@plt>
  4107bc:	mov	x19, x0
  4107c0:	mov	w2, #0xa                   	// #10
  4107c4:	add	x1, sp, #0x6c8
  4107c8:	mov	x0, x23
  4107cc:	str	wzr, [x19]
  4107d0:	bl	4101e0 <strtoull@plt>
  4107d4:	ldrb	w1, [x23]
  4107d8:	mov	x2, x0
  4107dc:	sub	w0, w1, #0x30
  4107e0:	and	w0, w0, #0xff
  4107e4:	cmp	w0, #0x9
  4107e8:	b.hi	411a2c <main+0x16ac>  // b.pmore
  4107ec:	ldr	w0, [x19]
  4107f0:	cbnz	w0, 411a2c <main+0x16ac>
  4107f4:	ldr	x0, [sp, #1736]
  4107f8:	cmp	x23, x0
  4107fc:	b.eq	411a2c <main+0x16ac>  // b.none
  410800:	ldrb	w0, [x0]
  410804:	cbnz	w0, 411a2c <main+0x16ac>
  410808:	mov	x0, #0x7fffffff            	// #2147483647
  41080c:	cmp	x2, x0
  410810:	b.hi	41199c <main+0x161c>  // b.pmore
  410814:	str	w2, [sp, #432]
  410818:	b	41048c <main+0x10c>
  41081c:	mov	x0, x27
  410820:	str	w1, [sp, #320]
  410824:	bl	4101b0 <free@plt>
  410828:	ldr	x0, [sp, #368]
  41082c:	bl	4101b0 <free@plt>
  410830:	ldr	w1, [sp, #320]
  410834:	adrp	x0, 420000 <_IO_stdin_used>
  410838:	add	x0, x0, #0x4d0
  41083c:	bl	411de0 <failf>
  410840:	adrp	x1, 420000 <_IO_stdin_used>
  410844:	mov	x0, x23
  410848:	add	x1, x1, #0x5c0
  41084c:	bl	412040 <parse_u64>
  410850:	str	x0, [sp, #376]
  410854:	b	41048c <main+0x10c>
  410858:	adrp	x1, 420000 <_IO_stdin_used>
  41085c:	mov	x0, x23
  410860:	add	x1, x1, #0x5e0
  410864:	bl	412040 <parse_u64>
  410868:	str	x0, [sp, #384]
  41086c:	b	41048c <main+0x10c>
  410870:	ldr	w1, [sp, #320]
  410874:	movi	v0.4s, #0x0
  410878:	add	x20, sp, #0x638
  41087c:	stp	q0, q0, [x20]
  410880:	sbfx	x0, x1, #3, #29
  410884:	and	x25, x0, #0x1ffffffffffffff8
  410888:	and	w0, w1, #0x3f
  41088c:	mov	x1, #0x1                   	// #1
  410890:	lsl	x1, x1, x0
  410894:	str	w0, [sp, #436]
  410898:	stp	q0, q0, [x20, #32]
  41089c:	stp	q0, q0, [x20, #64]
  4108a0:	stp	q0, q0, [x20, #96]
  4108a4:	ldr	x0, [x20, x25]
  4108a8:	orr	x0, x0, x1
  4108ac:	str	x0, [x20, x25]
  4108b0:	bl	410290 <pthread_self@plt>
  4108b4:	mov	x2, x20
  4108b8:	mov	x1, #0x80                  	// #128
  4108bc:	str	x0, [sp, #424]
  4108c0:	bl	410060 <pthread_setaffinity_np@plt>
  4108c4:	cbnz	w0, 410908 <main+0x588>
  4108c8:	movi	v0.4s, #0x0
  4108cc:	add	x19, sp, #0x6c8
  4108d0:	mov	x1, #0x80                  	// #128
  4108d4:	mov	x2, x19
  4108d8:	ldr	x0, [sp, #424]
  4108dc:	stp	q0, q0, [x19]
  4108e0:	stp	q0, q0, [x19, #32]
  4108e4:	stp	q0, q0, [x19, #64]
  4108e8:	stp	q0, q0, [x19, #96]
  4108ec:	bl	4102a0 <pthread_getaffinity_np@plt>
  4108f0:	cbnz	w0, 410908 <main+0x588>
  4108f4:	ldrb	w1, [sp, #436]
  4108f8:	ldr	x0, [x19, x25]
  4108fc:	lsr	x0, x0, x1
  410900:	tbnz	w0, #0, 41095c <main+0x5dc>
  410904:	mov	w0, #0x16                  	// #22
  410908:	bl	410140 <strerror@plt>
  41090c:	adrp	x3, 420000 <_IO_stdin_used>
  410910:	mov	x2, x0
  410914:	ldr	w1, [sp, #320]
  410918:	add	x0, x3, #0x728
  41091c:	bl	411de0 <failf>
  410920:	ldr	x2, [sp, #392]
  410924:	adrp	x1, 420000 <_IO_stdin_used>
  410928:	adrp	x0, 440000 <exit@GLIBC_2.17>
  41092c:	add	x1, x1, #0x2f8
  410930:	ldr	x0, [x0, #408]
  410934:	ldr	x2, [x2]
  410938:	bl	410350 <fprintf@plt>
  41093c:	mov	w0, #0x0                   	// #0
  410940:	bl	410040 <exit@plt>
  410944:	adrp	x1, 420000 <_IO_stdin_used>
  410948:	adrp	x0, 420000 <_IO_stdin_used>
  41094c:	mov	x2, x26
  410950:	add	x1, x1, #0x4c0
  410954:	add	x0, x0, #0xc0
  410958:	bl	411de0 <failf>
  41095c:	mov	x1, x19
  410960:	mov	x0, #0x80                  	// #128
  410964:	bl	410220 <__sched_cpucount@plt>
  410968:	cmp	w0, #0x1
  41096c:	b.ne	410904 <main+0x584>  // b.any
  410970:	bl	4100a0 <sched_getcpu@plt>
  410974:	ldr	w1, [sp, #320]
  410978:	cmp	w0, w1
  41097c:	b.ne	411b60 <main+0x17e0>  // b.any
  410980:	ldr	w0, [sp, #432]
  410984:	add	x1, sp, #0x294
  410988:	str	wzr, [sp, #660]
  41098c:	bl	4125f0 <bind_current_thread_memory_to_node.constprop.0>
  410990:	ands	w22, w0, #0xff
  410994:	b.eq	411b44 <main+0x17c4>  // b.none
  410998:	ldp	x0, x2, [sp, #376]
  41099c:	mov	x1, #0x8d3                 	// #2259
  4109a0:	add	x8, sp, #0x308
  4109a4:	movk	x1, #0x85a3, lsl #16
  4109a8:	movk	x1, #0x6a88, lsl #32
  4109ac:	movk	x1, #0x243f, lsl #48
  4109b0:	lsl	x2, x2, #20
  4109b4:	lsl	x0, x0, #20
  4109b8:	str	x2, [sp, #336]
  4109bc:	bl	412800 <make_cycle>
  4109c0:	ldr	x2, [sp, #792]
  4109c4:	mov	x1, #0x7344                	// #29508
  4109c8:	add	x8, sp, #0x338
  4109cc:	movk	x1, #0x370, lsl #16
  4109d0:	mov	x0, #0x2000                	// #8192
  4109d4:	ldr	x21, [sp, #776]
  4109d8:	movk	x1, #0x8a2e, lsl #32
  4109dc:	movk	x1, #0x1319, lsl #48
  4109e0:	str	x2, [sp, #352]
  4109e4:	ldr	x2, [sp, #800]
  4109e8:	str	x21, [sp, #448]
  4109ec:	str	x2, [sp, #400]
  4109f0:	bl	412800 <make_cycle>
  4109f4:	ldr	x23, [sp, #824]
  4109f8:	mov	x0, x21
  4109fc:	add	x8, sp, #0x2b8
  410a00:	ldr	x1, [sp, #848]
  410a04:	ldr	x21, [sp, #840]
  410a08:	str	x23, [sp, #464]
  410a0c:	str	x1, [sp, #416]
  410a10:	bl	4120cc <read_map_evidence>
  410a14:	mov	x0, x23
  410a18:	add	x8, sp, #0x2e0
  410a1c:	bl	4120cc <read_map_evidence>
  410a20:	movi	v0.4s, #0x0
  410a24:	ldr	w2, [sp, #344]
  410a28:	mov	x1, #0x0                   	// #0
  410a2c:	str	xzr, [x19, #144]
  410a30:	mov	x0, x19
  410a34:	str	q0, [x19, #128]
  410a38:	str	x26, [sp, #1872]
  410a3c:	str	w2, [sp, #1880]
  410a40:	stp	q0, q0, [x19]
  410a44:	stp	q0, q0, [x19, #32]
  410a48:	stp	q0, q0, [x19, #64]
  410a4c:	stp	q0, q0, [x19, #96]
  410a50:	bl	410150 <pthread_mutex_init@plt>
  410a54:	cbnz	w0, 411b30 <main+0x17b0>
  410a58:	mov	x1, #0x0                   	// #0
  410a5c:	add	x0, sp, #0x6f8
  410a60:	bl	410250 <pthread_cond_init@plt>
  410a64:	cbnz	w0, 411b1c <main+0x179c>
  410a68:	mov	x1, #0x88                  	// #136
  410a6c:	mov	x0, x26
  410a70:	bl	410100 <calloc@plt>
  410a74:	mov	x23, x0
  410a78:	mov	x1, #0x8                   	// #8
  410a7c:	mov	x0, x26
  410a80:	bl	410100 <calloc@plt>
  410a84:	cmp	x23, #0x0
  410a88:	mov	x24, x0
  410a8c:	cset	w1, eq	// eq = none
  410a90:	cmp	x0, #0x0
  410a94:	cset	w0, eq	// eq = none
  410a98:	orr	w0, w1, w0
  410a9c:	str	w0, [sp, #328]
  410aa0:	cbnz	w0, 411c28 <main+0x18a8>
  410aa4:	cbz	x26, 410b38 <main+0x7b8>
  410aa8:	mov	x27, #0x0                   	// #0
  410aac:	adrp	x2, 412000 <worker_wait_for_phase+0x98>
  410ab0:	stp	x23, x21, [sp, #360]
  410ab4:	add	x2, x2, #0xa80
  410ab8:	mov	x21, x28
  410abc:	mov	w6, #0xffffffff            	// #-1
  410ac0:	mov	x28, x20
  410ac4:	mov	x20, x27
  410ac8:	mov	x27, x25
  410acc:	mov	w25, w22
  410ad0:	mov	x22, x24
  410ad4:	ldr	w4, [sp, #432]
  410ad8:	mov	x1, #0x0                   	// #0
  410adc:	mov	x3, x23
  410ae0:	mov	x0, x22
  410ae4:	str	x19, [x23]
  410ae8:	ldr	w7, [x21, x20, lsl #2]
  410aec:	stp	w6, w6, [x23, #16]
  410af0:	stp	w7, w4, [x23, #8]
  410af4:	ldr	x4, [sp, #336]
  410af8:	str	x4, [x23, #48]
  410afc:	bl	410210 <pthread_create@plt>
  410b00:	adrp	x1, 412000 <worker_wait_for_phase+0x98>
  410b04:	mov	w6, #0xffffffff            	// #-1
  410b08:	add	x2, x1, #0xa80
  410b0c:	cbnz	w0, 411c10 <main+0x1890>
  410b10:	add	x20, x20, #0x1
  410b14:	add	x23, x23, #0x88
  410b18:	add	x22, x22, #0x8
  410b1c:	cmp	x26, x20
  410b20:	b.ne	410ad4 <main+0x754>  // b.any
  410b24:	mov	x20, x28
  410b28:	mov	x28, x21
  410b2c:	ldp	x23, x21, [sp, #360]
  410b30:	mov	w22, w25
  410b34:	mov	x25, x27
  410b38:	mov	x0, x19
  410b3c:	bl	410310 <pthread_mutex_lock@plt>
  410b40:	cbz	w0, 410b58 <main+0x7d8>
  410b44:	b	411be8 <main+0x1868>
  410b48:	mov	x1, x19
  410b4c:	add	x0, sp, #0x6f8
  410b50:	bl	4101c0 <pthread_cond_wait@plt>
  410b54:	cbnz	w0, 411bfc <main+0x187c>
  410b58:	ldr	x0, [sp, #1840]
  410b5c:	cmp	x0, x26
  410b60:	b.ne	410b48 <main+0x7c8>  // b.any
  410b64:	mov	x0, x19
  410b68:	bl	410340 <pthread_mutex_unlock@plt>
  410b6c:	cbnz	w0, 411c44 <main+0x18c4>
  410b70:	cbz	x26, 410bf8 <main+0x878>
  410b74:	mov	x1, #0x0                   	// #0
  410b78:	mov	x27, x23
  410b7c:	str	x20, [sp, #336]
  410b80:	mov	x20, x1
  410b84:	ldr	w1, [x27, #28]
  410b88:	ldr	x0, [x27, #40]
  410b8c:	cmp	w1, #0x0
  410b90:	ldr	w1, [sp, #328]
  410b94:	csel	w1, w1, w22, eq	// eq = none
  410b98:	str	w1, [sp, #328]
  410b9c:	cbz	x0, 410bbc <main+0x83c>
  410ba0:	add	x8, sp, #0x260
  410ba4:	bl	4120cc <read_map_evidence>
  410ba8:	ldp	q0, q1, [sp, #608]
  410bac:	add	x0, x27, #0x60
  410bb0:	ldr	x1, [sp, #640]
  410bb4:	str	x1, [x27, #128]
  410bb8:	stp	q0, q1, [x0]
  410bbc:	add	x20, x20, #0x1
  410bc0:	add	x27, x27, #0x88
  410bc4:	cmp	x26, x20
  410bc8:	b.ne	410b84 <main+0x804>  // b.any
  410bcc:	ldr	w0, [sp, #328]
  410bd0:	ldr	x20, [sp, #336]
  410bd4:	cbz	w0, 410bf8 <main+0x878>
  410bd8:	mov	x0, x19
  410bdc:	bl	4126c0 <stop_workers>
  410be0:	mov	x1, x26
  410be4:	mov	x0, x24
  410be8:	bl	412300 <join_workers>
  410bec:	mov	x1, x26
  410bf0:	mov	x0, x23
  410bf4:	bl	411e70 <fail_if_worker_error>
  410bf8:	bl	412588 <now_ns>
  410bfc:	mov	x2, x0
  410c00:	mov	w1, #0x1                   	// #1
  410c04:	mov	x0, x19
  410c08:	str	x2, [sp, #504]
  410c0c:	bl	411ee8 <broadcast_phase>
  410c10:	ldr	x1, [sp, #408]
  410c14:	mov	x0, #0xb5ed                	// #46573
  410c18:	movk	x0, #0xf7a0, lsl #16
  410c1c:	movk	x0, #0x10c6, lsl #32
  410c20:	cmp	x1, x0
  410c24:	b.hi	411c6c <main+0x18ec>  // b.pmore
  410c28:	ldr	x2, [sp, #408]
  410c2c:	mov	x1, #0x4240                	// #16960
  410c30:	mov	x0, #0xca00                	// #51712
  410c34:	movk	x1, #0xf, lsl #16
  410c38:	movk	x0, #0x3b9a, lsl #16
  410c3c:	mul	x1, x2, x1
  410c40:	udiv	x2, x1, x0
  410c44:	msub	x0, x2, x0, x1
  410c48:	str	x2, [sp, #1592]
  410c4c:	str	x0, [sp, #1600]
  410c50:	b	410c64 <main+0x8e4>
  410c54:	bl	4102e0 <__errno_location@plt>
  410c58:	ldr	w0, [x0]
  410c5c:	cmp	w0, #0x4
  410c60:	b.ne	411c58 <main+0x18d8>  // b.any
  410c64:	mov	x1, x20
  410c68:	mov	x0, x20
  410c6c:	bl	4101d0 <nanosleep@plt>
  410c70:	cbnz	w0, 410c54 <main+0x8d4>
  410c74:	bl	412588 <now_ns>
  410c78:	mov	x1, x0
  410c7c:	mov	x0, x19
  410c80:	str	x1, [sp, #512]
  410c84:	bl	410310 <pthread_mutex_lock@plt>
  410c88:	cbnz	w0, 4116b8 <main+0x1338>
  410c8c:	mov	w1, #0x2                   	// #2
  410c90:	add	x0, sp, #0x728
  410c94:	stlr	w1, [x0]
  410c98:	add	x0, sp, #0x6f8
  410c9c:	bl	410110 <pthread_cond_broadcast@plt>
  410ca0:	cbz	w0, 410cb8 <main+0x938>
  410ca4:	b	4116a4 <main+0x1324>
  410ca8:	mov	x1, x19
  410cac:	add	x0, sp, #0x6f8
  410cb0:	bl	4101c0 <pthread_cond_wait@plt>
  410cb4:	cbnz	w0, 411c78 <main+0x18f8>
  410cb8:	ldr	x0, [sp, #1848]
  410cbc:	cmp	x0, x26
  410cc0:	b.ne	410ca8 <main+0x928>  // b.any
  410cc4:	mov	x0, x19
  410cc8:	bl	410340 <pthread_mutex_unlock@plt>
  410ccc:	cbnz	w0, 411634 <main+0x12b4>
  410cd0:	cbz	x26, 410d00 <main+0x980>
  410cd4:	add	x27, x23, #0x1c
  410cd8:	stp	xzr, x20, [sp, #328]
  410cdc:	ldr	w0, [x27]
  410ce0:	cbnz	w0, 411554 <main+0x11d4>
  410ce4:	ldr	x0, [sp, #328]
  410ce8:	add	x27, x27, #0x88
  410cec:	add	x0, x0, #0x1
  410cf0:	str	x0, [sp, #328]
  410cf4:	cmp	x26, x0
  410cf8:	b.ne	410cdc <main+0x95c>  // b.any
  410cfc:	ldr	x20, [sp, #336]
  410d00:	mov	x0, x19
  410d04:	bl	410310 <pthread_mutex_lock@plt>
  410d08:	cbnz	w0, 4117e8 <main+0x1468>
  410d0c:	bl	412588 <now_ns>
  410d10:	str	x0, [sp, #520]
  410d14:	mov	w1, #0x3                   	// #3
  410d18:	add	x0, sp, #0x728
  410d1c:	stlr	w1, [x0]
  410d20:	add	x0, sp, #0x6f8
  410d24:	bl	410110 <pthread_cond_broadcast@plt>
  410d28:	cbnz	w0, 4117c0 <main+0x1440>
  410d2c:	mov	x0, x19
  410d30:	bl	410340 <pthread_mutex_unlock@plt>
  410d34:	cbnz	w0, 411778 <main+0x13f8>
  410d38:	ldr	w0, [sp, #344]
  410d3c:	cmp	w0, #0x2
  410d40:	b.eq	411708 <main+0x1388>  // b.none
  410d44:	mov	x5, #0x100000              	// #1048576
  410d48:	mov	x27, #0xffffffffffffffff    	// #-1
  410d4c:	ldr	x1, [sp, #416]
  410d50:	add	x4, sp, #0x2a0
  410d54:	add	x3, sp, #0x298
  410d58:	str	xzr, [sp, #664]
  410d5c:	udiv	x2, x5, x21
  410d60:	ldr	x0, [sp, #464]
  410d64:	str	x27, [sp, #672]
  410d68:	msub	x6, x2, x21, x5
  410d6c:	madd	x2, x2, x21, x21
  410d70:	cmp	x6, #0x0
  410d74:	csel	x2, x2, x5, ne	// ne = any
  410d78:	str	x2, [sp, #360]
  410d7c:	bl	413280 <topic49_run_timed>
  410d80:	ldr	x2, [sp, #360]
  410d84:	str	x0, [sp, #472]
  410d88:	ldr	x1, [sp, #856]
  410d8c:	udiv	x21, x2, x21
  410d90:	mul	x21, x21, x1
  410d94:	bl	4100a0 <sched_getcpu@plt>
  410d98:	mov	w2, w0
  410d9c:	add	x1, sp, #0x518
  410da0:	mov	w0, #0x1                   	// #1
  410da4:	str	w2, [sp, #368]
  410da8:	bl	410180 <getrusage@plt>
  410dac:	cbnz	w0, 4116fc <main+0x137c>
  410db0:	add	x1, sp, #0x3f8
  410db4:	bl	410180 <getrusage@plt>
  410db8:	cbnz	w0, 411990 <main+0x1610>
  410dbc:	ldr	x1, [sp, #352]
  410dc0:	mov	x0, #0x3fffffffffffffff    	// #4611686018427387903
  410dc4:	cmp	x1, x0
  410dc8:	b.hi	4116f0 <main+0x1370>  // b.pmore
  410dcc:	ldr	x0, [sp, #352]
  410dd0:	add	x4, sp, #0x2b0
  410dd4:	add	x3, sp, #0x2a8
  410dd8:	str	x27, [sp, #688]
  410ddc:	ldr	x27, [sp, #400]
  410de0:	str	xzr, [sp, #680]
  410de4:	lsl	x0, x0, #2
  410de8:	mov	x2, x0
  410dec:	mov	x1, x27
  410df0:	str	x0, [sp, #392]
  410df4:	ldr	x0, [sp, #448]
  410df8:	bl	413280 <topic49_run_timed>
  410dfc:	mov	x2, x0
  410e00:	add	x1, sp, #0x488
  410e04:	mov	w0, #0x0                   	// #0
  410e08:	str	x2, [sp, #480]
  410e0c:	bl	410180 <getrusage@plt>
  410e10:	cbnz	w0, 411990 <main+0x1610>
  410e14:	add	x1, sp, #0x5a8
  410e18:	mov	w0, #0x1                   	// #1
  410e1c:	bl	410180 <getrusage@plt>
  410e20:	cbnz	w0, 4116fc <main+0x137c>
  410e24:	bl	4100a0 <sched_getcpu@plt>
  410e28:	str	w0, [sp, #400]
  410e2c:	mov	w3, #0x1                   	// #1
  410e30:	add	x0, sp, #0x72c
  410e34:	stlrb	w3, [x0]
  410e38:	mov	w1, #0x4                   	// #4
  410e3c:	mov	x0, x19
  410e40:	bl	411ee8 <broadcast_phase>
  410e44:	mov	x1, x26
  410e48:	mov	x0, x24
  410e4c:	bl	412300 <join_workers>
  410e50:	bl	412588 <now_ns>
  410e54:	ldr	x3, [sp, #416]
  410e58:	str	x0, [sp, #528]
  410e5c:	ldr	x1, [sp, #672]
  410e60:	ldr	x0, [sp, #808]
  410e64:	cmp	x1, x3
  410e68:	ldr	x3, [sp, #472]
  410e6c:	lsl	x0, x0, #2
  410e70:	ccmp	x3, x21, #0x0, eq	// eq = none
  410e74:	b.ne	4116e4 <main+0x1364>  // b.any
  410e78:	ldr	x1, [sp, #688]
  410e7c:	cmp	x1, x27
  410e80:	ldr	x1, [sp, #480]
  410e84:	ccmp	x1, x0, #0x0, eq	// eq = none
  410e88:	b.ne	4116e4 <main+0x1364>  // b.any
  410e8c:	ldr	w0, [sp, #320]
  410e90:	ldr	w1, [sp, #400]
  410e94:	cmp	w0, w1
  410e98:	ldr	w1, [sp, #368]
  410e9c:	ccmp	w0, w1, #0x0, eq	// eq = none
  410ea0:	b.ne	4116cc <main+0x134c>  // b.any
  410ea4:	movi	v0.4s, #0x0
  410ea8:	mov	x2, x20
  410eac:	mov	x1, #0x80                  	// #128
  410eb0:	ldr	x0, [sp, #424]
  410eb4:	stp	q0, q0, [x20]
  410eb8:	stp	q0, q0, [x20, #32]
  410ebc:	stp	q0, q0, [x20, #64]
  410ec0:	stp	q0, q0, [x20, #96]
  410ec4:	bl	4102a0 <pthread_getaffinity_np@plt>
  410ec8:	mov	w21, w0
  410ecc:	cbnz	w0, 41166c <main+0x12ec>
  410ed0:	ldrb	w1, [sp, #436]
  410ed4:	ldr	x0, [x20, x25]
  410ed8:	lsr	x0, x0, x1
  410edc:	tbz	w0, #0, 411668 <main+0x12e8>
  410ee0:	mov	x1, x20
  410ee4:	mov	x0, #0x80                  	// #128
  410ee8:	bl	410220 <__sched_cpucount@plt>
  410eec:	cmp	w0, #0x1
  410ef0:	b.ne	411668 <main+0x12e8>  // b.any
  410ef4:	mov	x1, x26
  410ef8:	mov	x0, x23
  410efc:	bl	411e70 <fail_if_worker_error>
  410f00:	add	x7, sp, #0x4c8
  410f04:	ldr	x2, [sp, #1080]
  410f08:	ldp	x6, x0, [x7]
  410f0c:	ldp	x5, x3, [x7, #64]
  410f10:	sub	x2, x6, x2
  410f14:	ldr	x1, [sp, #1088]
  410f18:	str	x2, [sp, #592]
  410f1c:	ldr	x4, [sp, #1144]
  410f20:	ldr	x2, [sp, #1368]
  410f24:	subs	x1, x0, x1
  410f28:	ldr	x0, [sp, #1152]
  410f2c:	sub	x4, x5, x4
  410f30:	ldr	x7, [sp, #1512]
  410f34:	str	x4, [sp, #584]
  410f38:	ldr	x5, [sp, #1376]
  410f3c:	sub	x0, x3, x0
  410f40:	ldr	x3, [sp, #1432]
  410f44:	sub	x2, x7, x2
  410f48:	str	x0, [sp, #576]
  410f4c:	ldr	x0, [sp, #1440]
  410f50:	str	x2, [sp, #536]
  410f54:	ldr	x6, [sp, #1520]
  410f58:	ldr	x4, [sp, #1576]
  410f5c:	ldr	x2, [sp, #1584]
  410f60:	sub	x5, x6, x5
  410f64:	sub	x3, x4, x3
  410f68:	str	x5, [sp, #544]
  410f6c:	sub	x0, x2, x0
  410f70:	str	x3, [sp, #552]
  410f74:	str	x0, [sp, #560]
  410f78:	b.ne	411684 <main+0x1304>  // b.any
  410f7c:	ldrb	w2, [sp, #816]
  410f80:	ldrb	w0, [sp, #864]
  410f84:	ldrb	w1, [sp, #696]
  410f88:	cmp	w2, #0x0
  410f8c:	csel	w0, w0, wzr, ne	// ne = any
  410f90:	and	w0, w0, #0x1
  410f94:	str	w0, [sp, #436]
  410f98:	cbz	w1, 410fa0 <main+0xc20>
  410f9c:	ldrb	w21, [sp, #736]
  410fa0:	lsl	x25, x26, #2
  410fa4:	lsl	x27, x26, #3
  410fa8:	mov	x0, x25
  410fac:	and	w21, w21, #0x1
  410fb0:	bl	4100e0 <malloc@plt>
  410fb4:	mov	x1, x0
  410fb8:	mov	x0, x25
  410fbc:	mov	x25, x1
  410fc0:	str	x1, [sp, #416]
  410fc4:	bl	4100e0 <malloc@plt>
  410fc8:	mov	x1, x0
  410fcc:	mov	x0, x27
  410fd0:	str	x1, [sp, #328]
  410fd4:	bl	4100e0 <malloc@plt>
  410fd8:	ldr	x1, [sp, #328]
  410fdc:	cmp	x25, #0x0
  410fe0:	ccmp	x1, #0x0, #0x4, ne	// ne = any
  410fe4:	mov	x1, x0
  410fe8:	cset	w0, eq	// eq = none
  410fec:	cmp	x1, #0x0
  410ff0:	str	x1, [sp, #336]
  410ff4:	cset	w1, eq	// eq = none
  410ff8:	orr	w0, w0, w1
  410ffc:	cbnz	w0, 41181c <main+0x149c>
  411000:	cbz	x26, 411808 <main+0x1488>
  411004:	ldr	w7, [sp, #344]
  411008:	add	x0, x23, #0x8
  41100c:	mov	w2, w22
  411010:	ldp	x9, x10, [sp, #328]
  411014:	mov	x1, #0x0                   	// #0
  411018:	mov	x5, #0x0                   	// #0
  41101c:	mov	x25, #0x0                   	// #0
  411020:	ldr	w6, [sp, #436]
  411024:	ldr	x8, [sp, #416]
  411028:	ldr	x3, [x0, #64]
  41102c:	ldrb	w4, [x0, #72]
  411030:	str	x3, [x10, x1, lsl #3]
  411034:	cmp	w7, #0x2
  411038:	b.eq	411608 <main+0x1288>  // b.none
  41103c:	cmp	x3, #0x0
  411040:	ccmp	w4, #0x0, #0x0, eq	// eq = none
  411044:	b.ne	4117fc <main+0x147c>  // b.any
  411048:	ldr	x4, [x0, #80]
  41104c:	ldr	x3, [x0, #112]
  411050:	add	x25, x25, x4
  411054:	add	x5, x5, x3
  411058:	cbz	w22, 4115f4 <main+0x1274>
  41105c:	ldrb	w22, [x0, #88]
  411060:	cbz	w22, 411600 <main+0x1280>
  411064:	ldrb	w22, [x0, #124]
  411068:	cbz	w22, 4115fc <main+0x127c>
  41106c:	cbz	w21, 411600 <main+0x1280>
  411070:	mov	w22, w21
  411074:	ldp	w3, w4, [x0, #8]
  411078:	cbz	w2, 411094 <main+0xd14>
  41107c:	ldrb	w2, [x0, #16]
  411080:	cbz	w2, 411094 <main+0xd14>
  411084:	ldr	w11, [x0]
  411088:	mov	w2, #0x0                   	// #0
  41108c:	cmp	w11, w3
  411090:	b.eq	4115e8 <main+0x1268>  // b.none
  411094:	cbz	w6, 41109c <main+0xd1c>
  411098:	ldrb	w6, [x0, #17]
  41109c:	str	w3, [x8, x1, lsl #2]
  4110a0:	add	x0, x0, #0x88
  4110a4:	str	w4, [x9, x1, lsl #2]
  4110a8:	add	x1, x1, #0x1
  4110ac:	cmp	x26, x1
  4110b0:	b.ne	411028 <main+0xca8>  // b.any
  4110b4:	ldr	x0, [sp, #336]
  4110b8:	str	w6, [sp, #436]
  4110bc:	str	x5, [sp, #488]
  4110c0:	add	x1, x27, x0
  4110c4:	mov	x27, #0x0                   	// #0
  4110c8:	ldr	x3, [x0]
  4110cc:	adds	x27, x27, x3
  4110d0:	b.cs	411838 <main+0x14b8>  // b.hs, b.nlast
  4110d4:	add	x0, x0, #0x8
  4110d8:	cmp	x1, x0
  4110dc:	b.ne	4110c8 <main+0xd48>  // b.any
  4110e0:	ldr	x0, [sp, #1864]
  4110e4:	str	x0, [sp, #456]
  4110e8:	cbnz	x0, 41195c <main+0x15dc>
  4110ec:	ldr	w1, [sp, #344]
  4110f0:	ldr	x0, [sp, #1856]
  4110f4:	cmp	w1, #0x2
  4110f8:	b.eq	41190c <main+0x158c>  // b.none
  4110fc:	orr	x0, x27, x0
  411100:	str	x0, [sp, #440]
  411104:	cbnz	x0, 411900 <main+0x1580>
  411108:	str	xzr, [sp, #424]
  41110c:	cbz	w2, 4118f4 <main+0x1574>
  411110:	ldr	x1, [sp, #392]
  411114:	mov	x0, #0x3ffffffffffffff     	// #288230376151711743
  411118:	cmp	x1, x0
  41111c:	b.hi	4118e8 <main+0x1568>  // b.pmore
  411120:	mov	x1, x20
  411124:	mov	w0, #0x0                   	// #0
  411128:	bl	410180 <getrusage@plt>
  41112c:	ldr	x1, [sp, #352]
  411130:	lsl	x1, x1, #8
  411134:	str	x1, [sp, #352]
  411138:	cbnz	w0, 411990 <main+0x1610>
  41113c:	ldr	x1, [sp, #944]
  411140:	ldr	x0, [sp, #1664]
  411144:	subs	x1, x0, x1
  411148:	b.ne	4118dc <main+0x155c>  // b.any
  41114c:	ldr	x0, [sp, #448]
  411150:	ldr	x1, [sp, #784]
  411154:	bl	410230 <munmap@plt>
  411158:	cbnz	w0, 4118c0 <main+0x1540>
  41115c:	ldr	x0, [sp, #464]
  411160:	ldr	x1, [sp, #832]
  411164:	bl	410230 <munmap@plt>
  411168:	cbnz	w0, 4118a4 <main+0x1524>
  41116c:	add	x0, sp, #0x6f8
  411170:	bl	4102b0 <pthread_cond_destroy@plt>
  411174:	cbnz	w0, 411890 <main+0x1510>
  411178:	mov	x0, x19
  41117c:	bl	410240 <pthread_mutex_destroy@plt>
  411180:	cbnz	w0, 41187c <main+0x14fc>
  411184:	bl	412588 <now_ns>
  411188:	ldr	x2, [sp, #528]
  41118c:	ldr	x1, [sp, #664]
  411190:	sub	x3, x0, x2
  411194:	str	x3, [sp, #528]
  411198:	ldr	x3, [sp, #496]
  41119c:	sub	x0, x0, x3
  4111a0:	str	x0, [sp, #568]
  4111a4:	ldr	x0, [sp, #504]
  4111a8:	sub	x3, x0, x3
  4111ac:	str	x3, [sp, #448]
  4111b0:	ldr	x3, [sp, #512]
  4111b4:	sub	x0, x3, x0
  4111b8:	str	x0, [sp, #464]
  4111bc:	ldr	x0, [sp, #520]
  4111c0:	sub	x3, x0, x3
  4111c4:	sub	x20, x2, x0
  4111c8:	str	x3, [sp, #496]
  4111cc:	cbz	x1, 411864 <main+0x14e4>
  4111d0:	ldr	x0, [sp, #680]
  4111d4:	cmp	x0, #0x0
  4111d8:	ccmp	x20, #0x0, #0x4, ne	// ne = any
  4111dc:	b.eq	411864 <main+0x14e4>  // b.none
  4111e0:	ldr	d1, [sp, #424]
  4111e4:	mov	x2, #0xcd6500000000        	// #225833675390976
  4111e8:	ucvtf	d8, x1
  4111ec:	movk	x2, #0x41cd, lsl #48
  4111f0:	ucvtf	d0, x20
  4111f4:	mov	x1, #0x3e10000000000000    	// #4472074429978902528
  4111f8:	ldr	d3, [sp, #360]
  4111fc:	ucvtf	d9, x0
  411200:	fmov	d2, x2
  411204:	ldr	w0, [sp, #344]
  411208:	ucvtf	d10, d1
  41120c:	ldr	d1, [sp, #440]
  411210:	ucvtf	d3, d3
  411214:	ucvtf	d11, d1
  411218:	fmov	d1, x1
  41121c:	fdiv	d0, d0, d2
  411220:	fdiv	d8, d8, d3
  411224:	fmul	d10, d10, d1
  411228:	fmul	d11, d11, d1
  41122c:	ldr	d1, [sp, #392]
  411230:	scvtf	d1, d1
  411234:	fdiv	d10, d10, d0
  411238:	fdiv	d11, d11, d0
  41123c:	fdiv	d9, d9, d1
  411240:	cmp	w0, #0x1
  411244:	b.ne	411844 <main+0x14c4>  // b.any
  411248:	movi	d0, #0x0
  41124c:	fcmp	d10, d0
  411250:	fccmp	d11, d0, #0x0, eq	// eq = none
  411254:	b.ne	41165c <main+0x12dc>  // b.any
  411258:	adrp	x0, 420000 <_IO_stdin_used>
  41125c:	add	x0, x0, #0xe60
  411260:	bl	410300 <getenv@plt>
  411264:	mov	x4, x0
  411268:	cbz	x0, 411648 <main+0x12c8>
  41126c:	adrp	x5, 420000 <_IO_stdin_used>
  411270:	add	x5, x5, #0x2c0
  411274:	adrp	x19, 440000 <exit@GLIBC_2.17>
  411278:	adrp	x0, 420000 <_IO_stdin_used>
  41127c:	str	x5, [sp, #344]
  411280:	ldr	x3, [x19, #416]
  411284:	mov	x2, #0x2e                  	// #46
  411288:	mov	x1, #0x1                   	// #1
  41128c:	add	x0, x0, #0xe70
  411290:	str	x4, [sp, #504]
  411294:	bl	410200 <fwrite@plt>
  411298:	ldr	x4, [sp, #504]
  41129c:	mov	x0, x4
  4112a0:	bl	412364 <print_json_string>
  4112a4:	adrp	x0, 420000 <_IO_stdin_used>
  4112a8:	ldr	x3, [x19, #416]
  4112ac:	mov	x2, #0xd                   	// #13
  4112b0:	mov	x1, #0x1                   	// #1
  4112b4:	add	x0, x0, #0xea0
  4112b8:	bl	410200 <fwrite@plt>
  4112bc:	ldr	x5, [sp, #344]
  4112c0:	mov	x0, x5
  4112c4:	bl	412364 <print_json_string>
  4112c8:	ldr	w1, [sp, #320]
  4112cc:	adrp	x0, 420000 <_IO_stdin_used>
  4112d0:	add	x0, x0, #0xeb0
  4112d4:	bl	4102d0 <printf@plt>
  4112d8:	mov	x1, x26
  4112dc:	mov	x0, x28
  4112e0:	bl	4124e4 <print_cpu_array>
  4112e4:	adrp	x0, 420000 <_IO_stdin_used>
  4112e8:	ldr	w2, [sp, #368]
  4112ec:	add	x0, x0, #0xed0
  4112f0:	ldr	w3, [sp, #400]
  4112f4:	ldr	w1, [sp, #432]
  4112f8:	bl	4102d0 <printf@plt>
  4112fc:	ldr	x0, [sp, #416]
  411300:	mov	x1, x26
  411304:	bl	4124e4 <print_cpu_array>
  411308:	ldr	x3, [x19, #416]
  41130c:	adrp	x0, 420000 <_IO_stdin_used>
  411310:	mov	x2, #0x13                  	// #19
  411314:	mov	x1, #0x1                   	// #1
  411318:	add	x0, x0, #0xf58
  41131c:	bl	410200 <fwrite@plt>
  411320:	mov	x1, x26
  411324:	ldr	x0, [sp, #328]
  411328:	bl	4124e4 <print_cpu_array>
  41132c:	ldr	w0, [sp, #436]
  411330:	adrp	x4, 420000 <_IO_stdin_used>
  411334:	adrp	x1, 420000 <_IO_stdin_used>
  411338:	add	x1, x1, #0x2d0
  41133c:	add	x4, x4, #0x2d8
  411340:	str	x20, [sp, #104]
  411344:	ldrb	w2, [sp, #732]
  411348:	fmov	d1, d9
  41134c:	fmov	d0, d8
  411350:	ldrb	w8, [sp, #772]
  411354:	cmp	w0, #0x0
  411358:	csel	x5, x1, x4, ne	// ne = any
  41135c:	adrp	x0, 420000 <_IO_stdin_used>
  411360:	ldr	x9, [sp, #448]
  411364:	cmp	w21, #0x0
  411368:	csel	x7, x1, x4, ne	// ne = any
  41136c:	cmp	w2, #0x0
  411370:	csel	x2, x1, x4, ne	// ne = any
  411374:	add	x0, x0, #0xf70
  411378:	ldr	x14, [sp, #720]
  41137c:	cmp	w8, #0x0
  411380:	csel	x8, x1, x4, ne	// ne = any
  411384:	cmp	w22, #0x0
  411388:	csel	x4, x1, x4, ne	// ne = any
  41138c:	ldr	x1, [sp, #488]
  411390:	stp	x4, x9, [sp, #72]
  411394:	mov	w4, #0x40000               	// #262144
  411398:	ldr	x9, [sp, #464]
  41139c:	str	x14, [sp, #16]
  4113a0:	stp	x8, x1, [sp, #56]
  4113a4:	str	x9, [sp, #88]
  4113a8:	ldr	x9, [sp, #496]
  4113ac:	ldr	w8, [sp, #728]
  4113b0:	ldr	x11, [sp, #744]
  4113b4:	str	x9, [sp, #96]
  4113b8:	ldr	x14, [sp, #760]
  4113bc:	str	w8, [sp, #24]
  4113c0:	ldr	x9, [sp, #528]
  4113c4:	stp	x2, x11, [sp, #32]
  4113c8:	str	x14, [sp, #48]
  4113cc:	ldp	x1, x2, [sp, #376]
  4113d0:	ldr	x3, [sp, #408]
  4113d4:	ldr	x6, [sp, #600]
  4113d8:	ldr	x13, [sp, #664]
  4113dc:	ldr	x12, [sp, #680]
  4113e0:	ldr	x8, [sp, #704]
  4113e4:	ldr	x11, [sp, #712]
  4113e8:	str	x9, [sp, #112]
  4113ec:	ldr	x9, [sp, #568]
  4113f0:	str	x13, [sp, #136]
  4113f4:	str	x12, [sp, #160]
  4113f8:	stp	x8, x11, [sp]
  4113fc:	str	x9, [sp, #120]
  411400:	ldr	x9, [sp, #360]
  411404:	str	x27, [sp, #184]
  411408:	str	x9, [sp, #128]
  41140c:	ldr	x9, [sp, #472]
  411410:	str	x9, [sp, #144]
  411414:	ldr	x9, [sp, #392]
  411418:	str	x9, [sp, #152]
  41141c:	ldr	x9, [sp, #352]
  411420:	str	x9, [sp, #168]
  411424:	ldr	x9, [sp, #480]
  411428:	str	x9, [sp, #176]
  41142c:	bl	4102d0 <printf@plt>
  411430:	ldr	x3, [x19, #416]
  411434:	adrp	x0, 421000 <__dso_handle+0xff8>
  411438:	mov	x1, #0x1                   	// #1
  41143c:	mov	x2, #0x1b                  	// #27
  411440:	add	x0, x0, #0x280
  411444:	bl	410200 <fwrite@plt>
  411448:	ldr	x1, [x19, #416]
  41144c:	mov	w0, #0x5b                  	// #91
  411450:	bl	410070 <putc@plt>
  411454:	cbz	x26, 411490 <main+0x1110>
  411458:	adrp	x20, 421000 <__dso_handle+0xff8>
  41145c:	ldr	x21, [sp, #456]
  411460:	add	x20, x20, #0x278
  411464:	b	411474 <main+0x10f4>
  411468:	ldr	x1, [x19, #416]
  41146c:	mov	w0, #0x2c                  	// #44
  411470:	bl	410070 <putc@plt>
  411474:	ldr	x1, [sp, #336]
  411478:	mov	x0, x20
  41147c:	ldr	x1, [x1, x21, lsl #3]
  411480:	add	x21, x21, #0x1
  411484:	bl	4102d0 <printf@plt>
  411488:	cmp	x26, x21
  41148c:	b.ne	411468 <main+0x10e8>  // b.any
  411490:	ldr	x1, [x19, #416]
  411494:	mov	w0, #0x5d                  	// #93
  411498:	bl	410070 <putc@plt>
  41149c:	ldr	x8, [sp, #544]
  4114a0:	adrp	x0, 421000 <__dso_handle+0xff8>
  4114a4:	fmov	d1, d11
  4114a8:	fmov	d0, d10
  4114ac:	mov	x4, x25
  4114b0:	mov	x6, #0x0                   	// #0
  4114b4:	ldr	x1, [sp, #576]
  4114b8:	add	x0, x0, #0x2a0
  4114bc:	str	xzr, [sp, #40]
  4114c0:	ldr	x2, [sp, #424]
  4114c4:	str	x8, [sp, #16]
  4114c8:	ldr	x8, [sp, #552]
  4114cc:	str	x1, [sp]
  4114d0:	ldr	x1, [sp, #536]
  4114d4:	ldr	x3, [sp, #440]
  4114d8:	str	x8, [sp, #24]
  4114dc:	ldr	x8, [sp, #560]
  4114e0:	str	x1, [sp, #8]
  4114e4:	mov	x1, x2
  4114e8:	ldr	x7, [sp, #584]
  4114ec:	ldr	x5, [sp, #592]
  4114f0:	str	x8, [sp, #32]
  4114f4:	bl	4102d0 <printf@plt>
  4114f8:	ldr	x0, [sp, #416]
  4114fc:	bl	4101b0 <free@plt>
  411500:	ldr	x0, [sp, #328]
  411504:	bl	4101b0 <free@plt>
  411508:	ldr	x0, [sp, #336]
  41150c:	bl	4101b0 <free@plt>
  411510:	mov	x0, x23
  411514:	bl	4101b0 <free@plt>
  411518:	mov	x0, x24
  41151c:	bl	4101b0 <free@plt>
  411520:	mov	x0, x28
  411524:	bl	4101b0 <free@plt>
  411528:	mov	w0, #0x0                   	// #0
  41152c:	ldp	x29, x30, [sp, #192]
  411530:	ldp	x19, x20, [sp, #208]
  411534:	ldp	x21, x22, [sp, #224]
  411538:	ldp	x23, x24, [sp, #240]
  41153c:	ldp	x25, x26, [sp, #256]
  411540:	ldp	x27, x28, [sp, #272]
  411544:	ldp	d8, d9, [sp, #288]
  411548:	ldp	d10, d11, [sp, #304]
  41154c:	add	sp, sp, #0x760
  411550:	ret
  411554:	mov	w1, #0x1                   	// #1
  411558:	add	x0, sp, #0x72c
  41155c:	stlrb	w1, [x0]
  411560:	mov	w1, #0x4                   	// #4
  411564:	mov	x0, x19
  411568:	mov	x20, #0x0                   	// #0
  41156c:	bl	411ee8 <broadcast_phase>
  411570:	b	411578 <main+0x11f8>
  411574:	mov	x20, x0
  411578:	mov	x1, #0x0                   	// #0
  41157c:	ldr	x0, [x24, x20, lsl #3]
  411580:	bl	4102f0 <pthread_join@plt>
  411584:	cbnz	w0, 411690 <main+0x1310>
  411588:	add	x0, x20, #0x1
  41158c:	cmp	x26, x0
  411590:	b.ne	411574 <main+0x11f4>  // b.any
  411594:	mov	x0, x23
  411598:	mov	x1, #0x0                   	// #0
  41159c:	b	4115b4 <main+0x1234>
  4115a0:	add	x0, x0, #0x88
  4115a4:	add	x2, x1, #0x1
  4115a8:	cmp	x1, x20
  4115ac:	b.eq	410ce4 <main+0x964>  // b.none
  4115b0:	mov	x1, x2
  4115b4:	ldr	w2, [x0, #28]
  4115b8:	cbz	w2, 4115a0 <main+0x1220>
  4115bc:	ldr	w0, [x0, #32]
  4115c0:	cbz	w0, 411628 <main+0x12a8>
  4115c4:	str	x1, [sp, #320]
  4115c8:	str	w2, [sp, #328]
  4115cc:	bl	410140 <strerror@plt>
  4115d0:	adrp	x4, 420000 <_IO_stdin_used>
  4115d4:	mov	x3, x0
  4115d8:	ldr	w2, [sp, #328]
  4115dc:	add	x0, x4, #0x10
  4115e0:	ldr	x1, [sp, #320]
  4115e4:	bl	411de0 <failf>
  4115e8:	cmp	w3, w4
  4115ec:	cset	w2, eq	// eq = none
  4115f0:	b	411094 <main+0xd14>
  4115f4:	cbz	w21, 411600 <main+0x1280>
  4115f8:	ldrb	w21, [x0, #88]
  4115fc:	cbnz	w21, 411074 <main+0xcf4>
  411600:	mov	w21, #0x0                   	// #0
  411604:	b	411074 <main+0xcf4>
  411608:	eor	w4, w4, #0x1
  41160c:	cmp	x3, #0x0
  411610:	cset	w3, eq	// eq = none
  411614:	orr	w3, w3, w4
  411618:	cbz	w3, 411048 <main+0xcc8>
  41161c:	adrp	x0, 420000 <_IO_stdin_used>
  411620:	add	x0, x0, #0xb70
  411624:	bl	411de0 <failf>
  411628:	adrp	x0, 420000 <_IO_stdin_used>
  41162c:	add	x0, x0, #0x38
  411630:	bl	411de0 <failf>
  411634:	bl	410140 <strerror@plt>
  411638:	adrp	x2, 420000 <_IO_stdin_used>
  41163c:	mov	x1, x0
  411640:	add	x0, x2, #0x908
  411644:	bl	411de0 <failf>
  411648:	adrp	x4, 420000 <_IO_stdin_used>
  41164c:	adrp	x5, 420000 <_IO_stdin_used>
  411650:	add	x4, x4, #0x160
  411654:	add	x5, x5, #0x2c0
  411658:	b	411274 <main+0xef4>
  41165c:	adrp	x0, 420000 <_IO_stdin_used>
  411660:	add	x0, x0, #0xe30
  411664:	bl	411de0 <failf>
  411668:	mov	w21, #0x16                  	// #22
  41166c:	mov	w0, w21
  411670:	bl	410140 <strerror@plt>
  411674:	adrp	x2, 420000 <_IO_stdin_used>
  411678:	mov	x1, x0
  41167c:	add	x0, x2, #0xae8
  411680:	bl	411de0 <failf>
  411684:	adrp	x0, 420000 <_IO_stdin_used>
  411688:	add	x0, x0, #0xb08
  41168c:	bl	411de0 <failf>
  411690:	bl	410140 <strerror@plt>
  411694:	adrp	x2, 420000 <_IO_stdin_used>
  411698:	mov	x1, x0
  41169c:	add	x0, x2, #0x170
  4116a0:	bl	411de0 <failf>
  4116a4:	bl	410140 <strerror@plt>
  4116a8:	adrp	x2, 420000 <_IO_stdin_used>
  4116ac:	mov	x1, x0
  4116b0:	add	x0, x2, #0x8c8
  4116b4:	bl	411de0 <failf>
  4116b8:	bl	410140 <strerror@plt>
  4116bc:	adrp	x2, 420000 <_IO_stdin_used>
  4116c0:	mov	x1, x0
  4116c4:	add	x0, x2, #0x8a8
  4116c8:	bl	411de0 <failf>
  4116cc:	adrp	x0, 420000 <_IO_stdin_used>
  4116d0:	mov	x2, x1
  4116d4:	ldr	w3, [sp, #400]
  4116d8:	add	x0, x0, #0xab8
  4116dc:	ldr	w1, [sp, #320]
  4116e0:	bl	411de0 <failf>
  4116e4:	adrp	x0, 420000 <_IO_stdin_used>
  4116e8:	add	x0, x0, #0xa88
  4116ec:	bl	411de0 <failf>
  4116f0:	adrp	x0, 420000 <_IO_stdin_used>
  4116f4:	add	x0, x0, #0xa58
  4116f8:	bl	411de0 <failf>
  4116fc:	adrp	x0, 420000 <_IO_stdin_used>
  411700:	add	x0, x0, #0xa48
  411704:	bl	4125c0 <read_usage.part.0>
  411708:	mov	x0, x19
  41170c:	bl	410310 <pthread_mutex_lock@plt>
  411710:	cbz	w0, 41172c <main+0x13ac>
  411714:	b	4117d4 <main+0x1454>
  411718:	cbnz	x27, 4117a0 <main+0x1420>
  41171c:	mov	x1, x19
  411720:	add	x0, sp, #0x6f8
  411724:	bl	4101c0 <pthread_cond_wait@plt>
  411728:	cbnz	w0, 41178c <main+0x140c>
  41172c:	ldr	x0, [sp, #1856]
  411730:	ldr	x27, [sp, #1864]
  411734:	cmp	x0, x26
  411738:	b.ne	411718 <main+0x1398>  // b.any
  41173c:	mov	x0, x19
  411740:	bl	410340 <pthread_mutex_unlock@plt>
  411744:	cbnz	w0, 4117ac <main+0x142c>
  411748:	cbz	x27, 410d44 <main+0x9c4>
  41174c:	mov	x0, x19
  411750:	bl	4126c0 <stop_workers>
  411754:	mov	x1, x26
  411758:	mov	x0, x24
  41175c:	bl	412300 <join_workers>
  411760:	mov	x0, x23
  411764:	mov	x1, x26
  411768:	bl	411e70 <fail_if_worker_error>
  41176c:	adrp	x0, 420000 <_IO_stdin_used>
  411770:	add	x0, x0, #0xa18
  411774:	bl	411de0 <failf>
  411778:	bl	410140 <strerror@plt>
  41177c:	adrp	x2, 420000 <_IO_stdin_used>
  411780:	mov	x1, x0
  411784:	add	x0, x2, #0x968
  411788:	bl	411de0 <failf>
  41178c:	bl	410140 <strerror@plt>
  411790:	adrp	x2, 420000 <_IO_stdin_used>
  411794:	mov	x1, x0
  411798:	add	x0, x2, #0x9b8
  41179c:	bl	411de0 <failf>
  4117a0:	mov	x0, x19
  4117a4:	bl	410340 <pthread_mutex_unlock@plt>
  4117a8:	cbz	w0, 41174c <main+0x13cc>
  4117ac:	bl	410140 <strerror@plt>
  4117b0:	adrp	x2, 420000 <_IO_stdin_used>
  4117b4:	mov	x1, x0
  4117b8:	add	x0, x2, #0x9e8
  4117bc:	bl	411de0 <failf>
  4117c0:	bl	410140 <strerror@plt>
  4117c4:	adrp	x2, 420000 <_IO_stdin_used>
  4117c8:	mov	x1, x0
  4117cc:	add	x0, x2, #0x948
  4117d0:	bl	411de0 <failf>
  4117d4:	bl	410140 <strerror@plt>
  4117d8:	adrp	x2, 420000 <_IO_stdin_used>
  4117dc:	mov	x1, x0
  4117e0:	add	x0, x2, #0x988
  4117e4:	bl	411de0 <failf>
  4117e8:	bl	410140 <strerror@plt>
  4117ec:	adrp	x2, 420000 <_IO_stdin_used>
  4117f0:	mov	x1, x0
  4117f4:	add	x0, x2, #0x928
  4117f8:	bl	411de0 <failf>
  4117fc:	adrp	x0, 420000 <_IO_stdin_used>
  411800:	add	x0, x0, #0xba8
  411804:	bl	411de0 <failf>
  411808:	mov	w2, w22
  41180c:	mov	x25, #0x0                   	// #0
  411810:	str	xzr, [sp, #488]
  411814:	mov	x27, #0x0                   	// #0
  411818:	b	4110e0 <main+0xd60>
  41181c:	bl	4102e0 <__errno_location@plt>
  411820:	ldr	w0, [x0]
  411824:	bl	410140 <strerror@plt>
  411828:	adrp	x2, 420000 <_IO_stdin_used>
  41182c:	mov	x1, x0
  411830:	add	x0, x2, #0xb48
  411834:	bl	411de0 <failf>
  411838:	adrp	x0, 420000 <_IO_stdin_used>
  41183c:	add	x0, x0, #0xbe0
  411840:	bl	411de0 <failf>
  411844:	adrp	x0, 420000 <_IO_stdin_used>
  411848:	add	x0, x0, #0xe60
  41184c:	bl	410300 <getenv@plt>
  411850:	mov	x4, x0
  411854:	cbz	x0, 411870 <main+0x14f0>
  411858:	adrp	x5, 420000 <_IO_stdin_used>
  41185c:	add	x5, x5, #0x2c8
  411860:	b	411274 <main+0xef4>
  411864:	adrp	x0, 420000 <_IO_stdin_used>
  411868:	add	x0, x0, #0xdf8
  41186c:	bl	411de0 <failf>
  411870:	adrp	x4, 420000 <_IO_stdin_used>
  411874:	add	x4, x4, #0x160
  411878:	b	411858 <main+0x14d8>
  41187c:	bl	410140 <strerror@plt>
  411880:	adrp	x2, 420000 <_IO_stdin_used>
  411884:	mov	x1, x0
  411888:	add	x0, x2, #0xdd8
  41188c:	bl	411de0 <failf>
  411890:	bl	410140 <strerror@plt>
  411894:	adrp	x2, 420000 <_IO_stdin_used>
  411898:	mov	x1, x0
  41189c:	add	x0, x2, #0xdb8
  4118a0:	bl	411de0 <failf>
  4118a4:	bl	4102e0 <__errno_location@plt>
  4118a8:	ldr	w0, [x0]
  4118ac:	bl	410140 <strerror@plt>
  4118b0:	adrp	x2, 420000 <_IO_stdin_used>
  4118b4:	mov	x1, x0
  4118b8:	add	x0, x2, #0xda0
  4118bc:	bl	411de0 <failf>
  4118c0:	bl	4102e0 <__errno_location@plt>
  4118c4:	ldr	w0, [x0]
  4118c8:	bl	410140 <strerror@plt>
  4118cc:	adrp	x2, 420000 <_IO_stdin_used>
  4118d0:	mov	x1, x0
  4118d4:	add	x0, x2, #0xd88
  4118d8:	bl	411de0 <failf>
  4118dc:	adrp	x0, 420000 <_IO_stdin_used>
  4118e0:	add	x0, x0, #0xd58
  4118e4:	bl	411de0 <failf>
  4118e8:	adrp	x0, 420000 <_IO_stdin_used>
  4118ec:	add	x0, x0, #0xd38
  4118f0:	bl	411de0 <failf>
  4118f4:	adrp	x0, 420000 <_IO_stdin_used>
  4118f8:	add	x0, x0, #0xc98
  4118fc:	bl	411de0 <failf>
  411900:	adrp	x0, 420000 <_IO_stdin_used>
  411904:	add	x0, x0, #0xc68
  411908:	bl	411de0 <failf>
  41190c:	cmp	x26, x27
  411910:	ccmp	x26, x0, #0x0, ls	// ls = plast
  411914:	b.ne	411984 <main+0x1604>  // b.any
  411918:	cbz	w2, 4118f4 <main+0x1574>
  41191c:	mov	x0, #0x3fffffffffff        	// #70368744177663
  411920:	cmp	x27, x0
  411924:	b.hi	411978 <main+0x15f8>  // b.pmore
  411928:	lsl	x1, x27, #18
  41192c:	mvn	x0, x27, lsl #18
  411930:	str	x1, [sp, #424]
  411934:	cmp	x26, x0, lsr #18
  411938:	b.hi	41196c <main+0x15ec>  // b.pmore
  41193c:	lsl	x0, x26, #18
  411940:	lsl	x1, x27, #18
  411944:	adds	x0, x0, x1
  411948:	str	x0, [sp, #440]
  41194c:	b.cc	411110 <main+0xd90>  // b.lo, b.ul, b.last
  411950:	adrp	x0, 420000 <_IO_stdin_used>
  411954:	add	x0, x0, #0xd10
  411958:	bl	411de0 <failf>
  41195c:	adrp	x0, 420000 <_IO_stdin_used>
  411960:	ldr	x1, [sp, #456]
  411964:	add	x0, x0, #0xc00
  411968:	bl	411de0 <failf>
  41196c:	adrp	x0, 420000 <_IO_stdin_used>
  411970:	add	x0, x0, #0xce8
  411974:	bl	411de0 <failf>
  411978:	adrp	x0, 420000 <_IO_stdin_used>
  41197c:	add	x0, x0, #0xcc8
  411980:	bl	411de0 <failf>
  411984:	adrp	x0, 420000 <_IO_stdin_used>
  411988:	add	x0, x0, #0xc38
  41198c:	bl	411de0 <failf>
  411990:	adrp	x0, 420000 <_IO_stdin_used>
  411994:	add	x0, x0, #0x2e0
  411998:	bl	4125c0 <read_usage.part.0>
  41199c:	adrp	x0, 420000 <_IO_stdin_used>
  4119a0:	mov	x1, x23
  4119a4:	add	x0, x0, #0x590
  4119a8:	bl	411de0 <failf>
  4119ac:	mov	x0, x27
  4119b0:	bl	4101b0 <free@plt>
  4119b4:	ldr	x0, [sp, #368]
  4119b8:	bl	4101b0 <free@plt>
  4119bc:	mov	x1, x23
  4119c0:	adrp	x0, 420000 <_IO_stdin_used>
  4119c4:	add	x0, x0, #0x490
  4119c8:	bl	411de0 <failf>
  4119cc:	ldr	x0, [sp, #368]
  4119d0:	bl	4101b0 <free@plt>
  4119d4:	mov	x0, x27
  4119d8:	bl	4101b0 <free@plt>
  4119dc:	adrp	x0, 420000 <_IO_stdin_used>
  4119e0:	add	x0, x0, #0x540
  4119e4:	bl	411de0 <failf>
  4119e8:	mov	x0, x27
  4119ec:	bl	4101b0 <free@plt>
  4119f0:	ldr	x0, [sp, #368]
  4119f4:	bl	4101b0 <free@plt>
  4119f8:	ldr	w0, [x25]
  4119fc:	bl	410140 <strerror@plt>
  411a00:	adrp	x2, 420000 <_IO_stdin_used>
  411a04:	mov	x1, x0
  411a08:	add	x0, x2, #0x520
  411a0c:	bl	411de0 <failf>
  411a10:	mov	x0, x27
  411a14:	bl	4101b0 <free@plt>
  411a18:	ldr	x0, [sp, #368]
  411a1c:	bl	4101b0 <free@plt>
  411a20:	adrp	x0, 420000 <_IO_stdin_used>
  411a24:	add	x0, x0, #0x500
  411a28:	bl	411de0 <failf>
  411a2c:	adrp	x1, 420000 <_IO_stdin_used>
  411a30:	adrp	x0, 420000 <_IO_stdin_used>
  411a34:	mov	x2, x23
  411a38:	add	x1, x1, #0x580
  411a3c:	add	x0, x0, #0xc0
  411a40:	bl	411de0 <failf>
  411a44:	adrp	x1, 420000 <_IO_stdin_used>
  411a48:	adrp	x0, 420000 <_IO_stdin_used>
  411a4c:	mov	x2, x23
  411a50:	add	x1, x1, #0x3d0
  411a54:	add	x0, x0, #0x3e0
  411a58:	bl	411de0 <failf>
  411a5c:	adrp	x0, 420000 <_IO_stdin_used>
  411a60:	mov	x1, x23
  411a64:	add	x0, x0, #0x3a8
  411a68:	bl	411de0 <failf>
  411a6c:	ldr	x2, [sp, #392]
  411a70:	adrp	x1, 420000 <_IO_stdin_used>
  411a74:	adrp	x0, 440000 <exit@GLIBC_2.17>
  411a78:	add	x1, x1, #0x2f8
  411a7c:	ldr	x0, [x0, #408]
  411a80:	ldr	x2, [x2]
  411a84:	bl	410350 <fprintf@plt>
  411a88:	ldr	x1, [sp, #328]
  411a8c:	adrp	x0, 420000 <_IO_stdin_used>
  411a90:	add	x0, x0, #0x380
  411a94:	ldr	x1, [x1]
  411a98:	bl	411de0 <failf>
  411a9c:	adrp	x1, 420000 <_IO_stdin_used>
  411aa0:	adrp	x0, 420000 <_IO_stdin_used>
  411aa4:	mov	x2, x26
  411aa8:	add	x1, x1, #0x4c0
  411aac:	add	x0, x0, #0x3e0
  411ab0:	bl	411de0 <failf>
  411ab4:	adrp	x0, 420000 <_IO_stdin_used>
  411ab8:	ldr	w1, [sp, #320]
  411abc:	add	x0, x0, #0x6d0
  411ac0:	bl	411de0 <failf>
  411ac4:	ldr	x0, [sp, #368]
  411ac8:	bl	4101b0 <free@plt>
  411acc:	bl	4102e0 <__errno_location@plt>
  411ad0:	ldr	w0, [x0]
  411ad4:	bl	410140 <strerror@plt>
  411ad8:	adrp	x2, 420000 <_IO_stdin_used>
  411adc:	mov	x1, x0
  411ae0:	add	x0, x2, #0x468
  411ae4:	bl	411de0 <failf>
  411ae8:	bl	4102e0 <__errno_location@plt>
  411aec:	ldr	w0, [x0]
  411af0:	bl	410140 <strerror@plt>
  411af4:	adrp	x2, 420000 <_IO_stdin_used>
  411af8:	mov	x1, x0
  411afc:	add	x0, x2, #0x448
  411b00:	bl	411de0 <failf>
  411b04:	adrp	x0, 420000 <_IO_stdin_used>
  411b08:	add	x0, x0, #0x678
  411b0c:	bl	411de0 <failf>
  411b10:	adrp	x0, 420000 <_IO_stdin_used>
  411b14:	add	x0, x0, #0x6a8
  411b18:	bl	411de0 <failf>
  411b1c:	bl	410140 <strerror@plt>
  411b20:	adrp	x2, 420000 <_IO_stdin_used>
  411b24:	mov	x1, x0
  411b28:	add	x0, x2, #0x7c0
  411b2c:	bl	411de0 <failf>
  411b30:	bl	410140 <strerror@plt>
  411b34:	adrp	x2, 420000 <_IO_stdin_used>
  411b38:	mov	x1, x0
  411b3c:	add	x0, x2, #0x7a8
  411b40:	bl	411de0 <failf>
  411b44:	ldr	w0, [sp, #660]
  411b48:	bl	410140 <strerror@plt>
  411b4c:	adrp	x3, 420000 <_IO_stdin_used>
  411b50:	mov	x2, x0
  411b54:	ldr	w1, [sp, #432]
  411b58:	add	x0, x3, #0x770
  411b5c:	bl	411de0 <failf>
  411b60:	adrp	x0, 420000 <_IO_stdin_used>
  411b64:	ldr	w1, [sp, #320]
  411b68:	add	x0, x0, #0x748
  411b6c:	bl	411de0 <failf>
  411b70:	adrp	x1, 420000 <_IO_stdin_used>
  411b74:	adrp	x0, 420000 <_IO_stdin_used>
  411b78:	mov	x2, x23
  411b7c:	add	x1, x1, #0x3d0
  411b80:	add	x0, x0, #0xc0
  411b84:	bl	411de0 <failf>
  411b88:	ldr	x2, [sp, #392]
  411b8c:	adrp	x1, 420000 <_IO_stdin_used>
  411b90:	adrp	x0, 440000 <exit@GLIBC_2.17>
  411b94:	add	x1, x1, #0x2f8
  411b98:	ldr	x0, [x0, #408]
  411b9c:	ldr	x2, [x2]
  411ba0:	bl	410350 <fprintf@plt>
  411ba4:	adrp	x0, 420000 <_IO_stdin_used>
  411ba8:	ldr	x1, [x20]
  411bac:	add	x0, x0, #0x618
  411bb0:	bl	411de0 <failf>
  411bb4:	adrp	x0, 420000 <_IO_stdin_used>
  411bb8:	add	x0, x0, #0x418
  411bbc:	bl	411de0 <failf>
  411bc0:	ldr	x2, [sp, #392]
  411bc4:	adrp	x1, 420000 <_IO_stdin_used>
  411bc8:	adrp	x0, 440000 <exit@GLIBC_2.17>
  411bcc:	add	x1, x1, #0x2f8
  411bd0:	ldr	x0, [x0, #408]
  411bd4:	ldr	x2, [x2]
  411bd8:	bl	410350 <fprintf@plt>
  411bdc:	adrp	x0, 420000 <_IO_stdin_used>
  411be0:	add	x0, x0, #0x630
  411be4:	bl	411de0 <failf>
  411be8:	bl	410140 <strerror@plt>
  411bec:	adrp	x2, 420000 <_IO_stdin_used>
  411bf0:	mov	x1, x0
  411bf4:	add	x0, x2, #0x818
  411bf8:	bl	411de0 <failf>
  411bfc:	bl	410140 <strerror@plt>
  411c00:	adrp	x2, 420000 <_IO_stdin_used>
  411c04:	mov	x1, x0
  411c08:	add	x0, x2, #0x838
  411c0c:	bl	411de0 <failf>
  411c10:	bl	410140 <strerror@plt>
  411c14:	adrp	x3, 420000 <_IO_stdin_used>
  411c18:	mov	x2, x0
  411c1c:	mov	x1, x20
  411c20:	add	x0, x3, #0x7f8
  411c24:	bl	411de0 <failf>
  411c28:	bl	4102e0 <__errno_location@plt>
  411c2c:	ldr	w0, [x0]
  411c30:	bl	410140 <strerror@plt>
  411c34:	adrp	x2, 420000 <_IO_stdin_used>
  411c38:	mov	x1, x0
  411c3c:	add	x0, x2, #0x7d8
  411c40:	bl	411de0 <failf>
  411c44:	bl	410140 <strerror@plt>
  411c48:	adrp	x2, 420000 <_IO_stdin_used>
  411c4c:	mov	x1, x0
  411c50:	add	x0, x2, #0x858
  411c54:	bl	411de0 <failf>
  411c58:	bl	410140 <strerror@plt>
  411c5c:	adrp	x2, 420000 <_IO_stdin_used>
  411c60:	mov	x1, x0
  411c64:	add	x0, x2, #0x898
  411c68:	bl	411de0 <failf>
  411c6c:	adrp	x0, 420000 <_IO_stdin_used>
  411c70:	add	x0, x0, #0x878
  411c74:	bl	411de0 <failf>
  411c78:	bl	410140 <strerror@plt>
  411c7c:	adrp	x2, 420000 <_IO_stdin_used>
  411c80:	mov	x1, x0
  411c84:	add	x0, x2, #0x8e8
  411c88:	bl	411de0 <failf>
  411c8c:	nop
  411c90:	nop
  411c94:	nop
  411c98:	nop
  411c9c:	nop
  411ca0:	nop
  411ca4:	nop
  411ca8:	nop
  411cac:	nop
  411cb0:	nop
  411cb4:	nop
  411cb8:	nop
  411cbc:	nop

0000000000411cc0 <_start>:
  411cc0:	bti	c
  411cc4:	mov	x29, #0x0                   	// #0
  411cc8:	mov	x30, #0x0                   	// #0
  411ccc:	mov	x5, x0
  411cd0:	ldr	x1, [sp]
  411cd4:	add	x2, sp, #0x8
  411cd8:	mov	x6, sp
  411cdc:	adrp	x0, 411000 <main+0xc80>
  411ce0:	add	x0, x0, #0xcf4
  411ce4:	mov	x3, #0x0                   	// #0
  411ce8:	mov	x4, #0x0                   	// #0
  411cec:	bl	410050 <__libc_start_main@plt>
  411cf0:	bl	410170 <abort@plt>

0000000000411cf4 <__wrap_main>:
  411cf4:	bti	c
  411cf8:	b	410380 <main>
  411cfc:	nop

0000000000411d00 <_dl_relocate_static_pie>:
  411d00:	bti	c
  411d04:	ret

0000000000411d08 <call_weak_fn>:
  411d08:	adrp	x0, 43f000 <__FRAME_END__+0x1d51c>
  411d0c:	ldr	x0, [x0, #4056]
  411d10:	cbz	x0, 411d18 <call_weak_fn+0x10>
  411d14:	b	410160 <__gmon_start__@plt>
  411d18:	ret
  411d1c:	nop

0000000000411d20 <deregister_tm_clones>:
  411d20:	adrp	x0, 440000 <exit@GLIBC_2.17>
  411d24:	adrp	x1, 440000 <exit@GLIBC_2.17>
  411d28:	add	x0, x0, #0x198
  411d2c:	add	x1, x1, #0x198
  411d30:	cmp	x1, x0
  411d34:	b.eq	411d4c <deregister_tm_clones+0x2c>  // b.none
  411d38:	adrp	x1, 43f000 <__FRAME_END__+0x1d51c>
  411d3c:	ldr	x1, [x1, #4048]
  411d40:	cbz	x1, 411d4c <deregister_tm_clones+0x2c>
  411d44:	mov	x16, x1
  411d48:	br	x16
  411d4c:	ret

0000000000411d50 <register_tm_clones>:
  411d50:	adrp	x0, 440000 <exit@GLIBC_2.17>
  411d54:	adrp	x1, 440000 <exit@GLIBC_2.17>
  411d58:	add	x0, x0, #0x198
  411d5c:	add	x1, x1, #0x198
  411d60:	sub	x1, x1, x0
  411d64:	lsr	x2, x1, #63
  411d68:	add	x1, x2, x1, asr #3
  411d6c:	asr	x1, x1, #1
  411d70:	cbz	x1, 411d88 <register_tm_clones+0x38>
  411d74:	adrp	x2, 43f000 <__FRAME_END__+0x1d51c>
  411d78:	ldr	x2, [x2, #4064]
  411d7c:	cbz	x2, 411d88 <register_tm_clones+0x38>
  411d80:	mov	x16, x2
  411d84:	br	x16
  411d88:	ret

0000000000411d8c <__do_global_dtors_aux>:
  411d8c:	paciasp
  411d90:	stp	x29, x30, [sp, #-32]!
  411d94:	mov	x29, sp
  411d98:	str	x19, [sp, #16]
  411d9c:	adrp	x19, 440000 <exit@GLIBC_2.17>
  411da0:	ldrb	w0, [x19, #424]
  411da4:	cbnz	w0, 411db4 <__do_global_dtors_aux+0x28>
  411da8:	bl	411d20 <deregister_tm_clones>
  411dac:	mov	w0, #0x1                   	// #1
  411db0:	strb	w0, [x19, #424]
  411db4:	ldr	x19, [sp, #16]
  411db8:	ldp	x29, x30, [sp], #32
  411dbc:	autiasp
  411dc0:	ret

0000000000411dc4 <frame_dummy>:
  411dc4:	bti	c
  411dc8:	b	411d50 <register_tm_clones>
  411dcc:	nop
  411dd0:	nop
  411dd4:	nop
  411dd8:	nop
  411ddc:	nop

0000000000411de0 <failf>:
  411de0:	stp	x29, x30, [sp, #-288]!
  411de4:	add	x11, sp, #0x120
  411de8:	add	x8, sp, #0x120
  411dec:	mov	x29, sp
  411df0:	add	x10, sp, #0xe0
  411df4:	mov	w9, #0xffffffc8            	// #-56
  411df8:	stp	x8, x11, [sp, #64]
  411dfc:	mov	w8, #0xffffff80            	// #-128
  411e00:	str	x10, [sp, #80]
  411e04:	str	w9, [sp, #88]
  411e08:	str	w8, [sp, #92]
  411e0c:	ldp	q16, q17, [sp, #64]
  411e10:	str	x19, [sp, #16]
  411e14:	adrp	x19, 440000 <exit@GLIBC_2.17>
  411e18:	stp	x1, x2, [sp, #232]
  411e1c:	mov	x1, x0
  411e20:	add	x2, sp, #0x20
  411e24:	ldr	x0, [x19, #408]
  411e28:	str	q0, [sp, #96]
  411e2c:	stp	q16, q17, [sp, #32]
  411e30:	str	q1, [sp, #112]
  411e34:	str	q2, [sp, #128]
  411e38:	str	q3, [sp, #144]
  411e3c:	str	q4, [sp, #160]
  411e40:	str	q5, [sp, #176]
  411e44:	str	q6, [sp, #192]
  411e48:	str	q7, [sp, #208]
  411e4c:	stp	x3, x4, [sp, #248]
  411e50:	stp	x5, x6, [sp, #264]
  411e54:	str	x7, [sp, #280]
  411e58:	bl	4102c0 <vfprintf@plt>
  411e5c:	ldr	x1, [x19, #408]
  411e60:	mov	w0, #0xa                   	// #10
  411e64:	bl	410080 <fputc@plt>
  411e68:	mov	w0, #0x2                   	// #2
  411e6c:	bl	410040 <exit@plt>

0000000000411e70 <fail_if_worker_error>:
  411e70:	cbz	x1, 411ee4 <fail_if_worker_error+0x74>
  411e74:	stp	x29, x30, [sp, #-32]!
  411e78:	mov	x29, sp
  411e7c:	stp	x19, x20, [sp, #16]
  411e80:	mov	x19, #0x0                   	// #0
  411e84:	b	411e98 <fail_if_worker_error+0x28>
  411e88:	add	x19, x19, #0x1
  411e8c:	add	x0, x0, #0x88
  411e90:	cmp	x1, x19
  411e94:	b.eq	411ec4 <fail_if_worker_error+0x54>  // b.none
  411e98:	ldr	w20, [x0, #28]
  411e9c:	cbz	w20, 411e88 <fail_if_worker_error+0x18>
  411ea0:	ldr	w0, [x0, #32]
  411ea4:	cbz	w0, 411ed0 <fail_if_worker_error+0x60>
  411ea8:	bl	410140 <strerror@plt>
  411eac:	adrp	x4, 420000 <_IO_stdin_used>
  411eb0:	mov	x3, x0
  411eb4:	mov	w2, w20
  411eb8:	mov	x1, x19
  411ebc:	add	x0, x4, #0x10
  411ec0:	bl	411de0 <failf>
  411ec4:	ldp	x19, x20, [sp, #16]
  411ec8:	ldp	x29, x30, [sp], #32
  411ecc:	ret
  411ed0:	adrp	x0, 420000 <_IO_stdin_used>
  411ed4:	mov	w2, w20
  411ed8:	mov	x1, x19
  411edc:	add	x0, x0, #0x38
  411ee0:	bl	411de0 <failf>
  411ee4:	ret

0000000000411ee8 <broadcast_phase>:
  411ee8:	stp	x29, x30, [sp, #-32]!
  411eec:	mov	x29, sp
  411ef0:	stp	x19, x20, [sp, #16]
  411ef4:	mov	w20, w1
  411ef8:	mov	x19, x0
  411efc:	bl	410310 <pthread_mutex_lock@plt>
  411f00:	cbnz	w0, 411f2c <broadcast_phase+0x44>
  411f04:	stlur	w20, [x19, #96]
  411f08:	add	x0, x19, #0x30
  411f0c:	bl	410110 <pthread_cond_broadcast@plt>
  411f10:	cbnz	w0, 411f54 <broadcast_phase+0x6c>
  411f14:	mov	x0, x19
  411f18:	bl	410340 <pthread_mutex_unlock@plt>
  411f1c:	cbnz	w0, 411f40 <broadcast_phase+0x58>
  411f20:	ldp	x19, x20, [sp, #16]
  411f24:	ldp	x29, x30, [sp], #32
  411f28:	ret
  411f2c:	bl	410140 <strerror@plt>
  411f30:	adrp	x2, 420000 <_IO_stdin_used>
  411f34:	mov	x1, x0
  411f38:	add	x0, x2, #0x68
  411f3c:	bl	411de0 <failf>
  411f40:	bl	410140 <strerror@plt>
  411f44:	adrp	x2, 420000 <_IO_stdin_used>
  411f48:	mov	x1, x0
  411f4c:	add	x0, x2, #0xa0
  411f50:	bl	411de0 <failf>
  411f54:	bl	410140 <strerror@plt>
  411f58:	adrp	x2, 420000 <_IO_stdin_used>
  411f5c:	mov	x1, x0
  411f60:	add	x0, x2, #0x80
  411f64:	bl	411de0 <failf>

0000000000411f68 <worker_wait_for_phase>:
  411f68:	stp	x29, x30, [sp, #-64]!
  411f6c:	mov	x29, sp
  411f70:	stp	x19, x20, [sp, #16]
  411f74:	mov	w20, w1
  411f78:	ldr	x19, [x0]
  411f7c:	str	x23, [sp, #48]
  411f80:	mov	x23, x0
  411f84:	mov	x0, x19
  411f88:	bl	410310 <pthread_mutex_lock@plt>
  411f8c:	cbnz	w0, 412000 <worker_wait_for_phase+0x98>
  411f90:	stp	x21, x22, [sp, #32]
  411f94:	add	x22, x19, #0x60
  411f98:	add	x21, x19, #0x30
  411f9c:	b	411fa8 <worker_wait_for_phase+0x40>
  411fa0:	bl	4101c0 <pthread_cond_wait@plt>
  411fa4:	cbnz	w0, 412020 <worker_wait_for_phase+0xb8>
  411fa8:	ldar	w2, [x22]
  411fac:	mov	x1, x19
  411fb0:	mov	x0, x21
  411fb4:	cmp	w2, w20
  411fb8:	b.eq	411fa0 <worker_wait_for_phase+0x38>  // b.none
  411fbc:	mov	x0, x19
  411fc0:	bl	410340 <pthread_mutex_unlock@plt>
  411fc4:	cbnz	w0, 411fdc <worker_wait_for_phase+0x74>
  411fc8:	ldp	x21, x22, [sp, #32]
  411fcc:	ldp	x19, x20, [sp, #16]
  411fd0:	ldr	x23, [sp, #48]
  411fd4:	ldp	x29, x30, [sp], #64
  411fd8:	ret
  411fdc:	ldr	w1, [x23, #28]
  411fe0:	cbnz	w1, 411fc8 <worker_wait_for_phase+0x60>
  411fe4:	mov	w1, #0x16                  	// #22
  411fe8:	ldp	x19, x20, [sp, #16]
  411fec:	ldp	x21, x22, [sp, #32]
  411ff0:	stp	w1, w0, [x23, #28]
  411ff4:	ldr	x23, [sp, #48]
  411ff8:	ldp	x29, x30, [sp], #64
  411ffc:	ret
  412000:	ldr	w1, [x23, #28]
  412004:	cbnz	w1, 411fcc <worker_wait_for_phase+0x64>
  412008:	mov	w1, #0x14                  	// #20
  41200c:	ldp	x19, x20, [sp, #16]
  412010:	stp	w1, w0, [x23, #28]
  412014:	ldr	x23, [sp, #48]
  412018:	ldp	x29, x30, [sp], #64
  41201c:	ret
  412020:	ldr	w1, [x23, #28]
  412024:	cbnz	w1, 411fbc <worker_wait_for_phase+0x54>
  412028:	mov	w1, #0x15                  	// #21
  41202c:	stp	w1, w0, [x23, #28]
  412030:	mov	x0, x19
  412034:	bl	410340 <pthread_mutex_unlock@plt>
  412038:	cbz	w0, 411fc8 <worker_wait_for_phase+0x60>
  41203c:	b	411fdc <worker_wait_for_phase+0x74>

0000000000412040 <parse_u64>:
  412040:	stp	x29, x30, [sp, #-64]!
  412044:	mov	x29, sp
  412048:	stp	x19, x20, [sp, #16]
  41204c:	mov	x19, x0
  412050:	str	x21, [sp, #32]
  412054:	mov	x21, x1
  412058:	str	xzr, [sp, #56]
  41205c:	bl	4102e0 <__errno_location@plt>
  412060:	mov	x20, x0
  412064:	mov	w2, #0xa                   	// #10
  412068:	mov	x0, x19
  41206c:	add	x1, sp, #0x38
  412070:	str	wzr, [x20]
  412074:	bl	4101e0 <strtoull@plt>
  412078:	ldrb	w2, [x19]
  41207c:	sub	w2, w2, #0x30
  412080:	and	w2, w2, #0xff
  412084:	cmp	w2, #0x9
  412088:	b.hi	4120b8 <parse_u64+0x78>  // b.pmore
  41208c:	ldr	w1, [x20]
  412090:	cbnz	w1, 4120b8 <parse_u64+0x78>
  412094:	ldr	x2, [sp, #56]
  412098:	cmp	x2, x19
  41209c:	b.eq	4120b8 <parse_u64+0x78>  // b.none
  4120a0:	ldrb	w1, [x2]
  4120a4:	cbnz	w1, 4120b8 <parse_u64+0x78>
  4120a8:	ldp	x19, x20, [sp, #16]
  4120ac:	ldr	x21, [sp, #32]
  4120b0:	ldp	x29, x30, [sp], #64
  4120b4:	ret
  4120b8:	adrp	x0, 420000 <_IO_stdin_used>
  4120bc:	mov	x2, x19
  4120c0:	mov	x1, x21
  4120c4:	add	x0, x0, #0xc0
  4120c8:	bl	411de0 <failf>

00000000004120cc <read_map_evidence>:
  4120cc:	mov	x2, x0
  4120d0:	adrp	x1, 420000 <_IO_stdin_used>
  4120d4:	stp	x29, x30, [sp, #-176]!
  4120d8:	adrp	x3, 420000 <_IO_stdin_used>
  4120dc:	mov	x29, sp
  4120e0:	add	x1, x1, #0xd0
  4120e4:	add	x0, x3, #0xd8
  4120e8:	stp	x19, x20, [sp, #16]
  4120ec:	mov	x19, x8
  4120f0:	stp	x23, x24, [sp, #48]
  4120f4:	stp	x25, x26, [sp, #64]
  4120f8:	stp	x27, x28, [sp, #80]
  4120fc:	str	x2, [sp, #112]
  412100:	bl	4100d0 <fopen@plt>
  412104:	cbz	x0, 4122e0 <read_map_evidence+0x214>
  412108:	adrp	x23, 420000 <_IO_stdin_used>
  41210c:	stp	x21, x22, [sp, #32]
  412110:	adrp	x21, 420000 <_IO_stdin_used>
  412114:	mov	x20, x0
  412118:	add	x21, x21, #0xf0
  41211c:	add	x23, x23, #0x100
  412120:	mov	w28, #0xffffffff            	// #-1
  412124:	mov	x27, #0x0                   	// #0
  412128:	mov	x25, #0x0                   	// #0
  41212c:	str	wzr, [sp, #108]
  412130:	mov	x24, #0x0                   	// #0
  412134:	mov	w26, #0x0                   	// #0
  412138:	stp	xzr, xzr, [sp, #136]
  41213c:	mov	w22, #0x0                   	// #0
  412140:	mov	x3, x20
  412144:	mov	w2, #0xa                   	// #10
  412148:	add	x1, sp, #0x90
  41214c:	add	x0, sp, #0x88
  412150:	bl	410330 <__getdelim@plt>
  412154:	tbnz	x0, #63, 4121c0 <read_map_evidence+0xf4>
  412158:	add	x3, sp, #0xa0
  41215c:	add	x2, sp, #0x98
  412160:	ldr	x0, [sp, #136]
  412164:	mov	x1, x21
  412168:	stp	xzr, xzr, [sp, #152]
  41216c:	bl	410280 <__isoc99_sscanf@plt>
  412170:	cmp	w0, #0x2
  412174:	b.eq	412204 <read_map_evidence+0x138>  // b.none
  412178:	cbz	w22, 412140 <read_map_evidence+0x74>
  41217c:	mov	x1, x23
  412180:	add	x2, sp, #0xa8
  412184:	ldr	x0, [sp, #136]
  412188:	str	wzr, [sp, #132]
  41218c:	str	xzr, [sp, #168]
  412190:	bl	410280 <__isoc99_sscanf@plt>
  412194:	cmp	w0, #0x1
  412198:	b.ne	412230 <read_map_evidence+0x164>  // b.any
  41219c:	mov	x3, x20
  4121a0:	mov	w2, #0xa                   	// #10
  4121a4:	ldr	x24, [sp, #168]
  4121a8:	add	x1, sp, #0x90
  4121ac:	add	x0, sp, #0x88
  4121b0:	bl	410330 <__getdelim@plt>
  4121b4:	tbz	x0, #63, 412158 <read_map_evidence+0x8c>
  4121b8:	nop
  4121bc:	nop
  4121c0:	ldr	x0, [sp, #136]
  4121c4:	bl	4101b0 <free@plt>
  4121c8:	mov	x0, x20
  4121cc:	bl	4100b0 <fclose@plt>
  4121d0:	ldp	x21, x22, [sp, #32]
  4121d4:	strb	w26, [x19]
  4121d8:	ldrb	w0, [sp, #108]
  4121dc:	stp	x24, x25, [x19, #8]
  4121e0:	str	x27, [x19, #24]
  4121e4:	str	w28, [x19, #32]
  4121e8:	strb	w0, [x19, #36]
  4121ec:	ldp	x19, x20, [sp, #16]
  4121f0:	ldp	x23, x24, [sp, #48]
  4121f4:	ldp	x25, x26, [sp, #64]
  4121f8:	ldp	x27, x28, [sp, #80]
  4121fc:	ldp	x29, x30, [sp], #176
  412200:	ret
  412204:	cbnz	w22, 4121c0 <read_map_evidence+0xf4>
  412208:	ldr	x1, [sp, #112]
  41220c:	ldr	x0, [sp, #152]
  412210:	cmp	x0, x1
  412214:	b.hi	412140 <read_map_evidence+0x74>  // b.pmore
  412218:	ldr	x0, [sp, #160]
  41221c:	cmp	x0, x1
  412220:	b.ls	412140 <read_map_evidence+0x74>  // b.plast
  412224:	mov	w26, #0x1                   	// #1
  412228:	mov	w22, w26
  41222c:	b	412140 <read_map_evidence+0x74>
  412230:	adrp	x1, 420000 <_IO_stdin_used>
  412234:	add	x2, sp, #0xa8
  412238:	ldr	x0, [sp, #136]
  41223c:	add	x1, x1, #0x118
  412240:	bl	410280 <__isoc99_sscanf@plt>
  412244:	cmp	w0, #0x1
  412248:	b.ne	412254 <read_map_evidence+0x188>  // b.any
  41224c:	ldr	x25, [sp, #168]
  412250:	b	412140 <read_map_evidence+0x74>
  412254:	adrp	x1, 420000 <_IO_stdin_used>
  412258:	add	x2, sp, #0xa8
  41225c:	ldr	x0, [sp, #136]
  412260:	add	x1, x1, #0x130
  412264:	bl	410280 <__isoc99_sscanf@plt>
  412268:	cmp	w0, #0x1
  41226c:	b.ne	412278 <read_map_evidence+0x1ac>  // b.any
  412270:	ldr	x27, [sp, #168]
  412274:	b	412140 <read_map_evidence+0x74>
  412278:	adrp	x1, 420000 <_IO_stdin_used>
  41227c:	add	x2, sp, #0x84
  412280:	ldr	x0, [sp, #136]
  412284:	add	x1, x1, #0x148
  412288:	bl	410280 <__isoc99_sscanf@plt>
  41228c:	cmp	w0, #0x1
  412290:	b.eq	4122d8 <read_map_evidence+0x20c>  // b.none
  412294:	ldr	x3, [sp, #136]
  412298:	adrp	x1, 420000 <_IO_stdin_used>
  41229c:	mov	x2, #0x8                   	// #8
  4122a0:	add	x1, x1, #0x158
  4122a4:	mov	x0, x3
  4122a8:	str	x3, [sp, #120]
  4122ac:	bl	4100f0 <strncmp@plt>
  4122b0:	cbnz	w0, 412140 <read_map_evidence+0x74>
  4122b4:	ldr	x3, [sp, #120]
  4122b8:	adrp	x1, 420000 <_IO_stdin_used>
  4122bc:	add	x1, x1, #0x168
  4122c0:	mov	x0, x3
  4122c4:	bl	410270 <strstr@plt>
  4122c8:	cmp	x0, #0x0
  4122cc:	cset	w0, ne	// ne = any
  4122d0:	str	w0, [sp, #108]
  4122d4:	b	412140 <read_map_evidence+0x74>
  4122d8:	ldr	w28, [sp, #132]
  4122dc:	b	412140 <read_map_evidence+0x74>
  4122e0:	mov	w26, #0x0                   	// #0
  4122e4:	mov	x24, #0x0                   	// #0
  4122e8:	str	wzr, [sp, #108]
  4122ec:	mov	x25, #0x0                   	// #0
  4122f0:	mov	x27, #0x0                   	// #0
  4122f4:	mov	w28, #0xffffffff            	// #-1
  4122f8:	b	4121d4 <read_map_evidence+0x108>
  4122fc:	nop

0000000000412300 <join_workers>:
  412300:	cbz	x1, 41234c <join_workers+0x4c>
  412304:	stp	x29, x30, [sp, #-48]!
  412308:	mov	x29, sp
  41230c:	stp	x19, x20, [sp, #16]
  412310:	mov	x20, x1
  412314:	mov	x19, #0x0                   	// #0
  412318:	str	x21, [sp, #32]
  41231c:	mov	x21, x0
  412320:	mov	x1, #0x0                   	// #0
  412324:	ldr	x0, [x21, x19, lsl #3]
  412328:	bl	4102f0 <pthread_join@plt>
  41232c:	cbnz	w0, 412350 <join_workers+0x50>
  412330:	add	x19, x19, #0x1
  412334:	cmp	x20, x19
  412338:	b.ne	412320 <join_workers+0x20>  // b.any
  41233c:	ldp	x19, x20, [sp, #16]
  412340:	ldr	x21, [sp, #32]
  412344:	ldp	x29, x30, [sp], #48
  412348:	ret
  41234c:	ret
  412350:	bl	410140 <strerror@plt>
  412354:	adrp	x2, 420000 <_IO_stdin_used>
  412358:	mov	x1, x0
  41235c:	add	x0, x2, #0x170
  412360:	bl	411de0 <failf>

0000000000412364 <print_json_string>:
  412364:	stp	x29, x30, [sp, #-48]!
  412368:	mov	x29, sp
  41236c:	stp	x19, x20, [sp, #16]
  412370:	adrp	x20, 440000 <exit@GLIBC_2.17>
  412374:	mov	x19, x0
  412378:	mov	w0, #0x22                  	// #34
  41237c:	ldr	x1, [x20, #416]
  412380:	bl	410070 <putc@plt>
  412384:	ldrb	w1, [x19]
  412388:	cbz	w1, 412414 <print_json_string+0xb0>
  41238c:	stp	x21, x22, [sp, #32]
  412390:	adrp	x21, 420000 <_IO_stdin_used>
  412394:	adrp	x22, 420000 <_IO_stdin_used>
  412398:	add	x21, x21, #0x1a0
  41239c:	add	x22, x22, #0x1c0
  4123a0:	b	4123d4 <print_json_string+0x70>
  4123a4:	cmp	w1, #0x9
  4123a8:	b.eq	412488 <print_json_string+0x124>  // b.none
  4123ac:	cmp	w1, #0xa
  4123b0:	b.ne	412428 <print_json_string+0xc4>  // b.any
  4123b4:	adrp	x0, 420000 <_IO_stdin_used>
  4123b8:	ldr	x3, [x20, #416]
  4123bc:	mov	x2, #0x2                   	// #2
  4123c0:	add	x0, x0, #0x1a8
  4123c4:	mov	x1, #0x1                   	// #1
  4123c8:	bl	410200 <fwrite@plt>
  4123cc:	ldrb	w1, [x19, #1]!
  4123d0:	cbz	w1, 412410 <print_json_string+0xac>
  4123d4:	cmp	w1, #0xc
  4123d8:	b.eq	412470 <print_json_string+0x10c>  // b.none
  4123dc:	b.ls	4123a4 <print_json_string+0x40>  // b.plast
  4123e0:	cmp	w1, #0x22
  4123e4:	b.eq	4124a4 <print_json_string+0x140>  // b.none
  4123e8:	cmp	w1, #0x5c
  4123ec:	b.ne	41244c <print_json_string+0xe8>  // b.any
  4123f0:	adrp	x0, 420000 <_IO_stdin_used>
  4123f4:	mov	x1, #0x1                   	// #1
  4123f8:	ldr	x3, [x20, #416]
  4123fc:	mov	x2, #0x2                   	// #2
  412400:	add	x0, x0, #0x190
  412404:	bl	410200 <fwrite@plt>
  412408:	ldrb	w1, [x19, #1]!
  41240c:	cbnz	w1, 4123d4 <print_json_string+0x70>
  412410:	ldp	x21, x22, [sp, #32]
  412414:	mov	w0, #0x22                  	// #34
  412418:	ldr	x1, [x20, #416]
  41241c:	ldp	x19, x20, [sp, #16]
  412420:	ldp	x29, x30, [sp], #48
  412424:	b	410070 <putc@plt>
  412428:	cmp	w1, #0x8
  41242c:	b.ne	4124d8 <print_json_string+0x174>  // b.any
  412430:	adrp	x0, 420000 <_IO_stdin_used>
  412434:	ldr	x3, [x20, #416]
  412438:	mov	x2, #0x2                   	// #2
  41243c:	mov	x1, #0x1                   	// #1
  412440:	add	x0, x0, #0x198
  412444:	bl	410200 <fwrite@plt>
  412448:	b	4123cc <print_json_string+0x68>
  41244c:	cmp	w1, #0xd
  412450:	b.ne	4124c0 <print_json_string+0x15c>  // b.any
  412454:	adrp	x0, 420000 <_IO_stdin_used>
  412458:	ldr	x3, [x20, #416]
  41245c:	mov	x2, #0x2                   	// #2
  412460:	mov	x1, #0x1                   	// #1
  412464:	add	x0, x0, #0x1b0
  412468:	bl	410200 <fwrite@plt>
  41246c:	b	4123cc <print_json_string+0x68>
  412470:	ldr	x3, [x20, #416]
  412474:	mov	x2, #0x2                   	// #2
  412478:	mov	x1, #0x1                   	// #1
  41247c:	mov	x0, x21
  412480:	bl	410200 <fwrite@plt>
  412484:	b	4123cc <print_json_string+0x68>
  412488:	adrp	x0, 420000 <_IO_stdin_used>
  41248c:	ldr	x3, [x20, #416]
  412490:	mov	x2, #0x2                   	// #2
  412494:	mov	x1, #0x1                   	// #1
  412498:	add	x0, x0, #0x1b8
  41249c:	bl	410200 <fwrite@plt>
  4124a0:	b	4123cc <print_json_string+0x68>
  4124a4:	adrp	x0, 420000 <_IO_stdin_used>
  4124a8:	ldr	x3, [x20, #416]
  4124ac:	mov	x2, #0x2                   	// #2
  4124b0:	mov	x1, #0x1                   	// #1
  4124b4:	add	x0, x0, #0x188
  4124b8:	bl	410200 <fwrite@plt>
  4124bc:	b	4123cc <print_json_string+0x68>
  4124c0:	cmp	w1, #0x1f
  4124c4:	b.ls	4124d8 <print_json_string+0x174>  // b.plast
  4124c8:	mov	w0, w1
  4124cc:	ldr	x1, [x20, #416]
  4124d0:	bl	410070 <putc@plt>
  4124d4:	b	4123cc <print_json_string+0x68>
  4124d8:	mov	x0, x22
  4124dc:	bl	4102d0 <printf@plt>
  4124e0:	b	4123cc <print_json_string+0x68>

00000000004124e4 <print_cpu_array>:
  4124e4:	stp	x29, x30, [sp, #-64]!
  4124e8:	mov	x29, sp
  4124ec:	str	x23, [sp, #48]
  4124f0:	adrp	x23, 440000 <exit@GLIBC_2.17>
  4124f4:	stp	x19, x20, [sp, #16]
  4124f8:	mov	x20, x1
  4124fc:	mov	x19, #0x0                   	// #0
  412500:	ldr	x1, [x23, #416]
  412504:	stp	x21, x22, [sp, #32]
  412508:	mov	x22, x0
  41250c:	adrp	x21, 420000 <_IO_stdin_used>
  412510:	mov	w0, #0x5b                  	// #91
  412514:	add	x21, x21, #0x1c8
  412518:	bl	410070 <putc@plt>
  41251c:	cbnz	x20, 41252c <print_cpu_array+0x48>
  412520:	b	412548 <print_cpu_array+0x64>
  412524:	ldr	x1, [x23, #416]
  412528:	bl	410070 <putc@plt>
  41252c:	ldr	w1, [x22, x19, lsl #2]
  412530:	mov	x0, x21
  412534:	add	x19, x19, #0x1
  412538:	bl	4102d0 <printf@plt>
  41253c:	mov	w0, #0x2c                  	// #44
  412540:	cmp	x20, x19
  412544:	b.ne	412524 <print_cpu_array+0x40>  // b.any
  412548:	ldr	x1, [x23, #416]
  41254c:	mov	w0, #0x5d                  	// #93
  412550:	ldp	x19, x20, [sp, #16]
  412554:	ldp	x21, x22, [sp, #32]
  412558:	ldr	x23, [sp, #48]
  41255c:	ldp	x29, x30, [sp], #64
  412560:	b	410070 <putc@plt>

0000000000412564 <now_ns.part.0>:
  412564:	stp	x29, x30, [sp, #-16]!
  412568:	mov	x29, sp
  41256c:	bl	4102e0 <__errno_location@plt>
  412570:	ldr	w0, [x0]
  412574:	bl	410140 <strerror@plt>
  412578:	adrp	x2, 420000 <_IO_stdin_used>
  41257c:	mov	x1, x0
  412580:	add	x0, x2, #0x1d0
  412584:	bl	411de0 <failf>

0000000000412588 <now_ns>:
  412588:	stp	x29, x30, [sp, #-32]!
  41258c:	mov	w0, #0x4                   	// #4
  412590:	mov	x29, sp
  412594:	add	x1, sp, #0x10
  412598:	bl	410090 <clock_gettime@plt>
  41259c:	cbnz	w0, 4125b8 <now_ns+0x30>
  4125a0:	ldp	x2, x1, [sp, #16]
  4125a4:	mov	x0, #0xca00                	// #51712
  4125a8:	movk	x0, #0x3b9a, lsl #16
  4125ac:	ldp	x29, x30, [sp], #32
  4125b0:	madd	x0, x2, x0, x1
  4125b4:	ret
  4125b8:	bl	412564 <now_ns.part.0>
  4125bc:	nop

00000000004125c0 <read_usage.part.0>:
  4125c0:	stp	x29, x30, [sp, #-32]!
  4125c4:	mov	x29, sp
  4125c8:	str	x19, [sp, #16]
  4125cc:	mov	x19, x0
  4125d0:	bl	4102e0 <__errno_location@plt>
  4125d4:	ldr	w0, [x0]
  4125d8:	bl	410140 <strerror@plt>
  4125dc:	adrp	x3, 420000 <_IO_stdin_used>
  4125e0:	mov	x2, x0
  4125e4:	mov	x1, x19
  4125e8:	add	x0, x3, #0x1f8
  4125ec:	bl	411de0 <failf>

00000000004125f0 <bind_current_thread_memory_to_node.constprop.0>:
  4125f0:	stp	x29, x30, [sp, #-64]!
  4125f4:	mov	x29, sp
  4125f8:	stp	x21, x22, [sp, #32]
  4125fc:	sxtw	x21, w0
  412600:	stp	x19, x20, [sp, #16]
  412604:	mov	x19, x21
  412608:	lsr	x21, x21, #6
  41260c:	stp	x23, x24, [sp, #48]
  412610:	add	x23, x21, #0x1
  412614:	mov	x24, x1
  412618:	mov	x0, x23
  41261c:	mov	x1, #0x8                   	// #8
  412620:	bl	410100 <calloc@plt>
  412624:	cbz	x0, 4126a0 <bind_current_thread_memory_to_node.constprop.0+0xb0>
  412628:	mov	x22, #0x1                   	// #1
  41262c:	mov	x20, x0
  412630:	lsl	x19, x22, x19
  412634:	mov	x2, x0
  412638:	lsl	x3, x23, #6
  41263c:	mov	w1, #0x2                   	// #2
  412640:	mov	x0, #0xed                  	// #237
  412644:	str	x19, [x20, x21, lsl #3]
  412648:	bl	410320 <syscall@plt>
  41264c:	cbnz	x0, 412670 <bind_current_thread_memory_to_node.constprop.0+0x80>
  412650:	mov	x0, x20
  412654:	bl	4101b0 <free@plt>
  412658:	mov	w0, w22
  41265c:	ldp	x19, x20, [sp, #16]
  412660:	ldp	x21, x22, [sp, #32]
  412664:	ldp	x23, x24, [sp, #48]
  412668:	ldp	x29, x30, [sp], #64
  41266c:	ret
  412670:	bl	4102e0 <__errno_location@plt>
  412674:	mov	x1, x0
  412678:	mov	x0, x20
  41267c:	ldr	w1, [x1]
  412680:	str	w1, [x24]
  412684:	bl	4101b0 <free@plt>
  412688:	mov	w0, #0x0                   	// #0
  41268c:	ldp	x19, x20, [sp, #16]
  412690:	ldp	x21, x22, [sp, #32]
  412694:	ldp	x23, x24, [sp, #48]
  412698:	ldp	x29, x30, [sp], #64
  41269c:	ret
  4126a0:	bl	4102e0 <__errno_location@plt>
  4126a4:	ldr	w1, [x0]
  4126a8:	mov	w2, #0xc                   	// #12
  4126ac:	mov	w0, #0x0                   	// #0
  4126b0:	cmp	w1, #0x0
  4126b4:	csel	w1, w1, w2, ne	// ne = any
  4126b8:	str	w1, [x24]
  4126bc:	b	41265c <bind_current_thread_memory_to_node.constprop.0+0x6c>

00000000004126c0 <stop_workers>:
  4126c0:	stp	x29, x30, [sp, #-32]!
  4126c4:	mov	x29, sp
  4126c8:	str	x19, [sp, #16]
  4126cc:	mov	x19, x0
  4126d0:	mov	w1, #0x1                   	// #1
  4126d4:	stlurb	w1, [x0, #100]
  4126d8:	bl	410310 <pthread_mutex_lock@plt>
  4126dc:	cbnz	w0, 41270c <stop_workers+0x4c>
  4126e0:	mov	w0, #0x4                   	// #4
  4126e4:	stlur	w0, [x19, #96]
  4126e8:	add	x0, x19, #0x30
  4126ec:	bl	410110 <pthread_cond_broadcast@plt>
  4126f0:	cbnz	w0, 412734 <stop_workers+0x74>
  4126f4:	mov	x0, x19
  4126f8:	bl	410340 <pthread_mutex_unlock@plt>
  4126fc:	cbnz	w0, 412720 <stop_workers+0x60>
  412700:	ldr	x19, [sp, #16]
  412704:	ldp	x29, x30, [sp], #32
  412708:	ret
  41270c:	bl	410140 <strerror@plt>
  412710:	adrp	x2, 420000 <_IO_stdin_used>
  412714:	mov	x1, x0
  412718:	add	x0, x2, #0x68
  41271c:	bl	411de0 <failf>
  412720:	bl	410140 <strerror@plt>
  412724:	adrp	x2, 420000 <_IO_stdin_used>
  412728:	mov	x1, x0
  41272c:	add	x0, x2, #0xa0
  412730:	bl	411de0 <failf>
  412734:	bl	410140 <strerror@plt>
  412738:	adrp	x2, 420000 <_IO_stdin_used>
  41273c:	mov	x1, x0
  412740:	add	x0, x2, #0x80
  412744:	bl	411de0 <failf>

0000000000412748 <topic49_page_prepare>:
  412748:	cbz	x1, 4127a4 <topic49_page_prepare+0x5c>
  41274c:	mov	x6, #0x7c15                	// #31765
  412750:	mov	x5, #0xe5b9                	// #58809
  412754:	add	x3, x0, x1, lsl #3
  412758:	mov	x4, #0x11eb                	// #4587
  41275c:	movk	x6, #0x7f4a, lsl #16
  412760:	movk	x5, #0x1ce4, lsl #16
  412764:	movk	x4, #0x1331, lsl #16
  412768:	movk	x6, #0x79b9, lsl #32
  41276c:	movk	x5, #0x476d, lsl #32
  412770:	movk	x4, #0x49bb, lsl #32
  412774:	movk	x6, #0x9e37, lsl #48
  412778:	movk	x5, #0xbf58, lsl #48
  41277c:	movk	x4, #0x94d0, lsl #48
  412780:	add	x2, x2, x6
  412784:	eor	x1, x2, x2, lsr #30
  412788:	mul	x1, x1, x5
  41278c:	eor	x1, x1, x1, lsr #27
  412790:	mul	x1, x1, x4
  412794:	eor	x1, x1, x1, lsr #31
  412798:	str	x1, [x0], #8
  41279c:	cmp	x3, x0
  4127a0:	b.ne	412780 <topic49_page_prepare+0x38>  // b.any
  4127a4:	ret

00000000004127a8 <topic49_walk_dependent>:
  4127a8:	mov	x5, x0
  4127ac:	cbz	x2, 4127e8 <topic49_walk_dependent+0x40>
  4127b0:	mov	x4, #0x0                   	// #0
  4127b4:	mov	x0, #0x0                   	// #0
  4127b8:	nop
  4127bc:	nop
  4127c0:	lsl	x1, x1, #6
  4127c4:	add	x4, x4, #0x1
  4127c8:	add	x6, x5, x1
  4127cc:	ldr	x1, [x5, x1]
  4127d0:	ldr	x6, [x6, #8]
  4127d4:	add	x0, x0, x6
  4127d8:	cmp	x2, x4
  4127dc:	b.ne	4127c0 <topic49_walk_dependent+0x18>  // b.any
  4127e0:	str	x1, [x3]
  4127e4:	ret
  4127e8:	mov	x0, #0x0                   	// #0
  4127ec:	str	x1, [x3]
  4127f0:	ret
  4127f4:	nop
  4127f8:	nop
  4127fc:	nop

0000000000412800 <make_cycle>:
  412800:	stp	x29, x30, [sp, #-80]!
  412804:	mov	x29, sp
  412808:	stp	x19, x20, [sp, #16]
  41280c:	stp	x21, x22, [sp, #32]
  412810:	mov	x22, x0
  412814:	stp	x23, x24, [sp, #48]
  412818:	cmp	x0, #0x3f
  41281c:	b.ls	412a28 <make_cycle+0x228>  // b.plast
  412820:	mov	x19, x1
  412824:	mov	x5, #0x0                   	// #0
  412828:	mov	x1, x0
  41282c:	mov	w4, #0xffffffff            	// #-1
  412830:	mov	w3, #0x22                  	// #34
  412834:	mov	w2, #0x3                   	// #3
  412838:	mov	x0, #0x0                   	// #0
  41283c:	mov	x20, x8
  412840:	bl	4101a0 <mmap@plt>
  412844:	lsr	x21, x22, #6
  412848:	mov	x24, x0
  41284c:	cmn	x0, #0x1
  412850:	b.eq	4129e0 <make_cycle+0x1e0>  // b.none
  412854:	mov	w2, #0xf                   	// #15
  412858:	mov	x1, x22
  41285c:	bl	4101f0 <madvise@plt>
  412860:	cbnz	w0, 4129c4 <make_cycle+0x1c4>
  412864:	mov	x2, #0xc909                	// #51465
  412868:	mov	x0, x24
  41286c:	movk	x2, #0xf3bc, lsl #16
  412870:	lsr	x1, x22, #3
  412874:	movk	x2, #0xe667, lsl #32
  412878:	movk	x2, #0x6a09, lsl #48
  41287c:	eor	x2, x19, x2
  412880:	bl	412748 <topic49_page_prepare>
  412884:	lsl	x0, x21, #3
  412888:	bl	4100e0 <malloc@plt>
  41288c:	cbz	x0, 412a00 <make_cycle+0x200>
  412890:	mov	x23, #0x0                   	// #0
  412894:	mov	x1, #0x0                   	// #0
  412898:	add	x3, x24, #0x8
  41289c:	nop
  4128a0:	lsl	x2, x1, #6
  4128a4:	str	x1, [x0, x1, lsl #3]
  4128a8:	add	x1, x1, #0x1
  4128ac:	ldr	x2, [x3, x2]
  4128b0:	add	x23, x23, x2
  4128b4:	cmp	x21, x1
  4128b8:	b.ne	4128a0 <make_cycle+0xa0>  // b.any
  4128bc:	mov	x6, #0x7c15                	// #31765
  4128c0:	mov	x5, #0xe5b9                	// #58809
  4128c4:	mov	x4, #0x11eb                	// #4587
  4128c8:	movk	x6, #0x7f4a, lsl #16
  4128cc:	movk	x5, #0x1ce4, lsl #16
  4128d0:	movk	x4, #0x1331, lsl #16
  4128d4:	movk	x6, #0x79b9, lsl #32
  4128d8:	movk	x5, #0x476d, lsl #32
  4128dc:	movk	x4, #0x49bb, lsl #32
  4128e0:	sub	x1, x21, #0x1
  4128e4:	movk	x6, #0x9e37, lsl #48
  4128e8:	movk	x5, #0xbf58, lsl #48
  4128ec:	movk	x4, #0x94d0, lsl #48
  4128f0:	add	x7, x1, #0x1
  4128f4:	mvn	x2, x1
  4128f8:	udiv	x3, x2, x7
  4128fc:	msub	x3, x3, x7, x2
  412900:	add	x19, x19, x6
  412904:	eor	x2, x19, x19, lsr #30
  412908:	mul	x2, x2, x5
  41290c:	eor	x2, x2, x2, lsr #27
  412910:	mul	x2, x2, x4
  412914:	eor	x2, x2, x2, lsr #31
  412918:	cmp	x3, x2
  41291c:	b.hi	412900 <make_cycle+0x100>  // b.pmore
  412920:	udiv	x3, x2, x7
  412924:	ldr	x8, [x0, x1, lsl #3]
  412928:	msub	x2, x3, x7, x2
  41292c:	ldr	x3, [x0, x2, lsl #3]
  412930:	str	x3, [x0, x1, lsl #3]
  412934:	subs	x1, x1, #0x1
  412938:	str	x8, [x0, x2, lsl #3]
  41293c:	b.ne	4128f0 <make_cycle+0xf0>  // b.any
  412940:	ldr	x2, [x0, x1, lsl #3]
  412944:	add	x1, x1, #0x1
  412948:	udiv	x3, x1, x21
  41294c:	lsl	x2, x2, #6
  412950:	msub	x3, x3, x21, x1
  412954:	ldr	x3, [x0, x3, lsl #3]
  412958:	str	x3, [x24, x2]
  41295c:	cmp	x21, x1
  412960:	b.ne	412940 <make_cycle+0x140>  // b.any
  412964:	ldr	x19, [x0]
  412968:	bl	4101b0 <free@plt>
  41296c:	mov	x1, #0xffffffffffffffff    	// #-1
  412970:	add	x3, sp, #0x48
  412974:	mov	x2, x21
  412978:	mov	x0, x24
  41297c:	str	x1, [sp, #72]
  412980:	mov	x1, x19
  412984:	bl	4127a8 <topic49_walk_dependent>
  412988:	ldr	x1, [sp, #72]
  41298c:	cmp	x19, x1
  412990:	b.ne	412a1c <make_cycle+0x21c>  // b.any
  412994:	cmp	x23, x0
  412998:	b.ne	412a1c <make_cycle+0x21c>  // b.any
  41299c:	mov	w0, #0x1                   	// #1
  4129a0:	stp	x24, x22, [x20]
  4129a4:	stp	x21, x19, [x20, #16]
  4129a8:	str	x23, [x20, #32]
  4129ac:	strb	w0, [x20, #40]
  4129b0:	ldp	x19, x20, [sp, #16]
  4129b4:	ldp	x21, x22, [sp, #32]
  4129b8:	ldp	x23, x24, [sp, #48]
  4129bc:	ldp	x29, x30, [sp], #80
  4129c0:	ret
  4129c4:	bl	4102e0 <__errno_location@plt>
  4129c8:	mov	x19, x0
  4129cc:	mov	x1, x22
  4129d0:	ldr	w20, [x19]
  4129d4:	mov	x0, x24
  4129d8:	bl	410230 <munmap@plt>
  4129dc:	str	w20, [x19]
  4129e0:	bl	4102e0 <__errno_location@plt>
  4129e4:	ldr	w0, [x0]
  4129e8:	bl	410140 <strerror@plt>
  4129ec:	adrp	x3, 420000 <_IO_stdin_used>
  4129f0:	mov	x2, x0
  4129f4:	mov	x1, x22
  4129f8:	add	x0, x3, #0x240
  4129fc:	bl	411de0 <failf>
  412a00:	bl	4102e0 <__errno_location@plt>
  412a04:	ldr	w0, [x0]
  412a08:	bl	410140 <strerror@plt>
  412a0c:	adrp	x2, 420000 <_IO_stdin_used>
  412a10:	mov	x1, x0
  412a14:	add	x0, x2, #0x268
  412a18:	bl	411de0 <failf>
  412a1c:	adrp	x0, 420000 <_IO_stdin_used>
  412a20:	add	x0, x0, #0x288
  412a24:	bl	411de0 <failf>
  412a28:	adrp	x0, 420000 <_IO_stdin_used>
  412a2c:	mov	x1, x22
  412a30:	add	x0, x0, #0x210
  412a34:	mov	w2, #0x40                  	// #64
  412a38:	bl	411de0 <failf>
  412a3c:	nop

0000000000412a40 <topic49_stream_scan>:
  412a40:	cbz	x1, 412a74 <topic49_stream_scan+0x34>
  412a44:	mov	x2, #0x0                   	// #0
  412a48:	whilelo	p0.d, xzr, x1
  412a4c:	mov	z0.b, #0
  412a50:	ld1d	{z1.d}, p0/z, [x0, x2, lsl #3]
  412a54:	incd	x2
  412a58:	add	z0.d, p0/m, z0.d, z1.d
  412a5c:	whilelo	p0.d, x2, x1
  412a60:	b.ne	412a50 <topic49_stream_scan+0x10>  // b.any
  412a64:	ptrue	p0.b
  412a68:	uaddv	d0, p0, z0.d
  412a6c:	fmov	x0, d0
  412a70:	ret
  412a74:	fmov	d0, xzr
  412a78:	fmov	x0, d0
  412a7c:	ret

0000000000412a80 <worker_main>:
  412a80:	stp	x29, x30, [sp, #-352]!
  412a84:	mov	x29, sp
  412a88:	movi	v0.4s, #0x0
  412a8c:	stp	x23, x24, [sp, #48]
  412a90:	ldr	w24, [x0, #8]
  412a94:	stp	x19, x20, [sp, #16]
  412a98:	add	x20, sp, #0x60
  412a9c:	mov	x19, x0
  412aa0:	stp	x21, x22, [sp, #32]
  412aa4:	sxtw	x22, w24
  412aa8:	stp	q0, q0, [x20]
  412aac:	stp	q0, q0, [x20, #32]
  412ab0:	stp	q0, q0, [x20, #64]
  412ab4:	stp	q0, q0, [x20, #96]
  412ab8:	ldr	x21, [x0]
  412abc:	cmp	x22, #0x3ff
  412ac0:	b.hi	412adc <worker_main+0x5c>  // b.pmore
  412ac4:	lsr	x2, x22, #6
  412ac8:	mov	x1, #0x1                   	// #1
  412acc:	ldr	x0, [x20, x2, lsl #3]
  412ad0:	lsl	x1, x1, x24
  412ad4:	orr	x0, x0, x1
  412ad8:	str	x0, [x20, x2, lsl #3]
  412adc:	bl	410290 <pthread_self@plt>
  412ae0:	mov	x2, x20
  412ae4:	mov	x1, #0x80                  	// #128
  412ae8:	mov	x23, x0
  412aec:	bl	410060 <pthread_setaffinity_np@plt>
  412af0:	cbz	w0, 412d18 <worker_main+0x298>
  412af4:	ldr	w1, [x19, #28]
  412af8:	strb	wzr, [x19, #24]
  412afc:	cbz	w1, 412bfc <worker_main+0x17c>
  412b00:	bl	4100a0 <sched_getcpu@plt>
  412b04:	ldr	w1, [x19, #8]
  412b08:	str	w0, [x19, #16]
  412b0c:	cmp	w0, w1
  412b10:	b.eq	412c18 <worker_main+0x198>  // b.none
  412b14:	ldr	w0, [x19, #28]
  412b18:	cbnz	w0, 412b5c <worker_main+0xdc>
  412b1c:	mov	x0, #0x2                   	// #2
  412b20:	str	wzr, [sp, #96]
  412b24:	stur	x0, [x19, #28]
  412b28:	mov	x0, x21
  412b2c:	bl	410310 <pthread_mutex_lock@plt>
  412b30:	cbz	w0, 412b6c <worker_main+0xec>
  412b34:	ldr	w1, [x19, #28]
  412b38:	cbnz	w1, 412b44 <worker_main+0xc4>
  412b3c:	mov	w1, #0x5                   	// #5
  412b40:	stp	w1, w0, [x19, #28]
  412b44:	mov	x0, #0x0                   	// #0
  412b48:	ldp	x19, x20, [sp, #16]
  412b4c:	ldp	x21, x22, [sp, #32]
  412b50:	ldp	x23, x24, [sp, #48]
  412b54:	ldp	x29, x30, [sp], #352
  412b58:	ret
  412b5c:	mov	x0, x21
  412b60:	str	wzr, [sp, #96]
  412b64:	bl	410310 <pthread_mutex_lock@plt>
  412b68:	cbnz	w0, 412b34 <worker_main+0xb4>
  412b6c:	ldr	x1, [x21, #104]
  412b70:	add	x22, x21, #0x30
  412b74:	add	x20, x21, #0x60
  412b78:	mov	x0, x22
  412b7c:	add	x1, x1, #0x1
  412b80:	str	x1, [x21, #104]
  412b84:	bl	410110 <pthread_cond_broadcast@plt>
  412b88:	b	412b94 <worker_main+0x114>
  412b8c:	bl	4101c0 <pthread_cond_wait@plt>
  412b90:	cbnz	w0, 412eec <worker_main+0x46c>
  412b94:	ldar	w2, [x20]
  412b98:	mov	x1, x21
  412b9c:	mov	x0, x22
  412ba0:	cbz	w2, 412b8c <worker_main+0x10c>
  412ba4:	mov	x0, x21
  412ba8:	bl	410340 <pthread_mutex_unlock@plt>
  412bac:	cbz	w0, 412d64 <worker_main+0x2e4>
  412bb0:	ldr	w1, [x19, #28]
  412bb4:	cbz	w1, 412f14 <worker_main+0x494>
  412bb8:	nop
  412bbc:	nop
  412bc0:	mov	x0, x21
  412bc4:	str	xzr, [x19, #72]
  412bc8:	str	xzr, [x19, #88]
  412bcc:	bl	410310 <pthread_mutex_lock@plt>
  412bd0:	cbz	w0, 412d98 <worker_main+0x318>
  412bd4:	ldr	w1, [x19, #28]
  412bd8:	cbnz	w1, 412b44 <worker_main+0xc4>
  412bdc:	mov	w1, #0x8                   	// #8
  412be0:	ldp	x21, x22, [sp, #32]
  412be4:	stp	w1, w0, [x19, #28]
  412be8:	mov	x0, #0x0                   	// #0
  412bec:	ldp	x19, x20, [sp, #16]
  412bf0:	ldp	x23, x24, [sp, #48]
  412bf4:	ldp	x29, x30, [sp], #352
  412bf8:	ret
  412bfc:	mov	w1, #0x1                   	// #1
  412c00:	stp	w1, w0, [x19, #28]
  412c04:	bl	4100a0 <sched_getcpu@plt>
  412c08:	ldr	w1, [x19, #8]
  412c0c:	str	w0, [x19, #16]
  412c10:	cmp	w0, w1
  412c14:	b.ne	412b14 <worker_main+0x94>  // b.any
  412c18:	ldr	w0, [x19, #28]
  412c1c:	str	wzr, [sp, #96]
  412c20:	cbnz	w0, 412b28 <worker_main+0xa8>
  412c24:	ldr	w0, [x19, #12]
  412c28:	mov	x1, x20
  412c2c:	bl	4125f0 <bind_current_thread_memory_to_node.constprop.0>
  412c30:	tst	w0, #0xff
  412c34:	ldr	w0, [x19, #28]
  412c38:	b.eq	412f00 <worker_main+0x480>  // b.none
  412c3c:	cbnz	w0, 412b28 <worker_main+0xa8>
  412c40:	ldr	x22, [x19, #48]
  412c44:	mov	x5, #0x0                   	// #0
  412c48:	mov	w4, #0xffffffff            	// #-1
  412c4c:	mov	w3, #0x22                  	// #34
  412c50:	mov	w2, #0x3                   	// #3
  412c54:	mov	x0, #0x0                   	// #0
  412c58:	mov	x1, x22
  412c5c:	bl	4101a0 <mmap@plt>
  412c60:	mov	x20, x0
  412c64:	cmn	x0, #0x1
  412c68:	b.eq	412fd0 <worker_main+0x550>  // b.none
  412c6c:	mov	w2, #0xf                   	// #15
  412c70:	mov	x1, x22
  412c74:	bl	4101f0 <madvise@plt>
  412c78:	cbnz	w0, 412ff0 <worker_main+0x570>
  412c7c:	mov	w1, #0x1                   	// #1
  412c80:	ldr	w0, [x19, #28]
  412c84:	str	x20, [x19, #40]
  412c88:	strb	w1, [x19, #25]
  412c8c:	cbnz	w0, 412b28 <worker_main+0xa8>
  412c90:	ldrsw	x3, [x19, #8]
  412c94:	mov	x2, #0x82d1                	// #33489
  412c98:	mov	x0, x20
  412c9c:	movk	x2, #0xade6, lsl #16
  412ca0:	ldr	x1, [x19, #48]
  412ca4:	movk	x2, #0x527f, lsl #32
  412ca8:	movk	x2, #0x510e, lsl #48
  412cac:	eor	x2, x3, x2
  412cb0:	lsr	x1, x1, #3
  412cb4:	bl	412748 <topic49_page_prepare>
  412cb8:	ldr	x20, [x19, #48]
  412cbc:	lsr	x20, x20, #18
  412cc0:	lsl	x0, x20, #3
  412cc4:	str	x20, [x19, #64]
  412cc8:	bl	4100e0 <malloc@plt>
  412ccc:	str	x0, [x19, #56]
  412cd0:	mov	x22, x0
  412cd4:	cbz	x0, 41325c <worker_main+0x7dc>
  412cd8:	ldr	w0, [x19, #28]
  412cdc:	cbnz	w0, 412b28 <worker_main+0xa8>
  412ce0:	cbz	x20, 412b28 <worker_main+0xa8>
  412ce4:	mov	x20, #0x0                   	// #0
  412ce8:	b	412cf0 <worker_main+0x270>
  412cec:	ldr	x22, [x19, #56]
  412cf0:	mov	x1, #0x8000                	// #32768
  412cf4:	ldr	x0, [x19, #40]
  412cf8:	add	x0, x0, x20, lsl #18
  412cfc:	bl	412a40 <topic49_stream_scan>
  412d00:	str	x0, [x22, x20, lsl #3]
  412d04:	add	x20, x20, #0x1
  412d08:	ldr	x0, [x19, #64]
  412d0c:	cmp	x0, x20
  412d10:	b.hi	412cec <worker_main+0x26c>  // b.pmore
  412d14:	b	412b28 <worker_main+0xa8>
  412d18:	movi	v0.4s, #0x0
  412d1c:	mov	x1, #0x80                  	// #128
  412d20:	add	x2, sp, #0xe0
  412d24:	mov	x0, x23
  412d28:	stp	q0, q0, [sp, #224]
  412d2c:	stp	q0, q0, [sp, #256]
  412d30:	stp	q0, q0, [sp, #288]
  412d34:	stp	q0, q0, [sp, #320]
  412d38:	bl	4102a0 <pthread_getaffinity_np@plt>
  412d3c:	cbnz	w0, 412af4 <worker_main+0x74>
  412d40:	cmp	x22, #0x3ff
  412d44:	b.hi	412d5c <worker_main+0x2dc>  // b.pmore
  412d48:	lsr	x22, x22, #6
  412d4c:	add	x0, sp, #0xe0
  412d50:	ldr	x0, [x0, x22, lsl #3]
  412d54:	lsr	x0, x0, x24
  412d58:	tbnz	w0, #0, 412f34 <worker_main+0x4b4>
  412d5c:	mov	w0, #0x16                  	// #22
  412d60:	b	412af4 <worker_main+0x74>
  412d64:	ldr	w0, [x19, #28]
  412d68:	cbnz	w0, 412bc0 <worker_main+0x140>
  412d6c:	ldr	w0, [x21, #144]
  412d70:	cmp	w0, #0x2
  412d74:	b.eq	412f50 <worker_main+0x4d0>  // b.none
  412d78:	mov	x0, x19
  412d7c:	mov	w1, #0x1                   	// #1
  412d80:	bl	411f68 <worker_wait_for_phase>
  412d84:	mov	x0, x21
  412d88:	str	xzr, [x19, #72]
  412d8c:	str	xzr, [x19, #88]
  412d90:	bl	410310 <pthread_mutex_lock@plt>
  412d94:	cbnz	w0, 412bd4 <worker_main+0x154>
  412d98:	ldr	x1, [x21, #112]
  412d9c:	mov	x0, x22
  412da0:	add	x1, x1, #0x1
  412da4:	str	x1, [x21, #112]
  412da8:	bl	410110 <pthread_cond_broadcast@plt>
  412dac:	b	412db8 <worker_main+0x338>
  412db0:	bl	4101c0 <pthread_cond_wait@plt>
  412db4:	cbnz	w0, 412fbc <worker_main+0x53c>
  412db8:	ldar	w2, [x20]
  412dbc:	mov	x1, x21
  412dc0:	mov	x0, x22
  412dc4:	cmp	w2, #0x2
  412dc8:	b.eq	412db0 <worker_main+0x330>  // b.none
  412dcc:	mov	x0, x21
  412dd0:	bl	410340 <pthread_mutex_unlock@plt>
  412dd4:	cbnz	w0, 412f20 <worker_main+0x4a0>
  412dd8:	ldr	w0, [x19, #28]
  412ddc:	cbnz	w0, 412df8 <worker_main+0x378>
  412de0:	ldr	w0, [x21, #144]
  412de4:	cmp	w0, #0x2
  412de8:	b.eq	413010 <worker_main+0x590>  // b.none
  412dec:	mov	w1, #0x3                   	// #3
  412df0:	mov	x0, x19
  412df4:	bl	411f68 <worker_wait_for_phase>
  412df8:	bl	4100a0 <sched_getcpu@plt>
  412dfc:	ldr	w20, [x19, #8]
  412e00:	str	w0, [x19, #20]
  412e04:	cmp	w0, w20
  412e08:	b.eq	412e1c <worker_main+0x39c>  // b.none
  412e0c:	ldr	w0, [x19, #28]
  412e10:	cbnz	w0, 412e1c <worker_main+0x39c>
  412e14:	mov	x0, #0xb                   	// #11
  412e18:	stur	x0, [x19, #28]
  412e1c:	movi	v0.4s, #0x0
  412e20:	mov	x0, x23
  412e24:	add	x2, sp, #0xe0
  412e28:	mov	x1, #0x80                  	// #128
  412e2c:	stp	q0, q0, [sp, #224]
  412e30:	stp	q0, q0, [sp, #256]
  412e34:	stp	q0, q0, [sp, #288]
  412e38:	stp	q0, q0, [sp, #320]
  412e3c:	bl	4102a0 <pthread_getaffinity_np@plt>
  412e40:	cbnz	w0, 412e84 <worker_main+0x404>
  412e44:	sxtw	x0, w20
  412e48:	cmp	x0, #0x3ff
  412e4c:	b.hi	412e80 <worker_main+0x400>  // b.pmore
  412e50:	lsr	x0, x0, #6
  412e54:	add	x1, sp, #0xe0
  412e58:	ldr	x0, [x1, x0, lsl #3]
  412e5c:	lsr	x0, x0, x20
  412e60:	tbz	w0, #0, 412e80 <worker_main+0x400>
  412e64:	mov	x0, #0x80                  	// #128
  412e68:	bl	410220 <__sched_cpucount@plt>
  412e6c:	cmp	w0, #0x1
  412e70:	b.eq	412e98 <worker_main+0x418>  // b.none
  412e74:	nop
  412e78:	nop
  412e7c:	nop
  412e80:	mov	w0, #0x16                  	// #22
  412e84:	ldr	w1, [x19, #28]
  412e88:	strb	wzr, [x19, #24]
  412e8c:	cbnz	w1, 412e98 <worker_main+0x418>
  412e90:	mov	w1, #0xc                   	// #12
  412e94:	stp	w1, w0, [x19, #28]
  412e98:	ldr	x0, [x19, #56]
  412e9c:	bl	4101b0 <free@plt>
  412ea0:	str	xzr, [x19, #56]
  412ea4:	ldr	x0, [x19, #40]
  412ea8:	cbz	x0, 412b44 <worker_main+0xc4>
  412eac:	ldr	x1, [x19, #48]
  412eb0:	bl	410230 <munmap@plt>
  412eb4:	cbz	w0, 412ed0 <worker_main+0x450>
  412eb8:	ldr	w0, [x19, #28]
  412ebc:	cbnz	w0, 412ed0 <worker_main+0x450>
  412ec0:	bl	4102e0 <__errno_location@plt>
  412ec4:	ldr	w0, [x0]
  412ec8:	mov	w1, #0xd                   	// #13
  412ecc:	stp	w1, w0, [x19, #28]
  412ed0:	str	xzr, [x19, #40]
  412ed4:	mov	x0, #0x0                   	// #0
  412ed8:	ldp	x19, x20, [sp, #16]
  412edc:	ldp	x21, x22, [sp, #32]
  412ee0:	ldp	x23, x24, [sp, #48]
  412ee4:	ldp	x29, x30, [sp], #352
  412ee8:	ret
  412eec:	ldr	w1, [x19, #28]
  412ef0:	cbnz	w1, 412ba4 <worker_main+0x124>
  412ef4:	mov	w1, #0x6                   	// #6
  412ef8:	stp	w1, w0, [x19, #28]
  412efc:	b	412ba4 <worker_main+0x124>
  412f00:	ldr	w1, [sp, #96]
  412f04:	cbnz	w0, 412b28 <worker_main+0xa8>
  412f08:	mov	w0, #0x26                  	// #38
  412f0c:	stp	w0, w1, [x19, #28]
  412f10:	b	412b28 <worker_main+0xa8>
  412f14:	mov	w1, #0x7                   	// #7
  412f18:	stp	w1, w0, [x19, #28]
  412f1c:	b	412bc0 <worker_main+0x140>
  412f20:	ldr	w1, [x19, #28]
  412f24:	cbnz	w1, 412df8 <worker_main+0x378>
  412f28:	mov	w1, #0xa                   	// #10
  412f2c:	stp	w1, w0, [x19, #28]
  412f30:	b	412df8 <worker_main+0x378>
  412f34:	add	x1, sp, #0xe0
  412f38:	mov	x0, #0x80                  	// #128
  412f3c:	bl	410220 <__sched_cpucount@plt>
  412f40:	cmp	w0, #0x1
  412f44:	b.ne	412d5c <worker_main+0x2dc>  // b.any
  412f48:	strb	w0, [x19, #24]
  412f4c:	b	412b00 <worker_main+0x80>
  412f50:	mov	x24, #0x0                   	// #0
  412f54:	nop
  412f58:	nop
  412f5c:	nop
  412f60:	ldar	w0, [x20]
  412f64:	mov	x1, #0x8000                	// #32768
  412f68:	cmp	w0, #0x1
  412f6c:	b.ne	412bc0 <worker_main+0x140>  // b.any
  412f70:	ldr	x0, [x19, #40]
  412f74:	add	x0, x0, x24, lsl #18
  412f78:	bl	412a40 <topic49_stream_scan>
  412f7c:	ldr	x1, [x19, #56]
  412f80:	ldr	x1, [x1, x24, lsl #3]
  412f84:	cmp	x0, x1
  412f88:	b.eq	412fa0 <worker_main+0x520>  // b.none
  412f8c:	ldr	w0, [x19, #28]
  412f90:	cbnz	w0, 412bc0 <worker_main+0x140>
  412f94:	mov	x0, #0x1e                  	// #30
  412f98:	stur	x0, [x19, #28]
  412f9c:	b	412bc0 <worker_main+0x140>
  412fa0:	ldr	x0, [x19, #64]
  412fa4:	add	x24, x24, #0x1
  412fa8:	ldr	w1, [x19, #28]
  412fac:	udiv	x2, x24, x0
  412fb0:	msub	x24, x2, x0, x24
  412fb4:	cbz	w1, 412f60 <worker_main+0x4e0>
  412fb8:	b	412bc0 <worker_main+0x140>
  412fbc:	ldr	w1, [x19, #28]
  412fc0:	cbnz	w1, 412dcc <worker_main+0x34c>
  412fc4:	mov	w1, #0x9                   	// #9
  412fc8:	stp	w1, w0, [x19, #28]
  412fcc:	b	412dcc <worker_main+0x34c>
  412fd0:	bl	4102e0 <__errno_location@plt>
  412fd4:	ldr	w20, [x0]
  412fd8:	str	xzr, [x19, #40]
  412fdc:	ldr	w0, [x19, #28]
  412fe0:	cbnz	w0, 412b28 <worker_main+0xa8>
  412fe4:	mov	w0, #0x3                   	// #3
  412fe8:	stp	w0, w20, [x19, #28]
  412fec:	b	412b28 <worker_main+0xa8>
  412ff0:	bl	4102e0 <__errno_location@plt>
  412ff4:	mov	x1, x22
  412ff8:	mov	x22, x0
  412ffc:	mov	x0, x20
  413000:	ldr	w20, [x22]
  413004:	bl	410230 <munmap@plt>
  413008:	str	w20, [x22]
  41300c:	b	412fd8 <worker_main+0x558>
  413010:	ldar	w0, [x20]
  413014:	cmp	w0, #0x3
  413018:	b.eq	413028 <worker_main+0x5a8>  // b.none
  41301c:	ldr	w0, [x19, #28]
  413020:	cbnz	w0, 412df8 <worker_main+0x378>
  413024:	b	412dec <worker_main+0x36c>
  413028:	mov	x22, #0xe5b9                	// #58809
  41302c:	mov	x20, #0x11eb                	// #4587
  413030:	stp	x25, x26, [sp, #64]
  413034:	movk	x22, #0x1ce4, lsl #16
  413038:	movk	x20, #0x1331, lsl #16
  41303c:	movk	x22, #0x476d, lsl #32
  413040:	movk	x20, #0x49bb, lsl #32
  413044:	add	x21, x21, #0x64
  413048:	mov	x26, #0x0                   	// #0
  41304c:	str	x27, [sp, #80]
  413050:	movk	x22, #0xbf58, lsl #48
  413054:	movk	x20, #0x94d0, lsl #48
  413058:	mov	w25, #0x21                  	// #33
  41305c:	mov	w24, #0x1                   	// #1
  413060:	ldarb	w0, [x21]
  413064:	tst	w0, #0xff
  413068:	b.ne	41309c <worker_main+0x61c>  // b.any
  41306c:	ldr	x0, [x19, #40]
  413070:	mov	x1, #0x8000                	// #32768
  413074:	add	x0, x0, x26, lsl #18
  413078:	bl	412a40 <topic49_stream_scan>
  41307c:	ldr	x1, [x19, #56]
  413080:	ldr	x1, [x1, x26, lsl #3]
  413084:	cmp	x0, x1
  413088:	b.eq	4130b0 <worker_main+0x630>  // b.none
  41308c:	ldr	w0, [x19, #28]
  413090:	cbnz	w0, 41309c <worker_main+0x61c>
  413094:	mov	x0, #0x1e                  	// #30
  413098:	stur	x0, [x19, #28]
  41309c:	ldrb	w0, [x19, #80]
  4130a0:	cbz	w0, 4131d0 <worker_main+0x750>
  4130a4:	ldp	x25, x26, [sp, #64]
  4130a8:	ldr	x27, [sp, #80]
  4130ac:	b	412df8 <worker_main+0x378>
  4130b0:	ldr	w1, [x19, #28]
  4130b4:	cbnz	w1, 41309c <worker_main+0x61c>
  4130b8:	ldarb	w1, [x21]
  4130bc:	tst	w1, #0xff
  4130c0:	b.ne	41309c <worker_main+0x61c>  // b.any
  4130c4:	eor	x1, x26, x26, lsr #30
  4130c8:	ldr	x3, [x19, #72]
  4130cc:	ldr	x2, [x19, #88]
  4130d0:	mul	x1, x1, x22
  4130d4:	ldrb	w4, [x19, #80]
  4130d8:	add	x3, x3, #0x1
  4130dc:	eor	x1, x1, x1, lsr #27
  4130e0:	str	x3, [x19, #72]
  4130e4:	mul	x1, x1, x20
  4130e8:	eor	x1, x1, x1, lsr #31
  4130ec:	eor	x0, x1, x0
  4130f0:	add	x0, x2, x0
  4130f4:	str	x0, [x19, #88]
  4130f8:	cbz	w4, 413110 <worker_main+0x690>
  4130fc:	ldr	x0, [x19, #64]
  413100:	add	x26, x26, #0x1
  413104:	udiv	x1, x26, x0
  413108:	msub	x26, x1, x0, x26
  41310c:	b	413060 <worker_main+0x5e0>
  413110:	ldr	x27, [x19]
  413114:	mov	x0, x27
  413118:	bl	410310 <pthread_mutex_lock@plt>
  41311c:	cbnz	w0, 4131bc <worker_main+0x73c>
  413120:	ldrb	w0, [x19, #80]
  413124:	cbnz	w0, 413190 <worker_main+0x710>
  413128:	ldr	x0, [x19, #72]
  41312c:	cbz	x0, 413190 <worker_main+0x710>
  413130:	ldr	x0, [x27, #120]
  413134:	ldr	x1, [x27, #136]
  413138:	cmp	x0, x1
  41313c:	b.cs	413190 <worker_main+0x710>  // b.hs, b.nlast
  413140:	add	x0, x0, #0x1
  413144:	strb	w24, [x19, #80]
  413148:	str	x0, [x27, #120]
  41314c:	add	x0, x27, #0x30
  413150:	bl	410110 <pthread_cond_broadcast@plt>
  413154:	cbz	w0, 413164 <worker_main+0x6e4>
  413158:	ldr	w1, [x19, #28]
  41315c:	cbnz	w1, 413164 <worker_main+0x6e4>
  413160:	stp	w25, w0, [x19, #28]
  413164:	mov	x0, x27
  413168:	bl	410340 <pthread_mutex_unlock@plt>
  41316c:	cbz	w0, 413184 <worker_main+0x704>
  413170:	ldr	w1, [x19, #28]
  413174:	cbnz	w1, 41309c <worker_main+0x61c>
  413178:	mov	w1, #0x22                  	// #34
  41317c:	stp	w1, w0, [x19, #28]
  413180:	b	41309c <worker_main+0x61c>
  413184:	ldr	w0, [x19, #28]
  413188:	cbz	w0, 4130fc <worker_main+0x67c>
  41318c:	b	41309c <worker_main+0x61c>
  413190:	ldr	w0, [x19, #28]
  413194:	cbnz	w0, 4131a0 <worker_main+0x720>
  413198:	mov	x0, #0x20                  	// #32
  41319c:	stur	x0, [x19, #28]
  4131a0:	ldrb	w0, [x19, #81]
  4131a4:	cbnz	w0, 41314c <worker_main+0x6cc>
  4131a8:	ldr	x0, [x27, #128]
  4131ac:	strb	w24, [x19, #81]
  4131b0:	add	x0, x0, #0x1
  4131b4:	str	x0, [x27, #128]
  4131b8:	b	41314c <worker_main+0x6cc>
  4131bc:	ldr	w1, [x19, #28]
  4131c0:	cbnz	w1, 41309c <worker_main+0x61c>
  4131c4:	mov	w1, #0x1f                  	// #31
  4131c8:	stp	w1, w0, [x19, #28]
  4131cc:	b	41309c <worker_main+0x61c>
  4131d0:	ldr	x20, [x19]
  4131d4:	mov	x0, x20
  4131d8:	bl	410310 <pthread_mutex_lock@plt>
  4131dc:	cbnz	w0, 413240 <worker_main+0x7c0>
  4131e0:	ldrb	w0, [x19, #81]
  4131e4:	cbnz	w0, 4131fc <worker_main+0x77c>
  4131e8:	ldr	x0, [x20, #128]
  4131ec:	mov	w1, #0x1                   	// #1
  4131f0:	strb	w1, [x19, #81]
  4131f4:	add	x0, x0, #0x1
  4131f8:	str	x0, [x20, #128]
  4131fc:	add	x0, x20, #0x30
  413200:	bl	410110 <pthread_cond_broadcast@plt>
  413204:	cbz	w0, 413218 <worker_main+0x798>
  413208:	ldr	w1, [x19, #28]
  41320c:	cbnz	w1, 413218 <worker_main+0x798>
  413210:	mov	w1, #0x24                  	// #36
  413214:	stp	w1, w0, [x19, #28]
  413218:	mov	x0, x20
  41321c:	bl	410340 <pthread_mutex_unlock@plt>
  413220:	cbz	w0, 4130a4 <worker_main+0x624>
  413224:	ldr	w1, [x19, #28]
  413228:	cbnz	w1, 4130a4 <worker_main+0x624>
  41322c:	mov	w1, #0x25                  	// #37
  413230:	ldp	x25, x26, [sp, #64]
  413234:	ldr	x27, [sp, #80]
  413238:	stp	w1, w0, [x19, #28]
  41323c:	b	412df8 <worker_main+0x378>
  413240:	ldr	w1, [x19, #28]
  413244:	cbnz	w1, 4130a4 <worker_main+0x624>
  413248:	mov	w1, #0x23                  	// #35
  41324c:	ldp	x25, x26, [sp, #64]
  413250:	ldr	x27, [sp, #80]
  413254:	stp	w1, w0, [x19, #28]
  413258:	b	412df8 <worker_main+0x378>
  41325c:	bl	4102e0 <__errno_location@plt>
  413260:	ldr	w2, [x19, #28]
  413264:	ldr	w1, [x0]
  413268:	cbnz	w2, 412b28 <worker_main+0xa8>
  41326c:	mov	w0, #0x4                   	// #4
  413270:	stp	w0, w1, [x19, #28]
  413274:	b	412b28 <worker_main+0xa8>
  413278:	nop
  41327c:	nop

0000000000413280 <topic49_run_timed>:
  413280:	stp	x29, x30, [sp, #-96]!
  413284:	mov	x29, sp
  413288:	stp	x19, x20, [sp, #16]
  41328c:	mov	x20, x0
  413290:	mov	w0, #0x4                   	// #4
  413294:	mov	x19, x3
  413298:	stp	x21, x22, [sp, #32]
  41329c:	mov	x21, x1
  4132a0:	add	x1, sp, #0x50
  4132a4:	mov	x22, x2
  4132a8:	stp	x23, x24, [sp, #48]
  4132ac:	mov	x23, x4
  4132b0:	bl	410090 <clock_gettime@plt>
  4132b4:	cbnz	w0, 413320 <topic49_run_timed+0xa0>
  4132b8:	mov	x2, x22
  4132bc:	ldp	x4, x22, [sp, #80]
  4132c0:	mov	x24, #0xca00                	// #51712
  4132c4:	movk	x24, #0x3b9a, lsl #16
  4132c8:	mov	x1, x21
  4132cc:	mov	x0, x20
  4132d0:	mov	x3, x23
  4132d4:	mul	x20, x4, x24
  4132d8:	bl	4127a8 <topic49_walk_dependent>
  4132dc:	mov	x21, x0
  4132e0:	add	x1, sp, #0x40
  4132e4:	mov	w0, #0x4                   	// #4
  4132e8:	bl	410090 <clock_gettime@plt>
  4132ec:	cbnz	w0, 413320 <topic49_run_timed+0xa0>
  4132f0:	ldp	x2, x1, [sp, #64]
  4132f4:	mov	x0, x21
  4132f8:	mul	x2, x2, x24
  4132fc:	sub	x1, x1, x20
  413300:	ldp	x23, x24, [sp, #48]
  413304:	sub	x2, x2, x22
  413308:	ldp	x21, x22, [sp, #32]
  41330c:	add	x1, x1, x2
  413310:	str	x1, [x19]
  413314:	ldp	x19, x20, [sp, #16]
  413318:	ldp	x29, x30, [sp], #96
  41331c:	ret
  413320:	bl	412564 <now_ns.part.0>

Disassembly of section .fini:

0000000000413324 <_fini>:
  413324:	paciasp
  413328:	stp	x29, x30, [sp, #-16]!
  41332c:	mov	x29, sp
  413330:	ldp	x29, x30, [sp], #16
  413334:	autiasp
  413338:	ret
