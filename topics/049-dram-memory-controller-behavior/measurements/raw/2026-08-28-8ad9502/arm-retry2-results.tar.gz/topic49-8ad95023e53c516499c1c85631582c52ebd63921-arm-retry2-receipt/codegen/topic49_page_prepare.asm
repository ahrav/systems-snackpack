0000000000412748 <topic49_page_prepare>:
  412748:	cbz	x1, 4127a4 <topic49_page_prepare+0x5c>
  41274c:	mov	x6, #0x7c15                	// #31765
  412750:	mov	x5, #0xe5b9                	// #58809
  412754:	add	x3, x0, x1, lsl #3
  412758:	mov	x4, #0x11eb                	// #4587
  41275c:	movk	x6, #0x7f4a, lsl #16
  412760:	movk	x5, #0x1ce4, lsl #16
  412764:	movk	x4, #0x1331, lsl #16
  412768:	movk	x6, #0x79b9, lsl #32
  41276c:	movk	x5, #0x476d, lsl #32
  412770:	movk	x4, #0x49bb, lsl #32
  412774:	movk	x6, #0x9e37, lsl #48
  412778:	movk	x5, #0xbf58, lsl #48
  41277c:	movk	x4, #0x94d0, lsl #48
  412780:	add	x2, x2, x6
  412784:	eor	x1, x2, x2, lsr #30
  412788:	mul	x1, x1, x5
  41278c:	eor	x1, x1, x1, lsr #27
  412790:	mul	x1, x1, x4
  412794:	eor	x1, x1, x1, lsr #31
  412798:	str	x1, [x0], #8
  41279c:	cmp	x3, x0
  4127a0:	b.ne	412780 <topic49_page_prepare+0x38>  // b.any
  4127a4:	ret

