00000000004127a8 <topic49_walk_dependent>:
  4127a8:	mov	x5, x0
  4127ac:	cbz	x2, 4127e8 <topic49_walk_dependent+0x40>
  4127b0:	mov	x4, #0x0                   	// #0
  4127b4:	mov	x0, #0x0                   	// #0
  4127b8:	nop
  4127bc:	nop
  4127c0:	lsl	x1, x1, #6
  4127c4:	add	x4, x4, #0x1
  4127c8:	add	x6, x5, x1
  4127cc:	ldr	x1, [x5, x1]
  4127d0:	ldr	x6, [x6, #8]
  4127d4:	add	x0, x0, x6
  4127d8:	cmp	x2, x4
  4127dc:	b.ne	4127c0 <topic49_walk_dependent+0x18>  // b.any
  4127e0:	str	x1, [x3]
  4127e4:	ret
  4127e8:	mov	x0, #0x0                   	// #0
  4127ec:	str	x1, [x3]
  4127f0:	ret
  4127f4:	nop
  4127f8:	nop
  4127fc:	nop

