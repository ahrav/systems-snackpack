0000000000413280 <topic49_run_timed>:
  413280:	stp	x29, x30, [sp, #-96]!
  413284:	mov	x29, sp
  413288:	stp	x19, x20, [sp, #16]
  41328c:	mov	x20, x0
  413290:	mov	w0, #0x4                   	// #4
  413294:	mov	x19, x3
  413298:	stp	x21, x22, [sp, #32]
  41329c:	mov	x21, x1
  4132a0:	add	x1, sp, #0x50
  4132a4:	mov	x22, x2
  4132a8:	stp	x23, x24, [sp, #48]
  4132ac:	mov	x23, x4
  4132b0:	bl	410090 <clock_gettime@plt>
  4132b4:	cbnz	w0, 413320 <topic49_run_timed+0xa0>
  4132b8:	mov	x2, x22
  4132bc:	ldp	x4, x22, [sp, #80]
  4132c0:	mov	x24, #0xca00                	// #51712
  4132c4:	movk	x24, #0x3b9a, lsl #16
  4132c8:	mov	x1, x21
  4132cc:	mov	x0, x20
  4132d0:	mov	x3, x23
  4132d4:	mul	x20, x4, x24
  4132d8:	bl	4127a8 <topic49_walk_dependent>
  4132dc:	mov	x21, x0
  4132e0:	add	x1, sp, #0x40
  4132e4:	mov	w0, #0x4                   	// #4
  4132e8:	bl	410090 <clock_gettime@plt>
  4132ec:	cbnz	w0, 413320 <topic49_run_timed+0xa0>
  4132f0:	ldp	x2, x1, [sp, #64]
  4132f4:	mov	x0, x21
  4132f8:	mul	x2, x2, x24
  4132fc:	sub	x1, x1, x20
  413300:	ldp	x23, x24, [sp, #48]
  413304:	sub	x2, x2, x22
  413308:	ldp	x21, x22, [sp, #32]
  41330c:	add	x1, x1, x2
  413310:	str	x1, [x19]
  413314:	ldp	x19, x20, [sp, #16]
  413318:	ldp	x29, x30, [sp], #96
  41331c:	ret
  413320:	bl	412564 <now_ns.part.0>

Disassembly of section .fini:

