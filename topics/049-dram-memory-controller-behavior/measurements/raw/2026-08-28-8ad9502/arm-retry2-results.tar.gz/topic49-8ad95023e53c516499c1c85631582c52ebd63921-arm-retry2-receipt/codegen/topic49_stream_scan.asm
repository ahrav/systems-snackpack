0000000000412a40 <topic49_stream_scan>:
  412a40:	cbz	x1, 412a74 <topic49_stream_scan+0x34>
  412a44:	mov	x2, #0x0                   	// #0
  412a48:	whilelo	p0.d, xzr, x1
  412a4c:	mov	z0.b, #0
  412a50:	ld1d	{z1.d}, p0/z, [x0, x2, lsl #3]
  412a54:	incd	x2
  412a58:	add	z0.d, p0/m, z0.d, z1.d
  412a5c:	whilelo	p0.d, x2, x1
  412a60:	b.ne	412a50 <topic49_stream_scan+0x10>  // b.any
  412a64:	ptrue	p0.b
  412a68:	uaddv	d0, p0, z0.d
  412a6c:	fmov	x0, d0
  412a70:	ret
  412a74:	fmov	d0, xzr
  412a78:	fmov	x0, d0
  412a7c:	ret

