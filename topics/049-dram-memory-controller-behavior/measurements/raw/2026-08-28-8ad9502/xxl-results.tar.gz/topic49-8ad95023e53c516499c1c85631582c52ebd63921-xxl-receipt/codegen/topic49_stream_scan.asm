00000000004050a0 <topic49_stream_scan>:
  4050a0:	mov    %rdi,%rcx
  4050a3:	test   %rsi,%rsi
  4050a6:	je     405148 <topic49_stream_scan+0xa8>
  4050ac:	lea    -0x1(%rsi),%rax
  4050b0:	cmp    $0x3,%rax
  4050b4:	jbe    405154 <topic49_stream_scan+0xb4>
  4050ba:	mov    %rsi,%rdx
  4050bd:	shr    $0x2,%rdx
  4050c1:	shl    $0x5,%rdx
  4050c5:	mov    %rdi,%rax
  4050c8:	add    %rdi,%rdx
  4050cb:	vpxor  %xmm0,%xmm0,%xmm0
  4050cf:	nop
  4050d0:	vpaddq (%rax),%ymm0,%ymm0
  4050d4:	add    $0x20,%rax
  4050d8:	cmp    %rax,%rdx
  4050db:	jne    4050d0 <topic49_stream_scan+0x30>
  4050dd:	vmovdqa %xmm0,%xmm1
  4050e1:	vextracti64x2 $0x1,%ymm0,%xmm0
  4050e8:	vpaddq %xmm0,%xmm1,%xmm0
  4050ec:	vpsrldq $0x8,%xmm0,%xmm1
  4050f1:	vpaddq %xmm1,%xmm0,%xmm0
  4050f5:	mov    %rsi,%rdx
  4050f8:	vmovq  %xmm0,%rax
  4050fd:	and    $0xfffffffffffffffc,%rdx
  405101:	test   $0x3,%sil
  405105:	je     405150 <topic49_stream_scan+0xb0>
  405107:	vzeroupper
  40510a:	lea    0x1(%rdx),%r8
  40510e:	lea    0x0(,%rdx,8),%rdi
  405116:	add    (%rcx,%rdx,8),%rax
  40511a:	cmp    %r8,%rsi
  40511d:	jbe    40514a <topic49_stream_scan+0xaa>
  40511f:	lea    0x2(%rdx),%r8
  405123:	add    0x8(%rcx,%rdi,1),%rax
  405128:	cmp    %r8,%rsi
  40512b:	jbe    40514a <topic49_stream_scan+0xaa>
  40512d:	add    $0x3,%rdx
  405131:	add    0x10(%rcx,%rdi,1),%rax
  405136:	cmp    %rdx,%rsi
  405139:	jbe    40514a <topic49_stream_scan+0xaa>
  40513b:	add    0x18(%rcx,%rdi,1),%rax
  405140:	ret
  405141:	nopl   0x0(%rax)
  405148:	xor    %eax,%eax
  40514a:	ret
  40514b:	nopl   0x0(%rax,%rax,1)
  405150:	vzeroupper
  405153:	ret
  405154:	xor    %edx,%edx
  405156:	xor    %eax,%eax
  405158:	jmp    40510a <topic49_stream_scan+0x6a>
  40515a:	nopw   0x0(%rax,%rax,1)

