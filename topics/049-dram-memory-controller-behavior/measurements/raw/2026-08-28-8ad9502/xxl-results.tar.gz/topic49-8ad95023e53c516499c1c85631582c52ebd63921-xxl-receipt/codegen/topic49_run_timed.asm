0000000000405a90 <topic49_run_timed>:
  405a90:	push   %r15
  405a92:	push   %r14
  405a94:	mov    %r8,%r14
  405a97:	push   %r13
  405a99:	mov    %rdx,%r13
  405a9c:	push   %r12
  405a9e:	mov    %rsi,%r12
  405aa1:	push   %rbp
  405aa2:	mov    %rdi,%rbp
  405aa5:	mov    $0x4,%edi
  405aaa:	push   %rbx
  405aab:	mov    %rcx,%rbx
  405aae:	sub    $0x38,%rsp
  405ab2:	lea    0x20(%rsp),%rsi
  405ab7:	call   402090 <clock_gettime@plt>
  405abc:	test   %eax,%eax
  405abe:	jne    405b28 <topic49_run_timed+0x98>
  405ac0:	mov    0x28(%rsp),%r8
  405ac5:	mov    %r12,%rsi
  405ac8:	mov    %rbp,%rdi
  405acb:	mov    %r14,%rcx
  405ace:	mov    %r13,%rdx
  405ad1:	imul   $0x3b9aca00,0x20(%rsp),%r15
  405ada:	mov    %r8,0x8(%rsp)
  405adf:	call   404de0 <topic49_walk_dependent>
  405ae4:	lea    0x10(%rsp),%rsi
  405ae9:	mov    $0x4,%edi
  405aee:	mov    %rax,%r12
  405af1:	call   402090 <clock_gettime@plt>
  405af6:	test   %eax,%eax
  405af8:	jne    405b28 <topic49_run_timed+0x98>
  405afa:	imul   $0x3b9aca00,0x10(%rsp),%rdx
  405b03:	mov    0x8(%rsp),%r8
  405b08:	mov    %r12,%rax
  405b0b:	sub    %r8,%rdx
  405b0e:	add    0x18(%rsp),%rdx
  405b13:	sub    %r15,%rdx
  405b16:	mov    %rdx,(%rbx)
  405b19:	add    $0x38,%rsp
  405b1d:	pop    %rbx
  405b1e:	pop    %rbp
  405b1f:	pop    %r12
  405b21:	pop    %r13
  405b23:	pop    %r14
  405b25:	pop    %r15
  405b27:	ret
  405b28:	call   404a90 <now_ns.part.0>

Disassembly of section .fini:

