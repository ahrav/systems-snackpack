0000000000404c40 <topic49_page_prepare>:
  404c40:	mov    %rdi,%rcx
  404c43:	test   %rsi,%rsi
  404c46:	je     404dc6 <topic49_page_prepare+0x186>
  404c4c:	lea    -0x1(%rsi),%rax
  404c50:	cmp    $0x2,%rax
  404c54:	jbe    404dd4 <topic49_page_prepare+0x194>
  404c5a:	mov    %rdi,%rax
  404c5d:	mov    %rsi,%rdi
  404c60:	vpbroadcastq %rdx,%ymm2
  404c66:	shr    $0x2,%rdi
  404c6a:	shl    $0x5,%rdi
  404c6e:	vpaddq 0x282a(%rip),%ymm2,%ymm2        # 4074a0 <__dso_handle+0x1498>
  404c76:	vpbroadcastq 0x2841(%rip),%ymm6        # 4074c0 <__dso_handle+0x14b8>
  404c7f:	vpbroadcastq 0x2820(%rip),%ymm5        # 4074a8 <__dso_handle+0x14a0>
  404c88:	vpbroadcastq 0x2837(%rip),%ymm4        # 4074c8 <__dso_handle+0x14c0>
  404c91:	vpbroadcastq 0x2836(%rip),%ymm3        # 4074d0 <__dso_handle+0x14c8>
  404c9a:	add    %rcx,%rdi
  404c9d:	nopl   (%rax)
  404ca0:	vmovdqa %ymm2,%ymm0
  404ca4:	vpaddq %ymm5,%ymm0,%ymm0
  404ca8:	vpsrlq $0x1e,%ymm0,%ymm1
  404cad:	vpxor  %ymm0,%ymm1,%ymm1
  404cb1:	vpmullq %ymm4,%ymm1,%ymm1
  404cb7:	add    $0x20,%rax
  404cbb:	vpaddq %ymm6,%ymm2,%ymm2
  404cbf:	vpsrlq $0x1b,%ymm1,%ymm0
  404cc4:	vpxor  %ymm1,%ymm0,%ymm0
  404cc8:	vpmullq %ymm3,%ymm0,%ymm0
  404cce:	vpsrlq $0x1f,%ymm0,%ymm1
  404cd3:	vpxor  %ymm0,%ymm1,%ymm0
  404cd7:	vmovdqu %ymm0,-0x20(%rax)
  404cdc:	cmp    %rax,%rdi
  404cdf:	jne    404ca0 <topic49_page_prepare+0x60>
  404ce1:	mov    %rsi,%rdi
  404ce4:	and    $0xfffffffffffffffc,%rdi
  404ce8:	movabs $0x9e3779b97f4a7c15,%rax
  404cf2:	imul   %rdi,%rax
  404cf6:	add    %rax,%rdx
  404cf9:	cmp    %rdi,%rsi
  404cfc:	je     404dd0 <topic49_page_prepare+0x190>
  404d02:	vzeroupper
  404d05:	sub    %rdi,%rsi
  404d08:	cmp    $0x1,%rsi
  404d0c:	je     404d7b <topic49_page_prepare+0x13b>
  404d0e:	movabs $0x9e3779b97f4a7c15,%r8
  404d18:	lea    (%rdx,%r8,1),%rax
  404d1c:	vmovq  %rdx,%xmm7
  404d21:	vpinsrq $0x1,%rax,%xmm7,%xmm0
  404d27:	vpaddq 0x2777(%rip){1to2},%xmm0,%xmm0        # 4074a8 <__dso_handle+0x14a0>
  404d31:	vpsrlq $0x1e,%xmm0,%xmm1
  404d36:	vpxor  %xmm0,%xmm1,%xmm1
  404d3a:	vpmullq 0x2784(%rip){1to2},%xmm1,%xmm1        # 4074c8 <__dso_handle+0x14c0>
  404d44:	mov    %rsi,%rax
  404d47:	and    $0xfffffffffffffffe,%rax
  404d4b:	imul   %rax,%r8
  404d4f:	vpsrlq $0x1b,%xmm1,%xmm0
  404d54:	vpxor  %xmm1,%xmm0,%xmm0
  404d58:	vpmullq 0x276e(%rip){1to2},%xmm0,%xmm0        # 4074d0 <__dso_handle+0x14c8>
  404d62:	add    %r8,%rdx
  404d65:	vpsrlq $0x1f,%xmm0,%xmm1
  404d6a:	vpxor  %xmm0,%xmm1,%xmm0
  404d6e:	vmovdqu %xmm0,(%rcx,%rdi,8)
  404d73:	add    %rax,%rdi
  404d76:	cmp    %rax,%rsi
  404d79:	je     404dc6 <topic49_page_prepare+0x186>
  404d7b:	movabs $0x9e3779b97f4a7c15,%rax
  404d85:	add    %rax,%rdx
  404d88:	mov    %rdx,%rax
  404d8b:	shr    $0x1e,%rax
  404d8f:	xor    %rdx,%rax
  404d92:	movabs $0xbf58476d1ce4e5b9,%rdx
  404d9c:	imul   %rdx,%rax
  404da0:	mov    %rax,%rdx
  404da3:	shr    $0x1b,%rdx
  404da7:	xor    %rdx,%rax
  404daa:	movabs $0x94d049bb133111eb,%rdx
  404db4:	imul   %rdx,%rax
  404db8:	mov    %rax,%rdx
  404dbb:	shr    $0x1f,%rdx
  404dbf:	xor    %rdx,%rax
  404dc2:	mov    %rax,(%rcx,%rdi,8)
  404dc6:	ret
  404dc7:	nopw   0x0(%rax,%rax,1)
  404dd0:	vzeroupper
  404dd3:	ret
  404dd4:	xor    %edi,%edi
  404dd6:	jmp    404d05 <topic49_page_prepare+0xc5>
  404ddb:	nopl   0x0(%rax,%rax,1)

