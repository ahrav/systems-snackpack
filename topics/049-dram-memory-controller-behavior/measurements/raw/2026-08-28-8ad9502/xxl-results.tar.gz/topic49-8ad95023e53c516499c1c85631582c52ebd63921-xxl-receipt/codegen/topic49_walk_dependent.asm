0000000000404de0 <topic49_walk_dependent>:
  404de0:	test   %rdx,%rdx
  404de3:	je     404e10 <topic49_walk_dependent+0x30>
  404de5:	xor    %eax,%eax
  404de7:	xor    %r8d,%r8d
  404dea:	nopw   0x0(%rax,%rax,1)
  404df0:	shl    $0x6,%rsi
  404df4:	add    %rdi,%rsi
  404df7:	inc    %rax
  404dfa:	add    0x8(%rsi),%r8
  404dfe:	mov    (%rsi),%rsi
  404e01:	cmp    %rax,%rdx
  404e04:	jne    404df0 <topic49_walk_dependent+0x10>
  404e06:	mov    %rsi,(%rcx)
  404e09:	mov    %r8,%rax
  404e0c:	ret
  404e0d:	nopl   (%rax)
  404e10:	xor    %r8d,%r8d
  404e13:	mov    %rsi,(%rcx)
  404e16:	mov    %r8,%rax
  404e19:	ret
  404e1a:	nopw   0x0(%rax,%rax,1)

