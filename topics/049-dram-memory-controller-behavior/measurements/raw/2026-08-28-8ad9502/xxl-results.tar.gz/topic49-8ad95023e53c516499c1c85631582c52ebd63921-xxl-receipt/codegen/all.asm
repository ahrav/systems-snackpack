
/tmp/topic49-8ad95023e53c516499c1c85631582c52ebd63921-xxl-receipt/binary/path-a/dram_bench:     file format elf64-x86-64


Disassembly of section .init:

0000000000402000 <_init>:
  402000:	endbr64
  402004:	sub    $0x8,%rsp
  402008:	mov    0x6fc9(%rip),%rax        # 408fd8 <__gmon_start__@Base>
  40200f:	test   %rax,%rax
  402012:	je     402016 <_init+0x16>
  402014:	call   *%rax
  402016:	add    $0x8,%rsp
  40201a:	ret

Disassembly of section .plt:

0000000000402020 <getenv@plt-0x10>:
  402020:	push   0x6fca(%rip)        # 408ff0 <_GLOBAL_OFFSET_TABLE_+0x8>
  402026:	jmp    *0x6fcc(%rip)        # 408ff8 <_GLOBAL_OFFSET_TABLE_+0x10>
  40202c:	nopl   0x0(%rax)

0000000000402030 <getenv@plt>:
  402030:	jmp    *0x6fca(%rip)        # 409000 <getenv@GLIBC_2.2.5>
  402036:	push   $0x0
  40203b:	jmp    402020 <_init+0x20>

0000000000402040 <free@plt>:
  402040:	jmp    *0x6fc2(%rip)        # 409008 <free@GLIBC_2.2.5>
  402046:	push   $0x1
  40204b:	jmp    402020 <_init+0x20>

0000000000402050 <__errno_location@plt>:
  402050:	jmp    *0x6fba(%rip)        # 409010 <__errno_location@GLIBC_2.2.5>
  402056:	push   $0x2
  40205b:	jmp    402020 <_init+0x20>

0000000000402060 <strncmp@plt>:
  402060:	jmp    *0x6fb2(%rip)        # 409018 <strncmp@GLIBC_2.2.5>
  402066:	push   $0x3
  40206b:	jmp    402020 <_init+0x20>

0000000000402070 <pthread_cond_broadcast@plt>:
  402070:	jmp    *0x6faa(%rip)        # 409020 <pthread_cond_broadcast@GLIBC_2.3.2>
  402076:	push   $0x4
  40207b:	jmp    402020 <_init+0x20>

0000000000402080 <pthread_setaffinity_np@plt>:
  402080:	jmp    *0x6fa2(%rip)        # 409028 <pthread_setaffinity_np@GLIBC_2.34>
  402086:	push   $0x5
  40208b:	jmp    402020 <_init+0x20>

0000000000402090 <clock_gettime@plt>:
  402090:	jmp    *0x6f9a(%rip)        # 409030 <clock_gettime@GLIBC_2.17>
  402096:	push   $0x6
  40209b:	jmp    402020 <_init+0x20>

00000000004020a0 <pthread_cond_wait@plt>:
  4020a0:	jmp    *0x6f92(%rip)        # 409038 <pthread_cond_wait@GLIBC_2.3.2>
  4020a6:	push   $0x7
  4020ab:	jmp    402020 <_init+0x20>

00000000004020b0 <fclose@plt>:
  4020b0:	jmp    *0x6f8a(%rip)        # 409040 <fclose@GLIBC_2.2.5>
  4020b6:	push   $0x8
  4020bb:	jmp    402020 <_init+0x20>

00000000004020c0 <__sched_cpucount@plt>:
  4020c0:	jmp    *0x6f82(%rip)        # 409048 <__sched_cpucount@GLIBC_2.6>
  4020c6:	push   $0x9
  4020cb:	jmp    402020 <_init+0x20>

00000000004020d0 <mmap@plt>:
  4020d0:	jmp    *0x6f7a(%rip)        # 409050 <mmap@GLIBC_2.2.5>
  4020d6:	push   $0xa
  4020db:	jmp    402020 <_init+0x20>

00000000004020e0 <printf@plt>:
  4020e0:	jmp    *0x6f72(%rip)        # 409058 <printf@GLIBC_2.2.5>
  4020e6:	push   $0xb
  4020eb:	jmp    402020 <_init+0x20>

00000000004020f0 <pthread_mutex_destroy@plt>:
  4020f0:	jmp    *0x6f6a(%rip)        # 409060 <pthread_mutex_destroy@GLIBC_2.2.5>
  4020f6:	push   $0xc
  4020fb:	jmp    402020 <_init+0x20>

0000000000402100 <nanosleep@plt>:
  402100:	jmp    *0x6f62(%rip)        # 409068 <nanosleep@GLIBC_2.2.5>
  402106:	push   $0xd
  40210b:	jmp    402020 <_init+0x20>

0000000000402110 <fputc@plt>:
  402110:	jmp    *0x6f5a(%rip)        # 409070 <fputc@GLIBC_2.2.5>
  402116:	push   $0xe
  40211b:	jmp    402020 <_init+0x20>

0000000000402120 <strtok_r@plt>:
  402120:	jmp    *0x6f52(%rip)        # 409078 <strtok_r@GLIBC_2.2.5>
  402126:	push   $0xf
  40212b:	jmp    402020 <_init+0x20>

0000000000402130 <strtoull@plt>:
  402130:	jmp    *0x6f4a(%rip)        # 409080 <strtoull@GLIBC_2.2.5>
  402136:	push   $0x10
  40213b:	jmp    402020 <_init+0x20>

0000000000402140 <calloc@plt>:
  402140:	jmp    *0x6f42(%rip)        # 409088 <calloc@GLIBC_2.2.5>
  402146:	push   $0x11
  40214b:	jmp    402020 <_init+0x20>

0000000000402150 <__getdelim@plt>:
  402150:	jmp    *0x6f3a(%rip)        # 409090 <__getdelim@GLIBC_2.2.5>
  402156:	push   $0x12
  40215b:	jmp    402020 <_init+0x20>

0000000000402160 <strcmp@plt>:
  402160:	jmp    *0x6f32(%rip)        # 409098 <strcmp@GLIBC_2.2.5>
  402166:	push   $0x13
  40216b:	jmp    402020 <_init+0x20>

0000000000402170 <putc@plt>:
  402170:	jmp    *0x6f2a(%rip)        # 4090a0 <putc@GLIBC_2.2.5>
  402176:	push   $0x14
  40217b:	jmp    402020 <_init+0x20>

0000000000402180 <fprintf@plt>:
  402180:	jmp    *0x6f22(%rip)        # 4090a8 <fprintf@GLIBC_2.2.5>
  402186:	push   $0x15
  40218b:	jmp    402020 <_init+0x20>

0000000000402190 <syscall@plt>:
  402190:	jmp    *0x6f1a(%rip)        # 4090b0 <syscall@GLIBC_2.2.5>
  402196:	push   $0x16
  40219b:	jmp    402020 <_init+0x20>

00000000004021a0 <pthread_cond_init@plt>:
  4021a0:	jmp    *0x6f12(%rip)        # 4090b8 <pthread_cond_init@GLIBC_2.3.2>
  4021a6:	push   $0x17
  4021ab:	jmp    402020 <_init+0x20>

00000000004021b0 <pthread_mutex_unlock@plt>:
  4021b0:	jmp    *0x6f0a(%rip)        # 4090c0 <pthread_mutex_unlock@GLIBC_2.2.5>
  4021b6:	push   $0x18
  4021bb:	jmp    402020 <_init+0x20>

00000000004021c0 <malloc@plt>:
  4021c0:	jmp    *0x6f02(%rip)        # 4090c8 <malloc@GLIBC_2.2.5>
  4021c6:	push   $0x19
  4021cb:	jmp    402020 <_init+0x20>

00000000004021d0 <__isoc99_sscanf@plt>:
  4021d0:	jmp    *0x6efa(%rip)        # 4090d0 <__isoc99_sscanf@GLIBC_2.7>
  4021d6:	push   $0x1a
  4021db:	jmp    402020 <_init+0x20>

00000000004021e0 <realloc@plt>:
  4021e0:	jmp    *0x6ef2(%rip)        # 4090d8 <realloc@GLIBC_2.2.5>
  4021e6:	push   $0x1b
  4021eb:	jmp    402020 <_init+0x20>

00000000004021f0 <munmap@plt>:
  4021f0:	jmp    *0x6eea(%rip)        # 4090e0 <munmap@GLIBC_2.2.5>
  4021f6:	push   $0x1c
  4021fb:	jmp    402020 <_init+0x20>

0000000000402200 <pthread_create@plt>:
  402200:	jmp    *0x6ee2(%rip)        # 4090e8 <pthread_create@GLIBC_2.34>
  402206:	push   $0x1d
  40220b:	jmp    402020 <_init+0x20>

0000000000402210 <madvise@plt>:
  402210:	jmp    *0x6eda(%rip)        # 4090f0 <madvise@GLIBC_2.2.5>
  402216:	push   $0x1e
  40221b:	jmp    402020 <_init+0x20>

0000000000402220 <pthread_self@plt>:
  402220:	jmp    *0x6ed2(%rip)        # 4090f8 <pthread_self@GLIBC_2.2.5>
  402226:	push   $0x1f
  40222b:	jmp    402020 <_init+0x20>

0000000000402230 <pthread_cond_destroy@plt>:
  402230:	jmp    *0x6eca(%rip)        # 409100 <pthread_cond_destroy@GLIBC_2.3.2>
  402236:	push   $0x20
  40223b:	jmp    402020 <_init+0x20>

0000000000402240 <fopen@plt>:
  402240:	jmp    *0x6ec2(%rip)        # 409108 <fopen@GLIBC_2.2.5>
  402246:	push   $0x21
  40224b:	jmp    402020 <_init+0x20>

0000000000402250 <getrusage@plt>:
  402250:	jmp    *0x6eba(%rip)        # 409110 <getrusage@GLIBC_2.2.5>
  402256:	push   $0x22
  40225b:	jmp    402020 <_init+0x20>

0000000000402260 <sysconf@plt>:
  402260:	jmp    *0x6eb2(%rip)        # 409118 <sysconf@GLIBC_2.2.5>
  402266:	push   $0x23
  40226b:	jmp    402020 <_init+0x20>

0000000000402270 <vfprintf@plt>:
  402270:	jmp    *0x6eaa(%rip)        # 409120 <vfprintf@GLIBC_2.2.5>
  402276:	push   $0x24
  40227b:	jmp    402020 <_init+0x20>

0000000000402280 <sched_getcpu@plt>:
  402280:	jmp    *0x6ea2(%rip)        # 409128 <sched_getcpu@GLIBC_2.6>
  402286:	push   $0x25
  40228b:	jmp    402020 <_init+0x20>

0000000000402290 <exit@plt>:
  402290:	jmp    *0x6e9a(%rip)        # 409130 <exit@GLIBC_2.2.5>
  402296:	push   $0x26
  40229b:	jmp    402020 <_init+0x20>

00000000004022a0 <fwrite@plt>:
  4022a0:	jmp    *0x6e92(%rip)        # 409138 <fwrite@GLIBC_2.2.5>
  4022a6:	push   $0x27
  4022ab:	jmp    402020 <_init+0x20>

00000000004022b0 <pthread_getaffinity_np@plt>:
  4022b0:	jmp    *0x6e8a(%rip)        # 409140 <pthread_getaffinity_np@GLIBC_2.32>
  4022b6:	push   $0x28
  4022bb:	jmp    402020 <_init+0x20>

00000000004022c0 <pthread_join@plt>:
  4022c0:	jmp    *0x6e82(%rip)        # 409148 <pthread_join@GLIBC_2.34>
  4022c6:	push   $0x29
  4022cb:	jmp    402020 <_init+0x20>

00000000004022d0 <strdup@plt>:
  4022d0:	jmp    *0x6e7a(%rip)        # 409150 <strdup@GLIBC_2.2.5>
  4022d6:	push   $0x2a
  4022db:	jmp    402020 <_init+0x20>

00000000004022e0 <strerror@plt>:
  4022e0:	jmp    *0x6e72(%rip)        # 409158 <strerror@GLIBC_2.2.5>
  4022e6:	push   $0x2b
  4022eb:	jmp    402020 <_init+0x20>

00000000004022f0 <pthread_mutex_init@plt>:
  4022f0:	jmp    *0x6e6a(%rip)        # 409160 <pthread_mutex_init@GLIBC_2.2.5>
  4022f6:	push   $0x2c
  4022fb:	jmp    402020 <_init+0x20>

0000000000402300 <strstr@plt>:
  402300:	jmp    *0x6e62(%rip)        # 409168 <strstr@GLIBC_2.2.5>
  402306:	push   $0x2d
  40230b:	jmp    402020 <_init+0x20>

0000000000402310 <pthread_mutex_lock@plt>:
  402310:	jmp    *0x6e5a(%rip)        # 409170 <pthread_mutex_lock@GLIBC_2.2.5>
  402316:	push   $0x2e
  40231b:	jmp    402020 <_init+0x20>

Disassembly of section .text:

0000000000402320 <main>:
  402320:	lea    0x8(%rsp),%r10
  402325:	and    $0xffffffffffffffc0,%rsp
  402329:	push   -0x8(%r10)
  40232d:	push   %rbp
  40232e:	mov    %rsp,%rbp
  402331:	push   %r15
  402333:	push   %r14
  402335:	push   %r13
  402337:	push   %r12
  402339:	push   %r10
  40233b:	push   %rbx
  40233c:	mov    %edi,%ebx
  40233e:	sub    $0x6c0,%rsp
  402345:	mov    %rsi,-0x5d0(%rbp)
  40234c:	call   404ab0 <now_ns>
  402351:	xor    %edi,%edi
  402353:	lea    -0x420(%rbp),%rsi
  40235a:	mov    %rax,-0x640(%rbp)
  402361:	call   402250 <getrusage@plt>
  402366:	test   %eax,%eax
  402368:	jne    403ec9 <main+0x1ba9>
  40236e:	cmp    $0x1,%ebx
  402371:	jle    404118 <main+0x1df8>
  402377:	lea    -0x2(%rbx),%eax
  40237a:	mov    -0x5d0(%rbp),%rdi
  402381:	shr    $1,%eax
  402383:	shl    $0x4,%rax
  402387:	lea    0x18(%rdi,%rax,1),%rax
  40238c:	mov    %rax,-0x5a8(%rbp)
  402393:	lea    -0x1(%rbx),%eax
  402396:	shr    $1,%eax
  402398:	lea    0x8(%rdi),%rcx
  40239c:	shl    $0x4,%rax
  4023a0:	add    %rcx,%rax
  4023a3:	mov    %rcx,-0x578(%rbp)
  4023aa:	mov    %rax,-0x5b0(%rbp)
  4023b1:	movq   $0x2ee,-0x5d8(%rbp)
  4023bc:	movq   $0x80,-0x5c8(%rbp)
  4023c7:	movq   $0x200,-0x5c0(%rbp)
  4023d2:	movl   $0xffffffff,-0x5a0(%rbp)
  4023dc:	movl   $0xffffffff,-0x59c(%rbp)
  4023e6:	movl   $0x0,-0x598(%rbp)
  4023f0:	xor    %r13d,%r13d
  4023f3:	xor    %r15d,%r15d
  4023f6:	jmp    402448 <main+0x128>
  4023f8:	mov    $0x406f91,%esi
  4023fd:	mov    %rbx,%rdi
  402400:	call   402160 <strcmp@plt>
  402405:	test   %eax,%eax
  402407:	je     40266b <main+0x34b>
  40240d:	mov    $0x406f96,%esi
  402412:	mov    %rbx,%rdi
  402415:	call   402160 <strcmp@plt>
  40241a:	test   %eax,%eax
  40241c:	jne    403fa7 <main+0x1c87>
  402422:	movl   $0x2,-0x598(%rbp)
  40242c:	addq   $0x10,-0x578(%rbp)
  402434:	mov    -0x578(%rbp),%rax
  40243b:	cmp    -0x5a8(%rbp),%rax
  402442:	je     402858 <main+0x538>
  402448:	mov    -0x578(%rbp),%rax
  40244f:	mov    $0x406fb4,%esi
  402454:	mov    (%rax),%r12
  402457:	mov    %r12,%rdi
  40245a:	call   402160 <strcmp@plt>
  40245f:	test   %eax,%eax
  402461:	je     4029f1 <main+0x6d1>
  402467:	mov    -0x5b0(%rbp),%rcx
  40246e:	cmp    %rcx,-0x578(%rbp)
  402475:	je     403fb6 <main+0x1c96>
  40247b:	mov    -0x578(%rbp),%rax
  402482:	mov    $0x406fd0,%esi
  402487:	mov    0x8(%rax),%rbx
  40248b:	mov    %r12,%rdi
  40248e:	mov    %rbx,-0x590(%rbp)
  402495:	call   402160 <strcmp@plt>
  40249a:	test   %eax,%eax
  40249c:	je     4023f8 <main+0xd8>
  4024a2:	mov    $0x406ff2,%esi
  4024a7:	mov    %r12,%rdi
  4024aa:	call   402160 <strcmp@plt>
  4024af:	test   %eax,%eax
  4024b1:	je     4026eb <main+0x3cb>
  4024b7:	mov    $0x407008,%esi
  4024bc:	mov    %r12,%rdi
  4024bf:	call   402160 <strcmp@plt>
  4024c4:	test   %eax,%eax
  4024c6:	jne    40267a <main+0x35a>
  4024cc:	test   %r13,%r13
  4024cf:	jne    40410e <main+0x1dee>
  4024d5:	mov    %rbx,%rdi
  4024d8:	call   4022d0 <strdup@plt>
  4024dd:	mov    %rax,-0x5b8(%rbp)
  4024e4:	test   %rax,%rax
  4024e7:	je     404036 <main+0x1d16>
  4024ed:	mov    $0x10,%edi
  4024f2:	call   4021c0 <malloc@plt>
  4024f7:	mov    %rax,%r13
  4024fa:	test   %rax,%rax
  4024fd:	je     40400f <main+0x1cef>
  402503:	lea    -0x150(%rbp),%rax
  40250a:	mov    -0x5b8(%rbp),%rdi
  402511:	mov    %rax,%rdx
  402514:	mov    $0x40704c,%esi
  402519:	movq   $0x0,-0x150(%rbp)
  402524:	mov    %rax,-0x580(%rbp)
  40252b:	call   402120 <strtok_r@plt>
  402530:	mov    %rax,%r14
  402533:	test   %rax,%rax
  402536:	je     403f0d <main+0x1bed>
  40253c:	mov    %r13,%rax
  40253f:	mov    $0x4,%r12d
  402545:	mov    %r14,%r13
  402548:	xor    %r15d,%r15d
  40254b:	mov    %rax,%r14
  40254e:	xchg   %ax,%ax
  402550:	cmpb   $0x0,0x0(%r13)
  402555:	je     403ee6 <main+0x1bc6>
  40255b:	movq   $0x0,-0xc0(%rbp)
  402566:	call   402050 <__errno_location@plt>
  40256b:	movl   $0x0,(%rax)
  402571:	mov    $0xa,%edx
  402576:	lea    -0xc0(%rbp),%rsi
  40257d:	mov    %r13,%rdi
  402580:	mov    %rax,%rbx
  402583:	call   402130 <strtoull@plt>
  402588:	mov    %rax,%rdx
  40258b:	movzbl 0x0(%r13),%eax
  402590:	sub    $0x30,%eax
  402593:	cmp    $0x9,%al
  402595:	ja     402a15 <main+0x6f5>
  40259b:	mov    (%rbx),%ecx
  40259d:	test   %ecx,%ecx
  40259f:	jne    402a15 <main+0x6f5>
  4025a5:	mov    -0xc0(%rbp),%rax
  4025ac:	cmp    %rax,%r13
  4025af:	je     402a15 <main+0x6f5>
  4025b5:	cmpb   $0x0,(%rax)
  4025b8:	jne    402a15 <main+0x6f5>
  4025be:	cmp    $0x3ff,%rdx
  4025c5:	ja     403fe9 <main+0x1cc9>
  4025cb:	mov    %edx,%esi
  4025cd:	test   %r15,%r15
  4025d0:	je     4025ea <main+0x2ca>
  4025d2:	xor    %eax,%eax
  4025d4:	nopl   0x0(%rax)
  4025d8:	cmp    %esi,(%r14,%rax,4)
  4025dc:	je     4027f2 <main+0x4d2>
  4025e2:	inc    %rax
  4025e5:	cmp    %rax,%r15
  4025e8:	jne    4025d8 <main+0x2b8>
  4025ea:	cmp    %r12,%r15
  4025ed:	jne    402630 <main+0x310>
  4025ef:	movabs $0x1fffffffffffffff,%rax
  4025f9:	cmp    %rax,%r15
  4025fc:	ja     403f57 <main+0x1c37>
  402602:	lea    0x0(,%r15,8),%rsi
  40260a:	mov    %r14,%rdi
  40260d:	mov    %rdx,-0x588(%rbp)
  402614:	call   4021e0 <realloc@plt>
  402619:	test   %rax,%rax
  40261c:	mov    -0x588(%rbp),%rdx
  402623:	lea    (%r15,%r15,1),%r12
  402627:	je     403f2d <main+0x1c0d>
  40262d:	mov    %rax,%r14
  402630:	inc    %r15
  402633:	mov    %edx,-0x4(%r14,%r15,4)
  402638:	mov    -0x580(%rbp),%rdx
  40263f:	mov    $0x40704c,%esi
  402644:	xor    %edi,%edi
  402646:	call   402120 <strtok_r@plt>
  40264b:	mov    %rax,%r13
  40264e:	test   %rax,%rax
  402651:	jne    402550 <main+0x230>
  402657:	mov    -0x5b8(%rbp),%rdi
  40265e:	mov    %r14,%r13
  402661:	call   402040 <free@plt>
  402666:	jmp    40242c <main+0x10c>
  40266b:	movl   $0x1,-0x598(%rbp)
  402675:	jmp    40242c <main+0x10c>
  40267a:	mov    $0x407092,%esi
  40267f:	mov    %r12,%rdi
  402682:	call   402160 <strcmp@plt>
  402687:	test   %eax,%eax
  402689:	je     40276c <main+0x44c>
  40268f:	mov    $0x4070c3,%esi
  402694:	mov    %r12,%rdi
  402697:	call   402160 <strcmp@plt>
  40269c:	test   %eax,%eax
  40269e:	je     40281e <main+0x4fe>
  4026a4:	mov    $0x4070d9,%esi
  4026a9:	mov    %r12,%rdi
  4026ac:	call   402160 <strcmp@plt>
  4026b1:	test   %eax,%eax
  4026b3:	je     40283b <main+0x51b>
  4026b9:	mov    $0x4070f1,%esi
  4026be:	mov    %r12,%rdi
  4026c1:	call   402160 <strcmp@plt>
  4026c6:	test   %eax,%eax
  4026c8:	jne    4040db <main+0x1dbb>
  4026ce:	mov    -0x590(%rbp),%rdi
  4026d5:	mov    $0x4070fd,%esi
  4026da:	call   404550 <parse_u64>
  4026df:	mov    %rax,-0x5d8(%rbp)
  4026e6:	jmp    40242c <main+0x10c>
  4026eb:	movq   $0x0,-0xc0(%rbp)
  4026f6:	call   402050 <__errno_location@plt>
  4026fb:	movl   $0x0,(%rax)
  402701:	mov    %rbx,%r14
  402704:	mov    $0xa,%edx
  402709:	mov    %r14,%rdi
  40270c:	lea    -0xc0(%rbp),%rsi
  402713:	mov    %rax,%rbx
  402716:	call   402130 <strtoull@plt>
  40271b:	movzbl (%r14),%edi
  40271f:	lea    -0x30(%rdi),%edx
  402722:	mov    %dil,-0x580(%rbp)
  402729:	cmp    $0x9,%dl
  40272c:	ja     4040c3 <main+0x1da3>
  402732:	mov    (%rbx),%esi
  402734:	test   %esi,%esi
  402736:	jne    4040c3 <main+0x1da3>
  40273c:	mov    -0xc0(%rbp),%rdx
  402743:	cmp    %rdx,%r14
  402746:	je     4040c3 <main+0x1da3>
  40274c:	cmpb   $0x0,(%rdx)
  40274f:	jne    4040c3 <main+0x1da3>
  402755:	cmp    $0x3ff,%rax
  40275b:	ja     403f8f <main+0x1c6f>
  402761:	mov    %eax,-0x59c(%rbp)
  402767:	jmp    40242c <main+0x10c>
  40276c:	movq   $0x0,-0xc0(%rbp)
  402777:	call   402050 <__errno_location@plt>
  40277c:	movl   $0x0,(%rax)
  402782:	mov    -0x590(%rbp),%r14
  402789:	mov    $0xa,%edx
  40278e:	mov    %r14,%rdi
  402791:	lea    -0xc0(%rbp),%rsi
  402798:	mov    %rax,%rbx
  40279b:	call   402130 <strtoull@plt>
  4027a0:	movzbl (%r14),%edi
  4027a4:	lea    -0x30(%rdi),%edx
  4027a7:	mov    %dil,-0x580(%rbp)
  4027ae:	cmp    $0x9,%dl
  4027b1:	ja     403f77 <main+0x1c57>
  4027b7:	cmpl   $0x0,(%rbx)
  4027ba:	jne    403f77 <main+0x1c57>
  4027c0:	mov    -0xc0(%rbp),%rdx
  4027c7:	cmp    %rdx,%r14
  4027ca:	je     403f77 <main+0x1c57>
  4027d0:	cmpb   $0x0,(%rdx)
  4027d3:	jne    403f77 <main+0x1c57>
  4027d9:	mov    $0x80000000,%ecx
  4027de:	cmp    %rcx,%rax
  4027e1:	jae    403ed3 <main+0x1bb3>
  4027e7:	mov    %eax,-0x5a0(%rbp)
  4027ed:	jmp    40242c <main+0x10c>
  4027f2:	mov    %r14,%rdi
  4027f5:	mov    %esi,-0x578(%rbp)
  4027fb:	call   402040 <free@plt>
  402800:	mov    -0x5b8(%rbp),%rdi
  402807:	call   402040 <free@plt>
  40280c:	mov    -0x578(%rbp),%esi
  402812:	mov    $0x406278,%edi
  402817:	xor    %eax,%eax
  402819:	call   4042e0 <failf>
  40281e:	mov    -0x590(%rbp),%rdi
  402825:	mov    $0x4070cf,%esi
  40282a:	call   404550 <parse_u64>
  40282f:	mov    %rax,-0x5c0(%rbp)
  402836:	jmp    40242c <main+0x10c>
  40283b:	mov    -0x590(%rbp),%rdi
  402842:	mov    $0x4070e6,%esi
  402847:	call   404550 <parse_u64>
  40284c:	mov    %rax,-0x5c8(%rbp)
  402853:	jmp    40242c <main+0x10c>
  402858:	cmpl   $0x0,-0x598(%rbp)
  40285f:	xchg   %r15,%r13
  402862:	je     404118 <main+0x1df8>
  402868:	test   %r15,%r15
  40286b:	je     404118 <main+0x1df8>
  402871:	mov    -0x5a0(%rbp),%eax
  402877:	or     -0x59c(%rbp),%eax
  40287d:	js     404118 <main+0x1df8>
  402883:	cmpq   $0x0,-0x5c0(%rbp)
  40288b:	je     404051 <main+0x1d31>
  402891:	cmpq   $0x0,-0x5c8(%rbp)
  402899:	je     404051 <main+0x1d31>
  40289f:	mov    -0x5c0(%rbp),%rdx
  4028a6:	movabs $0xfffffffffff,%rax
  4028b0:	or     -0x5c8(%rbp),%rdx
  4028b7:	cmp    %rax,%rdx
  4028ba:	ja     40405d <main+0x1d3d>
  4028c0:	mov    -0x59c(%rbp),%edx
  4028c6:	xor    %eax,%eax
  4028c8:	test   %r13,%r13
  4028cb:	je     4028df <main+0x5bf>
  4028cd:	cmp    (%r15,%rax,4),%edx
  4028d1:	je     403ffd <main+0x1cdd>
  4028d7:	inc    %rax
  4028da:	cmp    %rax,%r13
  4028dd:	jne    4028cd <main+0x5ad>
  4028df:	mov    $0x1e,%edi
  4028e4:	call   402260 <sysconf@plt>
  4028e9:	mov    %rax,-0x6b0(%rbp)
  4028f0:	test   %rax,%rax
  4028f3:	jg     402910 <main+0x5f0>
  4028f5:	call   402050 <__errno_location@plt>
  4028fa:	mov    (%rax),%edi
  4028fc:	call   4022e0 <strerror@plt>
  402901:	mov    %rax,%rsi
  402904:	mov    $0x407124,%edi
  402909:	xor    %eax,%eax
  40290b:	call   4042e0 <failf>
  402910:	lea    -0x150(%rbp),%rdi
  402917:	xor    %eax,%eax
  402919:	mov    $0x20,%ecx
  40291e:	mov    %rdi,%r14
  402921:	mov    %rdi,-0x618(%rbp)
  402928:	rep stos %eax,%es:(%rdi)
  40292a:	movslq -0x59c(%rbp),%rax
  402931:	mov    %rax,%rcx
  402934:	shr    $0x6,%rax
  402938:	lea    0x0(,%rax,8),%rbx
  402940:	mov    %ecx,%eax
  402942:	and    $0x3f,%eax
  402945:	mov    %eax,-0x608(%rbp)
  40294b:	mov    $0x1,%eax
  402950:	shlx   %rcx,%rax,%rax
  402955:	or     %rax,(%r14,%rbx,1)
  402959:	mov    %rbx,-0x600(%rbp)
  402960:	call   402220 <pthread_self@plt>
  402965:	mov    %rax,%rdi
  402968:	mov    %r14,%rdx
  40296b:	mov    $0x80,%esi
  402970:	mov    %rax,-0x5b8(%rbp)
  402977:	call   402080 <pthread_setaffinity_np@plt>
  40297c:	mov    %eax,%r14d
  40297f:	test   %eax,%eax
  402981:	jne    4029d4 <main+0x6b4>
  402983:	mov    %r14d,%eax
  402986:	mov    $0x20,%ecx
  40298b:	lea    -0xc0(%rbp),%rdi
  402992:	rep stos %eax,%es:(%rdi)
  402994:	mov    -0x5b8(%rbp),%rdi
  40299b:	lea    -0xc0(%rbp),%rdx
  4029a2:	mov    $0x80,%esi
  4029a7:	call   4022b0 <pthread_getaffinity_np@plt>
  4029ac:	mov    %eax,%r14d
  4029af:	test   %eax,%eax
  4029b1:	jne    4029d4 <main+0x6b4>
  4029b3:	mov    -0x600(%rbp),%rax
  4029ba:	mov    -0x608(%rbp),%ecx
  4029c0:	mov    -0xc0(%rbp,%rax,1),%rax
  4029c8:	bt     %rcx,%rax
  4029cc:	jb     402a29 <main+0x709>
  4029ce:	mov    $0x16,%r14d
  4029d4:	mov    %r14d,%edi
  4029d7:	call   4022e0 <strerror@plt>
  4029dc:	mov    -0x59c(%rbp),%esi
  4029e2:	mov    %rax,%rdx
  4029e5:	mov    $0x406368,%edi
  4029ea:	xor    %eax,%eax
  4029ec:	call   4042e0 <failf>
  4029f1:	mov    -0x5d0(%rbp),%rax
  4029f8:	mov    0x67a1(%rip),%rdi        # 4091a0 <stderr@GLIBC_2.2.5>
  4029ff:	mov    (%rax),%rdx
  402a02:	mov    $0x406120,%esi
  402a07:	xor    %eax,%eax
  402a09:	call   402180 <fprintf@plt>
  402a0e:	xor    %edi,%edi
  402a10:	call   402290 <exit@plt>
  402a15:	mov    %r13,%rdx
  402a18:	mov    $0x40704e,%esi
  402a1d:	mov    $0x406eaa,%edi
  402a22:	xor    %eax,%eax
  402a24:	call   4042e0 <failf>
  402a29:	lea    -0xc0(%rbp),%rsi
  402a30:	mov    $0x80,%edi
  402a35:	call   4020c0 <__sched_cpucount@plt>
  402a3a:	dec    %eax
  402a3c:	jne    4029ce <main+0x6ae>
  402a3e:	call   402280 <sched_getcpu@plt>
  402a43:	cmp    -0x59c(%rbp),%eax
  402a49:	jne    4040b1 <main+0x1d91>
  402a4f:	mov    -0x5a0(%rbp),%edi
  402a55:	lea    -0x504(%rbp),%rsi
  402a5c:	movl   $0x0,-0x504(%rbp)
  402a66:	call   404b10 <bind_current_thread_memory_to_node.constprop.0>
  402a6b:	mov    %eax,%r12d
  402a6e:	test   %al,%al
  402a70:	je     404091 <main+0x1d71>
  402a76:	mov    -0x5c8(%rbp),%rax
  402a7d:	mov    -0x5c0(%rbp),%rsi
  402a84:	shl    $0x14,%rax
  402a88:	shl    $0x14,%rsi
  402a8c:	movabs $0x243f6a8885a308d3,%rdx
  402a96:	lea    -0x480(%rbp),%rdi
  402a9d:	mov    %rax,-0x588(%rbp)
  402aa4:	call   404e20 <make_cycle>
  402aa9:	mov    -0x470(%rbp),%rax
  402ab0:	mov    -0x480(%rbp),%rbx
  402ab7:	mov    %rax,-0x5d0(%rbp)
  402abe:	mov    -0x468(%rbp),%rax
  402ac5:	movabs $0x13198a2e03707344,%rdx
  402acf:	mov    $0x2000,%esi
  402ad4:	lea    -0x450(%rbp),%rdi
  402adb:	mov    %rax,-0x5f8(%rbp)
  402ae2:	mov    %rbx,-0x610(%rbp)
  402ae9:	call   404e20 <make_cycle>
  402aee:	mov    -0x440(%rbp),%rcx
  402af5:	mov    -0x450(%rbp),%rax
  402afc:	mov    %rcx,-0x590(%rbp)
  402b03:	mov    -0x438(%rbp),%rcx
  402b0a:	mov    %rbx,%rsi
  402b0d:	lea    -0x4e0(%rbp),%rdi
  402b14:	mov    %rax,-0x5e0(%rbp)
  402b1b:	mov    %rcx,-0x5a8(%rbp)
  402b22:	call   4045d0 <read_map_evidence>
  402b27:	mov    -0x5e0(%rbp),%rsi
  402b2e:	lea    -0x4b0(%rbp),%rdi
  402b35:	call   4045d0 <read_map_evidence>
  402b3a:	mov    %r14d,%eax
  402b3d:	lea    -0x390(%rbp),%rdi
  402b44:	mov    $0x24,%ecx
  402b49:	rep stos %eax,%es:(%rdi)
  402b4b:	mov    -0x598(%rbp),%eax
  402b51:	lea    -0x390(%rbp),%rdi
  402b58:	xor    %esi,%esi
  402b5a:	mov    %r13,-0x310(%rbp)
  402b61:	mov    %eax,-0x308(%rbp)
  402b67:	call   4022f0 <pthread_mutex_init@plt>
  402b6c:	mov    %eax,%edi
  402b6e:	test   %eax,%eax
  402b70:	jne    40407d <main+0x1d5d>
  402b76:	lea    -0x368(%rbp),%rdi
  402b7d:	xor    %esi,%esi
  402b7f:	call   4021a0 <pthread_cond_init@plt>
  402b84:	mov    %eax,%edi
  402b86:	test   %eax,%eax
  402b88:	jne    404069 <main+0x1d49>
  402b8e:	mov    $0x88,%esi
  402b93:	mov    %r13,%rdi
  402b96:	call   402140 <calloc@plt>
  402b9b:	mov    %rax,%rbx
  402b9e:	mov    $0x8,%esi
  402ba3:	mov    %r13,%rdi
  402ba6:	mov    %rax,-0x578(%rbp)
  402bad:	call   402140 <calloc@plt>
  402bb2:	test   %rbx,%rbx
  402bb5:	sete   %dl
  402bb8:	test   %rax,%rax
  402bbb:	mov    %rax,%r14
  402bbe:	sete   %al
  402bc1:	or     %al,%dl
  402bc3:	mov    %dl,-0x580(%rbp)
  402bc9:	jne    404180 <main+0x1e60>
  402bcf:	test   %r13,%r13
  402bd2:	je     402c6b <main+0x94b>
  402bd8:	mov    -0x578(%rbp),%rcx
  402bdf:	mov    %r14,-0x5b0(%rbp)
  402be6:	xor    %ebx,%ebx
  402be8:	mov    %r12b,-0x5e4(%rbp)
  402bef:	mov    %rbx,%r12
  402bf2:	mov    %rcx,%rbx
  402bf5:	lea    -0x390(%rbp),%rax
  402bfc:	mov    %rax,(%rbx)
  402bff:	vmovd  (%r15,%r12,4),%xmm5
  402c05:	mov    -0x588(%rbp),%rax
  402c0c:	vpinsrd $0x1,-0x5a0(%rbp),%xmm5,%xmm0
  402c16:	movl   $0xffffffff,0x10(%rbx)
  402c1d:	movl   $0xffffffff,0x14(%rbx)
  402c24:	mov    %rax,0x30(%rbx)
  402c28:	mov    %r14,%rdi
  402c2b:	vmovq  %xmm0,0x8(%rbx)
  402c30:	mov    %rbx,%rcx
  402c33:	mov    $0x405160,%edx
  402c38:	xor    %esi,%esi
  402c3a:	call   402200 <pthread_create@plt>
  402c3f:	mov    %eax,%edi
  402c41:	test   %eax,%eax
  402c43:	jne    404169 <main+0x1e49>
  402c49:	inc    %r12
  402c4c:	add    $0x88,%rbx
  402c53:	add    $0x8,%r14
  402c57:	cmp    %r12,%r13
  402c5a:	jne    402bf5 <main+0x8d5>
  402c5c:	mov    -0x5b0(%rbp),%r14
  402c63:	movzbl -0x5e4(%rbp),%r12d
  402c6b:	lea    -0x390(%rbp),%rdi
  402c72:	call   402310 <pthread_mutex_lock@plt>
  402c77:	mov    %eax,%edi
  402c79:	test   %eax,%eax
  402c7b:	je     402ca5 <main+0x985>
  402c7d:	jmp    404141 <main+0x1e21>
  402c82:	nopw   0x0(%rax,%rax,1)
  402c88:	lea    -0x368(%rbp),%rdi
  402c8f:	lea    -0x390(%rbp),%rsi
  402c96:	call   4020a0 <pthread_cond_wait@plt>
  402c9b:	mov    %eax,%edi
  402c9d:	test   %eax,%eax
  402c9f:	jne    404155 <main+0x1e35>
  402ca5:	cmp    %r13,-0x330(%rbp)
  402cac:	jne    402c88 <main+0x968>
  402cae:	lea    -0x390(%rbp),%rdi
  402cb5:	call   4021b0 <pthread_mutex_unlock@plt>
  402cba:	mov    %eax,%edi
  402cbc:	test   %eax,%eax
  402cbe:	jne    40419b <main+0x1e7b>
  402cc4:	mov    -0x578(%rbp),%rax
  402ccb:	xor    %edx,%edx
  402ccd:	test   %r13,%r13
  402cd0:	je     402d87 <main+0xa67>
  402cd6:	mov    %r15,-0x588(%rbp)
  402cdd:	mov    %rax,%rbx
  402ce0:	mov    %r14,%r15
  402ce3:	mov    %r13,%r14
  402ce6:	mov    %rdx,%r13
  402ce9:	mov    0x1c(%rbx),%edx
  402cec:	movzbl -0x580(%rbp),%eax
  402cf3:	test   %edx,%edx
  402cf5:	cmovne %r12d,%eax
  402cf9:	mov    0x28(%rbx),%rsi
  402cfd:	mov    %al,-0x580(%rbp)
  402d03:	test   %rsi,%rsi
  402d06:	je     402d3c <main+0xa1c>
  402d08:	lea    -0x570(%rbp),%rdi
  402d0f:	call   4045d0 <read_map_evidence>
  402d14:	vmovdqu -0x570(%rbp),%xmm4
  402d1c:	vmovdqu %xmm4,0x60(%rbx)
  402d21:	vmovdqu -0x560(%rbp),%xmm4
  402d29:	vmovdqu %xmm4,0x70(%rbx)
  402d2e:	mov    -0x550(%rbp),%rax
  402d35:	mov    %rax,0x80(%rbx)
  402d3c:	inc    %r13
  402d3f:	add    $0x88,%rbx
  402d46:	cmp    %r13,%r14
  402d49:	jne    402ce9 <main+0x9c9>
  402d4b:	cmpb   $0x0,-0x580(%rbp)
  402d52:	mov    %r14,%r13
  402d55:	mov    %r15,%r14
  402d58:	mov    -0x588(%rbp),%r15
  402d5f:	je     402d87 <main+0xa67>
  402d61:	lea    -0x390(%rbp),%rdi
  402d68:	call   404bc0 <stop_workers>
  402d6d:	mov    %r13,%rsi
  402d70:	mov    %r14,%rdi
  402d73:	call   404850 <join_workers>
  402d78:	mov    -0x578(%rbp),%rdi
  402d7f:	mov    %r13,%rsi
  402d82:	call   4043a0 <fail_if_worker_error>
  402d87:	call   404ab0 <now_ns>
  402d8c:	mov    $0x1,%esi
  402d91:	lea    -0x390(%rbp),%rdi
  402d98:	mov    %rax,-0x648(%rbp)
  402d9f:	call   404410 <broadcast_phase>
  402da4:	movabs $0x10c6f7a0b5ed,%rax
  402dae:	cmp    %rax,-0x5d8(%rbp)
  402db5:	ja     4041c3 <main+0x1ea3>
  402dbb:	imul   $0xf4240,-0x5d8(%rbp),%rax
  402dc6:	mov    $0x3b9aca00,%ecx
  402dcb:	xor    %edx,%edx
  402dcd:	div    %rcx
  402dd0:	vmovq  %rax,%xmm6
  402dd5:	vpinsrq $0x1,%rdx,%xmm6,%xmm0
  402ddb:	vmovdqa %xmm0,-0xc0(%rbp)
  402de3:	jmp    402df8 <main+0xad8>
  402de5:	nopl   (%rax)
  402de8:	call   402050 <__errno_location@plt>
  402ded:	mov    (%rax),%edi
  402def:	cmp    $0x4,%edi
  402df2:	jne    4041af <main+0x1e8f>
  402df8:	lea    -0xc0(%rbp),%rsi
  402dff:	mov    %rsi,%rdi
  402e02:	call   402100 <nanosleep@plt>
  402e07:	test   %eax,%eax
  402e09:	jne    402de8 <main+0xac8>
  402e0b:	call   404ab0 <now_ns>
  402e10:	lea    -0x390(%rbp),%rdi
  402e17:	mov    %rax,-0x650(%rbp)
  402e1e:	call   402310 <pthread_mutex_lock@plt>
  402e23:	mov    %eax,%edi
  402e25:	test   %eax,%eax
  402e27:	jne    403be4 <main+0x18c4>
  402e2d:	movl   $0x2,-0x338(%rbp)
  402e37:	lea    -0x368(%rbp),%rdi
  402e3e:	call   402070 <pthread_cond_broadcast@plt>
  402e43:	mov    %eax,%edi
  402e45:	test   %eax,%eax
  402e47:	je     402e6d <main+0xb4d>
  402e49:	jmp    403bd0 <main+0x18b0>
  402e4e:	xchg   %ax,%ax
  402e50:	lea    -0x368(%rbp),%rdi
  402e57:	lea    -0x390(%rbp),%rsi
  402e5e:	call   4020a0 <pthread_cond_wait@plt>
  402e63:	mov    %eax,%edi
  402e65:	test   %eax,%eax
  402e67:	jne    4041cf <main+0x1eaf>
  402e6d:	cmp    %r13,-0x328(%rbp)
  402e74:	jne    402e50 <main+0xb30>
  402e76:	lea    -0x390(%rbp),%rdi
  402e7d:	call   4021b0 <pthread_mutex_unlock@plt>
  402e82:	mov    %eax,%edi
  402e84:	test   %eax,%eax
  402e86:	jne    403bbc <main+0x189c>
  402e8c:	mov    -0x578(%rbp),%rax
  402e93:	movq   $0x0,-0x580(%rbp)
  402e9e:	add    $0x1c,%rax
  402ea2:	mov    %rax,-0x588(%rbp)
  402ea9:	test   %r13,%r13
  402eac:	je     402edd <main+0xbbd>
  402eae:	mov    -0x588(%rbp),%rax
  402eb5:	mov    (%rax),%eax
  402eb7:	test   %eax,%eax
  402eb9:	jne    4031d8 <main+0xeb8>
  402ebf:	incq   -0x580(%rbp)
  402ec6:	addq   $0x88,-0x588(%rbp)
  402ed1:	mov    -0x580(%rbp),%rax
  402ed8:	cmp    %rax,%r13
  402edb:	jne    402eae <main+0xb8e>
  402edd:	lea    -0x390(%rbp),%rdi
  402ee4:	call   402310 <pthread_mutex_lock@plt>
  402ee9:	mov    %eax,%edi
  402eeb:	test   %eax,%eax
  402eed:	jne    403d12 <main+0x19f2>
  402ef3:	call   404ab0 <now_ns>
  402ef8:	mov    %rax,-0x658(%rbp)
  402eff:	lea    -0x368(%rbp),%rdi
  402f06:	movl   $0x3,-0x338(%rbp)
  402f10:	call   402070 <pthread_cond_broadcast@plt>
  402f15:	mov    %eax,%edi
  402f17:	test   %eax,%eax
  402f19:	jne    403cea <main+0x19ca>
  402f1f:	lea    -0x390(%rbp),%rdi
  402f26:	call   4021b0 <pthread_mutex_unlock@plt>
  402f2b:	mov    %eax,%edi
  402f2d:	test   %eax,%eax
  402f2f:	jne    403c9c <main+0x197c>
  402f35:	cmpl   $0x2,-0x598(%rbp)
  402f3c:	je     403bf8 <main+0x18d8>
  402f42:	mov    -0x590(%rbp),%rcx
  402f49:	mov    $0x100000,%eax
  402f4e:	xor    %edx,%edx
  402f50:	div    %rcx
  402f53:	movq   $0x100000,-0x5b0(%rbp)
  402f5e:	test   %rdx,%rdx
  402f61:	je     402f71 <main+0xc51>
  402f63:	inc    %rax
  402f66:	imul   %rcx,%rax
  402f6a:	mov    %rax,-0x5b0(%rbp)
  402f71:	mov    -0x5b0(%rbp),%rbx
  402f78:	mov    -0x5a8(%rbp),%rsi
  402f7f:	mov    -0x5e0(%rbp),%rdi
  402f86:	lea    -0x4f8(%rbp),%r8
  402f8d:	lea    -0x500(%rbp),%rcx
  402f94:	mov    %rbx,%rdx
  402f97:	movq   $0x0,-0x500(%rbp)
  402fa2:	movq   $0xffffffffffffffff,-0x4f8(%rbp)
  402fad:	call   405a90 <topic49_run_timed>
  402fb2:	mov    %rax,-0x620(%rbp)
  402fb9:	xor    %edx,%edx
  402fbb:	mov    %rbx,%rax
  402fbe:	divq   -0x590(%rbp)
  402fc5:	imul   -0x430(%rbp),%rax
  402fcd:	mov    %rax,-0x580(%rbp)
  402fd4:	call   402280 <sched_getcpu@plt>
  402fd9:	lea    -0x1e0(%rbp),%rsi
  402fe0:	mov    $0x1,%edi
  402fe5:	mov    %eax,-0x5e4(%rbp)
  402feb:	call   402250 <getrusage@plt>
  402ff0:	test   %eax,%eax
  402ff2:	jne    403b18 <main+0x17f8>
  402ff8:	xor    %edi,%edi
  402ffa:	lea    -0x300(%rbp),%rsi
  403001:	call   402250 <getrusage@plt>
  403006:	test   %eax,%eax
  403008:	jne    403ec9 <main+0x1ba9>
  40300e:	movabs $0x3fffffffffffffff,%rax
  403018:	cmp    %rax,-0x5d0(%rbp)
  40301f:	ja     403b2e <main+0x180e>
  403025:	mov    -0x5d0(%rbp),%rax
  40302c:	mov    -0x5f8(%rbp),%rbx
  403033:	shl    $0x2,%rax
  403037:	mov    -0x610(%rbp),%rdi
  40303e:	mov    %rbx,%rsi
  403041:	lea    -0x4e8(%rbp),%r8
  403048:	lea    -0x4f0(%rbp),%rcx
  40304f:	mov    %rax,%rdx
  403052:	mov    %rax,-0x5f0(%rbp)
  403059:	movq   $0x0,-0x4f0(%rbp)
  403064:	movq   $0xffffffffffffffff,-0x4e8(%rbp)
  40306f:	call   405a90 <topic49_run_timed>
  403074:	xor    %edi,%edi
  403076:	lea    -0x270(%rbp),%rsi
  40307d:	mov    %rax,-0x628(%rbp)
  403084:	call   402250 <getrusage@plt>
  403089:	test   %eax,%eax
  40308b:	jne    403ec9 <main+0x1ba9>
  403091:	mov    -0x618(%rbp),%rsi
  403098:	mov    $0x1,%edi
  40309d:	call   402250 <getrusage@plt>
  4030a2:	test   %eax,%eax
  4030a4:	jne    403b18 <main+0x17f8>
  4030aa:	call   402280 <sched_getcpu@plt>
  4030af:	mov    %eax,-0x5f8(%rbp)
  4030b5:	mov    $0x1,%eax
  4030ba:	xchg   %al,-0x334(%rbp)
  4030c0:	mov    $0x4,%esi
  4030c5:	lea    -0x390(%rbp),%rdi
  4030cc:	call   404410 <broadcast_phase>
  4030d1:	mov    %r14,%rdi
  4030d4:	mov    %r13,%rsi
  4030d7:	call   404850 <join_workers>
  4030dc:	call   404ab0 <now_ns>
  4030e1:	mov    -0x460(%rbp),%rdi
  4030e8:	mov    %rax,-0x660(%rbp)
  4030ef:	lea    0x0(,%rdi,4),%rax
  4030f7:	mov    -0x5a8(%rbp),%rdi
  4030fe:	cmp    %rdi,-0x4f8(%rbp)
  403105:	jne    403b22 <main+0x1802>
  40310b:	mov    -0x580(%rbp),%rdx
  403112:	cmp    %rdx,-0x620(%rbp)
  403119:	jne    403b22 <main+0x1802>
  40311f:	cmp    %rbx,-0x4e8(%rbp)
  403126:	jne    403b22 <main+0x1802>
  40312c:	cmp    %rax,-0x628(%rbp)
  403133:	jne    403b22 <main+0x1802>
  403139:	mov    -0x59c(%rbp),%eax
  40313f:	mov    -0x5f8(%rbp),%ecx
  403145:	cmp    %ecx,%eax
  403147:	jne    403b9e <main+0x187e>
  40314d:	mov    -0x5e4(%rbp),%ecx
  403153:	cmp    %ecx,%eax
  403155:	jne    403b9e <main+0x187e>
  40315b:	xor    %eax,%eax
  40315d:	mov    $0x20,%ecx
  403162:	lea    -0xc0(%rbp),%rdi
  403169:	rep stos %eax,%es:(%rdi)
  40316b:	mov    -0x5b8(%rbp),%rdi
  403172:	lea    -0xc0(%rbp),%rdx
  403179:	mov    $0x80,%esi
  40317e:	call   4022b0 <pthread_getaffinity_np@plt>
  403183:	mov    %eax,%ebx
  403185:	test   %eax,%eax
  403187:	jne    4031c2 <main+0xea2>
  403189:	mov    -0x600(%rbp),%rax
  403190:	mov    -0x608(%rbp),%ecx
  403196:	mov    -0xc0(%rbp,%rax,1),%rax
  40319e:	bt     %rcx,%rax
  4031a2:	jae    4031bd <main+0xe9d>
  4031a4:	lea    -0xc0(%rbp),%rsi
  4031ab:	mov    $0x80,%edi
  4031b0:	call   4020c0 <__sched_cpucount@plt>
  4031b5:	dec    %eax
  4031b7:	je     40328b <main+0xf6b>
  4031bd:	mov    $0x16,%ebx
  4031c2:	mov    %ebx,%edi
  4031c4:	call   4022e0 <strerror@plt>
  4031c9:	mov    %rax,%rsi
  4031cc:	mov    $0x4072a2,%edi
  4031d1:	xor    %eax,%eax
  4031d3:	call   4042e0 <failf>
  4031d8:	mov    $0x1,%eax
  4031dd:	xchg   %al,-0x334(%rbp)
  4031e3:	mov    $0x4,%esi
  4031e8:	xor    %ebx,%ebx
  4031ea:	lea    -0x390(%rbp),%rdi
  4031f1:	call   404410 <broadcast_phase>
  4031f6:	jmp    403203 <main+0xee3>
  4031f8:	nopl   0x0(%rax,%rax,1)
  403200:	mov    %rax,%rbx
  403203:	mov    (%r14,%rbx,8),%rdi
  403207:	xor    %esi,%esi
  403209:	call   4022c0 <pthread_join@plt>
  40320e:	mov    %eax,%edi
  403210:	test   %eax,%eax
  403212:	jne    403b8a <main+0x186a>
  403218:	lea    0x1(%rbx),%rax
  40321c:	cmp    %rax,%r13
  40321f:	jne    403200 <main+0xee0>
  403221:	mov    -0x578(%rbp),%rsi
  403228:	xor    %r8d,%r8d
  40322b:	jmp    403244 <main+0xf24>
  40322d:	lea    0x1(%r8),%rax
  403231:	add    $0x88,%rsi
  403238:	cmp    %rbx,%r8
  40323b:	je     402ebf <main+0xb9f>
  403241:	mov    %rax,%r8
  403244:	mov    0x1c(%rsi),%r9d
  403248:	test   %r9d,%r9d
  40324b:	je     40322d <main+0xf0d>
  40324d:	mov    0x20(%rsi),%edi
  403250:	mov    %rsi,-0x580(%rbp)
  403257:	test   %edi,%edi
  403259:	je     403b06 <main+0x17e6>
  40325f:	mov    %r8,-0x578(%rbp)
  403266:	call   4022e0 <strerror@plt>
  40326b:	mov    -0x580(%rbp),%rsi
  403272:	mov    %rax,%rcx
  403275:	mov    0x1c(%rsi),%edx
  403278:	mov    -0x578(%rbp),%rsi
  40327f:	mov    $0x406010,%edi
  403284:	xor    %eax,%eax
  403286:	call   4042e0 <failf>
  40328b:	mov    -0x578(%rbp),%rdi
  403292:	mov    %r13,%rsi
  403295:	call   4043a0 <fail_if_worker_error>
  40329a:	mov    -0x1f0(%rbp),%rdx
  4032a1:	mov    -0x230(%rbp),%rax
  4032a8:	sub    -0x280(%rbp),%rdx
  4032af:	mov    %rdx,-0x6a0(%rbp)
  4032b6:	mov    -0x1e8(%rbp),%rdx
  4032bd:	sub    -0x2c0(%rbp),%rax
  4032c4:	sub    -0x278(%rbp),%rdx
  4032cb:	mov    %rdx,-0x698(%rbp)
  4032d2:	mov    -0x110(%rbp),%rdx
  4032d9:	mov    %rax,-0x6a8(%rbp)
  4032e0:	sub    -0x1a0(%rbp),%rdx
  4032e7:	mov    %rdx,-0x668(%rbp)
  4032ee:	mov    -0x108(%rbp),%rdx
  4032f5:	mov    -0x228(%rbp),%rax
  4032fc:	sub    -0x198(%rbp),%rdx
  403303:	mov    %rdx,-0x670(%rbp)
  40330a:	mov    -0xd0(%rbp),%rdx
  403311:	sub    -0x160(%rbp),%rdx
  403318:	mov    %rdx,-0x678(%rbp)
  40331f:	mov    -0xc8(%rbp),%rdx
  403326:	sub    -0x158(%rbp),%rdx
  40332d:	sub    -0x2b8(%rbp),%rax
  403334:	mov    %rdx,-0x680(%rbp)
  40333b:	mov    %rax,%rsi
  40333e:	jne    403b7e <main+0x185e>
  403344:	xor    %eax,%eax
  403346:	cmpb   $0x0,-0x458(%rbp)
  40334d:	je     403356 <main+0x1036>
  40334f:	movzbl -0x428(%rbp),%eax
  403356:	and    $0x1,%eax
  403359:	cmpb   $0x0,-0x4e0(%rbp)
  403360:	mov    %al,-0x600(%rbp)
  403366:	je     40336f <main+0x104f>
  403368:	movzbl -0x4b0(%rbp),%ebx
  40336f:	lea    0x0(,%r13,4),%rdi
  403377:	mov    %rdi,-0x580(%rbp)
  40337e:	call   4021c0 <malloc@plt>
  403383:	mov    -0x580(%rbp),%rdi
  40338a:	mov    %rax,-0x588(%rbp)
  403391:	call   4021c0 <malloc@plt>
  403396:	lea    0x0(,%r13,8),%rdi
  40339e:	mov    %rdi,-0x580(%rbp)
  4033a5:	mov    %rax,-0x590(%rbp)
  4033ac:	and    $0x1,%ebx
  4033af:	call   4021c0 <malloc@plt>
  4033b4:	cmpq   $0x0,-0x588(%rbp)
  4033bc:	mov    %rax,%rdi
  4033bf:	mov    %rax,-0x5a8(%rbp)
  4033c6:	sete   %al
  4033c9:	cmpq   $0x0,-0x590(%rbp)
  4033d1:	sete   %dl
  4033d4:	or     %edx,%eax
  4033d6:	test   %rdi,%rdi
  4033d9:	sete   %dl
  4033dc:	or     %dl,%al
  4033de:	jne    403b63 <main+0x1843>
  4033e4:	test   %r13,%r13
  4033e7:	mov    -0x580(%rbp),%rdi
  4033ee:	je     403b3a <main+0x181a>
  4033f4:	mov    -0x578(%rbp),%rax
  4033fb:	mov    %rdi,-0x580(%rbp)
  403402:	movzbl -0x600(%rbp),%r11d
  40340a:	add    $0x8,%rax
  40340e:	mov    %r12d,%edx
  403411:	xor    %esi,%esi
  403413:	xor    %r9d,%r9d
  403416:	xor    %r10d,%r10d
  403419:	jmp    403493 <main+0x1173>
  40341b:	nopl   0x0(%rax,%rax,1)
  403420:	movzbl 0x58(%rax),%r12d
  403425:	test   %r12b,%r12b
  403428:	je     4034e3 <main+0x11c3>
  40342e:	movzbl 0x7c(%rax),%r12d
  403433:	test   %r12b,%r12b
  403436:	je     4034db <main+0x11bb>
  40343c:	test   %bl,%bl
  40343e:	je     4034e3 <main+0x11c3>
  403444:	mov    %ebx,%r12d
  403447:	mov    0x8(%rax),%ecx
  40344a:	mov    0xc(%rax),%r8d
  40344e:	test   %dl,%dl
  403450:	je     403466 <main+0x1146>
  403452:	movzbl 0x10(%rax),%edx
  403456:	test   %dl,%dl
  403458:	je     403466 <main+0x1146>
  40345a:	xor    %edx,%edx
  40345c:	cmp    %ecx,(%rax)
  40345e:	jne    403466 <main+0x1146>
  403460:	cmp    %r8d,%ecx
  403463:	sete   %dl
  403466:	test   %r11b,%r11b
  403469:	je     403470 <main+0x1150>
  40346b:	movzbl 0x11(%rax),%r11d
  403470:	mov    -0x588(%rbp),%rdi
  403477:	add    $0x88,%rax
  40347d:	mov    %ecx,(%rdi,%rsi,4)
  403480:	mov    -0x590(%rbp),%rcx
  403487:	mov    %r8d,(%rcx,%rsi,4)
  40348b:	inc    %rsi
  40348e:	cmp    %rsi,%r13
  403491:	je     403501 <main+0x11e1>
  403493:	mov    -0x5a8(%rbp),%r8
  40349a:	mov    0x40(%rax),%rcx
  40349e:	cmpl   $0x2,-0x598(%rbp)
  4034a5:	mov    %rcx,(%r8,%rsi,8)
  4034a9:	movzbl 0x48(%rax),%r8d
  4034ae:	je     4034ea <main+0x11ca>
  4034b0:	test   %rcx,%rcx
  4034b3:	jne    403ebd <main+0x1b9d>
  4034b9:	test   %r8b,%r8b
  4034bc:	jne    403ebd <main+0x1b9d>
  4034c2:	add    0x50(%rax),%r10
  4034c6:	add    0x70(%rax),%r9
  4034ca:	test   %r12b,%r12b
  4034cd:	jne    403420 <main+0x1100>
  4034d3:	test   %bl,%bl
  4034d5:	je     4034e3 <main+0x11c3>
  4034d7:	movzbl 0x58(%rax),%ebx
  4034db:	test   %bl,%bl
  4034dd:	jne    403447 <main+0x1127>
  4034e3:	xor    %ebx,%ebx
  4034e5:	jmp    403447 <main+0x1127>
  4034ea:	test   %rcx,%rcx
  4034ed:	je     4034f5 <main+0x11d5>
  4034ef:	cmp    $0x1,%r8b
  4034f3:	je     4034c2 <main+0x11a2>
  4034f5:	mov    $0x406600,%edi
  4034fa:	xor    %eax,%eax
  4034fc:	call   4042e0 <failf>
  403501:	mov    -0x580(%rbp),%rdi
  403508:	mov    -0x5a8(%rbp),%rcx
  40350f:	mov    %r9,-0x630(%rbp)
  403516:	mov    %r10,-0x638(%rbp)
  40351d:	mov    %r11b,-0x600(%rbp)
  403524:	movq   $0x0,-0x580(%rbp)
  40352f:	mov    %rcx,%rax
  403532:	add    %rcx,%rdi
  403535:	mov    -0x580(%rbp),%rcx
  40353c:	add    (%rax),%rcx
  40353f:	jb     403eb1 <main+0x1b91>
  403545:	add    $0x8,%rax
  403549:	mov    %rcx,-0x580(%rbp)
  403550:	cmp    %rdi,%rax
  403553:	jne    403535 <main+0x1215>
  403555:	mov    -0x318(%rbp),%rax
  40355c:	mov    %rax,-0x618(%rbp)
  403563:	test   %rax,%rax
  403566:	jne    403e7e <main+0x1b5e>
  40356c:	cmpl   $0x2,-0x598(%rbp)
  403573:	mov    -0x320(%rbp),%rax
  40357a:	je     403e0c <main+0x1aec>
  403580:	or     -0x580(%rbp),%rax
  403587:	mov    %rax,-0x608(%rbp)
  40358e:	jne    403e00 <main+0x1ae0>
  403594:	movq   $0x0,-0x5b8(%rbp)
  40359f:	test   %dl,%dl
  4035a1:	je     403df4 <main+0x1ad4>
  4035a7:	movabs $0x3ffffffffffffff,%rax
  4035b1:	cmp    %rax,-0x5f0(%rbp)
  4035b8:	ja     403de8 <main+0x1ac8>
  4035be:	mov    -0x5d0(%rbp),%rax
  4035c5:	xor    %edi,%edi
  4035c7:	shl    $0x8,%rax
  4035cb:	lea    -0xc0(%rbp),%rsi
  4035d2:	mov    %rax,-0x688(%rbp)
  4035d9:	call   402250 <getrusage@plt>
  4035de:	test   %eax,%eax
  4035e0:	jne    403ec9 <main+0x1ba9>
  4035e6:	mov    -0x78(%rbp),%rax
  4035ea:	sub    -0x3d8(%rbp),%rax
  4035f1:	mov    %rax,%rsi
  4035f4:	jne    403ddc <main+0x1abc>
  4035fa:	mov    -0x478(%rbp),%rsi
  403601:	mov    -0x610(%rbp),%rdi
  403608:	call   4021f0 <munmap@plt>
  40360d:	test   %eax,%eax
  40360f:	jne    403dc1 <main+0x1aa1>
  403615:	mov    -0x448(%rbp),%rsi
  40361c:	mov    -0x5e0(%rbp),%rdi
  403623:	call   4021f0 <munmap@plt>
  403628:	test   %eax,%eax
  40362a:	jne    403da6 <main+0x1a86>
  403630:	lea    -0x368(%rbp),%rdi
  403637:	call   402230 <pthread_cond_destroy@plt>
  40363c:	mov    %eax,%edi
  40363e:	test   %eax,%eax
  403640:	jne    403d92 <main+0x1a72>
  403646:	lea    -0x390(%rbp),%rdi
  40364d:	call   4020f0 <pthread_mutex_destroy@plt>
  403652:	mov    %eax,%edi
  403654:	test   %eax,%eax
  403656:	jne    403d7e <main+0x1a5e>
  40365c:	call   404ab0 <now_ns>
  403661:	mov    -0x648(%rbp),%rcx
  403668:	mov    -0x640(%rbp),%rsi
  40366f:	mov    %rcx,%rdi
  403672:	sub    %rsi,%rdi
  403675:	mov    %rdi,-0x5e0(%rbp)
  40367c:	mov    -0x650(%rbp),%rdi
  403683:	mov    %rdi,%rdx
  403686:	sub    %rcx,%rdx
  403689:	mov    %rdx,-0x610(%rbp)
  403690:	mov    -0x658(%rbp),%rdx
  403697:	mov    %rdx,%rcx
  40369a:	sub    %rdi,%rcx
  40369d:	mov    -0x660(%rbp),%rdi
  4036a4:	mov    %rcx,-0x640(%rbp)
  4036ab:	mov    %rdi,%rcx
  4036ae:	sub    %rdx,%rcx
  4036b1:	mov    %rax,%rdx
  4036b4:	sub    %rdi,%rdx
  4036b7:	mov    %rdx,-0x648(%rbp)
  4036be:	mov    -0x500(%rbp),%rdx
  4036c5:	sub    %rsi,%rax
  4036c8:	mov    %rcx,-0x5d0(%rbp)
  4036cf:	mov    %rax,-0x650(%rbp)
  4036d6:	test   %rdx,%rdx
  4036d9:	je     403d6a <main+0x1a4a>
  4036df:	mov    -0x4f0(%rbp),%rax
  4036e6:	test   %rax,%rax
  4036e9:	je     403d6a <main+0x1a4a>
  4036ef:	test   %rcx,%rcx
  4036f2:	je     403d6a <main+0x1a4a>
  4036f8:	vxorps %xmm0,%xmm0,%xmm0
  4036fc:	vcvtusi2sd %rdx,%xmm0,%xmm1
  403702:	vmovsd 0x3dd6(%rip),%xmm4        # 4074e0 <__dso_handle+0x14d8>
  40370a:	cmpl   $0x1,-0x598(%rbp)
  403711:	vmovsd %xmm1,%xmm1,%xmm2
  403715:	vcvtusi2sdq -0x5b0(%rbp),%xmm0,%xmm1
  40371f:	vdivsd %xmm1,%xmm2,%xmm3
  403723:	vcvtsi2sdq -0x5f0(%rbp),%xmm0,%xmm2
  40372c:	vcvtusi2sd %rax,%xmm0,%xmm1
  403732:	vdivsd %xmm2,%xmm1,%xmm1
  403736:	vcvtusi2sdq -0x5d0(%rbp),%xmm0,%xmm2
  403740:	vdivsd 0x3d90(%rip),%xmm2,%xmm2        # 4074d8 <__dso_handle+0x14d0>
  403748:	vmovsd %xmm3,-0x658(%rbp)
  403750:	vcvtusi2sdq -0x5b8(%rbp),%xmm0,%xmm3
  40375a:	vcvtusi2sdq -0x608(%rbp),%xmm0,%xmm0
  403764:	vmulsd %xmm4,%xmm3,%xmm3
  403768:	vmulsd %xmm4,%xmm0,%xmm0
  40376c:	vdivsd %xmm2,%xmm3,%xmm7
  403770:	vdivsd %xmm2,%xmm0,%xmm6
  403774:	vmovsd %xmm7,-0x660(%rbp)
  40377c:	vmovsd %xmm6,-0x690(%rbp)
  403784:	jne    403d3d <main+0x1a1d>
  40378a:	vxorpd %xmm0,%xmm0,%xmm0
  40378e:	vucomisd %xmm0,%xmm7
  403792:	mov    $0x1,%edx
  403797:	setp   %al
  40379a:	cmovne %edx,%eax
  40379d:	test   %al,%al
  40379f:	jne    403d31 <main+0x1a11>
  4037a5:	vucomisd %xmm0,%xmm6
  4037a9:	setp   %al
  4037ac:	cmovne %edx,%eax
  4037af:	test   %al,%al
  4037b1:	jne    403d31 <main+0x1a11>
  4037b7:	mov    $0x40736f,%edi
  4037bc:	vmovsd %xmm1,-0x598(%rbp)
  4037c4:	call   402030 <getenv@plt>
  4037c9:	test   %rax,%rax
  4037cc:	vmovsd -0x598(%rbp),%xmm1
  4037d4:	mov    %rax,%r8
  4037d7:	je     403d26 <main+0x1a06>
  4037dd:	mov    $0x406f91,%r9d
  4037e3:	mov    0x5996(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  4037ea:	mov    $0x2e,%edx
  4037ef:	mov    $0x1,%esi
  4037f4:	mov    $0x406820,%edi
  4037f9:	mov    %r8,-0x6c0(%rbp)
  403800:	mov    %r9,-0x598(%rbp)
  403807:	vmovsd %xmm1,-0x6b8(%rbp)
  40380f:	call   4022a0 <fwrite@plt>
  403814:	mov    -0x6c0(%rbp),%rdi
  40381b:	call   4048a0 <print_json_string>
  403820:	mov    0x5959(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  403827:	mov    $0xd,%edx
  40382c:	mov    $0x1,%esi
  403831:	mov    $0x40737b,%edi
  403836:	call   4022a0 <fwrite@plt>
  40383b:	mov    -0x598(%rbp),%rdi
  403842:	call   4048a0 <print_json_string>
  403847:	mov    -0x59c(%rbp),%esi
  40384d:	mov    $0x406850,%edi
  403852:	xor    %eax,%eax
  403854:	call   4020e0 <printf@plt>
  403859:	mov    %r13,%rsi
  40385c:	mov    %r15,%rdi
  40385f:	call   404a20 <print_cpu_array>
  403864:	mov    -0x5f8(%rbp),%ecx
  40386a:	mov    -0x5e4(%rbp),%edx
  403870:	mov    -0x5a0(%rbp),%esi
  403876:	mov    $0x406870,%edi
  40387b:	xor    %eax,%eax
  40387d:	call   4020e0 <printf@plt>
  403882:	mov    -0x588(%rbp),%rdi
  403889:	mov    %r13,%rsi
  40388c:	call   404a20 <print_cpu_array>
  403891:	mov    0x58e8(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  403898:	mov    $0x13,%edx
  40389d:	mov    $0x1,%esi
  4038a2:	mov    $0x407389,%edi
  4038a7:	call   4022a0 <fwrite@plt>
  4038ac:	mov    -0x590(%rbp),%rdi
  4038b3:	mov    %r13,%rsi
  4038b6:	call   404a20 <print_cpu_array>
  4038bb:	push   -0x580(%rbp)
  4038c1:	mov    $0x406fa2,%eax
  4038c6:	mov    $0x406f9d,%r9d
  4038cc:	push   -0x628(%rbp)
  4038d2:	test   %r12b,%r12b
  4038d5:	mov    %rax,%rdi
  4038d8:	push   -0x688(%rbp)
  4038de:	cmovne %r9,%rdi
  4038e2:	mov    %rax,%rsi
  4038e5:	push   -0x4f0(%rbp)
  4038eb:	cmpb   $0x0,-0x48c(%rbp)
  4038f2:	cmovne %r9,%rsi
  4038f6:	push   -0x5f0(%rbp)
  4038fc:	cmpb   $0x0,-0x4bc(%rbp)
  403903:	mov    %rax,%rcx
  403906:	push   -0x620(%rbp)
  40390c:	cmovne %r9,%rcx
  403910:	mov    %rax,%rdx
  403913:	push   -0x500(%rbp)
  403919:	test   %bl,%bl
  40391b:	cmovne %r9,%rdx
  40391f:	push   -0x5b0(%rbp)
  403925:	cmpb   $0x0,-0x600(%rbp)
  40392c:	cmove  %rax,%r9
  403930:	push   -0x650(%rbp)
  403936:	mov    $0x40000,%r8d
  40393c:	mov    $0x2,%eax
  403941:	push   -0x648(%rbp)
  403947:	push   -0x5d0(%rbp)
  40394d:	push   -0x640(%rbp)
  403953:	push   -0x610(%rbp)
  403959:	push   -0x5e0(%rbp)
  40395f:	push   %rdi
  403960:	mov    $0x4068f8,%edi
  403965:	push   -0x630(%rbp)
  40396b:	vmovsd -0x6b8(%rbp),%xmm1
  403973:	vmovsd -0x658(%rbp),%xmm0
  40397b:	push   %rsi
  40397c:	mov    -0x5c0(%rbp),%rsi
  403983:	push   -0x498(%rbp)
  403989:	push   -0x4a8(%rbp)
  40398f:	push   %rcx
  403990:	mov    -0x4c0(%rbp),%ecx
  403996:	push   %rcx
  403997:	mov    -0x5d8(%rbp),%rcx
  40399e:	push   -0x4c8(%rbp)
  4039a4:	push   -0x4d0(%rbp)
  4039aa:	push   -0x4d8(%rbp)
  4039b0:	push   %rdx
  4039b1:	mov    -0x5c8(%rbp),%rdx
  4039b8:	push   -0x6b0(%rbp)
  4039be:	call   4020e0 <printf@plt>
  4039c3:	mov    0x57b6(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  4039ca:	add    $0xd0,%rsp
  4039d1:	mov    $0x1b,%edx
  4039d6:	mov    $0x1,%esi
  4039db:	mov    $0x40739d,%edi
  4039e0:	call   4022a0 <fwrite@plt>
  4039e5:	mov    0x5794(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  4039ec:	mov    $0x5b,%edi
  4039f1:	call   402170 <putc@plt>
  4039f6:	mov    -0x618(%rbp),%rbx
  4039fd:	test   %r13,%r13
  403a00:	jne    403a15 <main+0x16f5>
  403a02:	jmp    403a34 <main+0x1714>
  403a04:	mov    0x5775(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  403a0b:	mov    $0x2c,%edi
  403a10:	call   402170 <putc@plt>
  403a15:	mov    -0x5a8(%rbp),%rax
  403a1c:	mov    $0x4073b9,%edi
  403a21:	mov    (%rax,%rbx,8),%rsi
  403a25:	xor    %eax,%eax
  403a27:	inc    %rbx
  403a2a:	call   4020e0 <printf@plt>
  403a2f:	cmp    %rbx,%r13
  403a32:	jne    403a04 <main+0x16e4>
  403a34:	mov    0x5745(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  403a3b:	mov    $0x5d,%edi
  403a40:	call   402170 <putc@plt>
  403a45:	push   $0x0
  403a47:	mov    -0x5b8(%rbp),%rdx
  403a4e:	mov    -0x6a8(%rbp),%r9
  403a55:	push   -0x680(%rbp)
  403a5b:	mov    -0x638(%rbp),%r8
  403a62:	vmovsd -0x690(%rbp),%xmm1
  403a6a:	push   -0x678(%rbp)
  403a70:	vmovsd -0x660(%rbp),%xmm0
  403a78:	mov    -0x608(%rbp),%rcx
  403a7f:	push   -0x670(%rbp)
  403a85:	mov    %rdx,%rsi
  403a88:	mov    $0x406c08,%edi
  403a8d:	push   -0x668(%rbp)
  403a93:	mov    $0x2,%eax
  403a98:	push   -0x698(%rbp)
  403a9e:	push   -0x6a0(%rbp)
  403aa4:	push   $0x0
  403aa6:	call   4020e0 <printf@plt>
  403aab:	mov    -0x588(%rbp),%rdi
  403ab2:	add    $0x40,%rsp
  403ab6:	call   402040 <free@plt>
  403abb:	mov    -0x590(%rbp),%rdi
  403ac2:	call   402040 <free@plt>
  403ac7:	mov    -0x5a8(%rbp),%rdi
  403ace:	call   402040 <free@plt>
  403ad3:	mov    -0x578(%rbp),%rdi
  403ada:	call   402040 <free@plt>
  403adf:	mov    %r14,%rdi
  403ae2:	call   402040 <free@plt>
  403ae7:	mov    %r15,%rdi
  403aea:	call   402040 <free@plt>
  403aef:	lea    -0x30(%rbp),%rsp
  403af3:	pop    %rbx
  403af4:	pop    %r10
  403af6:	pop    %r12
  403af8:	pop    %r13
  403afa:	pop    %r14
  403afc:	pop    %r15
  403afe:	xor    %eax,%eax
  403b00:	pop    %rbp
  403b01:	lea    -0x8(%r10),%rsp
  403b05:	ret
  403b06:	mov    %r9d,%edx
  403b09:	mov    %r8,%rsi
  403b0c:	mov    $0x406038,%edi
  403b11:	xor    %eax,%eax
  403b13:	call   4042e0 <failf>
  403b18:	mov    $0x407294,%edi
  403b1d:	call   404ae0 <read_usage.part.0>
  403b22:	mov    $0x406538,%edi
  403b27:	xor    %eax,%eax
  403b29:	call   4042e0 <failf>
  403b2e:	mov    $0x406508,%edi
  403b33:	xor    %eax,%eax
  403b35:	call   4042e0 <failf>
  403b3a:	movq   $0x0,-0x630(%rbp)
  403b45:	movq   $0x0,-0x638(%rbp)
  403b50:	movq   $0x0,-0x580(%rbp)
  403b5b:	mov    %r12d,%edx
  403b5e:	jmp    403555 <main+0x1235>
  403b63:	call   402050 <__errno_location@plt>
  403b68:	mov    (%rax),%edi
  403b6a:	call   4022e0 <strerror@plt>
  403b6f:	mov    %rax,%rsi
  403b72:	mov    $0x4065d8,%edi
  403b77:	xor    %eax,%eax
  403b79:	call   4042e0 <failf>
  403b7e:	mov    $0x406598,%edi
  403b83:	xor    %eax,%eax
  403b85:	call   4042e0 <failf>
  403b8a:	call   4022e0 <strerror@plt>
  403b8f:	mov    %rax,%rsi
  403b92:	mov    $0x406f35,%edi
  403b97:	xor    %eax,%eax
  403b99:	call   4042e0 <failf>
  403b9e:	mov    -0x5f8(%rbp),%ecx
  403ba4:	mov    -0x5e4(%rbp),%edx
  403baa:	mov    -0x59c(%rbp),%esi
  403bb0:	mov    $0x406568,%edi
  403bb5:	xor    %eax,%eax
  403bb7:	call   4042e0 <failf>
  403bbc:	call   4022e0 <strerror@plt>
  403bc1:	mov    %rax,%rsi
  403bc4:	mov    $0x40723f,%edi
  403bc9:	xor    %eax,%eax
  403bcb:	call   4042e0 <failf>
  403bd0:	call   4022e0 <strerror@plt>
  403bd5:	mov    %rax,%rsi
  403bd8:	mov    $0x406408,%edi
  403bdd:	xor    %eax,%eax
  403bdf:	call   4042e0 <failf>
  403be4:	call   4022e0 <strerror@plt>
  403be9:	mov    %rax,%rsi
  403bec:	mov    $0x40720a,%edi
  403bf1:	xor    %eax,%eax
  403bf3:	call   4042e0 <failf>
  403bf8:	lea    -0x390(%rbp),%rdi
  403bff:	call   402310 <pthread_mutex_lock@plt>
  403c04:	mov    %eax,%edi
  403c06:	test   %eax,%eax
  403c08:	je     403c31 <main+0x1911>
  403c0a:	jmp    403cfe <main+0x19de>
  403c0f:	test   %rdx,%rdx
  403c12:	jne    403cc4 <main+0x19a4>
  403c18:	lea    -0x368(%rbp),%rdi
  403c1f:	lea    -0x390(%rbp),%rsi
  403c26:	call   4020a0 <pthread_cond_wait@plt>
  403c2b:	mov    %eax,%edi
  403c2d:	test   %eax,%eax
  403c2f:	jne    403cb0 <main+0x1990>
  403c31:	mov    -0x318(%rbp),%rdx
  403c38:	cmp    %r13,-0x320(%rbp)
  403c3f:	jne    403c0f <main+0x18ef>
  403c41:	lea    -0x390(%rbp),%rdi
  403c48:	mov    %rdx,-0x580(%rbp)
  403c4f:	call   4021b0 <pthread_mutex_unlock@plt>
  403c54:	test   %eax,%eax
  403c56:	mov    -0x580(%rbp),%rdx
  403c5d:	mov    %eax,%edi
  403c5f:	jne    403cd6 <main+0x19b6>
  403c61:	test   %rdx,%rdx
  403c64:	je     402f42 <main+0xc22>
  403c6a:	lea    -0x390(%rbp),%rdi
  403c71:	call   404bc0 <stop_workers>
  403c76:	mov    %r13,%rsi
  403c79:	mov    %r14,%rdi
  403c7c:	call   404850 <join_workers>
  403c81:	mov    -0x578(%rbp),%rdi
  403c88:	mov    %r13,%rsi
  403c8b:	call   4043a0 <fail_if_worker_error>
  403c90:	mov    $0x4064d8,%edi
  403c95:	xor    %eax,%eax
  403c97:	call   4042e0 <failf>
  403c9c:	call   4022e0 <strerror@plt>
  403ca1:	mov    %rax,%rsi
  403ca4:	mov    $0x407277,%edi
  403ca9:	xor    %eax,%eax
  403cab:	call   4042e0 <failf>
  403cb0:	call   4022e0 <strerror@plt>
  403cb5:	mov    %rax,%rsi
  403cb8:	mov    $0x406478,%edi
  403cbd:	xor    %eax,%eax
  403cbf:	call   4042e0 <failf>
  403cc4:	lea    -0x390(%rbp),%rdi
  403ccb:	call   4021b0 <pthread_mutex_unlock@plt>
  403cd0:	mov    %eax,%edi
  403cd2:	test   %eax,%eax
  403cd4:	je     403c6a <main+0x194a>
  403cd6:	call   4022e0 <strerror@plt>
  403cdb:	mov    %rax,%rsi
  403cde:	mov    $0x4064a8,%edi
  403ce3:	xor    %eax,%eax
  403ce5:	call   4042e0 <failf>
  403cea:	call   4022e0 <strerror@plt>
  403cef:	mov    %rax,%rsi
  403cf2:	mov    $0x406428,%edi
  403cf7:	xor    %eax,%eax
  403cf9:	call   4042e0 <failf>
  403cfe:	call   4022e0 <strerror@plt>
  403d03:	mov    %rax,%rsi
  403d06:	mov    $0x406448,%edi
  403d0b:	xor    %eax,%eax
  403d0d:	call   4042e0 <failf>
  403d12:	call   4022e0 <strerror@plt>
  403d17:	mov    %rax,%rsi
  403d1a:	mov    $0x40725c,%edi
  403d1f:	xor    %eax,%eax
  403d21:	call   4042e0 <failf>
  403d26:	mov    $0x406f48,%r8d
  403d2c:	jmp    4037dd <main+0x14bd>
  403d31:	mov    $0x4067f0,%edi
  403d36:	xor    %eax,%eax
  403d38:	call   4042e0 <failf>
  403d3d:	mov    $0x40736f,%edi
  403d42:	vmovsd %xmm1,-0x598(%rbp)
  403d4a:	call   402030 <getenv@plt>
  403d4f:	test   %rax,%rax
  403d52:	vmovsd -0x598(%rbp),%xmm1
  403d5a:	mov    %rax,%r8
  403d5d:	je     403d76 <main+0x1a56>
  403d5f:	mov    $0x406f96,%r9d
  403d65:	jmp    4037e3 <main+0x14c3>
  403d6a:	mov    $0x4067b8,%edi
  403d6f:	xor    %eax,%eax
  403d71:	call   4042e0 <failf>
  403d76:	mov    $0x406f48,%r8d
  403d7c:	jmp    403d5f <main+0x1a3f>
  403d7e:	call   4022e0 <strerror@plt>
  403d83:	mov    %rax,%rsi
  403d86:	mov    $0x407355,%edi
  403d8b:	xor    %eax,%eax
  403d8d:	call   4042e0 <failf>
  403d92:	call   4022e0 <strerror@plt>
  403d97:	mov    %rax,%rsi
  403d9a:	mov    $0x40733c,%edi
  403d9f:	xor    %eax,%eax
  403da1:	call   4042e0 <failf>
  403da6:	call   402050 <__errno_location@plt>
  403dab:	mov    (%rax),%edi
  403dad:	call   4022e0 <strerror@plt>
  403db2:	mov    %rax,%rsi
  403db5:	mov    $0x407325,%edi
  403dba:	xor    %eax,%eax
  403dbc:	call   4042e0 <failf>
  403dc1:	call   402050 <__errno_location@plt>
  403dc6:	mov    (%rax),%edi
  403dc8:	call   4022e0 <strerror@plt>
  403dcd:	mov    %rax,%rsi
  403dd0:	mov    $0x40730e,%edi
  403dd5:	xor    %eax,%eax
  403dd7:	call   4042e0 <failf>
  403ddc:	mov    $0x406788,%edi
  403de1:	xor    %eax,%eax
  403de3:	call   4042e0 <failf>
  403de8:	mov    $0x4072f4,%edi
  403ded:	xor    %eax,%eax
  403def:	call   4042e0 <failf>
  403df4:	mov    $0x406708,%edi
  403df9:	xor    %eax,%eax
  403dfb:	call   4042e0 <failf>
  403e00:	mov    $0x4066d8,%edi
  403e05:	xor    %eax,%eax
  403e07:	call   4042e0 <failf>
  403e0c:	cmp    -0x580(%rbp),%r13
  403e13:	ja     403ea5 <main+0x1b85>
  403e19:	cmp    %rax,%r13
  403e1c:	jne    403ea5 <main+0x1b85>
  403e22:	test   %dl,%dl
  403e24:	je     403df4 <main+0x1ad4>
  403e26:	movabs $0x3fffffffffff,%rax
  403e30:	cmp    %rax,-0x580(%rbp)
  403e37:	ja     403e99 <main+0x1b79>
  403e39:	mov    -0x580(%rbp),%rax
  403e40:	shl    $0x12,%rax
  403e44:	mov    %rax,-0x5b8(%rbp)
  403e4b:	not    %rax
  403e4e:	shr    $0x12,%rax
  403e52:	cmp    %r13,%rax
  403e55:	jb     403e8d <main+0x1b6d>
  403e57:	mov    %r13,%rax
  403e5a:	shl    $0x12,%rax
  403e5e:	add    -0x5b8(%rbp),%rax
  403e65:	mov    %rax,-0x608(%rbp)
  403e6c:	jae    4035a7 <main+0x1287>
  403e72:	mov    $0x406760,%edi
  403e77:	xor    %eax,%eax
  403e79:	call   4042e0 <failf>
  403e7e:	mov    %rax,%rsi
  403e81:	mov    $0x406670,%edi
  403e86:	xor    %eax,%eax
  403e88:	call   4042e0 <failf>
  403e8d:	mov    $0x406738,%edi
  403e92:	xor    %eax,%eax
  403e94:	call   4042e0 <failf>
  403e99:	mov    $0x4072d9,%edi
  403e9e:	xor    %eax,%eax
  403ea0:	call   4042e0 <failf>
  403ea5:	mov    $0x4066a8,%edi
  403eaa:	xor    %eax,%eax
  403eac:	call   4042e0 <failf>
  403eb1:	mov    $0x4072bd,%edi
  403eb6:	xor    %eax,%eax
  403eb8:	call   4042e0 <failf>
  403ebd:	mov    $0x406638,%edi
  403ec2:	xor    %eax,%eax
  403ec4:	call   4042e0 <failf>
  403ec9:	mov    $0x406fa8,%edi
  403ece:	call   404ae0 <read_usage.part.0>
  403ed3:	mov    -0x590(%rbp),%rsi
  403eda:	mov    $0x4070a8,%edi
  403edf:	xor    %eax,%eax
  403ee1:	call   4042e0 <failf>
  403ee6:	mov    %r14,%rdi
  403ee9:	call   402040 <free@plt>
  403eee:	mov    -0x5b8(%rbp),%rdi
  403ef5:	call   402040 <free@plt>
  403efa:	mov    -0x590(%rbp),%rsi
  403f01:	mov    $0x406248,%edi
  403f06:	xor    %eax,%eax
  403f08:	call   4042e0 <failf>
  403f0d:	mov    -0x5b8(%rbp),%rdi
  403f14:	call   402040 <free@plt>
  403f19:	mov    %r13,%rdi
  403f1c:	call   402040 <free@plt>
  403f21:	mov    $0x4062a8,%edi
  403f26:	xor    %eax,%eax
  403f28:	call   4042e0 <failf>
  403f2d:	mov    %r14,%rdi
  403f30:	call   402040 <free@plt>
  403f35:	mov    -0x5b8(%rbp),%rdi
  403f3c:	call   402040 <free@plt>
  403f41:	mov    (%rbx),%edi
  403f43:	call   4022e0 <strerror@plt>
  403f48:	mov    %rax,%rsi
  403f4b:	mov    $0x407076,%edi
  403f50:	xor    %eax,%eax
  403f52:	call   4042e0 <failf>
  403f57:	mov    %r14,%rdi
  403f5a:	call   402040 <free@plt>
  403f5f:	mov    -0x5b8(%rbp),%rdi
  403f66:	call   402040 <free@plt>
  403f6b:	mov    $0x407059,%edi
  403f70:	xor    %eax,%eax
  403f72:	call   4042e0 <failf>
  403f77:	mov    -0x590(%rbp),%rdx
  403f7e:	mov    $0x40709e,%esi
  403f83:	mov    $0x406eaa,%edi
  403f88:	xor    %eax,%eax
  403f8a:	call   4042e0 <failf>
  403f8f:	mov    -0x590(%rbp),%rdx
  403f96:	mov    $0x406ffe,%esi
  403f9b:	mov    $0x4061f0,%edi
  403fa0:	xor    %eax,%eax
  403fa2:	call   4042e0 <failf>
  403fa7:	mov    %rbx,%rsi
  403faa:	mov    $0x406fdc,%edi
  403faf:	xor    %eax,%eax
  403fb1:	call   4042e0 <failf>
  403fb6:	mov    -0x5d0(%rbp),%rax
  403fbd:	mov    0x51dc(%rip),%rdi        # 4091a0 <stderr@GLIBC_2.2.5>
  403fc4:	mov    (%rax),%rdx
  403fc7:	mov    $0x406120,%esi
  403fcc:	xor    %eax,%eax
  403fce:	call   402180 <fprintf@plt>
  403fd3:	mov    -0x578(%rbp),%rax
  403fda:	mov    $0x406fbb,%edi
  403fdf:	mov    (%rax),%rsi
  403fe2:	xor    %eax,%eax
  403fe4:	call   4042e0 <failf>
  403fe9:	mov    %r13,%rdx
  403fec:	mov    $0x40704e,%esi
  403ff1:	mov    $0x4061f0,%edi
  403ff6:	xor    %eax,%eax
  403ff8:	call   4042e0 <failf>
  403ffd:	mov    -0x59c(%rbp),%esi
  404003:	mov    $0x406330,%edi
  404008:	xor    %eax,%eax
  40400a:	call   4042e0 <failf>
  40400f:	mov    -0x5b8(%rbp),%rdi
  404016:	call   402040 <free@plt>
  40401b:	call   402050 <__errno_location@plt>
  404020:	mov    (%rax),%edi
  404022:	call   4022e0 <strerror@plt>
  404027:	mov    %rax,%rsi
  40402a:	mov    $0x407031,%edi
  40402f:	xor    %eax,%eax
  404031:	call   4042e0 <failf>
  404036:	call   402050 <__errno_location@plt>
  40403b:	mov    (%rax),%edi
  40403d:	call   4022e0 <strerror@plt>
  404042:	mov    %rax,%rsi
  404045:	mov    $0x407016,%edi
  40404a:	xor    %eax,%eax
  40404c:	call   4042e0 <failf>
  404051:	mov    $0x4062d8,%edi
  404056:	xor    %eax,%eax
  404058:	call   4042e0 <failf>
  40405d:	mov    $0x406308,%edi
  404062:	xor    %eax,%eax
  404064:	call   4042e0 <failf>
  404069:	call   4022e0 <strerror@plt>
  40406e:	mov    %rax,%rsi
  404071:	mov    $0x407155,%edi
  404076:	xor    %eax,%eax
  404078:	call   4042e0 <failf>
  40407d:	call   4022e0 <strerror@plt>
  404082:	mov    %rax,%rsi
  404085:	mov    $0x40713e,%edi
  40408a:	xor    %eax,%eax
  40408c:	call   4042e0 <failf>
  404091:	mov    -0x504(%rbp),%edi
  404097:	call   4022e0 <strerror@plt>
  40409c:	mov    -0x5a0(%rbp),%esi
  4040a2:	mov    %rax,%rdx
  4040a5:	mov    $0x4063b0,%edi
  4040aa:	xor    %eax,%eax
  4040ac:	call   4042e0 <failf>
  4040b1:	mov    -0x59c(%rbp),%esi
  4040b7:	mov    $0x406388,%edi
  4040bc:	xor    %eax,%eax
  4040be:	call   4042e0 <failf>
  4040c3:	mov    -0x590(%rbp),%rdx
  4040ca:	mov    $0x406ffe,%esi
  4040cf:	mov    $0x406eaa,%edi
  4040d4:	xor    %eax,%eax
  4040d6:	call   4042e0 <failf>
  4040db:	mov    -0x5d0(%rbp),%rax
  4040e2:	mov    0x50b7(%rip),%rdi        # 4091a0 <stderr@GLIBC_2.2.5>
  4040e9:	mov    (%rax),%rdx
  4040ec:	mov    $0x406120,%esi
  4040f1:	xor    %eax,%eax
  4040f3:	call   402180 <fprintf@plt>
  4040f8:	mov    -0x578(%rbp),%rax
  4040ff:	mov    $0x407111,%edi
  404104:	mov    (%rax),%rsi
  404107:	xor    %eax,%eax
  404109:	call   4042e0 <failf>
  40410e:	mov    $0x406218,%edi
  404113:	call   4042e0 <failf>
  404118:	mov    -0x5d0(%rbp),%rax
  40411f:	mov    0x507a(%rip),%rdi        # 4091a0 <stderr@GLIBC_2.2.5>
  404126:	mov    (%rax),%rdx
  404129:	mov    $0x406120,%esi
  40412e:	xor    %eax,%eax
  404130:	call   402180 <fprintf@plt>
  404135:	mov    $0x4061a8,%edi
  40413a:	xor    %eax,%eax
  40413c:	call   4042e0 <failf>
  404141:	call   4022e0 <strerror@plt>
  404146:	mov    %rax,%rsi
  404149:	mov    $0x4071a6,%edi
  40414e:	xor    %eax,%eax
  404150:	call   4042e0 <failf>
  404155:	call   4022e0 <strerror@plt>
  40415a:	mov    %rax,%rsi
  40415d:	mov    $0x4071c3,%edi
  404162:	xor    %eax,%eax
  404164:	call   4042e0 <failf>
  404169:	call   4022e0 <strerror@plt>
  40416e:	mov    %rax,%rdx
  404171:	mov    %r12,%rsi
  404174:	mov    $0x407188,%edi
  404179:	xor    %eax,%eax
  40417b:	call   4042e0 <failf>
  404180:	call   402050 <__errno_location@plt>
  404185:	mov    (%rax),%edi
  404187:	call   4022e0 <strerror@plt>
  40418c:	mov    %rax,%rsi
  40418f:	mov    $0x40716b,%edi
  404194:	xor    %eax,%eax
  404196:	call   4042e0 <failf>
  40419b:	call   4022e0 <strerror@plt>
  4041a0:	mov    %rax,%rsi
  4041a3:	mov    $0x4063e8,%edi
  4041a8:	xor    %eax,%eax
  4041aa:	call   4042e0 <failf>
  4041af:	call   4022e0 <strerror@plt>
  4041b4:	mov    %rax,%rsi
  4041b7:	mov    $0x4071fc,%edi
  4041bc:	xor    %eax,%eax
  4041be:	call   4042e0 <failf>
  4041c3:	mov    $0x4071df,%edi
  4041c8:	xor    %eax,%eax
  4041ca:	call   4042e0 <failf>
  4041cf:	call   4022e0 <strerror@plt>
  4041d4:	mov    %rax,%rsi
  4041d7:	mov    $0x407225,%edi
  4041dc:	xor    %eax,%eax
  4041de:	call   4042e0 <failf>
  4041e3:	cs nopw 0x0(%rax,%rax,1)
  4041ed:	nopl   (%rax)

00000000004041f0 <_start>:
  4041f0:	endbr64
  4041f4:	xor    %ebp,%ebp
  4041f6:	mov    %rdx,%r9
  4041f9:	pop    %rsi
  4041fa:	mov    %rsp,%rdx
  4041fd:	and    $0xfffffffffffffff0,%rsp
  404201:	push   %rax
  404202:	push   %rsp
  404203:	xor    %r8d,%r8d
  404206:	xor    %ecx,%ecx
  404208:	mov    $0x402320,%rdi
  40420f:	call   *0x4db3(%rip)        # 408fc8 <__libc_start_main@GLIBC_2.34>
  404215:	hlt
  404216:	cs nopw 0x0(%rax,%rax,1)

0000000000404220 <_dl_relocate_static_pie>:
  404220:	endbr64
  404224:	ret
  404225:	cs nopw 0x0(%rax,%rax,1)
  40422f:	nop

0000000000404230 <deregister_tm_clones>:
  404230:	lea    0x4f49(%rip),%rdi        # 409180 <stdout@GLIBC_2.2.5>
  404237:	lea    0x4f42(%rip),%rax        # 409180 <stdout@GLIBC_2.2.5>
  40423e:	cmp    %rdi,%rax
  404241:	je     404258 <deregister_tm_clones+0x28>
  404243:	mov    0x4d86(%rip),%rax        # 408fd0 <_ITM_deregisterTMCloneTable@Base>
  40424a:	test   %rax,%rax
  40424d:	je     404258 <deregister_tm_clones+0x28>
  40424f:	jmp    *%rax
  404251:	nopl   0x0(%rax)
  404258:	ret
  404259:	nopl   0x0(%rax)

0000000000404260 <register_tm_clones>:
  404260:	lea    0x4f19(%rip),%rdi        # 409180 <stdout@GLIBC_2.2.5>
  404267:	lea    0x4f12(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  40426e:	sub    %rdi,%rsi
  404271:	mov    %rsi,%rax
  404274:	shr    $0x3f,%rsi
  404278:	sar    $0x3,%rax
  40427c:	add    %rax,%rsi
  40427f:	sar    $1,%rsi
  404282:	je     404298 <register_tm_clones+0x38>
  404284:	mov    0x4d55(%rip),%rax        # 408fe0 <_ITM_registerTMCloneTable@Base>
  40428b:	test   %rax,%rax
  40428e:	je     404298 <register_tm_clones+0x38>
  404290:	jmp    *%rax
  404292:	nopw   0x0(%rax,%rax,1)
  404298:	ret
  404299:	nopl   0x0(%rax)

00000000004042a0 <__do_global_dtors_aux>:
  4042a0:	endbr64
  4042a4:	cmpb   $0x0,0x4efd(%rip)        # 4091a8 <completed.0>
  4042ab:	jne    4042c0 <__do_global_dtors_aux+0x20>
  4042ad:	push   %rbp
  4042ae:	mov    %rsp,%rbp
  4042b1:	call   404230 <deregister_tm_clones>
  4042b6:	movb   $0x1,0x4eeb(%rip)        # 4091a8 <completed.0>
  4042bd:	pop    %rbp
  4042be:	ret
  4042bf:	nop
  4042c0:	ret
  4042c1:	data16 cs nopw 0x0(%rax,%rax,1)
  4042cc:	nopl   0x0(%rax)

00000000004042d0 <frame_dummy>:
  4042d0:	endbr64
  4042d4:	jmp    404260 <register_tm_clones>
  4042d6:	cs nopw 0x0(%rax,%rax,1)

00000000004042e0 <failf>:
  4042e0:	sub    $0xd8,%rsp
  4042e7:	mov    %rsi,0x28(%rsp)
  4042ec:	mov    %rdx,0x30(%rsp)
  4042f1:	mov    %rcx,0x38(%rsp)
  4042f6:	mov    %r8,0x40(%rsp)
  4042fb:	mov    %r9,0x48(%rsp)
  404300:	mov    %rdi,%r10
  404303:	test   %al,%al
  404305:	je     404346 <failf+0x66>
  404307:	vmovaps %xmm0,0x50(%rsp)
  40430d:	vmovaps %xmm1,0x60(%rsp)
  404313:	vmovaps %xmm2,0x70(%rsp)
  404319:	vmovaps %xmm3,0x80(%rsp)
  404322:	vmovaps %xmm4,0x90(%rsp)
  40432b:	vmovaps %xmm5,0xa0(%rsp)
  404334:	vmovaps %xmm6,0xb0(%rsp)
  40433d:	vmovaps %xmm7,0xc0(%rsp)
  404346:	mov    0x4e53(%rip),%rdi        # 4091a0 <stderr@GLIBC_2.2.5>
  40434d:	lea    0xe0(%rsp),%rax
  404355:	mov    %r10,%rsi
  404358:	mov    %rax,0x10(%rsp)
  40435d:	lea    0x8(%rsp),%rdx
  404362:	lea    0x20(%rsp),%rax
  404367:	movl   $0x8,0x8(%rsp)
  40436f:	movl   $0x30,0xc(%rsp)
  404377:	mov    %rax,0x18(%rsp)
  40437c:	call   402270 <vfprintf@plt>
  404381:	mov    0x4e18(%rip),%rsi        # 4091a0 <stderr@GLIBC_2.2.5>
  404388:	mov    $0xa,%edi
  40438d:	call   402110 <fputc@plt>
  404392:	mov    $0x2,%edi
  404397:	call   402290 <exit@plt>
  40439c:	nopl   0x0(%rax)

00000000004043a0 <fail_if_worker_error>:
  4043a0:	test   %rsi,%rsi
  4043a3:	je     404402 <fail_if_worker_error+0x62>
  4043a5:	push   %rbp
  4043a6:	xor    %ebp,%ebp
  4043a8:	push   %rbx
  4043a9:	mov    %rdi,%rbx
  4043ac:	sub    $0x8,%rsp
  4043b0:	jmp    4043c7 <fail_if_worker_error+0x27>
  4043b2:	nopw   0x0(%rax,%rax,1)
  4043b8:	inc    %rbp
  4043bb:	add    $0x88,%rbx
  4043c2:	cmp    %rbp,%rsi
  4043c5:	je     4043ef <fail_if_worker_error+0x4f>
  4043c7:	mov    0x1c(%rbx),%edx
  4043ca:	test   %edx,%edx
  4043cc:	je     4043b8 <fail_if_worker_error+0x18>
  4043ce:	mov    0x20(%rbx),%edi
  4043d1:	test   %edi,%edi
  4043d3:	je     4043f3 <fail_if_worker_error+0x53>
  4043d5:	call   4022e0 <strerror@plt>
  4043da:	mov    0x1c(%rbx),%edx
  4043dd:	mov    %rax,%rcx
  4043e0:	mov    %rbp,%rsi
  4043e3:	mov    $0x406010,%edi
  4043e8:	xor    %eax,%eax
  4043ea:	call   4042e0 <failf>
  4043ef:	pop    %rax
  4043f0:	pop    %rbx
  4043f1:	pop    %rbp
  4043f2:	ret
  4043f3:	mov    %rbp,%rsi
  4043f6:	mov    $0x406038,%edi
  4043fb:	xor    %eax,%eax
  4043fd:	call   4042e0 <failf>
  404402:	ret
  404403:	data16 cs nopw 0x0(%rax,%rax,1)
  40440e:	xchg   %ax,%ax

0000000000404410 <broadcast_phase>:
  404410:	push   %rbp
  404411:	mov    %rdi,%rbp
  404414:	push   %rbx
  404415:	mov    %esi,%ebx
  404417:	sub    $0x8,%rsp
  40441b:	call   402310 <pthread_mutex_lock@plt>
  404420:	test   %eax,%eax
  404422:	jne    404447 <broadcast_phase+0x37>
  404424:	mov    %ebx,0x58(%rbp)
  404427:	lea    0x28(%rbp),%rdi
  40442b:	call   402070 <pthread_cond_broadcast@plt>
  404430:	test   %eax,%eax
  404432:	jne    404473 <broadcast_phase+0x63>
  404434:	mov    %rbp,%rdi
  404437:	call   4021b0 <pthread_mutex_unlock@plt>
  40443c:	test   %eax,%eax
  40443e:	jne    40445d <broadcast_phase+0x4d>
  404440:	add    $0x8,%rsp
  404444:	pop    %rbx
  404445:	pop    %rbp
  404446:	ret
  404447:	mov    %eax,%edi
  404449:	call   4022e0 <strerror@plt>
  40444e:	mov    %rax,%rsi
  404451:	mov    $0x406e5f,%edi
  404456:	xor    %eax,%eax
  404458:	call   4042e0 <failf>
  40445d:	mov    %eax,%edi
  40445f:	call   4022e0 <strerror@plt>
  404464:	mov    %rax,%rsi
  404467:	mov    $0x406e91,%edi
  40446c:	xor    %eax,%eax
  40446e:	call   4042e0 <failf>
  404473:	mov    %eax,%edi
  404475:	call   4022e0 <strerror@plt>
  40447a:	mov    %rax,%rsi
  40447d:	mov    $0x406e76,%edi
  404482:	xor    %eax,%eax
  404484:	call   4042e0 <failf>
  404489:	nopl   0x0(%rax)

0000000000404490 <worker_wait_for_phase>:
  404490:	push   %r14
  404492:	push   %r13
  404494:	mov    %rdi,%r13
  404497:	push   %r12
  404499:	push   %rbp
  40449a:	push   %rbx
  40449b:	mov    %esi,%ebx
  40449d:	mov    (%rdi),%r14
  4044a0:	mov    %r14,%rdi
  4044a3:	call   402310 <pthread_mutex_lock@plt>
  4044a8:	lea    0x58(%r14),%rbp
  4044ac:	lea    0x28(%r14),%r12
  4044b0:	test   %eax,%eax
  4044b2:	je     4044cf <worker_wait_for_phase+0x3f>
  4044b4:	jmp    404500 <worker_wait_for_phase+0x70>
  4044b6:	cs nopw 0x0(%rax,%rax,1)
  4044c0:	mov    %r14,%rsi
  4044c3:	mov    %r12,%rdi
  4044c6:	call   4020a0 <pthread_cond_wait@plt>
  4044cb:	test   %eax,%eax
  4044cd:	jne    404520 <worker_wait_for_phase+0x90>
  4044cf:	mov    0x0(%rbp),%eax
  4044d2:	cmp    %ebx,%eax
  4044d4:	je     4044c0 <worker_wait_for_phase+0x30>
  4044d6:	mov    %r14,%rdi
  4044d9:	call   4021b0 <pthread_mutex_unlock@plt>
  4044de:	test   %eax,%eax
  4044e0:	je     4044f6 <worker_wait_for_phase+0x66>
  4044e2:	mov    0x1c(%r13),%edx
  4044e6:	test   %edx,%edx
  4044e8:	jne    4044f6 <worker_wait_for_phase+0x66>
  4044ea:	movl   $0x16,0x1c(%r13)
  4044f2:	mov    %eax,0x20(%r13)
  4044f6:	pop    %rbx
  4044f7:	pop    %rbp
  4044f8:	pop    %r12
  4044fa:	pop    %r13
  4044fc:	pop    %r14
  4044fe:	ret
  4044ff:	nop
  404500:	mov    0x1c(%r13),%esi
  404504:	test   %esi,%esi
  404506:	jne    4044f6 <worker_wait_for_phase+0x66>
  404508:	pop    %rbx
  404509:	pop    %rbp
  40450a:	pop    %r12
  40450c:	movl   $0x14,0x1c(%r13)
  404514:	mov    %eax,0x20(%r13)
  404518:	pop    %r13
  40451a:	pop    %r14
  40451c:	ret
  40451d:	nopl   (%rax)
  404520:	mov    0x1c(%r13),%ecx
  404524:	test   %ecx,%ecx
  404526:	jne    4044d6 <worker_wait_for_phase+0x46>
  404528:	movl   $0x15,0x1c(%r13)
  404530:	mov    %eax,0x20(%r13)
  404534:	mov    %r14,%rdi
  404537:	call   4021b0 <pthread_mutex_unlock@plt>
  40453c:	test   %eax,%eax
  40453e:	je     4044f6 <worker_wait_for_phase+0x66>
  404540:	jmp    4044e2 <worker_wait_for_phase+0x52>
  404542:	data16 cs nopw 0x0(%rax,%rax,1)
  40454d:	nopl   (%rax)

0000000000404550 <parse_u64>:
  404550:	push   %r12
  404552:	mov    %rdi,%r12
  404555:	push   %rbp
  404556:	mov    %rsi,%rbp
  404559:	push   %rbx
  40455a:	sub    $0x10,%rsp
  40455e:	movq   $0x0,0x8(%rsp)
  404567:	call   402050 <__errno_location@plt>
  40456c:	movl   $0x0,(%rax)
  404572:	mov    $0xa,%edx
  404577:	lea    0x8(%rsp),%rsi
  40457c:	mov    %r12,%rdi
  40457f:	mov    %rax,%rbx
  404582:	call   402130 <strtoull@plt>
  404587:	movzbl (%r12),%ecx
  40458c:	lea    -0x30(%rcx),%edx
  40458f:	cmp    $0x9,%dl
  404592:	ja     4045b2 <parse_u64+0x62>
  404594:	mov    (%rbx),%edx
  404596:	test   %edx,%edx
  404598:	jne    4045b2 <parse_u64+0x62>
  40459a:	mov    0x8(%rsp),%rdx
  40459f:	cmp    %r12,%rdx
  4045a2:	je     4045b2 <parse_u64+0x62>
  4045a4:	cmpb   $0x0,(%rdx)
  4045a7:	jne    4045b2 <parse_u64+0x62>
  4045a9:	add    $0x10,%rsp
  4045ad:	pop    %rbx
  4045ae:	pop    %rbp
  4045af:	pop    %r12
  4045b1:	ret
  4045b2:	mov    %r12,%rdx
  4045b5:	mov    %rbp,%rsi
  4045b8:	mov    $0x406eaa,%edi
  4045bd:	xor    %eax,%eax
  4045bf:	call   4042e0 <failf>
  4045c4:	data16 cs nopw 0x0(%rax,%rax,1)
  4045cf:	nop

00000000004045d0 <read_map_evidence>:
  4045d0:	push   %r15
  4045d2:	push   %r14
  4045d4:	push   %r13
  4045d6:	push   %r12
  4045d8:	mov    %rdi,%r12
  4045db:	mov    $0x406eb9,%edi
  4045e0:	push   %rbp
  4045e1:	push   %rbx
  4045e2:	sub    $0x68,%rsp
  4045e6:	mov    %rsi,0x20(%rsp)
  4045eb:	mov    $0x406f56,%esi
  4045f0:	call   402240 <fopen@plt>
  4045f5:	test   %rax,%rax
  4045f8:	je     40481d <read_map_evidence+0x24d>
  4045fe:	movq   $0x0,0x38(%rsp)
  404607:	movq   $0x0,0x40(%rsp)
  404610:	movl   $0xffffffff,0x1c(%rsp)
  404618:	movq   $0x0,0x10(%rsp)
  404621:	movq   $0x0,0x8(%rsp)
  40462a:	mov    %rax,%rbp
  40462d:	xor    %r15d,%r15d
  404630:	xor    %r13d,%r13d
  404633:	xor    %r14d,%r14d
  404636:	xor    %ebx,%ebx
  404638:	mov    %rbp,%rcx
  40463b:	mov    $0xa,%edx
  404640:	lea    0x40(%rsp),%rsi
  404645:	lea    0x38(%rsp),%rdi
  40464a:	call   402150 <__getdelim@plt>
  40464f:	test   %rax,%rax
  404652:	js     4046c8 <read_map_evidence+0xf8>
  404654:	mov    0x38(%rsp),%rdi
  404659:	xor    %eax,%eax
  40465b:	lea    0x50(%rsp),%rcx
  404660:	lea    0x48(%rsp),%rdx
  404665:	mov    $0x406eca,%esi
  40466a:	movq   $0x0,0x48(%rsp)
  404673:	movq   $0x0,0x50(%rsp)
  40467c:	call   4021d0 <__isoc99_sscanf@plt>
  404681:	cmp    $0x2,%eax
  404684:	je     4046c0 <read_map_evidence+0xf0>
  404686:	test   %bl,%bl
  404688:	je     404638 <read_map_evidence+0x68>
  40468a:	mov    0x38(%rsp),%rdi
  40468f:	xor    %eax,%eax
  404691:	lea    0x58(%rsp),%rdx
  404696:	mov    $0x406ed4,%esi
  40469b:	movq   $0x0,0x58(%rsp)
  4046a4:	movl   $0x0,0x34(%rsp)
  4046ac:	call   4021d0 <__isoc99_sscanf@plt>
  4046b1:	cmp    $0x1,%eax
  4046b4:	jne    404720 <read_map_evidence+0x150>
  4046b6:	mov    0x58(%rsp),%r13
  4046bb:	jmp    404638 <read_map_evidence+0x68>
  4046c0:	test   %bl,%bl
  4046c2:	je     404780 <read_map_evidence+0x1b0>
  4046c8:	mov    0x38(%rsp),%rdi
  4046cd:	call   402040 <free@plt>
  4046d2:	mov    %rbp,%rdi
  4046d5:	call   4020b0 <fclose@plt>
  4046da:	mov    0x8(%rsp),%rax
  4046df:	mov    %r14b,(%r12)
  4046e3:	mov    %rax,0x10(%r12)
  4046e8:	mov    0x10(%rsp),%rax
  4046ed:	mov    %r13,0x8(%r12)
  4046f2:	mov    %rax,0x18(%r12)
  4046f7:	mov    0x1c(%rsp),%eax
  4046fb:	mov    %r15b,0x24(%r12)
  404700:	mov    %eax,0x20(%r12)
  404705:	add    $0x68,%rsp
  404709:	pop    %rbx
  40470a:	pop    %rbp
  40470b:	mov    %r12,%rax
  40470e:	pop    %r12
  404710:	pop    %r13
  404712:	pop    %r14
  404714:	pop    %r15
  404716:	ret
  404717:	nopw   0x0(%rax,%rax,1)
  404720:	mov    0x38(%rsp),%rdi
  404725:	xor    %eax,%eax
  404727:	lea    0x58(%rsp),%rdx
  40472c:	mov    $0x406eec,%esi
  404731:	call   4021d0 <__isoc99_sscanf@plt>
  404736:	cmp    $0x1,%eax
  404739:	jne    404750 <read_map_evidence+0x180>
  40473b:	mov    0x58(%rsp),%rax
  404740:	mov    %rax,0x8(%rsp)
  404745:	jmp    404638 <read_map_evidence+0x68>
  40474a:	nopw   0x0(%rax,%rax,1)
  404750:	mov    0x38(%rsp),%rdi
  404755:	xor    %eax,%eax
  404757:	lea    0x58(%rsp),%rdx
  40475c:	mov    $0x406f01,%esi
  404761:	call   4021d0 <__isoc99_sscanf@plt>
  404766:	cmp    $0x1,%eax
  404769:	jne    4047b0 <read_map_evidence+0x1e0>
  40476b:	mov    0x58(%rsp),%rax
  404770:	mov    %rax,0x10(%rsp)
  404775:	jmp    404638 <read_map_evidence+0x68>
  40477a:	nopw   0x0(%rax,%rax,1)
  404780:	mov    0x20(%rsp),%rax
  404785:	cmp    %rax,0x48(%rsp)
  40478a:	ja     404638 <read_map_evidence+0x68>
  404790:	cmp    0x50(%rsp),%rax
  404795:	mov    $0x1,%eax
  40479a:	cmovb  %eax,%r14d
  40479e:	setb   %bl
  4047a1:	jmp    404638 <read_map_evidence+0x68>
  4047a6:	cs nopw 0x0(%rax,%rax,1)
  4047b0:	mov    0x38(%rsp),%rdi
  4047b5:	xor    %eax,%eax
  4047b7:	lea    0x34(%rsp),%rdx
  4047bc:	mov    $0x406f18,%esi
  4047c1:	call   4021d0 <__isoc99_sscanf@plt>
  4047c6:	cmp    $0x1,%eax
  4047c9:	je     404810 <read_map_evidence+0x240>
  4047cb:	mov    0x38(%rsp),%rdi
  4047d0:	mov    $0x8,%edx
  4047d5:	mov    $0x406f28,%esi
  4047da:	mov    %rdi,0x28(%rsp)
  4047df:	call   402060 <strncmp@plt>
  4047e4:	test   %eax,%eax
  4047e6:	jne    404638 <read_map_evidence+0x68>
  4047ec:	mov    0x28(%rsp),%rdi
  4047f1:	mov    $0x406f31,%esi
  4047f6:	call   402300 <strstr@plt>
  4047fb:	test   %rax,%rax
  4047fe:	setne  %r15b
  404802:	jmp    404638 <read_map_evidence+0x68>
  404807:	nopw   0x0(%rax,%rax,1)
  404810:	mov    0x34(%rsp),%eax
  404814:	mov    %eax,0x1c(%rsp)
  404818:	jmp    404638 <read_map_evidence+0x68>
  40481d:	movq   $0x0,0x8(%rsp)
  404826:	movq   $0x0,0x10(%rsp)
  40482f:	movl   $0xffffffff,0x1c(%rsp)
  404837:	xor    %r14d,%r14d
  40483a:	xor    %r13d,%r13d
  40483d:	xor    %r15d,%r15d
  404840:	jmp    4046da <read_map_evidence+0x10a>
  404845:	data16 cs nopw 0x0(%rax,%rax,1)

0000000000404850 <join_workers>:
  404850:	test   %rsi,%rsi
  404853:	je     404884 <join_workers+0x34>
  404855:	push   %r12
  404857:	mov    %rdi,%r12
  40485a:	push   %rbp
  40485b:	mov    %rsi,%rbp
  40485e:	push   %rbx
  40485f:	xor    %ebx,%ebx
  404861:	nopl   0x0(%rax)
  404868:	mov    (%r12,%rbx,8),%rdi
  40486c:	xor    %esi,%esi
  40486e:	call   4022c0 <pthread_join@plt>
  404873:	test   %eax,%eax
  404875:	jne    404885 <join_workers+0x35>
  404877:	inc    %rbx
  40487a:	cmp    %rbx,%rbp
  40487d:	jne    404868 <join_workers+0x18>
  40487f:	pop    %rbx
  404880:	pop    %rbp
  404881:	pop    %r12
  404883:	ret
  404884:	ret
  404885:	mov    %eax,%edi
  404887:	call   4022e0 <strerror@plt>
  40488c:	mov    %rax,%rsi
  40488f:	mov    $0x406f35,%edi
  404894:	xor    %eax,%eax
  404896:	call   4042e0 <failf>
  40489b:	nopl   0x0(%rax,%rax,1)

00000000004048a0 <print_json_string>:
  4048a0:	push   %rbx
  4048a1:	mov    0x48d8(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  4048a8:	mov    %rdi,%rbx
  4048ab:	mov    $0x22,%edi
  4048b0:	call   402170 <putc@plt>
  4048b5:	movzbl (%rbx),%esi
  4048b8:	test   %sil,%sil
  4048bb:	je     40490c <print_json_string+0x6c>
  4048bd:	nopl   (%rax)
  4048c0:	cmp    $0x22,%sil
  4048c4:	ja     4049e0 <print_json_string+0x140>
  4048ca:	cmp    $0x7,%sil
  4048ce:	jbe    4048e1 <print_json_string+0x41>
  4048d0:	lea    -0x8(%rsi),%eax
  4048d3:	cmp    $0x1a,%al
  4048d5:	ja     4048e1 <print_json_string+0x41>
  4048d7:	movzbl %al,%eax
  4048da:	jmp    *0x4073c0(,%rax,8)
  4048e1:	cmp    $0x1f,%sil
  4048e5:	ja     404a06 <print_json_string+0x166>
  4048eb:	mov    $0x406f5b,%edi
  4048f0:	xor    %eax,%eax
  4048f2:	call   4020e0 <printf@plt>
  4048f7:	nopw   0x0(%rax,%rax,1)
  404900:	movzbl 0x1(%rbx),%esi
  404904:	inc    %rbx
  404907:	test   %sil,%sil
  40490a:	jne    4048c0 <print_json_string+0x20>
  40490c:	mov    0x486d(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  404913:	mov    $0x22,%edi
  404918:	pop    %rbx
  404919:	jmp    402170 <putc@plt>
  40491e:	xchg   %ax,%ax
  404920:	mov    0x4859(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  404927:	mov    $0x2,%edx
  40492c:	mov    $0x1,%esi
  404931:	mov    $0x406f46,%edi
  404936:	call   4022a0 <fwrite@plt>
  40493b:	jmp    404900 <print_json_string+0x60>
  40493d:	nopl   (%rax)
  404940:	mov    0x4839(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  404947:	mov    $0x2,%edx
  40494c:	mov    $0x1,%esi
  404951:	mov    $0x406f55,%edi
  404956:	call   4022a0 <fwrite@plt>
  40495b:	jmp    404900 <print_json_string+0x60>
  40495d:	nopl   (%rax)
  404960:	mov    0x4819(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  404967:	mov    $0x2,%edx
  40496c:	mov    $0x1,%esi
  404971:	mov    $0x406f4f,%edi
  404976:	call   4022a0 <fwrite@plt>
  40497b:	jmp    404900 <print_json_string+0x60>
  40497d:	nopl   (%rax)
  404980:	mov    0x47f9(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  404987:	mov    $0x2,%edx
  40498c:	mov    $0x1,%esi
  404991:	mov    $0x406f52,%edi
  404996:	call   4022a0 <fwrite@plt>
  40499b:	jmp    404900 <print_json_string+0x60>
  4049a0:	mov    0x47d9(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  4049a7:	mov    $0x2,%edx
  4049ac:	mov    $0x1,%esi
  4049b1:	mov    $0x406f58,%edi
  4049b6:	call   4022a0 <fwrite@plt>
  4049bb:	jmp    404900 <print_json_string+0x60>
  4049c0:	mov    0x47b9(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  4049c7:	mov    $0x2,%edx
  4049cc:	mov    $0x1,%esi
  4049d1:	mov    $0x406f4c,%edi
  4049d6:	call   4022a0 <fwrite@plt>
  4049db:	jmp    404900 <print_json_string+0x60>
  4049e0:	cmp    $0x5c,%sil
  4049e4:	jne    404a06 <print_json_string+0x166>
  4049e6:	mov    0x4793(%rip),%rcx        # 409180 <stdout@GLIBC_2.2.5>
  4049ed:	mov    $0x2,%edx
  4049f2:	mov    $0x1,%esi
  4049f7:	mov    $0x406f49,%edi
  4049fc:	call   4022a0 <fwrite@plt>
  404a01:	jmp    404900 <print_json_string+0x60>
  404a06:	movzbl %sil,%edi
  404a0a:	mov    0x476f(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  404a11:	call   402170 <putc@plt>
  404a16:	jmp    404900 <print_json_string+0x60>
  404a1b:	nopl   0x0(%rax,%rax,1)

0000000000404a20 <print_cpu_array>:
  404a20:	push   %r12
  404a22:	mov    %rdi,%r12
  404a25:	mov    $0x5b,%edi
  404a2a:	push   %rbp
  404a2b:	mov    %rsi,%rbp
  404a2e:	mov    0x474b(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  404a35:	push   %rbx
  404a36:	xor    %ebx,%ebx
  404a38:	call   402170 <putc@plt>
  404a3d:	test   %rbp,%rbp
  404a40:	jne    404a59 <print_cpu_array+0x39>
  404a42:	jmp    404a71 <print_cpu_array+0x51>
  404a44:	nopl   0x0(%rax)
  404a48:	mov    0x4731(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  404a4f:	mov    $0x2c,%edi
  404a54:	call   402170 <putc@plt>
  404a59:	mov    (%r12,%rbx,4),%esi
  404a5d:	mov    $0x406f25,%edi
  404a62:	xor    %eax,%eax
  404a64:	inc    %rbx
  404a67:	call   4020e0 <printf@plt>
  404a6c:	cmp    %rbx,%rbp
  404a6f:	jne    404a48 <print_cpu_array+0x28>
  404a71:	pop    %rbx
  404a72:	pop    %rbp
  404a73:	mov    0x4706(%rip),%rsi        # 409180 <stdout@GLIBC_2.2.5>
  404a7a:	mov    $0x5d,%edi
  404a7f:	pop    %r12
  404a81:	jmp    402170 <putc@plt>
  404a86:	cs nopw 0x0(%rax,%rax,1)

0000000000404a90 <now_ns.part.0>:
  404a90:	sub    $0x8,%rsp
  404a94:	call   402050 <__errno_location@plt>
  404a99:	mov    (%rax),%edi
  404a9b:	call   4022e0 <strerror@plt>
  404aa0:	mov    %rax,%rsi
  404aa3:	mov    $0x406068,%edi
  404aa8:	xor    %eax,%eax
  404aaa:	call   4042e0 <failf>
  404aaf:	nop

0000000000404ab0 <now_ns>:
  404ab0:	sub    $0x18,%rsp
  404ab4:	mov    %rsp,%rsi
  404ab7:	mov    $0x4,%edi
  404abc:	call   402090 <clock_gettime@plt>
  404ac1:	test   %eax,%eax
  404ac3:	jne    404ad7 <now_ns+0x27>
  404ac5:	imul   $0x3b9aca00,(%rsp),%rax
  404acd:	add    0x8(%rsp),%rax
  404ad2:	add    $0x18,%rsp
  404ad6:	ret
  404ad7:	call   404a90 <now_ns.part.0>
  404adc:	nopl   0x0(%rax)

0000000000404ae0 <read_usage.part.0>:
  404ae0:	push   %rbp
  404ae1:	mov    %rdi,%rbp
  404ae4:	call   402050 <__errno_location@plt>
  404ae9:	mov    (%rax),%edi
  404aeb:	call   4022e0 <strerror@plt>
  404af0:	mov    %rax,%rdx
  404af3:	mov    %rbp,%rsi
  404af6:	mov    $0x406f62,%edi
  404afb:	xor    %eax,%eax
  404afd:	call   4042e0 <failf>
  404b02:	data16 cs nopw 0x0(%rax,%rax,1)
  404b0d:	nopl   (%rax)

0000000000404b10 <bind_current_thread_memory_to_node.constprop.0>:
  404b10:	push   %r14
  404b12:	push   %r13
  404b14:	mov    %rsi,%r13
  404b17:	mov    $0x8,%esi
  404b1c:	push   %r12
  404b1e:	push   %rbp
  404b1f:	push   %rbx
  404b20:	movslq %edi,%rbx
  404b23:	mov    %rbx,%r12
  404b26:	shr    $0x6,%rbx
  404b2a:	lea    0x1(%rbx),%r14
  404b2e:	mov    %r14,%rdi
  404b31:	call   402140 <calloc@plt>
  404b36:	test   %rax,%rax
  404b39:	je     404ba6 <bind_current_thread_memory_to_node.constprop.0+0x96>
  404b3b:	mov    %rax,%rbp
  404b3e:	mov    $0x1,%eax
  404b43:	shlx   %r12,%rax,%rax
  404b48:	mov    %rax,0x0(%rbp,%rbx,8)
  404b4d:	mov    %r14,%rcx
  404b50:	shl    $0x6,%rcx
  404b54:	xor    %eax,%eax
  404b56:	mov    %rbp,%rdx
  404b59:	mov    $0x2,%esi
  404b5e:	mov    $0xee,%edi
  404b63:	call   402190 <syscall@plt>
  404b68:	test   %rax,%rax
  404b6b:	jne    404b88 <bind_current_thread_memory_to_node.constprop.0+0x78>
  404b6d:	mov    %rbp,%rdi
  404b70:	call   402040 <free@plt>
  404b75:	mov    $0x1,%eax
  404b7a:	pop    %rbx
  404b7b:	pop    %rbp
  404b7c:	pop    %r12
  404b7e:	pop    %r13
  404b80:	pop    %r14
  404b82:	ret
  404b83:	nopl   0x0(%rax,%rax,1)
  404b88:	call   402050 <__errno_location@plt>
  404b8d:	mov    (%rax),%eax
  404b8f:	mov    %rbp,%rdi
  404b92:	mov    %eax,0x0(%r13)
  404b96:	call   402040 <free@plt>
  404b9b:	pop    %rbx
  404b9c:	pop    %rbp
  404b9d:	pop    %r12
  404b9f:	pop    %r13
  404ba1:	xor    %eax,%eax
  404ba3:	pop    %r14
  404ba5:	ret
  404ba6:	call   402050 <__errno_location@plt>
  404bab:	mov    (%rax),%eax
  404bad:	test   %eax,%eax
  404baf:	jne    404bb6 <bind_current_thread_memory_to_node.constprop.0+0xa6>
  404bb1:	mov    $0xc,%eax
  404bb6:	mov    %eax,0x0(%r13)
  404bba:	xor    %eax,%eax
  404bbc:	jmp    404b7a <bind_current_thread_memory_to_node.constprop.0+0x6a>
  404bbe:	xchg   %ax,%ax

0000000000404bc0 <stop_workers>:
  404bc0:	push   %rbp
  404bc1:	mov    $0x1,%eax
  404bc6:	mov    %rdi,%rbp
  404bc9:	xchg   %al,0x5c(%rdi)
  404bcc:	call   402310 <pthread_mutex_lock@plt>
  404bd1:	test   %eax,%eax
  404bd3:	jne    404bf7 <stop_workers+0x37>
  404bd5:	movl   $0x4,0x58(%rbp)
  404bdc:	lea    0x28(%rbp),%rdi
  404be0:	call   402070 <pthread_cond_broadcast@plt>
  404be5:	test   %eax,%eax
  404be7:	jne    404c23 <stop_workers+0x63>
  404be9:	mov    %rbp,%rdi
  404bec:	call   4021b0 <pthread_mutex_unlock@plt>
  404bf1:	test   %eax,%eax
  404bf3:	jne    404c0d <stop_workers+0x4d>
  404bf5:	pop    %rbp
  404bf6:	ret
  404bf7:	mov    %eax,%edi
  404bf9:	call   4022e0 <strerror@plt>
  404bfe:	mov    %rax,%rsi
  404c01:	mov    $0x406e5f,%edi
  404c06:	xor    %eax,%eax
  404c08:	call   4042e0 <failf>
  404c0d:	mov    %eax,%edi
  404c0f:	call   4022e0 <strerror@plt>
  404c14:	mov    %rax,%rsi
  404c17:	mov    $0x406e91,%edi
  404c1c:	xor    %eax,%eax
  404c1e:	call   4042e0 <failf>
  404c23:	mov    %eax,%edi
  404c25:	call   4022e0 <strerror@plt>
  404c2a:	mov    %rax,%rsi
  404c2d:	mov    $0x406e76,%edi
  404c32:	xor    %eax,%eax
  404c34:	call   4042e0 <failf>
  404c39:	nopl   0x0(%rax)

0000000000404c40 <topic49_page_prepare>:
  404c40:	mov    %rdi,%rcx
  404c43:	test   %rsi,%rsi
  404c46:	je     404dc6 <topic49_page_prepare+0x186>
  404c4c:	lea    -0x1(%rsi),%rax
  404c50:	cmp    $0x2,%rax
  404c54:	jbe    404dd4 <topic49_page_prepare+0x194>
  404c5a:	mov    %rdi,%rax
  404c5d:	mov    %rsi,%rdi
  404c60:	vpbroadcastq %rdx,%ymm2
  404c66:	shr    $0x2,%rdi
  404c6a:	shl    $0x5,%rdi
  404c6e:	vpaddq 0x282a(%rip),%ymm2,%ymm2        # 4074a0 <__dso_handle+0x1498>
  404c76:	vpbroadcastq 0x2841(%rip),%ymm6        # 4074c0 <__dso_handle+0x14b8>
  404c7f:	vpbroadcastq 0x2820(%rip),%ymm5        # 4074a8 <__dso_handle+0x14a0>
  404c88:	vpbroadcastq 0x2837(%rip),%ymm4        # 4074c8 <__dso_handle+0x14c0>
  404c91:	vpbroadcastq 0x2836(%rip),%ymm3        # 4074d0 <__dso_handle+0x14c8>
  404c9a:	add    %rcx,%rdi
  404c9d:	nopl   (%rax)
  404ca0:	vmovdqa %ymm2,%ymm0
  404ca4:	vpaddq %ymm5,%ymm0,%ymm0
  404ca8:	vpsrlq $0x1e,%ymm0,%ymm1
  404cad:	vpxor  %ymm0,%ymm1,%ymm1
  404cb1:	vpmullq %ymm4,%ymm1,%ymm1
  404cb7:	add    $0x20,%rax
  404cbb:	vpaddq %ymm6,%ymm2,%ymm2
  404cbf:	vpsrlq $0x1b,%ymm1,%ymm0
  404cc4:	vpxor  %ymm1,%ymm0,%ymm0
  404cc8:	vpmullq %ymm3,%ymm0,%ymm0
  404cce:	vpsrlq $0x1f,%ymm0,%ymm1
  404cd3:	vpxor  %ymm0,%ymm1,%ymm0
  404cd7:	vmovdqu %ymm0,-0x20(%rax)
  404cdc:	cmp    %rax,%rdi
  404cdf:	jne    404ca0 <topic49_page_prepare+0x60>
  404ce1:	mov    %rsi,%rdi
  404ce4:	and    $0xfffffffffffffffc,%rdi
  404ce8:	movabs $0x9e3779b97f4a7c15,%rax
  404cf2:	imul   %rdi,%rax
  404cf6:	add    %rax,%rdx
  404cf9:	cmp    %rdi,%rsi
  404cfc:	je     404dd0 <topic49_page_prepare+0x190>
  404d02:	vzeroupper
  404d05:	sub    %rdi,%rsi
  404d08:	cmp    $0x1,%rsi
  404d0c:	je     404d7b <topic49_page_prepare+0x13b>
  404d0e:	movabs $0x9e3779b97f4a7c15,%r8
  404d18:	lea    (%rdx,%r8,1),%rax
  404d1c:	vmovq  %rdx,%xmm7
  404d21:	vpinsrq $0x1,%rax,%xmm7,%xmm0
  404d27:	vpaddq 0x2777(%rip){1to2},%xmm0,%xmm0        # 4074a8 <__dso_handle+0x14a0>
  404d31:	vpsrlq $0x1e,%xmm0,%xmm1
  404d36:	vpxor  %xmm0,%xmm1,%xmm1
  404d3a:	vpmullq 0x2784(%rip){1to2},%xmm1,%xmm1        # 4074c8 <__dso_handle+0x14c0>
  404d44:	mov    %rsi,%rax
  404d47:	and    $0xfffffffffffffffe,%rax
  404d4b:	imul   %rax,%r8
  404d4f:	vpsrlq $0x1b,%xmm1,%xmm0
  404d54:	vpxor  %xmm1,%xmm0,%xmm0
  404d58:	vpmullq 0x276e(%rip){1to2},%xmm0,%xmm0        # 4074d0 <__dso_handle+0x14c8>
  404d62:	add    %r8,%rdx
  404d65:	vpsrlq $0x1f,%xmm0,%xmm1
  404d6a:	vpxor  %xmm0,%xmm1,%xmm0
  404d6e:	vmovdqu %xmm0,(%rcx,%rdi,8)
  404d73:	add    %rax,%rdi
  404d76:	cmp    %rax,%rsi
  404d79:	je     404dc6 <topic49_page_prepare+0x186>
  404d7b:	movabs $0x9e3779b97f4a7c15,%rax
  404d85:	add    %rax,%rdx
  404d88:	mov    %rdx,%rax
  404d8b:	shr    $0x1e,%rax
  404d8f:	xor    %rdx,%rax
  404d92:	movabs $0xbf58476d1ce4e5b9,%rdx
  404d9c:	imul   %rdx,%rax
  404da0:	mov    %rax,%rdx
  404da3:	shr    $0x1b,%rdx
  404da7:	xor    %rdx,%rax
  404daa:	movabs $0x94d049bb133111eb,%rdx
  404db4:	imul   %rdx,%rax
  404db8:	mov    %rax,%rdx
  404dbb:	shr    $0x1f,%rdx
  404dbf:	xor    %rdx,%rax
  404dc2:	mov    %rax,(%rcx,%rdi,8)
  404dc6:	ret
  404dc7:	nopw   0x0(%rax,%rax,1)
  404dd0:	vzeroupper
  404dd3:	ret
  404dd4:	xor    %edi,%edi
  404dd6:	jmp    404d05 <topic49_page_prepare+0xc5>
  404ddb:	nopl   0x0(%rax,%rax,1)

0000000000404de0 <topic49_walk_dependent>:
  404de0:	test   %rdx,%rdx
  404de3:	je     404e10 <topic49_walk_dependent+0x30>
  404de5:	xor    %eax,%eax
  404de7:	xor    %r8d,%r8d
  404dea:	nopw   0x0(%rax,%rax,1)
  404df0:	shl    $0x6,%rsi
  404df4:	add    %rdi,%rsi
  404df7:	inc    %rax
  404dfa:	add    0x8(%rsi),%r8
  404dfe:	mov    (%rsi),%rsi
  404e01:	cmp    %rax,%rdx
  404e04:	jne    404df0 <topic49_walk_dependent+0x10>
  404e06:	mov    %rsi,(%rcx)
  404e09:	mov    %r8,%rax
  404e0c:	ret
  404e0d:	nopl   (%rax)
  404e10:	xor    %r8d,%r8d
  404e13:	mov    %rsi,(%rcx)
  404e16:	mov    %r8,%rax
  404e19:	ret
  404e1a:	nopw   0x0(%rax,%rax,1)

0000000000404e20 <make_cycle>:
  404e20:	push   %rbp
  404e21:	mov    %rsp,%rbp
  404e24:	push   %r15
  404e26:	push   %r14
  404e28:	push   %r13
  404e2a:	push   %r12
  404e2c:	mov    %rsi,%r12
  404e2f:	push   %rbx
  404e30:	and    $0xffffffffffffffe0,%rsp
  404e34:	sub    $0x40,%rsp
  404e38:	cmp    $0x3f,%rsi
  404e3c:	jbe    405087 <make_cycle+0x267>
  404e42:	mov    %rdi,%r13
  404e45:	mov    %rdx,%rbx
  404e48:	xor    %r9d,%r9d
  404e4b:	mov    $0xffffffff,%r8d
  404e51:	mov    $0x22,%ecx
  404e56:	mov    $0x3,%edx
  404e5b:	xor    %edi,%edi
  404e5d:	mov    %rsi,%r14
  404e60:	call   4020d0 <mmap@plt>
  404e65:	shr    $0x6,%r14
  404e69:	mov    %rax,%r15
  404e6c:	cmp    $0xffffffffffffffff,%rax
  404e70:	je     40503f <make_cycle+0x21f>
  404e76:	mov    $0xf,%edx
  404e7b:	mov    %r12,%rsi
  404e7e:	mov    %rax,%rdi
  404e81:	call   402210 <madvise@plt>
  404e86:	test   %eax,%eax
  404e88:	jne    405026 <make_cycle+0x206>
  404e8e:	movabs $0x6a09e667f3bcc909,%rdx
  404e98:	mov    %r12,%rsi
  404e9b:	xor    %rbx,%rdx
  404e9e:	shr    $0x3,%rsi
  404ea2:	mov    %r15,%rdi
  404ea5:	call   404c40 <topic49_page_prepare>
  404eaa:	lea    0x0(,%r14,8),%rdi
  404eb2:	call   4021c0 <malloc@plt>
  404eb7:	mov    %rax,%r9
  404eba:	test   %rax,%rax
  404ebd:	je     40505d <make_cycle+0x23d>
  404ec3:	xor    %edx,%edx
  404ec5:	xor    %eax,%eax
  404ec7:	nopw   0x0(%rax,%rax,1)
  404ed0:	mov    %rax,%rcx
  404ed3:	shl    $0x6,%rcx
  404ed7:	mov    %rax,(%r9,%rax,8)
  404edb:	add    0x8(%r15,%rcx,1),%rdx
  404ee0:	inc    %rax
  404ee3:	mov    %rdx,%r8
  404ee6:	cmp    %rax,%r14
  404ee9:	jne    404ed0 <make_cycle+0xb0>
  404eeb:	mov    %r14,%rcx
  404eee:	movabs $0x9e3779b97f4a7c15,%r10
  404ef8:	movabs $0xbf58476d1ce4e5b9,%rdi
  404f02:	movabs $0x94d049bb133111eb,%rsi
  404f0c:	nopl   0x0(%rax)
  404f10:	mov    %rcx,%rax
  404f13:	neg    %rax
  404f16:	xor    %edx,%edx
  404f18:	div    %rcx
  404f1b:	nopl   0x0(%rax,%rax,1)
  404f20:	add    %r10,%rbx
  404f23:	mov    %rbx,%rax
  404f26:	shr    $0x1e,%rax
  404f2a:	xor    %rbx,%rax
  404f2d:	imul   %rdi,%rax
  404f31:	mov    %rax,%r11
  404f34:	shr    $0x1b,%r11
  404f38:	xor    %r11,%rax
  404f3b:	imul   %rsi,%rax
  404f3f:	mov    %rax,%r11
  404f42:	shr    $0x1f,%r11
  404f46:	xor    %r11,%rax
  404f49:	cmp    %rax,%rdx
  404f4c:	ja     404f20 <make_cycle+0x100>
  404f4e:	xor    %edx,%edx
  404f50:	div    %rcx
  404f53:	mov    -0x8(%r9,%rcx,8),%r11
  404f58:	lea    (%r9,%rdx,8),%rax
  404f5c:	mov    (%rax),%rdx
  404f5f:	mov    %rdx,-0x8(%r9,%rcx,8)
  404f64:	dec    %rcx
  404f67:	mov    %r11,(%rax)
  404f6a:	cmp    $0x1,%rcx
  404f6e:	jne    404f10 <make_cycle+0xf0>
  404f70:	xor    %ecx,%ecx
  404f72:	nopw   0x0(%rax,%rax,1)
  404f78:	mov    (%r9,%rcx,8),%rsi
  404f7c:	inc    %rcx
  404f7f:	mov    %rcx,%rax
  404f82:	xor    %edx,%edx
  404f84:	div    %r14
  404f87:	shl    $0x6,%rsi
  404f8b:	mov    (%r9,%rdx,8),%rax
  404f8f:	mov    %rax,(%r15,%rsi,1)
  404f93:	cmp    %rcx,%r14
  404f96:	jne    404f78 <make_cycle+0x158>
  404f98:	mov    (%r9),%rbx
  404f9b:	vmovq  %r12,%xmm3
  404fa0:	vmovq  %rbx,%xmm2
  404fa5:	vpinsrq $0x1,%r8,%xmm2,%xmm1
  404fab:	vpinsrq $0x1,%r14,%xmm3,%xmm0
  404fb1:	vinserti128 $0x1,%xmm1,%ymm0,%ymm0
  404fb7:	mov    %r9,%rdi
  404fba:	mov    %r8,0x28(%rsp)
  404fbf:	vmovdqa %ymm0,(%rsp)
  404fc4:	vzeroupper
  404fc7:	call   402040 <free@plt>
  404fcc:	lea    0x38(%rsp),%rcx
  404fd1:	mov    %r14,%rdx
  404fd4:	mov    %rbx,%rsi
  404fd7:	mov    %r15,%rdi
  404fda:	movq   $0xffffffffffffffff,0x38(%rsp)
  404fe3:	call   404de0 <topic49_walk_dependent>
  404fe8:	cmp    0x38(%rsp),%rbx
  404fed:	jne    40507b <make_cycle+0x25b>
  404ff3:	mov    0x28(%rsp),%r8
  404ff8:	vmovdqa (%rsp),%ymm0
  404ffd:	cmp    %rax,%r8
  405000:	jne    405078 <make_cycle+0x258>
  405002:	mov    %r13,%rax
  405005:	mov    %r15,0x0(%r13)
  405009:	movb   $0x1,0x28(%r13)
  40500e:	vmovdqu %ymm0,0x8(%r13)
  405014:	vzeroupper
  405017:	lea    -0x28(%rbp),%rsp
  40501b:	pop    %rbx
  40501c:	pop    %r12
  40501e:	pop    %r13
  405020:	pop    %r14
  405022:	pop    %r15
  405024:	pop    %rbp
  405025:	ret
  405026:	call   402050 <__errno_location@plt>
  40502b:	mov    (%rax),%r13d
  40502e:	mov    %rax,%rbx
  405031:	mov    %r12,%rsi
  405034:	mov    %r15,%rdi
  405037:	call   4021f0 <munmap@plt>
  40503c:	mov    %r13d,(%rbx)
  40503f:	call   402050 <__errno_location@plt>
  405044:	mov    (%rax),%edi
  405046:	call   4022e0 <strerror@plt>
  40504b:	mov    %rax,%rdx
  40504e:	mov    %r12,%rsi
  405051:	mov    $0x4060c0,%edi
  405056:	xor    %eax,%eax
  405058:	call   4042e0 <failf>
  40505d:	call   402050 <__errno_location@plt>
  405062:	mov    (%rax),%edi
  405064:	call   4022e0 <strerror@plt>
  405069:	mov    %rax,%rsi
  40506c:	mov    $0x406f74,%edi
  405071:	xor    %eax,%eax
  405073:	call   4042e0 <failf>
  405078:	vzeroupper
  40507b:	mov    $0x4060e8,%edi
  405080:	xor    %eax,%eax
  405082:	call   4042e0 <failf>
  405087:	mov    $0x40,%edx
  40508c:	mov    $0x406090,%edi
  405091:	xor    %eax,%eax
  405093:	call   4042e0 <failf>
  405098:	nopl   0x0(%rax,%rax,1)

00000000004050a0 <topic49_stream_scan>:
  4050a0:	mov    %rdi,%rcx
  4050a3:	test   %rsi,%rsi
  4050a6:	je     405148 <topic49_stream_scan+0xa8>
  4050ac:	lea    -0x1(%rsi),%rax
  4050b0:	cmp    $0x3,%rax
  4050b4:	jbe    405154 <topic49_stream_scan+0xb4>
  4050ba:	mov    %rsi,%rdx
  4050bd:	shr    $0x2,%rdx
  4050c1:	shl    $0x5,%rdx
  4050c5:	mov    %rdi,%rax
  4050c8:	add    %rdi,%rdx
  4050cb:	vpxor  %xmm0,%xmm0,%xmm0
  4050cf:	nop
  4050d0:	vpaddq (%rax),%ymm0,%ymm0
  4050d4:	add    $0x20,%rax
  4050d8:	cmp    %rax,%rdx
  4050db:	jne    4050d0 <topic49_stream_scan+0x30>
  4050dd:	vmovdqa %xmm0,%xmm1
  4050e1:	vextracti64x2 $0x1,%ymm0,%xmm0
  4050e8:	vpaddq %xmm0,%xmm1,%xmm0
  4050ec:	vpsrldq $0x8,%xmm0,%xmm1
  4050f1:	vpaddq %xmm1,%xmm0,%xmm0
  4050f5:	mov    %rsi,%rdx
  4050f8:	vmovq  %xmm0,%rax
  4050fd:	and    $0xfffffffffffffffc,%rdx
  405101:	test   $0x3,%sil
  405105:	je     405150 <topic49_stream_scan+0xb0>
  405107:	vzeroupper
  40510a:	lea    0x1(%rdx),%r8
  40510e:	lea    0x0(,%rdx,8),%rdi
  405116:	add    (%rcx,%rdx,8),%rax
  40511a:	cmp    %r8,%rsi
  40511d:	jbe    40514a <topic49_stream_scan+0xaa>
  40511f:	lea    0x2(%rdx),%r8
  405123:	add    0x8(%rcx,%rdi,1),%rax
  405128:	cmp    %r8,%rsi
  40512b:	jbe    40514a <topic49_stream_scan+0xaa>
  40512d:	add    $0x3,%rdx
  405131:	add    0x10(%rcx,%rdi,1),%rax
  405136:	cmp    %rdx,%rsi
  405139:	jbe    40514a <topic49_stream_scan+0xaa>
  40513b:	add    0x18(%rcx,%rdi,1),%rax
  405140:	ret
  405141:	nopl   0x0(%rax)
  405148:	xor    %eax,%eax
  40514a:	ret
  40514b:	nopl   0x0(%rax,%rax,1)
  405150:	vzeroupper
  405153:	ret
  405154:	xor    %edx,%edx
  405156:	xor    %eax,%eax
  405158:	jmp    40510a <topic49_stream_scan+0x6a>
  40515a:	nopw   0x0(%rax,%rax,1)

0000000000405160 <worker_main>:
  405160:	push   %r15
  405162:	vpxor  %xmm0,%xmm0,%xmm0
  405166:	push   %r14
  405168:	push   %r13
  40516a:	push   %r12
  40516c:	push   %rbp
  40516d:	push   %rbx
  40516e:	mov    %rdi,%rbx
  405171:	sub    $0x118,%rsp
  405178:	movslq 0x8(%rdi),%rbp
  40517c:	mov    (%rdi),%r12
  40517f:	mov    %rbp,%r14
  405182:	vmovdqa %xmm0,0x10(%rsp)
  405188:	vmovdqa %xmm0,0x20(%rsp)
  40518e:	vmovdqa %xmm0,0x30(%rsp)
  405194:	vmovdqa %xmm0,0x40(%rsp)
  40519a:	vmovdqa %xmm0,0x50(%rsp)
  4051a0:	vmovdqa %xmm0,0x60(%rsp)
  4051a6:	vmovdqa %xmm0,0x70(%rsp)
  4051ac:	vmovdqa %xmm0,0x80(%rsp)
  4051b5:	cmp    $0x3ff,%rbp
  4051bc:	ja     4051d4 <worker_main+0x74>
  4051be:	mov    %rbp,%rdx
  4051c1:	shr    $0x6,%rdx
  4051c5:	mov    $0x1,%eax
  4051ca:	shlx   %rbp,%rax,%rax
  4051cf:	or     %rax,0x10(%rsp,%rdx,8)
  4051d4:	call   402220 <pthread_self@plt>
  4051d9:	mov    %rax,%rdi
  4051dc:	lea    0x10(%rsp),%rdx
  4051e1:	mov    $0x80,%esi
  4051e6:	mov    %rax,%r13
  4051e9:	call   402080 <pthread_setaffinity_np@plt>
  4051ee:	test   %eax,%eax
  4051f0:	je     405450 <worker_main+0x2f0>
  4051f6:	mov    0x1c(%rbx),%edi
  4051f9:	movb   $0x0,0x18(%rbx)
  4051fd:	test   %edi,%edi
  4051ff:	je     405310 <worker_main+0x1b0>
  405205:	call   402280 <sched_getcpu@plt>
  40520a:	mov    %eax,0x10(%rbx)
  40520d:	cmp    0x8(%rbx),%eax
  405210:	je     40532b <worker_main+0x1cb>
  405216:	mov    0x1c(%rbx),%ecx
  405219:	test   %ecx,%ecx
  40521b:	jne    405260 <worker_main+0x100>
  40521d:	movq   $0x2,0x1c(%rbx)
  405225:	movl   $0x0,0x10(%rsp)
  40522d:	mov    %r12,%rdi
  405230:	call   402310 <pthread_mutex_lock@plt>
  405235:	test   %eax,%eax
  405237:	je     405274 <worker_main+0x114>
  405239:	mov    0x1c(%rbx),%r11d
  40523d:	test   %r11d,%r11d
  405240:	jne    40524c <worker_main+0xec>
  405242:	movl   $0x5,0x1c(%rbx)
  405249:	mov    %eax,0x20(%rbx)
  40524c:	add    $0x118,%rsp
  405253:	pop    %rbx
  405254:	pop    %rbp
  405255:	pop    %r12
  405257:	pop    %r13
  405259:	pop    %r14
  40525b:	xor    %eax,%eax
  40525d:	pop    %r15
  40525f:	ret
  405260:	mov    %r12,%rdi
  405263:	movl   $0x0,0x10(%rsp)
  40526b:	call   402310 <pthread_mutex_lock@plt>
  405270:	test   %eax,%eax
  405272:	jne    405239 <worker_main+0xd9>
  405274:	incq   0x60(%r12)
  405279:	lea    0x28(%r12),%r14
  40527e:	mov    %r14,%rdi
  405281:	lea    0x58(%r12),%rbp
  405286:	call   402070 <pthread_cond_broadcast@plt>
  40528b:	jmp    4052a3 <worker_main+0x143>
  40528d:	nopl   (%rax)
  405290:	mov    %r12,%rsi
  405293:	mov    %r14,%rdi
  405296:	call   4020a0 <pthread_cond_wait@plt>
  40529b:	test   %eax,%eax
  40529d:	jne    4056b0 <worker_main+0x550>
  4052a3:	mov    0x0(%rbp),%eax
  4052a6:	test   %eax,%eax
  4052a8:	je     405290 <worker_main+0x130>
  4052aa:	mov    %r12,%rdi
  4052ad:	call   4021b0 <pthread_mutex_unlock@plt>
  4052b2:	test   %eax,%eax
  4052b4:	je     4054e8 <worker_main+0x388>
  4052ba:	mov    0x1c(%rbx),%r9d
  4052be:	test   %r9d,%r9d
  4052c1:	je     4056f0 <worker_main+0x590>
  4052c7:	nopw   0x0(%rax,%rax,1)
  4052d0:	movq   $0x0,0x48(%rbx)
  4052d8:	movq   $0x0,0x58(%rbx)
  4052e0:	mov    %r12,%rdi
  4052e3:	call   402310 <pthread_mutex_lock@plt>
  4052e8:	test   %eax,%eax
  4052ea:	je     405520 <worker_main+0x3c0>
  4052f0:	mov    0x1c(%rbx),%ecx
  4052f3:	test   %ecx,%ecx
  4052f5:	jne    40524c <worker_main+0xec>
  4052fb:	movl   $0x8,0x1c(%rbx)
  405302:	mov    %eax,0x20(%rbx)
  405305:	jmp    40524c <worker_main+0xec>
  40530a:	nopw   0x0(%rax,%rax,1)
  405310:	movl   $0x1,0x1c(%rbx)
  405317:	mov    %eax,0x20(%rbx)
  40531a:	call   402280 <sched_getcpu@plt>
  40531f:	mov    %eax,0x10(%rbx)
  405322:	cmp    0x8(%rbx),%eax
  405325:	jne    405216 <worker_main+0xb6>
  40532b:	mov    0x1c(%rbx),%esi
  40532e:	movl   $0x0,0x10(%rsp)
  405336:	test   %esi,%esi
  405338:	jne    40522d <worker_main+0xcd>
  40533e:	mov    0xc(%rbx),%edi
  405341:	lea    0x10(%rsp),%rsi
  405346:	call   404b10 <bind_current_thread_memory_to_node.constprop.0>
  40534b:	test   %al,%al
  40534d:	je     4056d0 <worker_main+0x570>
  405353:	mov    0x1c(%rbx),%eax
  405356:	test   %eax,%eax
  405358:	jne    40522d <worker_main+0xcd>
  40535e:	mov    0x30(%rbx),%r14
  405362:	xor    %r9d,%r9d
  405365:	mov    $0xffffffff,%r8d
  40536b:	mov    $0x22,%ecx
  405370:	mov    $0x3,%edx
  405375:	mov    %r14,%rsi
  405378:	xor    %edi,%edi
  40537a:	call   4020d0 <mmap@plt>
  40537f:	mov    %rax,%rbp
  405382:	cmp    $0xffffffffffffffff,%rax
  405386:	je     4057d8 <worker_main+0x678>
  40538c:	mov    $0xf,%edx
  405391:	mov    %r14,%rsi
  405394:	mov    %rax,%rdi
  405397:	call   402210 <madvise@plt>
  40539c:	test   %eax,%eax
  40539e:	jne    405808 <worker_main+0x6a8>
  4053a4:	mov    0x1c(%rbx),%eax
  4053a7:	movb   $0x1,0x19(%rbx)
  4053ab:	mov    %rbp,0x28(%rbx)
  4053af:	test   %eax,%eax
  4053b1:	jne    40522d <worker_main+0xcd>
  4053b7:	movslq 0x8(%rbx),%rdx
  4053bb:	movabs $0x510e527fade682d1,%rax
  4053c5:	xor    %rax,%rdx
  4053c8:	mov    %rbp,%rdi
  4053cb:	mov    $0x3,%eax
  4053d0:	shrx   %rax,0x30(%rbx),%rsi
  4053d6:	call   404c40 <topic49_page_prepare>
  4053db:	mov    $0x12,%eax
  4053e0:	shrx   %rax,0x30(%rbx),%rbp
  4053e6:	mov    %rbp,0x40(%rbx)
  4053ea:	lea    0x0(,%rbp,8),%rdi
  4053f2:	call   4021c0 <malloc@plt>
  4053f7:	mov    %rax,0x38(%rbx)
  4053fb:	test   %rax,%rax
  4053fe:	je     405a66 <worker_main+0x906>
  405404:	mov    0x1c(%rbx),%r14d
  405408:	test   %r14d,%r14d
  40540b:	jne    40522d <worker_main+0xcd>
  405411:	test   %rbp,%rbp
  405414:	je     40522d <worker_main+0xcd>
  40541a:	xor    %ebp,%ebp
  40541c:	jmp    405424 <worker_main+0x2c4>
  40541e:	xchg   %ax,%ax
  405420:	mov    0x38(%rbx),%rax
  405424:	mov    %rbp,%rdi
  405427:	shl    $0x12,%rdi
  40542b:	add    0x28(%rbx),%rdi
  40542f:	mov    $0x8000,%esi
  405434:	lea    (%rax,%rbp,8),%r14
  405438:	call   4050a0 <topic49_stream_scan>
  40543d:	mov    %rax,(%r14)
  405440:	inc    %rbp
  405443:	cmp    %rbp,0x40(%rbx)
  405447:	ja     405420 <worker_main+0x2c0>
  405449:	jmp    40522d <worker_main+0xcd>
  40544e:	xchg   %ax,%ax
  405450:	vpxor  %xmm0,%xmm0,%xmm0
  405454:	lea    0x90(%rsp),%rdx
  40545c:	mov    $0x80,%esi
  405461:	mov    %r13,%rdi
  405464:	vmovdqa %xmm0,0x90(%rsp)
  40546d:	vmovdqa %xmm0,0xa0(%rsp)
  405476:	vmovdqa %xmm0,0xb0(%rsp)
  40547f:	vmovdqa %xmm0,0xc0(%rsp)
  405488:	vmovdqa %xmm0,0xd0(%rsp)
  405491:	vmovdqa %xmm0,0xe0(%rsp)
  40549a:	vmovdqa %xmm0,0xf0(%rsp)
  4054a3:	vmovdqa %xmm0,0x100(%rsp)
  4054ac:	call   4022b0 <pthread_getaffinity_np@plt>
  4054b1:	test   %eax,%eax
  4054b3:	jne    4051f6 <worker_main+0x96>
  4054b9:	cmp    $0x3ff,%rbp
  4054c0:	ja     4054d8 <worker_main+0x378>
  4054c2:	shr    $0x6,%rbp
  4054c6:	mov    0x90(%rsp,%rbp,8),%rax
  4054ce:	bt     %r14,%rax
  4054d2:	jb     405720 <worker_main+0x5c0>
  4054d8:	mov    $0x16,%eax
  4054dd:	jmp    4051f6 <worker_main+0x96>
  4054e2:	nopw   0x0(%rax,%rax,1)
  4054e8:	mov    0x1c(%rbx),%r8d
  4054ec:	test   %r8d,%r8d
  4054ef:	jne    4052d0 <worker_main+0x170>
  4054f5:	cmpl   $0x2,0x88(%r12)
  4054fe:	je     405748 <worker_main+0x5e8>
  405504:	mov    $0x1,%esi
  405509:	mov    %rbx,%rdi
  40550c:	call   404490 <worker_wait_for_phase>
  405511:	jmp    4052d0 <worker_main+0x170>
  405516:	cs nopw 0x0(%rax,%rax,1)
  405520:	incq   0x68(%r12)
  405525:	mov    %r14,%rdi
  405528:	call   402070 <pthread_cond_broadcast@plt>
  40552d:	jmp    405543 <worker_main+0x3e3>
  40552f:	nop
  405530:	mov    %r12,%rsi
  405533:	mov    %r14,%rdi
  405536:	call   4020a0 <pthread_cond_wait@plt>
  40553b:	test   %eax,%eax
  40553d:	jne    4057b8 <worker_main+0x658>
  405543:	mov    0x0(%rbp),%eax
  405546:	cmp    $0x2,%eax
  405549:	je     405530 <worker_main+0x3d0>
  40554b:	mov    %r12,%rdi
  40554e:	call   4021b0 <pthread_mutex_unlock@plt>
  405553:	test   %eax,%eax
  405555:	jne    405700 <worker_main+0x5a0>
  40555b:	mov    0x1c(%rbx),%r14d
  40555f:	test   %r14d,%r14d
  405562:	jne    405580 <worker_main+0x420>
  405564:	cmpl   $0x2,0x88(%r12)
  40556d:	je     40582a <worker_main+0x6ca>
  405573:	mov    $0x3,%esi
  405578:	mov    %rbx,%rdi
  40557b:	call   404490 <worker_wait_for_phase>
  405580:	call   402280 <sched_getcpu@plt>
  405585:	mov    0x8(%rbx),%ebp
  405588:	mov    %eax,0x14(%rbx)
  40558b:	cmp    %ebp,%eax
  40558d:	je     40559e <worker_main+0x43e>
  40558f:	mov    0x1c(%rbx),%ecx
  405592:	test   %ecx,%ecx
  405594:	jne    40559e <worker_main+0x43e>
  405596:	movq   $0xb,0x1c(%rbx)
  40559e:	vpxor  %xmm0,%xmm0,%xmm0
  4055a2:	lea    0x90(%rsp),%rdx
  4055aa:	mov    $0x80,%esi
  4055af:	mov    %r13,%rdi
  4055b2:	vmovdqa %xmm0,0x90(%rsp)
  4055bb:	vmovdqa %xmm0,0xa0(%rsp)
  4055c4:	vmovdqa %xmm0,0xb0(%rsp)
  4055cd:	vmovdqa %xmm0,0xc0(%rsp)
  4055d6:	vmovdqa %xmm0,0xd0(%rsp)
  4055df:	vmovdqa %xmm0,0xe0(%rsp)
  4055e8:	vmovdqa %xmm0,0xf0(%rsp)
  4055f1:	vmovdqa %xmm0,0x100(%rsp)
  4055fa:	call   4022b0 <pthread_getaffinity_np@plt>
  4055ff:	test   %eax,%eax
  405601:	jne    405645 <worker_main+0x4e5>
  405603:	movslq %ebp,%rax
  405606:	cmp    $0x3ff,%rax
  40560c:	ja     405640 <worker_main+0x4e0>
  40560e:	shr    $0x6,%rax
  405612:	mov    0x90(%rsp,%rax,8),%rax
  40561a:	bt     %rbp,%rax
  40561e:	jae    405640 <worker_main+0x4e0>
  405620:	lea    0x90(%rsp),%rsi
  405628:	mov    $0x80,%edi
  40562d:	call   4020c0 <__sched_cpucount@plt>
  405632:	cmp    $0x1,%eax
  405635:	je     40565a <worker_main+0x4fa>
  405637:	nopw   0x0(%rax,%rax,1)
  405640:	mov    $0x16,%eax
  405645:	mov    0x1c(%rbx),%edx
  405648:	movb   $0x0,0x18(%rbx)
  40564c:	test   %edx,%edx
  40564e:	jne    40565a <worker_main+0x4fa>
  405650:	movl   $0xc,0x1c(%rbx)
  405657:	mov    %eax,0x20(%rbx)
  40565a:	mov    0x38(%rbx),%rdi
  40565e:	call   402040 <free@plt>
  405663:	mov    0x28(%rbx),%rdi
  405667:	movq   $0x0,0x38(%rbx)
  40566f:	test   %rdi,%rdi
  405672:	je     40524c <worker_main+0xec>
  405678:	mov    0x30(%rbx),%rsi
  40567c:	call   4021f0 <munmap@plt>
  405681:	test   %eax,%eax
  405683:	je     40569d <worker_main+0x53d>
  405685:	mov    0x1c(%rbx),%eax
  405688:	test   %eax,%eax
  40568a:	jne    40569d <worker_main+0x53d>
  40568c:	call   402050 <__errno_location@plt>
  405691:	mov    (%rax),%eax
  405693:	movl   $0xd,0x1c(%rbx)
  40569a:	mov    %eax,0x20(%rbx)
  40569d:	movq   $0x0,0x28(%rbx)
  4056a5:	jmp    40524c <worker_main+0xec>
  4056aa:	nopw   0x0(%rax,%rax,1)
  4056b0:	mov    0x1c(%rbx),%r10d
  4056b4:	test   %r10d,%r10d
  4056b7:	jne    4052aa <worker_main+0x14a>
  4056bd:	movl   $0x6,0x1c(%rbx)
  4056c4:	mov    %eax,0x20(%rbx)
  4056c7:	jmp    4052aa <worker_main+0x14a>
  4056cc:	nopl   0x0(%rax)
  4056d0:	mov    0x1c(%rbx),%edx
  4056d3:	mov    0x10(%rsp),%eax
  4056d7:	test   %edx,%edx
  4056d9:	jne    40522d <worker_main+0xcd>
  4056df:	movl   $0x26,0x1c(%rbx)
  4056e6:	mov    %eax,0x20(%rbx)
  4056e9:	jmp    40522d <worker_main+0xcd>
  4056ee:	xchg   %ax,%ax
  4056f0:	movl   $0x7,0x1c(%rbx)
  4056f7:	mov    %eax,0x20(%rbx)
  4056fa:	jmp    4052d0 <worker_main+0x170>
  4056ff:	nop
  405700:	mov    0x1c(%rbx),%r15d
  405704:	test   %r15d,%r15d
  405707:	jne    405580 <worker_main+0x420>
  40570d:	movl   $0xa,0x1c(%rbx)
  405714:	mov    %eax,0x20(%rbx)
  405717:	jmp    405580 <worker_main+0x420>
  40571c:	nopl   0x0(%rax)
  405720:	lea    0x90(%rsp),%rsi
  405728:	mov    $0x80,%edi
  40572d:	call   4020c0 <__sched_cpucount@plt>
  405732:	cmp    $0x1,%eax
  405735:	jne    4054d8 <worker_main+0x378>
  40573b:	movb   $0x1,0x18(%rbx)
  40573f:	jmp    405205 <worker_main+0xa5>
  405744:	nopl   0x0(%rax)
  405748:	xor    %r15d,%r15d
  40574b:	nopl   0x0(%rax,%rax,1)
  405750:	mov    0x0(%rbp),%eax
  405753:	cmp    $0x1,%eax
  405756:	jne    4052d0 <worker_main+0x170>
  40575c:	mov    %r15,%rdi
  40575f:	shl    $0x12,%rdi
  405763:	add    0x28(%rbx),%rdi
  405767:	mov    $0x8000,%esi
  40576c:	call   4050a0 <topic49_stream_scan>
  405771:	mov    0x38(%rbx),%rdx
  405775:	cmp    (%rdx,%r15,8),%rax
  405779:	je     405798 <worker_main+0x638>
  40577b:	mov    0x1c(%rbx),%edi
  40577e:	test   %edi,%edi
  405780:	jne    4052d0 <worker_main+0x170>
  405786:	movq   $0x1e,0x1c(%rbx)
  40578e:	jmp    4052d0 <worker_main+0x170>
  405793:	nopl   0x0(%rax,%rax,1)
  405798:	lea    0x1(%r15),%rax
  40579c:	xor    %edx,%edx
  40579e:	divq   0x40(%rbx)
  4057a2:	mov    0x1c(%rbx),%esi
  4057a5:	mov    %rdx,%r15
  4057a8:	test   %esi,%esi
  4057aa:	je     405750 <worker_main+0x5f0>
  4057ac:	jmp    4052d0 <worker_main+0x170>
  4057b1:	nopl   0x0(%rax)
  4057b8:	mov    0x1c(%rbx),%edx
  4057bb:	test   %edx,%edx
  4057bd:	jne    40554b <worker_main+0x3eb>
  4057c3:	movl   $0x9,0x1c(%rbx)
  4057ca:	mov    %eax,0x20(%rbx)
  4057cd:	jmp    40554b <worker_main+0x3eb>
  4057d2:	nopw   0x0(%rax,%rax,1)
  4057d8:	call   402050 <__errno_location@plt>
  4057dd:	mov    (%rax),%r15d
  4057e0:	mov    0x1c(%rbx),%eax
  4057e3:	movq   $0x0,0x28(%rbx)
  4057eb:	test   %eax,%eax
  4057ed:	jne    40522d <worker_main+0xcd>
  4057f3:	movl   $0x3,0x1c(%rbx)
  4057fa:	mov    %r15d,0x20(%rbx)
  4057fe:	jmp    40522d <worker_main+0xcd>
  405803:	nopl   0x0(%rax,%rax,1)
  405808:	call   402050 <__errno_location@plt>
  40580d:	mov    %r14,%rsi
  405810:	mov    %rbp,%rdi
  405813:	mov    (%rax),%r15d
  405816:	mov    %rax,0x8(%rsp)
  40581b:	call   4021f0 <munmap@plt>
  405820:	mov    0x8(%rsp),%rdx
  405825:	mov    %r15d,(%rdx)
  405828:	jmp    4057e0 <worker_main+0x680>
  40582a:	mov    0x58(%r12),%eax
  40582f:	cmp    $0x3,%eax
  405832:	je     405848 <worker_main+0x6e8>
  405834:	mov    0x1c(%rbx),%esi
  405837:	test   %esi,%esi
  405839:	jne    405580 <worker_main+0x420>
  40583f:	jmp    405573 <worker_main+0x413>
  405844:	nopl   0x0(%rax)
  405848:	add    $0x5c,%r12
  40584c:	xor    %r15d,%r15d
  40584f:	movabs $0xbf58476d1ce4e5b9,%r14
  405859:	nopl   0x0(%rax)
  405860:	movzbl (%r12),%eax
  405865:	test   %al,%al
  405867:	jne    4058a0 <worker_main+0x740>
  405869:	mov    %r15,%rdi
  40586c:	shl    $0x12,%rdi
  405870:	add    0x28(%rbx),%rdi
  405874:	mov    $0x8000,%esi
  405879:	call   4050a0 <topic49_stream_scan>
  40587e:	mov    %rax,%rdx
  405881:	mov    0x38(%rbx),%rax
  405885:	cmp    (%rax,%r15,8),%rdx
  405889:	je     405918 <worker_main+0x7b8>
  40588f:	mov    0x1c(%rbx),%r12d
  405893:	test   %r12d,%r12d
  405896:	jne    4058a0 <worker_main+0x740>
  405898:	movq   $0x1e,0x1c(%rbx)
  4058a0:	cmpb   $0x0,0x50(%rbx)
  4058a4:	jne    405580 <worker_main+0x420>
  4058aa:	mov    (%rbx),%rbp
  4058ad:	mov    %rbp,%rdi
  4058b0:	call   402310 <pthread_mutex_lock@plt>
  4058b5:	test   %eax,%eax
  4058b7:	jne    405a4d <worker_main+0x8ed>
  4058bd:	cmpb   $0x0,0x51(%rbx)
  4058c1:	jne    4058cb <worker_main+0x76b>
  4058c3:	movb   $0x1,0x51(%rbx)
  4058c7:	incq   0x78(%rbp)
  4058cb:	lea    0x28(%rbp),%rdi
  4058cf:	call   402070 <pthread_cond_broadcast@plt>
  4058d4:	test   %eax,%eax
  4058d6:	je     4058e8 <worker_main+0x788>
  4058d8:	cmpl   $0x0,0x1c(%rbx)
  4058dc:	jne    4058e8 <worker_main+0x788>
  4058de:	movl   $0x24,0x1c(%rbx)
  4058e5:	mov    %eax,0x20(%rbx)
  4058e8:	mov    %rbp,%rdi
  4058eb:	call   4021b0 <pthread_mutex_unlock@plt>
  4058f0:	test   %eax,%eax
  4058f2:	je     405580 <worker_main+0x420>
  4058f8:	cmpl   $0x0,0x1c(%rbx)
  4058fc:	jne    405580 <worker_main+0x420>
  405902:	movl   $0x25,0x1c(%rbx)
  405909:	mov    %eax,0x20(%rbx)
  40590c:	jmp    405580 <worker_main+0x420>
  405911:	nopl   0x0(%rax)
  405918:	mov    0x1c(%rbx),%ebp
  40591b:	test   %ebp,%ebp
  40591d:	jne    4058a0 <worker_main+0x740>
  40591f:	movzbl (%r12),%eax
  405924:	test   %al,%al
  405926:	jne    4058a0 <worker_main+0x740>
  40592c:	mov    %r15,%rax
  40592f:	shr    $0x1e,%rax
  405933:	xor    %r15,%rax
  405936:	imul   %r14,%rax
  40593a:	incq   0x48(%rbx)
  40593e:	mov    %rax,%rcx
  405941:	shr    $0x1b,%rcx
  405945:	xor    %rcx,%rax
  405948:	movabs $0x94d049bb133111eb,%rcx
  405952:	imul   %rcx,%rax
  405956:	mov    %rax,%rcx
  405959:	shr    $0x1f,%rcx
  40595d:	xor    %rcx,%rax
  405960:	xor    %rdx,%rax
  405963:	add    %rax,0x58(%rbx)
  405967:	cmpb   $0x0,0x50(%rbx)
  40596b:	je     40597f <worker_main+0x81f>
  40596d:	lea    0x1(%r15),%rax
  405971:	xor    %edx,%edx
  405973:	divq   0x40(%rbx)
  405977:	mov    %rdx,%r15
  40597a:	jmp    405860 <worker_main+0x700>
  40597f:	mov    (%rbx),%rbp
  405982:	mov    %rbp,%rdi
  405985:	call   402310 <pthread_mutex_lock@plt>
  40598a:	test   %eax,%eax
  40598c:	jne    405a31 <worker_main+0x8d1>
  405992:	cmpb   $0x0,0x50(%rbx)
  405996:	jne    405a10 <worker_main+0x8b0>
  405998:	cmpq   $0x0,0x48(%rbx)
  40599d:	je     405a10 <worker_main+0x8b0>
  40599f:	mov    0x70(%rbp),%rax
  4059a3:	cmp    0x80(%rbp),%rax
  4059aa:	jae    405a10 <worker_main+0x8b0>
  4059ac:	inc    %rax
  4059af:	movb   $0x1,0x50(%rbx)
  4059b3:	mov    %rax,0x70(%rbp)
  4059b7:	lea    0x28(%rbp),%rdi
  4059bb:	call   402070 <pthread_cond_broadcast@plt>
  4059c0:	test   %eax,%eax
  4059c2:	je     4059d7 <worker_main+0x877>
  4059c4:	mov    0x1c(%rbx),%r9d
  4059c8:	test   %r9d,%r9d
  4059cb:	jne    4059d7 <worker_main+0x877>
  4059cd:	movl   $0x21,0x1c(%rbx)
  4059d4:	mov    %eax,0x20(%rbx)
  4059d7:	mov    %rbp,%rdi
  4059da:	call   4021b0 <pthread_mutex_unlock@plt>
  4059df:	test   %eax,%eax
  4059e1:	je     4059ff <worker_main+0x89f>
  4059e3:	mov    0x1c(%rbx),%r8d
  4059e7:	test   %r8d,%r8d
  4059ea:	jne    4058a0 <worker_main+0x740>
  4059f0:	movl   $0x22,0x1c(%rbx)
  4059f7:	mov    %eax,0x20(%rbx)
  4059fa:	jmp    4058a0 <worker_main+0x740>
  4059ff:	mov    0x1c(%rbx),%edi
  405a02:	test   %edi,%edi
  405a04:	je     40596d <worker_main+0x80d>
  405a0a:	jmp    4058a0 <worker_main+0x740>
  405a0f:	nop
  405a10:	mov    0x1c(%rbx),%r10d
  405a14:	test   %r10d,%r10d
  405a17:	jne    405a21 <worker_main+0x8c1>
  405a19:	movq   $0x20,0x1c(%rbx)
  405a21:	cmpb   $0x0,0x51(%rbx)
  405a25:	jne    4059b7 <worker_main+0x857>
  405a27:	movb   $0x1,0x51(%rbx)
  405a2b:	incq   0x78(%rbp)
  405a2f:	jmp    4059b7 <worker_main+0x857>
  405a31:	mov    0x1c(%rbx),%r11d
  405a35:	test   %r11d,%r11d
  405a38:	jne    4058a0 <worker_main+0x740>
  405a3e:	movl   $0x1f,0x1c(%rbx)
  405a45:	mov    %eax,0x20(%rbx)
  405a48:	jmp    4058a0 <worker_main+0x740>
  405a4d:	cmpl   $0x0,0x1c(%rbx)
  405a51:	jne    405580 <worker_main+0x420>
  405a57:	movl   $0x23,0x1c(%rbx)
  405a5e:	mov    %eax,0x20(%rbx)
  405a61:	jmp    405580 <worker_main+0x420>
  405a66:	call   402050 <__errno_location@plt>
  405a6b:	cmpl   $0x0,0x1c(%rbx)
  405a6f:	mov    (%rax),%eax
  405a71:	jne    40522d <worker_main+0xcd>
  405a77:	movl   $0x4,0x1c(%rbx)
  405a7e:	mov    %eax,0x20(%rbx)
  405a81:	jmp    40522d <worker_main+0xcd>
  405a86:	cs nopw 0x0(%rax,%rax,1)

0000000000405a90 <topic49_run_timed>:
  405a90:	push   %r15
  405a92:	push   %r14
  405a94:	mov    %r8,%r14
  405a97:	push   %r13
  405a99:	mov    %rdx,%r13
  405a9c:	push   %r12
  405a9e:	mov    %rsi,%r12
  405aa1:	push   %rbp
  405aa2:	mov    %rdi,%rbp
  405aa5:	mov    $0x4,%edi
  405aaa:	push   %rbx
  405aab:	mov    %rcx,%rbx
  405aae:	sub    $0x38,%rsp
  405ab2:	lea    0x20(%rsp),%rsi
  405ab7:	call   402090 <clock_gettime@plt>
  405abc:	test   %eax,%eax
  405abe:	jne    405b28 <topic49_run_timed+0x98>
  405ac0:	mov    0x28(%rsp),%r8
  405ac5:	mov    %r12,%rsi
  405ac8:	mov    %rbp,%rdi
  405acb:	mov    %r14,%rcx
  405ace:	mov    %r13,%rdx
  405ad1:	imul   $0x3b9aca00,0x20(%rsp),%r15
  405ada:	mov    %r8,0x8(%rsp)
  405adf:	call   404de0 <topic49_walk_dependent>
  405ae4:	lea    0x10(%rsp),%rsi
  405ae9:	mov    $0x4,%edi
  405aee:	mov    %rax,%r12
  405af1:	call   402090 <clock_gettime@plt>
  405af6:	test   %eax,%eax
  405af8:	jne    405b28 <topic49_run_timed+0x98>
  405afa:	imul   $0x3b9aca00,0x10(%rsp),%rdx
  405b03:	mov    0x8(%rsp),%r8
  405b08:	mov    %r12,%rax
  405b0b:	sub    %r8,%rdx
  405b0e:	add    0x18(%rsp),%rdx
  405b13:	sub    %r15,%rdx
  405b16:	mov    %rdx,(%rbx)
  405b19:	add    $0x38,%rsp
  405b1d:	pop    %rbx
  405b1e:	pop    %rbp
  405b1f:	pop    %r12
  405b21:	pop    %r13
  405b23:	pop    %r14
  405b25:	pop    %r15
  405b27:	ret
  405b28:	call   404a90 <now_ns.part.0>

Disassembly of section .fini:

0000000000405b30 <_fini>:
  405b30:	endbr64
  405b34:	sub    $0x8,%rsp
  405b38:	add    $0x8,%rsp
  405b3c:	ret
