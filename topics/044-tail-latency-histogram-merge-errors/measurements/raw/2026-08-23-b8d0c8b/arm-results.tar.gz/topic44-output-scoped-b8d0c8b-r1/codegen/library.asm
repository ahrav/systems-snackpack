	.file	"histogram_merge_errors.367e9e928f27f9e4-cgu.0"
	.section	.text._RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt,@function
_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, .LBB0_3
	tbnz	w8, #26, .LBB0_4
	b	_RNvXsd_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impyNtB9_7Display3fmt
.LBB0_3:
	b	_RNvXsC_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8LowerHex3fmt
.LBB0_4:
	b	_RNvXsE_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8UpperHex3fmt
.Lfunc_end0:
	.size	_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt, .Lfunc_end0-_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text._RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt,@function
_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt:
	.cfi_startproc
	ldr	w8, [x1, #16]
	tbnz	w8, #25, .LBB1_3
	tbnz	w8, #26, .LBB1_4
	b	_RNvXsi_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impjNtB9_7Display3fmt
.LBB1_3:
	b	_RNvXs6_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8LowerHex3fmt
.LBB1_4:
	b	_RNvXs8_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8UpperHex3fmt
.Lfunc_end1:
	.size	_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt, .Lfunc_end1-_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E
	.p2align	4
	.type	_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E,@function
_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E:
	.cfi_startproc
	ldr	x10, [x0, #16]
	cbz	x10, .LBB2_6
	ldr	x9, [x0, #8]
	add	x11, x9, #8
	mov	w9, #1
	.p2align	5, , 16
.LBB2_2:
	cmp	x10, #2
	b.lo	.LBB2_8
	ldp	x12, x13, [x11, #-8]
	sub	x10, x10, #1
	add	x11, x11, #8
	cmp	x12, x13
	b.lo	.LBB2_2
	mov	w10, #1
	stp	x10, x9, [x8]
	ldr	x8, [x0]
	cbnz	x8, .LBB2_7
.LBB2_5:
	ret
.LBB2_6:
	mov	w10, #1
	stp	x10, xzr, [x8]
	ldr	x8, [x0]
	cbz	x8, .LBB2_5
.LBB2_7:
	ldr	x0, [x0, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB2_8:
	ldr	q0, [x0]
	ldr	x9, [x0, #16]
	str	xzr, [x8]
	str	x9, [x8, #24]
	stur	q0, [x8, #8]
	ret
.Lfunc_end2:
	.size	_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E, .Lfunc_end2-_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E,@function
_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E:
	.cfi_startproc
	sub	sp, sp, #80
	.cfi_def_cfa_offset 80
	stp	x29, x30, [sp, #48]
	str	x19, [sp, #64]
	add	x29, sp, #48
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	ldr	x10, [x1, #16]
	ldr	x9, [x0, #16]
	cmp	x10, x9
	b.ne	.LBB3_4
	ldr	x14, [x1, #8]
	lsl	x15, x10, #3
	mov	w11, #16
	mov	w9, #6
	mov	w12, #8
	mov	x13, xzr
	.p2align	5, , 16
.LBB3_2:
	cbz	x15, .LBB3_9
	ldr	x16, [x14], #8
	mov	x10, x13
	sub	x15, x15, #8
	adds	x13, x16, x13
	b.lo	.LBB3_2
	b	.LBB3_5
.LBB3_4:
	mov	w11, #2
	mov	w12, #16
	str	x11, [x8, #8]
	mov	w11, #24
.LBB3_5:
	str	x9, [x8, x12]
	mov	x9, #-9223372036854775808
	str	x10, [x8, x11]
	str	x9, [x8]
	ldr	x9, [x1]
	cbz	x9, .LBB3_7
	ldr	x8, [x1, #8]
	lsl	x1, x9, #3
	mov	w2, #8
	mov	x19, x0
	mov	x0, x8
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
	mov	x0, x19
.LBB3_7:
	ldr	x8, [x0]
	cbz	x8, .LBB3_10
	ldr	x0, [x0, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 80
	ldr	x19, [sp, #64]
	ldp	x29, x30, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB3_9:
	.cfi_restore_state
	ldr	x9, [x0, #16]
	ldr	q1, [x1]
	ldr	q0, [x0]
	str	x9, [sp, #16]
	ldr	x9, [x1, #16]
	stur	q1, [sp, #24]
	str	x9, [sp, #40]
	ldp	q1, q2, [sp, #16]
	str	q2, [x8, #32]
	stp	q0, q1, [x8]
.LBB3_10:
	.cfi_def_cfa wsp, 80
	ldr	x19, [sp, #64]
	ldp	x29, x30, [sp, #48]
	add	sp, sp, #80
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end3:
	.size	_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E, .Lfunc_end3-_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E,@function
_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E:
	.cfi_startproc
	ldp	x10, x11, [x0, #32]
	mov	x9, xzr
	lsl	x11, x11, #3
	.p2align	5, , 16
.LBB4_1:
	cbz	x11, .LBB4_4
	ldr	x13, [x10], #8
	mov	x12, x9
	sub	x11, x11, #8
	adds	x9, x13, x9
	b.lo	.LBB4_1
	mov	w9, #6
	stp	x9, x12, [x8]
	ret
.LBB4_4:
	mov	w10, #11
	stp	x10, x9, [x8]
	ret
.Lfunc_end4:
	.size	_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E, .Lfunc_end4-_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E,@function
_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E:
	.cfi_startproc
	sub	sp, sp, #112
	.cfi_def_cfa_offset 112
	stp	x29, x30, [sp, #32]
	stp	x26, x25, [sp, #48]
	stp	x24, x23, [sp, #64]
	stp	x22, x21, [sp, #80]
	stp	x20, x19, [sp, #96]
	add	x29, sp, #32
	.cfi_def_cfa w29, 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w30, -72
	.cfi_offset w29, -80
	.cfi_remember_state
	mov	x19, x8
	ldr	x8, [x0, #16]
	ldr	x9, [x1, #16]
	cmp	x8, x9
	b.ne	.LBB5_2
	mov	x21, x1
	mov	x20, x0
	ldr	x1, [x1, #8]
	ldr	x0, [x0, #8]
	lsl	x2, x8, #3
	bl	bcmp
	cbz	w0, .LBB5_5
.LBB5_2:
	mov	w8, #4
.LBB5_3:
	str	x8, [x19]
.LBB5_4:
	.cfi_def_cfa wsp, 112
	ldp	x20, x19, [sp, #96]
	ldp	x22, x21, [sp, #80]
	ldp	x24, x23, [sp, #64]
	ldp	x26, x25, [sp, #48]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #112
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB5_5:
	.cfi_restore_state
	ldr	x8, [x20, #40]
	ldr	x9, [x21, #40]
	cmp	x9, x8
	csel	x23, x9, x8, lo
	cbz	x23, .LBB5_14
	ldr	x24, [x20, #32]
	ldr	x25, [x21, #32]
	ldr	x8, [x24]
	ldr	x9, [x25]
	adds	x26, x9, x8
	b.hs	.LBB5_21
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #32
	mov	w1, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbz	x0, .LBB5_22
	mov	w22, #4
	mov	w8, #1
	cmp	x23, #1
	mov	x21, x0
	str	x26, [x0]
	stp	x22, x0, [sp, #8]
	str	x8, [sp, #24]
	b.eq	.LBB5_15
	mov	w22, #1
	b	.LBB5_11
	.p2align	5, , 16
.LBB5_10:
	str	x26, [x21, x22, lsl #3]
	add	x22, x22, #1
	cmp	x23, x22
	str	x22, [sp, #24]
	b.eq	.LBB5_18
.LBB5_11:
	ldr	x8, [x24, x22, lsl #3]
	ldr	x9, [x25, x22, lsl #3]
	adds	x26, x9, x8
	b.hs	.LBB5_19
	ldr	x8, [sp, #8]
	cmp	x22, x8
	b.ne	.LBB5_10
	add	x0, sp, #8
	mov	w2, #1
	mov	x1, x22
	bl	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE
	ldr	x21, [sp, #16]
	b	.LBB5_10
.LBB5_14:
	mov	x22, xzr
	mov	w21, #8
.LBB5_15:
	ldr	x8, [x20, #24]
	cbz	x8, .LBB5_17
.LBB5_16:
	ldr	x0, [x20, #32]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB5_17:
	mov	w8, #11
	stp	x22, x21, [x20, #24]
	str	x23, [x20, #40]
	b	.LBB5_3
.LBB5_18:
	ldp	x22, x21, [sp, #8]
	ldr	x8, [x20, #24]
	cbnz	x8, .LBB5_16
	b	.LBB5_17
.LBB5_19:
	ldr	x8, [sp, #8]
	cbz	x8, .LBB5_21
	ldr	x0, [sp, #16]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB5_21:
	mov	w8, #6
	stp	x8, x26, [x19]
	b	.LBB5_4
.LBB5_22:
	mov	w0, #8
	mov	w1, #32
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.Lfunc_end5:
	.size	_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E, .Lfunc_end5-_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E,@function
_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	sub	x9, x1, #1
	cmp	x9, x2
	b.hs	.LBB6_6
	ldp	x9, x10, [x0, #32]
	mov	x11, xzr
	lsl	x10, x10, #3
	mov	x13, x9
	mov	x12, x10
	.p2align	5, , 16
.LBB6_2:
	cbz	x12, .LBB6_7
	ldr	x15, [x13], #8
	mov	x14, x11
	sub	x12, x12, #8
	adds	x11, x15, x11
	b.lo	.LBB6_2
	str	x14, [x8, #16]
.LBB6_5:
	index	z0.d, #0, #4
	orr	z0.d, z0.d, #0x2
	str	q0, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_6:
	.cfi_restore_state
	.cfi_remember_state
	index	z0.d, #2, #5
	str	q0, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_7:
	.cfi_restore_state
	.cfi_remember_state
	cbz	x11, .LBB6_16
	umulh	x12, x11, x1
	cmp	xzr, x12
	b.ne	.LBB6_5
	mul	x12, x11, x1
	sub	x13, x2, #1
	adds	x12, x13, x12
	b.hs	.LBB6_5
	udiv	x12, x12, x2
	mov	x13, xzr
	mov	x14, xzr
	.p2align	5, , 16
.LBB6_11:
	cbz	x10, .LBB6_17
	ldr	x15, [x9, x13, lsl #3]
	adds	x14, x15, x14
	b.hs	.LBB6_5
	add	x13, x13, #1
	sub	x10, x10, #8
	cmp	x14, x12
	b.lo	.LBB6_11
	subs	x9, x13, #1
	b.ne	.LBB6_18
	ldr	x1, [x0, #16]
	mov	x10, xzr
	b	.LBB6_20
.LBB6_16:
	index	z0.d, #2, #6
	str	q0, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_17:
	.cfi_restore_state
	.cfi_remember_state
	index	z0.d, #0, #8
	orr	z0.d, z0.d, #0x2
	str	q0, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_18:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x1, [x0, #16]
	sub	x10, x13, #2
	cmp	x10, x1
	b.hs	.LBB6_23
	ldr	x10, [x0, #8]
	add	x10, x10, x13, lsl #3
	ldur	x14, [x10, #-16]
	mov	w10, #1
.LBB6_20:
	cmp	x9, x1
	b.hs	.LBB6_22
	ldr	x9, [x0, #8]
	stp	x10, x14, [x8]
	add	x9, x9, x13, lsl #3
	ldur	x9, [x9, #-8]
	stp	x9, x12, [x8, #16]
	str	x11, [x8, #32]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB6_22:
	.cfi_restore_state
	adrp	x2, .Lalloc_713e1b0d46806bc8c2cd07e9f5848152
	add	x2, x2, :lo12:.Lalloc_713e1b0d46806bc8c2cd07e9f5848152
	mov	x0, x9
	bl	_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check
.LBB6_23:
	adrp	x2, .Lalloc_9034bc150239ddb23220298f62c78c3d
	add	x2, x2, :lo12:.Lalloc_9034bc150239ddb23220298f62c78c3d
	mov	x0, x10
	bl	_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check
.Lfunc_end6:
	.size	_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E, .Lfunc_end6-_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E,@function
_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E:
	.cfi_startproc
	stp	x29, x30, [sp, #-48]!
	.cfi_def_cfa_offset 48
	stp	x22, x21, [sp, #16]
	stp	x20, x19, [sp, #32]
	mov	x29, sp
	.cfi_def_cfa w29, 48
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w30, -40
	.cfi_offset w29, -48
	ldr	x22, [x0, #16]
	mov	x20, x0
	mov	x19, x8
	cbz	x22, .LBB7_3
	lsl	x21, x22, #3
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x21
	bl	_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed
	cbnz	x0, .LBB7_4
	mov	w0, #8
	mov	x1, x21
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.LBB7_3:
	mov	w0, #8
.LBB7_4:
	ldr	q0, [x20]
	ldr	x8, [x20, #16]
	stp	x8, x22, [x19, #16]
	str	q0, [x19]
	stp	x0, x22, [x19, #32]
	.cfi_def_cfa wsp, 48
	ldp	x20, x19, [sp, #32]
	ldp	x22, x21, [sp, #16]
	ldp	x29, x30, [sp], #48
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end7:
	.size	_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E, .Lfunc_end7-_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E,@function
_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E:
	.cfi_startproc
	stp	x29, x30, [sp, #-16]!
	.cfi_def_cfa_offset 16
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldp	x10, x11, [x0, #8]
	cmp	x11, #1
	b.eq	.LBB8_8
	cbz	x11, .LBB8_11
	mov	x9, xzr
	mov	x12, x11
	.p2align	5, , 16
.LBB8_3:
	lsr	x13, x12, #1
	add	x14, x13, x9
	sub	x12, x12, x13
	ldr	x15, [x10, x14, lsl #3]
	cmp	x15, x1
	csel	x9, x14, x9, lo
	cmp	x12, #1
	b.hi	.LBB8_3
	ldr	x12, [x10, x9, lsl #3]
	cmp	x12, x1
	cinc	x9, x9, lo
	cmp	x9, x11
	b.hs	.LBB8_9
.LBB8_5:
	ldr	x1, [x0, #40]
	cmp	x9, x1
	b.hs	.LBB8_12
	ldr	x10, [x0, #32]
	ldr	x11, [x10, x9, lsl #3]
	cmn	x11, #1
	b.eq	.LBB8_10
	add	x11, x11, #1
	str	x11, [x10, x9, lsl #3]
	mov	w9, #11
	str	x9, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB8_8:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x12, [x10, xzr, lsl #3]
	cmp	x12, x1
	cset	x9, lo
	cmp	x9, x11
	b.lo	.LBB8_5
.LBB8_9:
	add	x9, x10, x11, lsl #3
	mov	w10, #3
	ldur	x9, [x9, #-8]
	stp	x10, x1, [x8]
	str	x9, [x8, #16]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB8_10:
	.cfi_restore_state
	.cfi_remember_state
	mov	w9, #6
	str	x9, [x8]
	.cfi_def_cfa wsp, 16
	ldp	x29, x30, [sp], #16
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB8_11:
	.cfi_restore_state
	adrp	x0, .Lalloc_4ed059f71d51ae16bc6826f989989385
	add	x0, x0, :lo12:.Lalloc_4ed059f71d51ae16bc6826f989989385
	adrp	x2, .Lalloc_72e1b02f1dc44543daa9de23d3bba29e
	add	x2, x2, :lo12:.Lalloc_72e1b02f1dc44543daa9de23d3bba29e
	mov	w1, #30
	bl	_RNvNtCs6Hz1PecaLG4_4core6option13expect_failed
.LBB8_12:
	adrp	x2, .Lalloc_96d0d7cd51bf3727855c17e0e20001f5
	add	x2, x2, :lo12:.Lalloc_96d0d7cd51bf3727855c17e0e20001f5
	mov	x0, x9
	bl	_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check
.Lfunc_end8:
	.size	_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E, .Lfunc_end8-_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E,"ax",@progbits
	.globl	_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E
	.p2align	4
	.type	_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E,@function
_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #48]
	str	x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	add	x29, sp, #48
	.cfi_def_cfa w29, 80
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -64
	.cfi_offset w30, -72
	.cfi_offset w29, -80
	.cfi_remember_state
	ldp	x23, x20, [x0, #8]
	ldr	x19, [x1, #16]
	mov	x21, x0
	cbz	x20, .LBB9_11
	cbz	x19, .LBB9_12
	ldr	x9, [x1, #8]
	add	x11, x23, x20, lsl #3
	ldur	x11, [x11, #-8]
	add	x10, x9, x19, lsl #3
	ldur	x12, [x10, #-8]
	cmp	x11, x12
	b.ne	.LBB9_12
	cmp	x20, #1
	lsl	x22, x19, #3
	b.ne	.LBB9_7
	mov	x10, x22
	.p2align	5, , 16
.LBB9_5:
	cbz	x10, .LBB9_15
	ldr	x11, [x9], #8
	ldr	x12, [x23]
	sub	x10, x10, #8
	cmp	x12, x11
	b.eq	.LBB9_5
	b	.LBB9_12
	.p2align	5, , 16
.LBB9_7:
	cmp	x9, x10
	b.eq	.LBB9_15
	ldr	x11, [x9]
	mov	x12, xzr
	mov	x13, x20
	.p2align	5, , 16
.LBB9_9:
	lsr	x14, x13, #1
	add	x15, x14, x12
	sub	x13, x13, x14
	ldr	x16, [x23, x15, lsl #3]
	cmp	x16, x11
	csel	x12, x12, x15, hi
	cmp	x13, #1
	b.hi	.LBB9_9
	ldr	x12, [x23, x12, lsl #3]
	add	x9, x9, #8
	cmp	x12, x11
	b.eq	.LBB9_7
	b	.LBB9_12
.LBB9_11:
	cbz	x19, .LBB9_14
.LBB9_12:
	mov	x9, #9
	mov	x10, #-9223372036854775808
	movk	x9, #32768, lsl #48
	index	z0.d, x10, x9
	str	q0, [x8]
	ldr	x8, [x1]
	cbz	x8, .LBB9_32
	ldr	x0, [x1, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldr	x25, [sp, #64]
	ldp	x24, x23, [sp, #80]
	ldp	x29, x30, [sp, #48]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB9_14:
	.cfi_restore_state
	.cfi_remember_state
	mov	w0, #8
	b	.LBB9_16
.LBB9_15:
	mov	x24, x8
	mov	x25, x1
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x22
	bl	_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed
	mov	x1, x25
	mov	x8, x24
	cbz	x0, .LBB9_36
.LBB9_16:
	ldr	q0, [x1]
	ldr	x9, [x21, #40]
	stp	x19, x19, [sp, #16]
	stp	x0, x19, [sp, #32]
	str	q0, [sp]
	cbz	x9, .LBB9_31
	cbz	x20, .LBB9_34
	ldr	x11, [x21, #32]
	ldr	x10, [sp, #8]
	cmp	x19, #1
	b.ne	.LBB9_24
	lsl	x12, x9, #3
	mov	w9, #1
	mov	x13, x20
	.p2align	5, , 16
.LBB9_20:
	cbz	x13, .LBB9_34
	ldr	x14, [x23], #8
	ldr	x15, [x10]
	cmp	x15, x14
	b.lo	.LBB9_35
	ldr	x14, [x0]
	ldr	x15, [x11], #8
	adds	x14, x15, x14
	b.hs	.LBB9_33
	sub	x13, x13, #1
	subs	x12, x12, #8
	str	x14, [x0]
	b.ne	.LBB9_20
	b	.LBB9_31
.LBB9_24:
	add	x12, x11, x9, lsl #3
	mov	x15, xzr
	.p2align	5, , 16
.LBB9_25:
	cmp	x15, x20
	b.eq	.LBB9_34
	add	x14, x15, #1
	ldr	x15, [x23, x15, lsl #3]
	add	x13, x11, #8
	mov	x9, xzr
	mov	x16, x19
	.p2align	5, , 16
.LBB9_27:
	lsr	x17, x16, #1
	add	x18, x17, x9
	sub	x16, x16, x17
	ldr	x1, [x10, x18, lsl #3]
	cmp	x1, x15
	csel	x9, x18, x9, lo
	cmp	x16, #1
	b.hi	.LBB9_27
	ldr	x16, [x10, x9, lsl #3]
	cmp	x16, x15
	cinc	x9, x9, lo
	cmp	x9, x19
	b.hs	.LBB9_35
	ldr	x15, [x0, x9, lsl #3]
	ldr	x11, [x11]
	adds	x11, x11, x15
	b.hs	.LBB9_33
	cmp	x13, x12
	str	x11, [x0, x9, lsl #3]
	mov	x15, x14
	mov	x11, x13
	b.ne	.LBB9_25
.LBB9_31:
	ldp	q0, q1, [sp]
	stp	q0, q1, [x8]
	ldr	q0, [sp, #32]
	str	q0, [x8, #32]
.LBB9_32:
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldr	x25, [sp, #64]
	ldp	x24, x23, [sp, #80]
	ldp	x29, x30, [sp, #48]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB9_33:
	.cfi_restore_state
	mov	x9, #6
	mov	x10, #-9223372036854775808
	mov	x0, sp
	movk	x9, #32768, lsl #48
	index	z0.d, x10, x9
	str	q0, [x8]
	bl	_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E
	b	.LBB9_32
.LBB9_34:
	adrp	x2, .Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd
	add	x2, x2, :lo12:.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd
	mov	x0, x20
	mov	x1, x20
	bl	_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check
.LBB9_35:
	adrp	x2, .Lalloc_4583e6a49f6781f6842cac8cdb2523af
	add	x2, x2, :lo12:.Lalloc_4583e6a49f6781f6842cac8cdb2523af
	mov	x0, x9
	mov	x1, x19
	bl	_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check
.LBB9_36:
	mov	w0, #8
	mov	x1, x22
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.Lfunc_end9:
	.size	_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E, .Lfunc_end9-_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE,"ax",@progbits
	.globl	_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE
	.p2align	4
	.type	_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE,@function
_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE:
	.cfi_startproc
	sub	sp, sp, #128
	.cfi_def_cfa_offset 128
	stp	x29, x30, [sp, #32]
	stp	x28, x27, [sp, #48]
	stp	x26, x25, [sp, #64]
	stp	x24, x23, [sp, #80]
	stp	x22, x21, [sp, #96]
	stp	x20, x19, [sp, #112]
	add	x29, sp, #32
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	mov	x19, x8
	ldr	x24, [x0, #16]
	ldr	x8, [x1, #16]
	cmp	x24, x8
	b.ne	.LBB10_2
	mov	x21, x1
	ldr	x1, [x1, #8]
	ldr	x22, [x0, #8]
	lsl	x20, x24, #3
	mov	x23, x0
	mov	x2, x20
	mov	x0, x22
	bl	bcmp
	cbz	w0, .LBB10_5
.LBB10_2:
	mov	x8, #4
.LBB10_3:
	movk	x8, #32768, lsl #48
	mov	x9, #-9223372036854775808
	index	z0.d, x9, x8
	str	q0, [x19]
.LBB10_4:
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x28, x27, [sp, #48]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB10_5:
	.cfi_restore_state
	.cfi_remember_state
	ldr	x8, [x23, #40]
	ldr	x9, [x21, #40]
	cmp	x9, x8
	csel	x25, x9, x8, lo
	cbz	x25, .LBB10_8
	ldr	x27, [x23, #32]
	ldr	x28, [x21, #32]
	ldr	x8, [x27]
	ldr	x9, [x28]
	subs	x23, x8, x9
	b.hs	.LBB10_9
.LBB10_7:
	mov	x8, #5
	b	.LBB10_3
.LBB10_8:
	mov	x26, xzr
	mov	w21, #8
	b	.LBB10_17
.LBB10_9:
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w0, #32
	mov	w1, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbz	x0, .LBB10_33
	mov	w26, #4
	mov	w8, #1
	cmp	x25, #1
	mov	x21, x0
	str	x23, [x0]
	stp	x26, x0, [sp, #8]
	str	x8, [sp, #24]
	b.eq	.LBB10_17
	mov	w23, #1
	.p2align	5, , 16
.LBB10_12:
	ldr	x8, [x27, x23, lsl #3]
	ldr	x9, [x28, x23, lsl #3]
	subs	x26, x8, x9
	b.lo	.LBB10_30
	ldr	x8, [sp, #8]
	cmp	x23, x8
	b.eq	.LBB10_15
	str	x26, [x21, x23, lsl #3]
	add	x23, x23, #1
	cmp	x25, x23
	str	x23, [sp, #24]
	b.ne	.LBB10_12
	b	.LBB10_16
.LBB10_15:
	add	x0, sp, #8
	mov	w2, #1
	mov	x1, x23
	bl	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE
	ldr	x21, [sp, #16]
	str	x26, [x21, x23, lsl #3]
	add	x23, x23, #1
	cmp	x25, x23
	str	x23, [sp, #24]
	b.ne	.LBB10_12
.LBB10_16:
	ldp	x26, x21, [sp, #8]
.LBB10_17:
	cbz	x24, .LBB10_24
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x20
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbz	x0, .LBB10_32
	mov	x23, x0
	mov	x1, x22
	mov	x2, x20
	bl	memcpy
	cmp	x25, x24
	b.ne	.LBB10_25
.LBB10_20:
	mov	w8, #16
	mov	w10, #6
	mov	w9, #8
	mov	x11, xzr
	mov	x12, xzr
	.p2align	5, , 16
.LBB10_21:
	cmp	x20, x11
	b.eq	.LBB10_23
	ldr	x13, [x21, x11]
	mov	x25, x12
	add	x11, x11, #8
	adds	x12, x13, x12
	b.lo	.LBB10_21
	b	.LBB10_26
.LBB10_23:
	stp	x24, x23, [x19]
	stp	x24, x26, [x19, #16]
	stp	x21, x24, [x19, #32]
	b	.LBB10_4
.LBB10_24:
	mov	w23, #8
	cmp	x25, x24
	b.eq	.LBB10_20
.LBB10_25:
	mov	w8, #2
	mov	w9, #16
	mov	x10, x24
	str	x8, [x19, #8]
	mov	w8, #24
.LBB10_26:
	str	x10, [x19, x9]
	str	x25, [x19, x8]
	mov	x8, #-9223372036854775808
	str	x8, [x19]
	cbz	x26, .LBB10_28
	lsl	x1, x26, #3
	mov	w2, #8
	mov	x0, x21
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB10_28:
	cbz	x24, .LBB10_4
	mov	x0, x23
	mov	x1, x20
	mov	w2, #8
	.cfi_def_cfa wsp, 128
	ldp	x20, x19, [sp, #112]
	ldp	x22, x21, [sp, #96]
	ldp	x24, x23, [sp, #80]
	ldp	x26, x25, [sp, #64]
	ldp	x28, x27, [sp, #48]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #128
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB10_30:
	.cfi_restore_state
	ldr	x8, [sp, #8]
	cbz	x8, .LBB10_7
	ldr	x0, [sp, #16]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
	b	.LBB10_7
.LBB10_32:
	mov	w0, #8
	mov	x1, x20
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.LBB10_33:
	mov	w0, #8
	mov	w1, #32
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.Lfunc_end10:
	.size	_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE, .Lfunc_end10-_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE
	.cfi_endproc

	.section	.text._ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE,"ax",@progbits
	.globl	_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE
	.p2align	4
	.type	_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE,@function
_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE:
	.cfi_startproc
	sub	sp, sp, #176
	.cfi_def_cfa_offset 176
	stp	x29, x30, [sp, #80]
	stp	x28, x27, [sp, #96]
	stp	x26, x25, [sp, #112]
	stp	x24, x23, [sp, #128]
	stp	x22, x21, [sp, #144]
	stp	x20, x19, [sp, #160]
	add	x29, sp, #80
	.cfi_def_cfa w29, 96
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w21, -24
	.cfi_offset w22, -32
	.cfi_offset w23, -40
	.cfi_offset w24, -48
	.cfi_offset w25, -56
	.cfi_offset w26, -64
	.cfi_offset w27, -72
	.cfi_offset w28, -80
	.cfi_offset w30, -88
	.cfi_offset w29, -96
	.cfi_remember_state
	ldp	x22, x28, [x0, #8]
	mov	x21, x1
	mov	x19, x0
	mov	x20, x8
	lsl	x23, x28, #3
	str	x22, [sp, #8]
	cbz	x28, .LBB11_12
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x23
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbz	x0, .LBB11_24
	mov	x24, x0
	mov	x1, x22
	mov	x2, x23
	bl	memcpy
	ldp	x25, x22, [x21, #8]
	lsl	x26, x22, #3
	cbz	x22, .LBB11_13
.LBB11_3:
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x26
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbz	x0, .LBB11_25
	mov	x27, x0
	mov	x1, x25
	mov	x2, x26
	bl	memcpy
	cmp	x22, x28
	b.ne	.LBB11_14
.LBB11_5:
	mov	w8, #6
	mov	x10, xzr
	mov	x11, xzr
	.p2align	5, , 16
.LBB11_6:
	cmp	x23, x10
	b.eq	.LBB11_9
	ldr	x12, [x27, x10]
	mov	x9, x11
	add	x10, x10, #8
	adds	x11, x12, x11
	b.lo	.LBB11_6
	add	x10, sp, #24
	add	x11, sp, #32
	b	.LBB11_15
.LBB11_9:
	cbz	x28, .LBB11_11
	mov	w2, #8
	mov	x0, x24
	mov	x1, x23
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
	mov	w2, #8
	mov	x0, x27
	mov	x1, x23
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB11_11:
	ldr	x8, [x19, #16]
	ldr	q1, [x21]
	ldr	q0, [x19]
	str	x8, [sp, #48]
	ldr	x8, [x21, #16]
	stur	q1, [sp, #56]
	str	x8, [sp, #72]
	ldp	q1, q2, [sp, #48]
	str	q2, [x20, #32]
	stp	q0, q1, [x20]
	b	.LBB11_23
.LBB11_12:
	mov	w24, #8
	ldp	x25, x22, [x21, #8]
	lsl	x26, x22, #3
	cbnz	x22, .LBB11_3
.LBB11_13:
	mov	w27, #8
	cmp	x22, x28
	b.eq	.LBB11_5
.LBB11_14:
	mov	w8, #2
	add	x10, sp, #16
	add	x11, sp, #24
	mov	x9, x22
	str	x8, [sp, #32]
	mov	x8, x28
.LBB11_15:
	str	x8, [x11]
	str	x9, [x10]
	cbz	x22, .LBB11_17
	mov	w2, #8
	mov	x0, x27
	mov	x1, x26
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB11_17:
	cbz	x28, .LBB11_19
	mov	w2, #8
	mov	x0, x24
	mov	x1, x23
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB11_19:
	ldp	x9, x8, [sp, #24]
	ldr	x10, [sp, #16]
	stp	x9, x10, [x20, #16]
	mov	x9, #-9223372036854775808
	stp	x9, x8, [x20]
	ldr	x8, [x21]
	cbz	x8, .LBB11_21
	lsl	x1, x8, #3
	mov	w2, #8
	mov	x0, x25
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB11_21:
	ldr	x8, [x19]
	cbz	x8, .LBB11_23
	ldr	x0, [sp, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 176
	ldp	x20, x19, [sp, #160]
	ldp	x22, x21, [sp, #144]
	ldp	x24, x23, [sp, #128]
	ldp	x26, x25, [sp, #112]
	ldp	x28, x27, [sp, #96]
	ldp	x29, x30, [sp, #80]
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB11_23:
	.cfi_restore_state
	.cfi_remember_state
	.cfi_def_cfa wsp, 176
	ldp	x20, x19, [sp, #160]
	ldp	x22, x21, [sp, #144]
	ldp	x24, x23, [sp, #128]
	ldp	x26, x25, [sp, #112]
	ldp	x28, x27, [sp, #96]
	ldp	x29, x30, [sp, #80]
	add	sp, sp, #176
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w21
	.cfi_restore w22
	.cfi_restore w23
	.cfi_restore w24
	.cfi_restore w25
	.cfi_restore w26
	.cfi_restore w27
	.cfi_restore w28
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB11_24:
	.cfi_restore_state
	mov	w0, #8
	mov	x1, x23
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.LBB11_25:
	mov	w0, #8
	mov	x1, x26
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.Lfunc_end11:
	.size	_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE, .Lfunc_end11-_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE
	.cfi_endproc

	.section	".text._ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE","ax",@progbits
	.p2align	4
	.type	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE,@function
_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, .LBB12_3
	tbnz	w8, #26, .LBB12_4
	b	_RNvXsd_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impyNtB9_7Display3fmt
.LBB12_3:
	b	_RNvXsC_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8LowerHex3fmt
.LBB12_4:
	b	_RNvXsE_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8UpperHex3fmt
.Lfunc_end12:
	.size	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE, .Lfunc_end12-_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE
	.cfi_endproc

	.section	".text._ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E","ax",@progbits
	.p2align	4
	.type	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E,@function
_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E:
	.cfi_startproc
	ldr	x0, [x0]
	ldr	w8, [x1, #16]
	tbnz	w8, #25, .LBB13_3
	tbnz	w8, #26, .LBB13_4
	b	_RNvXsi_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impjNtB9_7Display3fmt
.LBB13_3:
	b	_RNvXs6_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8LowerHex3fmt
.LBB13_4:
	b	_RNvXs8_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8UpperHex3fmt
.Lfunc_end13:
	.size	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E, .Lfunc_end13-_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E
	.cfi_endproc

	.section	".text._ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E","ax",@progbits
	.p2align	4
	.type	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E,@function
_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	.cfi_remember_state
	ldr	x9, [x0]
	adrp	x11, .LJTI14_0
	add	x11, x11, :lo12:.LJTI14_0
	mov	x8, x1
	ldr	x10, [x9]
	adr	x12, .LBB14_1
	ldrb	w13, [x11, x10]
	add	x12, x12, x13, lsl #2
	br	x12
.LBB14_1:
	adrp	x1, .Lalloc_5ee3dd04a3ebbd2958f69478a791f011
	add	x1, x1, :lo12:.Lalloc_5ee3dd04a3ebbd2958f69478a791f011
	mov	x0, x8
	mov	w2, #11
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_2:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_49160125fb4cd837bc8bd9b6ec63004a
	add	x1, x1, :lo12:.Lalloc_49160125fb4cd837bc8bd9b6ec63004a
	mov	x0, x8
	mov	w2, #14
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_3:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_99be15a9e516526f280317bea0cca5d0
	add	x1, x1, :lo12:.Lalloc_99be15a9e516526f280317bea0cca5d0
	mov	x0, x8
	mov	w2, #17
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_4:
	.cfi_restore_state
	.cfi_remember_state
	add	x10, x9, #16
	sub	x11, x29, #8
	mov	w12, #6
	adrp	x1, .Lalloc_ee08c9d314e4c5b701504a1a6f89727d
	add	x1, x1, :lo12:.Lalloc_ee08c9d314e4c5b701504a1a6f89727d
	mov	x0, x8
	stur	x10, [x29, #-8]
	adrp	x10, .Lvtable.1
	add	x10, x10, :lo12:.Lvtable.1
	adrp	x3, .Lalloc_adba73bbb963ea705e05d8e8c86355c2
	add	x3, x3, :lo12:.Lalloc_adba73bbb963ea705e05d8e8c86355c2
	stp	x12, x11, [sp]
	str	x10, [sp, #16]
	adrp	x6, .Lvtable.0
	add	x6, x6, :lo12:.Lvtable.0
	adrp	x7, .Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf
	add	x7, x7, :lo12:.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf
	add	x5, x9, #8
	mov	w2, #19
	mov	w4, #6
	bl	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB14_5:
	.cfi_restore_state
	.cfi_remember_state
	add	x10, x9, #16
	sub	x11, x29, #8
	mov	w12, #10
	adrp	x1, .Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2
	add	x1, x1, :lo12:.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2
	mov	x0, x8
	stur	x10, [x29, #-8]
	adrp	x10, .Lvtable.3
	add	x10, x10, :lo12:.Lvtable.3
	stp	x12, x11, [sp]
	adrp	x3, .Lalloc_58c73da900326cd1d22dde7834877fb1
	add	x3, x3, :lo12:.Lalloc_58c73da900326cd1d22dde7834877fb1
	str	x10, [sp, #16]
	adrp	x6, .Lvtable.2
	add	x6, x6, :lo12:.Lvtable.2
	adrp	x7, .Lalloc_86933f980174c2bccf56810e0d831ebb
	add	x7, x7, :lo12:.Lalloc_86933f980174c2bccf56810e0d831ebb
	add	x5, x9, #8
	mov	w2, #21
	mov	w4, #8
	bl	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter26debug_struct_field2_finish
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB14_6:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_f672c6af06448a01ecac398fe971f727
	add	x1, x1, :lo12:.Lalloc_f672c6af06448a01ecac398fe971f727
	mov	x0, x8
	mov	w2, #15
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_7:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_52433ae1027e4929c7c1de5d6490f243
	add	x1, x1, :lo12:.Lalloc_52433ae1027e4929c7c1de5d6490f243
	mov	x0, x8
	mov	w2, #19
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_8:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_99f3a809f00b524a3a34761496eda872
	add	x1, x1, :lo12:.Lalloc_99f3a809f00b524a3a34761496eda872
	mov	x0, x8
	mov	w2, #12
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_9:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_937ef498e46ce3dd2899f48f05d77c47
	add	x1, x1, :lo12:.Lalloc_937ef498e46ce3dd2899f48f05d77c47
	mov	x0, x8
	mov	w2, #18
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_10:
	.cfi_restore_state
	.cfi_remember_state
	adrp	x1, .Lalloc_4d26e1d2bef2fb4016390b651f78947e
	add	x1, x1, :lo12:.Lalloc_4d26e1d2bef2fb4016390b651f78947e
	mov	x0, x8
	mov	w2, #20
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.LBB14_11:
	.cfi_restore_state
	adrp	x1, .Lalloc_ce01d5de1e0bacc55ae5953b06653b2d
	add	x1, x1, :lo12:.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d
	mov	x0, x8
	mov	w2, #14
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str
.Lfunc_end14:
	.size	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E, .Lfunc_end14-_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E
	.cfi_endproc
	.section	".rodata._ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E","a",@progbits
.LJTI14_0:
	.byte	(.LBB14_1-.LBB14_1)>>2
	.byte	(.LBB14_7-.LBB14_1)>>2
	.byte	(.LBB14_4-.LBB14_1)>>2
	.byte	(.LBB14_5-.LBB14_1)>>2
	.byte	(.LBB14_2-.LBB14_1)>>2
	.byte	(.LBB14_8-.LBB14_1)>>2
	.byte	(.LBB14_9-.LBB14_1)>>2
	.byte	(.LBB14_6-.LBB14_1)>>2
	.byte	(.LBB14_11-.LBB14_1)>>2
	.byte	(.LBB14_3-.LBB14_1)>>2
	.byte	(.LBB14_10-.LBB14_1)>>2

	.section	".text._ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E","ax",@progbits
	.p2align	4
	.type	_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E,@function
_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E:
	.cfi_startproc
	stp	x29, x30, [sp, #-32]!
	.cfi_def_cfa_offset 32
	str	x19, [sp, #16]
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	ldr	x8, [x0]
	mov	x19, x0
	cbz	x8, .LBB15_2
	ldr	x0, [x19, #8]
	lsl	x1, x8, #3
	mov	w2, #8
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB15_2:
	ldr	x8, [x19, #24]
	cbz	x8, .LBB15_4
	ldr	x0, [x19, #32]
	lsl	x1, x8, #3
	mov	w2, #8
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]
	ldp	x29, x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	b	_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc
.LBB15_4:
	.cfi_restore_state
	.cfi_def_cfa wsp, 32
	ldr	x19, [sp, #16]
	ldp	x29, x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end15:
	.size	_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E, .Lfunc_end15-_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E
	.cfi_endproc

	.section	".text.unlikely._ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE","ax",@progbits
	.p2align	4
	.type	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE,@function
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE:
	.cfi_startproc
	stp	x29, x30, [sp, #-32]!
	.cfi_def_cfa_offset 32
	stp	x20, x19, [sp, #16]
	mov	x29, sp
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	mov	w8, #1
	mov	w9, #8
	lsr	x11, x3, #61
	mov	x19, x0
	mov	x10, xzr
	cbnz	x11, .LBB16_10
	lsl	x20, x3, #3
	mov	x11, #9223372036854775800
	cmp	x20, x11
	b.hi	.LBB16_10
	cbz	x1, .LBB16_4
	lsl	x1, x1, #3
	mov	x0, x2
	mov	w2, #8
	mov	x3, x20
	bl	_RNvCsfLfy6EI15iL_7___rustc14___rust_realloc
	cbnz	x0, .LBB16_8
	b	.LBB16_6
.LBB16_4:
	cbz	x20, .LBB16_7
	bl	_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	mov	w1, #8
	mov	x0, x20
	bl	_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc
	cbnz	x0, .LBB16_8
.LBB16_6:
	mov	w8, #8
	str	x8, [x19, #8]
	mov	w8, #1
	b	.LBB16_9
.LBB16_7:
	mov	w0, #8
.LBB16_8:
	mov	x8, xzr
	str	x0, [x19, #8]
.LBB16_9:
	mov	w9, #16
	mov	x10, x20
.LBB16_10:
	str	x10, [x19, x9]
	str	x8, [x19]
	.cfi_def_cfa wsp, 32
	ldp	x20, x19, [sp, #16]
	ldp	x29, x30, [sp], #32
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end16:
	.size	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE, .Lfunc_end16-_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE
	.cfi_endproc

	.section	".text.unlikely._ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE","ax",@progbits
	.p2align	4
	.type	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE,@function
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE:
	.cfi_startproc
	sub	sp, sp, #64
	.cfi_def_cfa_offset 64
	stp	x29, x30, [sp, #32]
	stp	x20, x19, [sp, #48]
	add	x29, sp, #32
	.cfi_def_cfa w29, 32
	.cfi_offset w19, -8
	.cfi_offset w20, -16
	.cfi_offset w30, -24
	.cfi_offset w29, -32
	.cfi_remember_state
	adds	x8, x2, x1
	b.hs	.LBB17_3
	ldp	x1, x2, [x0]
	mov	x19, x0
	add	x0, sp, #8
	lsl	x9, x1, #1
	cmp	x8, x1, lsl #1
	csel	x8, x8, x9, hi
	mov	w9, #4
	cmp	x8, #4
	csel	x20, x8, x9, hi
	mov	x3, x20
	bl	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE
	ldr	x8, [sp, #8]
	cmp	x8, #1
	b.eq	.LBB17_4
	ldr	x8, [sp, #16]
	stp	x20, x8, [x19]
	.cfi_def_cfa wsp, 64
	ldp	x20, x19, [sp, #48]
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #64
	.cfi_def_cfa_offset 0
	.cfi_restore w19
	.cfi_restore w20
	.cfi_restore w30
	.cfi_restore w29
	ret
.LBB17_3:
	.cfi_restore_state
	mov	x0, xzr
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.LBB17_4:
	ldp	x0, x1, [sp, #16]
	bl	_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error
.Lfunc_end17:
	.size	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE, .Lfunc_end17-_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE
	.cfi_endproc

	.section	".text._ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE","ax",@progbits
	.globl	_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE
	.p2align	4
	.type	_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE,@function
_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE:
	.cfi_startproc
	sub	sp, sp, #48
	.cfi_def_cfa_offset 48
	stp	x29, x30, [sp, #32]
	add	x29, sp, #32
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	add	x8, sp, #8
	adrp	x9, _ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E
	add	x9, x9, :lo12:_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E
	adrp	x2, .Lalloc_0c812808379efded5a4fb82d2790b556
	add	x2, x2, :lo12:.Lalloc_0c812808379efded5a4fb82d2790b556
	stp	x0, x8, [sp, #8]
	add	x3, sp, #16
	ldp	x0, x1, [x1]
	str	x9, [sp, #24]
	bl	_RNvNtCs6Hz1PecaLG4_4core3fmt5write
	.cfi_def_cfa wsp, 48
	ldp	x29, x30, [sp, #32]
	add	sp, sp, #48
	.cfi_def_cfa_offset 0
	.cfi_restore w30
	.cfi_restore w29
	ret
.Lfunc_end18:
	.size	_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE, .Lfunc_end18-_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE
	.cfi_endproc

	.section	.text.topic44_checked_merge_four,"ax",@progbits
	.globl	topic44_checked_merge_four
	.p2align	4
	.type	topic44_checked_merge_four,@function
topic44_checked_merge_four:
	.cfi_startproc
	ldr	x8, [x0]
	ldr	x9, [x1]
	adds	x8, x9, x8
	b.hs	.LBB19_5
	ldr	x9, [x0, #8]
	ldr	x10, [x1, #8]
	adds	x9, x10, x9
	b.hs	.LBB19_5
	ldr	x10, [x0, #16]
	ldr	x11, [x1, #16]
	adds	x10, x11, x10
	b.hs	.LBB19_5
	ldr	x11, [x0, #24]
	ldr	x12, [x1, #24]
	adds	x11, x12, x11
	b.hs	.LBB19_5
	stp	x8, x9, [x0]
	mov	w8, #1
	stp	x10, x11, [x0, #16]
	mov	w0, w8
	ret
.LBB19_5:
	mov	w0, wzr
	ret
.Lfunc_end19:
	.size	topic44_checked_merge_four, .Lfunc_end19-topic44_checked_merge_four
	.cfi_endproc

	.type	.Lalloc_4ed059f71d51ae16bc6826f989989385,@object
	.section	.rodata..Lalloc_4ed059f71d51ae16bc6826f989989385,"a",@progbits
.Lalloc_4ed059f71d51ae16bc6826f989989385:
	.ascii	"a validated schema is nonempty"
	.size	.Lalloc_4ed059f71d51ae16bc6826f989989385, 30

	.type	.Lalloc_5b145d9140118075524495df4810a119,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lalloc_5b145d9140118075524495df4810a119:
	.asciz	"/tmp/topic44-output-scoped-b8d0c8b-r1/.work/source/systems-snackpack-b8d0c8b06bd29dab090d40f18aa6aa086b5fdf76/topics/044-tail-latency-histogram-merge-errors/src/lib.rs"
	.size	.Lalloc_5b145d9140118075524495df4810a119, 168

	.type	.Lalloc_72e1b02f1dc44543daa9de23d3bba29e,@object
	.section	.data.rel.ro..Lalloc_72e1b02f1dc44543daa9de23d3bba29e,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_72e1b02f1dc44543daa9de23d3bba29e:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000?\000\000\000\026\000\000"
	.size	.Lalloc_72e1b02f1dc44543daa9de23d3bba29e, 24

	.type	.Lalloc_9034bc150239ddb23220298f62c78c3d,@object
	.section	.data.rel.ro..Lalloc_9034bc150239ddb23220298f62c78c3d,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_9034bc150239ddb23220298f62c78c3d:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\353\000\000\000D\000\000"
	.size	.Lalloc_9034bc150239ddb23220298f62c78c3d, 24

	.type	.Lalloc_713e1b0d46806bc8c2cd07e9f5848152,@object
	.section	.data.rel.ro..Lalloc_713e1b0d46806bc8c2cd07e9f5848152,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_713e1b0d46806bc8c2cd07e9f5848152:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\354\000\000\000D\000\000"
	.size	.Lalloc_713e1b0d46806bc8c2cd07e9f5848152, 24

	.type	.Lalloc_96d0d7cd51bf3727855c17e0e20001f5,@object
	.section	.data.rel.ro..Lalloc_96d0d7cd51bf3727855c17e0e20001f5,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_96d0d7cd51bf3727855c17e0e20001f5:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\205\000\000\000)\000\000"
	.size	.Lalloc_96d0d7cd51bf3727855c17e0e20001f5, 24

	.type	.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd,@object
	.section	.data.rel.ro..Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\r\001\000\000;\000\000"
	.size	.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd, 24

	.type	.Lalloc_4583e6a49f6781f6842cac8cdb2523af,@object
	.section	.data.rel.ro..Lalloc_4583e6a49f6781f6842cac8cdb2523af,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_4583e6a49f6781f6842cac8cdb2523af:
	.xword	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\022\001\000\0008\000\000"
	.size	.Lalloc_4583e6a49f6781f6842cac8cdb2523af, 24

	.type	.Lalloc_5ee3dd04a3ebbd2958f69478a791f011,@object
	.section	.rodata..Lalloc_5ee3dd04a3ebbd2958f69478a791f011,"a",@progbits
.Lalloc_5ee3dd04a3ebbd2958f69478a791f011:
	.ascii	"EmptySchema"
	.size	.Lalloc_5ee3dd04a3ebbd2958f69478a791f011, 11

	.type	.Lalloc_52433ae1027e4929c7c1de5d6490f243,@object
	.section	.rodata..Lalloc_52433ae1027e4929c7c1de5d6490f243,"a",@progbits
.Lalloc_52433ae1027e4929c7c1de5d6490f243:
	.ascii	"NonIncreasingBounds"
	.size	.Lalloc_52433ae1027e4929c7c1de5d6490f243, 19

	.type	.Lvtable.0,@object
	.section	.data.rel.ro..Lvtable.0,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt
	.size	.Lvtable.0, 32

	.type	.Lvtable.1,@object
	.section	.data.rel.ro..Lvtable.1,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E
	.size	.Lvtable.1, 32

	.type	.Lalloc_ee08c9d314e4c5b701504a1a6f89727d,@object
	.section	.rodata..Lalloc_ee08c9d314e4c5b701504a1a6f89727d,"a",@progbits
.Lalloc_ee08c9d314e4c5b701504a1a6f89727d:
	.ascii	"BucketCountMismatch"
	.size	.Lalloc_ee08c9d314e4c5b701504a1a6f89727d, 19

	.type	.Lalloc_adba73bbb963ea705e05d8e8c86355c2,@object
	.section	.rodata..Lalloc_adba73bbb963ea705e05d8e8c86355c2,"a",@progbits
.Lalloc_adba73bbb963ea705e05d8e8c86355c2:
	.ascii	"bounds"
	.size	.Lalloc_adba73bbb963ea705e05d8e8c86355c2, 6

	.type	.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf,@object
	.section	.rodata..Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf,"a",@progbits
.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf:
	.ascii	"counts"
	.size	.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf, 6

	.type	.Lvtable.2,@object
	.section	.data.rel.ro..Lvtable.2,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt
	.size	.Lvtable.2, 32

	.type	.Lvtable.3,@object
	.section	.data.rel.ro..Lvtable.3,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.3:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.xword	_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE
	.size	.Lvtable.3, 32

	.type	.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2,@object
	.section	.rodata..Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2,"a",@progbits
.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2:
	.ascii	"ObservationOutOfRange"
	.size	.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2, 21

	.type	.Lalloc_58c73da900326cd1d22dde7834877fb1,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lalloc_58c73da900326cd1d22dde7834877fb1:
	.ascii	"value_us"
	.size	.Lalloc_58c73da900326cd1d22dde7834877fb1, 8

	.type	.Lalloc_86933f980174c2bccf56810e0d831ebb,@object
	.section	.rodata..Lalloc_86933f980174c2bccf56810e0d831ebb,"a",@progbits
.Lalloc_86933f980174c2bccf56810e0d831ebb:
	.ascii	"maximum_us"
	.size	.Lalloc_86933f980174c2bccf56810e0d831ebb, 10

	.type	.Lalloc_49160125fb4cd837bc8bd9b6ec63004a,@object
	.section	.rodata..Lalloc_49160125fb4cd837bc8bd9b6ec63004a,"a",@progbits
.Lalloc_49160125fb4cd837bc8bd9b6ec63004a:
	.ascii	"SchemaMismatch"
	.size	.Lalloc_49160125fb4cd837bc8bd9b6ec63004a, 14

	.type	.Lalloc_99f3a809f00b524a3a34761496eda872,@object
	.section	.rodata..Lalloc_99f3a809f00b524a3a34761496eda872,"a",@progbits
.Lalloc_99f3a809f00b524a3a34761496eda872:
	.ascii	"CounterReset"
	.size	.Lalloc_99f3a809f00b524a3a34761496eda872, 12

	.type	.Lalloc_937ef498e46ce3dd2899f48f05d77c47,@object
	.section	.rodata..Lalloc_937ef498e46ce3dd2899f48f05d77c47,"a",@progbits
.Lalloc_937ef498e46ce3dd2899f48f05d77c47:
	.ascii	"ArithmeticOverflow"
	.size	.Lalloc_937ef498e46ce3dd2899f48f05d77c47, 18

	.type	.Lalloc_f672c6af06448a01ecac398fe971f727,@object
	.section	.rodata..Lalloc_f672c6af06448a01ecac398fe971f727,"a",@progbits
.Lalloc_f672c6af06448a01ecac398fe971f727:
	.ascii	"InvalidQuantile"
	.size	.Lalloc_f672c6af06448a01ecac398fe971f727, 15

	.type	.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d,@object
	.section	.rodata..Lalloc_ce01d5de1e0bacc55ae5953b06653b2d,"a",@progbits
.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d:
	.ascii	"EmptyHistogram"
	.size	.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d, 14

	.type	.Lalloc_99be15a9e516526f280317bea0cca5d0,@object
	.section	.rodata..Lalloc_99be15a9e516526f280317bea0cca5d0,"a",@progbits
.Lalloc_99be15a9e516526f280317bea0cca5d0:
	.ascii	"InvalidCoarsening"
	.size	.Lalloc_99be15a9e516526f280317bea0cca5d0, 17

	.type	.Lalloc_4d26e1d2bef2fb4016390b651f78947e,@object
	.section	.rodata..Lalloc_4d26e1d2bef2fb4016390b651f78947e,"a",@progbits
.Lalloc_4d26e1d2bef2fb4016390b651f78947e:
	.ascii	"CountInvariantBroken"
	.size	.Lalloc_4d26e1d2bef2fb4016390b651f78947e, 20

	.type	.Lalloc_0c812808379efded5a4fb82d2790b556,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lalloc_0c812808379efded5a4fb82d2790b556:
	.asciz	"\300"
	.size	.Lalloc_0c812808379efded5a4fb82d2790b556, 2

	.ident	"rustc version 1.95.0 (59807616e 2026-04-14)"
	.section	".note.GNU-stack","",@progbits
