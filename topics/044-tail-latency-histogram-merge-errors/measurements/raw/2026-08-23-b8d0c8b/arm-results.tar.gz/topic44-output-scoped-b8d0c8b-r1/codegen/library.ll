; ModuleID = 'histogram_merge_errors.367e9e928f27f9e4-cgu.0'
source_filename = "histogram_merge_errors.367e9e928f27f9e4-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i8:8:32-i16:16:32-i64:64-i128:128-n32:64-S128-Fn32"
target triple = "aarch64-unknown-linux-gnu"

@alloc_4ed059f71d51ae16bc6826f989989385 = private unnamed_addr constant [30 x i8] c"a validated schema is nonempty", align 1
@alloc_5b145d9140118075524495df4810a119 = private unnamed_addr constant [168 x i8] c"/tmp/topic44-output-scoped-b8d0c8b-r1/.work/source/systems-snackpack-b8d0c8b06bd29dab090d40f18aa6aa086b5fdf76/topics/044-tail-latency-histogram-merge-errors/src/lib.rs\00", align 1
@alloc_72e1b02f1dc44543daa9de23d3bba29e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00?\00\00\00\16\00\00\00" }>, align 8
@alloc_9034bc150239ddb23220298f62c78c3d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\EB\00\00\00D\00\00\00" }>, align 8
@alloc_713e1b0d46806bc8c2cd07e9f5848152 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\EC\00\00\00D\00\00\00" }>, align 8
@alloc_96d0d7cd51bf3727855c17e0e20001f5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\85\00\00\00)\00\00\00" }>, align 8
@alloc_4902ffe043ff59a1d70cb2012e4b3cfd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\0D\01\00\00;\00\00\00" }>, align 8
@alloc_4583e6a49f6781f6842cac8cdb2523af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\12\01\00\008\00\00\00" }>, align 8
@alloc_5ee3dd04a3ebbd2958f69478a791f011 = private unnamed_addr constant [11 x i8] c"EmptySchema", align 1
@alloc_52433ae1027e4929c7c1de5d6490f243 = private unnamed_addr constant [19 x i8] c"NonIncreasingBounds", align 1
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt }>, align 8
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E" }>, align 8
@alloc_ee08c9d314e4c5b701504a1a6f89727d = private unnamed_addr constant [19 x i8] c"BucketCountMismatch", align 1
@alloc_adba73bbb963ea705e05d8e8c86355c2 = private unnamed_addr constant [6 x i8] c"bounds", align 1
@alloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf = private unnamed_addr constant [6 x i8] c"counts", align 1
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt }>, align 8
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE" }>, align 8
@alloc_fc4accf12cdb5d5f3207e98a294cf4c2 = private unnamed_addr constant [21 x i8] c"ObservationOutOfRange", align 1
@alloc_58c73da900326cd1d22dde7834877fb1 = private unnamed_addr constant [8 x i8] c"value_us", align 1
@alloc_86933f980174c2bccf56810e0d831ebb = private unnamed_addr constant [10 x i8] c"maximum_us", align 1
@alloc_49160125fb4cd837bc8bd9b6ec63004a = private unnamed_addr constant [14 x i8] c"SchemaMismatch", align 1
@alloc_99f3a809f00b524a3a34761496eda872 = private unnamed_addr constant [12 x i8] c"CounterReset", align 1
@alloc_937ef498e46ce3dd2899f48f05d77c47 = private unnamed_addr constant [18 x i8] c"ArithmeticOverflow", align 1
@alloc_f672c6af06448a01ecac398fe971f727 = private unnamed_addr constant [15 x i8] c"InvalidQuantile", align 1
@alloc_ce01d5de1e0bacc55ae5953b06653b2d = private unnamed_addr constant [14 x i8] c"EmptyHistogram", align 1
@alloc_99be15a9e516526f280317bea0cca5d0 = private unnamed_addr constant [17 x i8] c"InvalidCoarsening", align 1
@alloc_4d26e1d2bef2fb4016390b651f78947e = private unnamed_addr constant [20 x i8] c"CountInvariantBroken", align 1
@alloc_0c812808379efded5a4fb82d2790b556 = private unnamed_addr constant [2 x i8] c"\C0\00", align 1

; <u64 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nounwind uwtable
define internal noundef zeroext i1 @_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !2
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsC_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb4:                                              ; preds = %bb2
; call <u64 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsd_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb3:                                              ; preds = %bb2
; call <u64 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsE_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; <usize as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nounwind uwtable
define internal noundef zeroext i1 @_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !2
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb4:                                              ; preds = %bb2
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb3:                                              ; preds = %bb2
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; histogram_merge_errors::BucketSchema::new
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors12BucketSchema3new17h8064ab0e990e3f80E(ptr dead_on_unwind noalias noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %upper_bounds_us) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 16
  %_10 = load i64, ptr %0, align 8, !noundef !2
  %_11 = icmp ult i64 %_10, 1152921504606846976
  tail call void @llvm.assume(i1 %_11)
  %1 = icmp eq i64 %_10, 0
  br i1 %1, label %bb5, label %bb2

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 8
  %_15 = load ptr, ptr %2, align 8, !nonnull !2, !noundef !2
  br label %bb1.us.i

bb1.us.i:                                         ; preds = %bb2, %bb3.us.i
  %_28.i6.us.i = phi ptr [ %_28.i.us.i, %bb3.us.i ], [ %_15, %bb2 ]
  %new_len.i5.us.i = phi i64 [ %new_len.i.us.i, %bb3.us.i ], [ %_10, %bb2 ]
  %_2.i.us.not.not.i = icmp ult i64 %new_len.i5.us.i, 2
  br i1 %_2.i.us.not.not.i, label %bb4, label %bb3.us.i

bb3.us.i:                                         ; preds = %bb1.us.i
  %new_len.i.us.i = add nsw i64 %new_len.i5.us.i, -1
  %_28.i.us.i = getelementptr inbounds nuw i8, ptr %_28.i6.us.i, i64 8
  %_3.i.i.us.i = load i64, ptr %_28.i6.us.i, align 8, !alias.scope !3, !noalias !8, !noundef !2
  %_6.i.i.us.i = load i64, ptr %_28.i.us.i, align 8, !alias.scope !3, !noalias !8, !noundef !2
  %_0.i.i.not.us.i = icmp ult i64 %_3.i.i.us.i, %_6.i.i.us.i
  br i1 %_0.i.i.not.us.i, label %bb1.us.i, label %bb5

bb5:                                              ; preds = %bb3.us.i, %start
  %.sink = phi i64 [ 0, %start ], [ 1, %bb3.us.i ]
  %3 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %.sink, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  %upper_bounds_us.val = load i64, ptr %upper_bounds_us, align 8, !range !11, !noundef !2
  %4 = icmp eq i64 %upper_bounds_us.val, 0
  br i1 %4, label %bb6, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb5
  %5 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 8
  %upper_bounds_us.val1 = load ptr, ptr %5, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i = shl nuw i64 %upper_bounds_us.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %upper_bounds_us.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb6

bb4:                                              ; preds = %bb1.us.i
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %6, ptr noundef nonnull align 8 dereferenceable(24) %upper_bounds_us, i64 24, i1 false)
  store i64 0, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i, %bb5, %bb4
  ret void
}

; histogram_merge_errors::IntervalHistogram::from_counts
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %counts) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %_15 = alloca [48 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %counts, i64 16
  %_4 = load i64, ptr %0, align 8, !noundef !2
  %_18 = icmp ult i64 %_4, 1152921504606846976
  tail call void @llvm.assume(i1 %_18)
  %1 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %_5 = load i64, ptr %1, align 8, !noundef !2
  %_19 = icmp ult i64 %_5, 1152921504606846976
  tail call void @llvm.assume(i1 %_19)
  %_3.not = icmp eq i64 %_4, %_5
  br i1 %_3.not, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %counts, i64 8
  %_25 = load ptr, ptr %2, align 8, !nonnull !2, !noundef !2
  %_29 = getelementptr inbounds nuw i64, ptr %_25, i64 %_4
  br label %bb1.i

bb1.i:                                            ; preds = %bb3.i, %bb2
  %_16.i24.i = phi ptr [ %_25, %bb2 ], [ %_16.i.i, %bb3.i ]
  %_9.sroa.5.0.i = phi i64 [ undef, %bb2 ], [ %_8.0.i.i, %bb3.i ]
  %accum.sroa.0.0.i = phi i64 [ 0, %bb2 ], [ %_8.0.i.i, %bb3.i ]
  %_6.i.i = icmp eq ptr %_16.i24.i, %_29
  br i1 %_6.i.i, label %bb9, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_16.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i, i64 8
  %.val.i = load i64, ptr %_16.i24.i, align 8, !noalias !12, !noundef !2
  %_8.0.i.i = add i64 %.val.i, %accum.sroa.0.0.i
  %_8.1.i.i = icmp ult i64 %_8.0.i.i, %accum.sroa.0.0.i
  br i1 %_8.1.i.i, label %bb5, label %bb1.i, !prof !16

bb1:                                              ; preds = %start
  %3 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 2, ptr %3, align 8
  br label %bb5

bb9:                                              ; preds = %bb1.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_15)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_15, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %4 = getelementptr inbounds nuw i8, ptr %_15, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %4, ptr noundef nonnull align 8 dereferenceable(24) %counts, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %_15, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_15)
  br label %bb7

bb7:                                              ; preds = %bb2.i.i.i.i.i, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", %bb9
  ret void

bb5:                                              ; preds = %bb3.i, %bb1
  %.sink14 = phi i64 [ 16, %bb1 ], [ 8, %bb3.i ]
  %_5.sink = phi i64 [ %_5, %bb1 ], [ 6, %bb3.i ]
  %.sink = phi i64 [ 24, %bb1 ], [ 16, %bb3.i ]
  %_4.sink = phi i64 [ %_4, %bb1 ], [ %_9.sroa.5.0.i, %bb3.i ]
  %_6.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink14
  store i64 %_5.sink, ptr %_6.sroa.4.0..sroa_idx, align 8
  %_6.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink
  store i64 %_4.sink, ptr %_6.sroa.5.0..sroa_idx, align 8
  store i64 -9223372036854775808, ptr %_0, align 8
  %counts.val = load i64, ptr %counts, align 8, !range !11, !noundef !2
  %5 = icmp eq i64 %counts.val, 0
  br i1 %5, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb5
  %6 = getelementptr inbounds nuw i8, ptr %counts, i64 8
  %counts.val5 = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i = shl nuw i64 %counts.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %counts.val5, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit": ; preds = %bb5, %bb2.i.i.i.i
  %schema.val = load i64, ptr %schema, align 8, !range !11, !noundef !2
  %7 = icmp eq i64 %schema.val, 0
  br i1 %7, label %bb7, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"
  %8 = getelementptr inbounds nuw i8, ptr %schema, i64 8
  %schema.val6 = load ptr, ptr %8, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %schema.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %schema.val6, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb7
}

; histogram_merge_errors::IntervalHistogram::total_count
; Function Attrs: nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_7 = load ptr, ptr %0, align 8, !nonnull !2, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_6 = load i64, ptr %1, align 8, !noundef !2
  %_11 = getelementptr inbounds nuw i64, ptr %_7, i64 %_6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !17)
  br label %bb1.i

bb1.i:                                            ; preds = %bb3.i, %start
  %_16.i24.i = phi ptr [ %_7, %start ], [ %_16.i.i, %bb3.i ]
  %_9.sroa.5.0.i = phi i64 [ undef, %start ], [ %_8.0.i.i, %bb3.i ]
  %accum.sroa.0.0.i = phi i64 [ 0, %start ], [ %_8.0.i.i, %bb3.i ]
  %_6.i.i = icmp eq ptr %_16.i24.i, %_11
  br i1 %_6.i.i, label %bb10.i, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_16.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i, i64 8
  %.val.i = load i64, ptr %_16.i24.i, align 8, !noalias !20, !noundef !2
  %_8.0.i.i = add i64 %.val.i, %accum.sroa.0.0.i
  %_8.1.i.i = icmp ult i64 %_8.0.i.i, %accum.sroa.0.0.i
  br i1 %_8.1.i.i, label %bb8.i, label %bb1.i, !prof !16

bb10.i:                                           ; preds = %bb1.i
  %2 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %accum.sroa.0.0.i, ptr %2, align 8, !alias.scope !22, !noalias !25
  store i64 11, ptr %_0, align 8, !alias.scope !22, !noalias !25
  br label %_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE.exit

bb8.i:                                            ; preds = %bb3.i
  store i64 6, ptr %_0, align 8, !alias.scope !26, !noalias !25
  %residual.sroa.2.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_9.sroa.5.0.i, ptr %residual.sroa.2.0._0.sroa_idx.i, align 8, !alias.scope !26, !noalias !25
  br label %_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE.exit

_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE.exit: ; preds = %bb10.i, %bb8.i
  ret void
}

; histogram_merge_errors::IntervalHistogram::merge_compatible
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram16merge_compatible17h761d5f50c87cea72E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %other) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %vector.i.i.i.i.i = alloca [24 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_14 = load i64, ptr %0, align 8, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_16 = load i64, ptr %1, align 8, !noundef !2
  %_18 = icmp eq i64 %_14, %_16
  br i1 %_18, label %bb7, label %bb1

bb7:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_17 = load ptr, ptr %2, align 8, !nonnull !2, !noundef !2
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_15 = load ptr, ptr %3, align 8, !nonnull !2, !noundef !2
  %_19 = shl nuw i64 %_14, 3
  %bcmp = tail call i32 @bcmp(ptr nonnull %_15, ptr nonnull %_17, i64 %_19)
  %_13.not = icmp eq i32 %bcmp, 0
  br i1 %_13.not, label %bb2, label %bb1

bb1:                                              ; preds = %start, %bb7
  store i64 4, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_26 = load ptr, ptr %4, align 8, !nonnull !2, !noundef !2
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_25 = load i64, ptr %5, align 8, !noundef !2
  %6 = getelementptr inbounds nuw i8, ptr %other, i64 32
  %_10.val = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %7 = getelementptr inbounds nuw i8, ptr %other, i64 40
  %_10.val2 = load i64, ptr %7, align 8, !noundef !2
  %..i.i.i = tail call noundef i64 @llvm.umin.i64(i64 %_10.val2, i64 %_25)
  call void @llvm.lifetime.start.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !30
  %_2.i.i.i.i.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 0
  br i1 %_2.i.i.i.i.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2
  %.val.i.i.i.i.i.i.i.i.i = load i64, ptr %_26, align 8, !noalias !46, !noundef !2
  %.val3.i.i.i.i.i.i.i.i.i = load i64, ptr %_10.val, align 8, !noalias !46, !noundef !2
  %_10.0.i.i.i.i.i.i.i.i.i.i.i = add i64 %.val3.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i
  %_10.1.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i
  br i1 %_10.1.i.i.i.i.i.i.i.i.i.i.i, label %bb4.thread.i, label %bb3.i.i.i.i.i.i.i, !prof !16

bb4.thread.i:                                     ; preds = %bb3.i.i.i.i.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !30
  br label %bb11

bb3.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !56
; call __rustc::__rust_alloc
  %8 = tail call noundef align 8 dereferenceable_or_null(32) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) 32, i64 noundef 8) #19, !noalias !56
  %9 = icmp eq ptr %8, null
  br i1 %9, label %bb3.i.i.i.i.i.i, label %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i"

bb3.i.i.i.i.i.i:                                  ; preds = %bb3.i.i.i.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 32) #20, !noalias !30
  unreachable

"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i": ; preds = %bb3.i.i.i.i.i.i.i
  store i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i, ptr %8, align 8, !noalias !30
  store i64 4, ptr %vector.i.i.i.i.i, align 8, !noalias !30
  %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 8
  store ptr %8, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !30
  %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 16
  store i64 1, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !30
  tail call void @llvm.experimental.noalias.scope.decl(metadata !59)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !62)
  %_2.i.i.i.i.i.i6.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 1
  br i1 %_2.i.i.i.i.i.i6.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i.i.i:                        ; preds = %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i", %bb8.i.i.i.i.i.i.i
  %_23.i.i12.i.i.i.i.i = phi ptr [ %_23.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ %8, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %len.i.i.i.i.i.i.i = phi i64 [ %new_len.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ 1, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %new_len.i.i.i.i.i.i.i = add nuw nsw i64 %len.i.i.i.i.i.i.i, 1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_26, i64 %len.i.i.i.i.i.i.i
  %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_10.val, i64 %len.i.i.i.i.i.i.i
  %.val.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !65, !noundef !2
  %.val3.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !65, !noundef !2
  %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i = add i64 %.val3.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i.i.i
  %_10.1.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i.i.i
  br i1 %_10.1.i.i.i.i.i.i.i.i.i.i.i.i.i, label %bb4.i, label %bb3.i.i3.i.i.i.i.i, !prof !16

bb3.i.i3.i.i.i.i.i:                               ; preds = %bb3.i.i.i.i.i.i.i.i.i.i.i
  %_19.i.i.i.i.i.i.i = icmp samesign ult i64 %len.i.i.i.i.i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i.i.i.i.i.i.i)
  %self1.i.i.i.i.i.i.i = load i64, ptr %vector.i.i.i.i.i, align 8, !range !11, !alias.scope !77, !noalias !78, !noundef !2
  %_8.i.i4.i.i.i.i.i = icmp eq i64 %len.i.i.i.i.i.i.i, %self1.i.i.i.i.i.i.i
  br i1 %_8.i.i4.i.i.i.i.i, label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i", label %bb8.i.i.i.i.i.i.i

"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i": ; preds = %bb3.i.i3.i.i.i.i.i
; call alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle
  call fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE"(ptr noalias noundef nonnull align 8 dereferenceable(24) %vector.i.i.i.i.i, i64 noundef %len.i.i.i.i.i.i.i, i64 noundef 1) #19
  %_23.i.i.pre.i.i.i.i.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !77, !noalias !78
  br label %bb8.i.i.i.i.i.i.i

bb8.i.i.i.i.i.i.i:                                ; preds = %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i", %bb3.i.i3.i.i.i.i.i
  %_23.i.i.i.i.i.i.i = phi ptr [ %_23.i.i.pre.i.i.i.i.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i" ], [ %_23.i.i12.i.i.i.i.i, %bb3.i.i3.i.i.i.i.i ]
  %dst.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_23.i.i.i.i.i.i.i, i64 %len.i.i.i.i.i.i.i
  store i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, ptr %dst.i.i.i.i.i.i.i, align 8, !noalias !79
  store i64 %new_len.i.i.i.i.i.i.i, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !77, !noalias !78
  %exitcond.not.i.i.i.i.i.i.i = icmp eq i64 %new_len.i.i.i.i.i.i.i, %..i.i.i
  br i1 %exitcond.not.i.i.i.i.i.i.i, label %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E.exit.thread27.loopexit.i", label %bb3.i.i.i.i.i.i.i.i.i.i.i

"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E.exit.thread27.loopexit.i": ; preds = %bb8.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload230.pre.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !80
  %value.sroa.6.0.copyload331.pre.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !80
  br label %bb12

bb4.i:                                            ; preds = %bb3.i.i.i.i.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload2.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !80
  %value.sroa.6.0.copyload3.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !80
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !30
  %10 = icmp eq i64 %value.sroa.0.0.copyload2.i, 0
  br i1 %10, label %bb11, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb4.i
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %value.sroa.0.0.copyload2.i, 3
  %11 = icmp ne ptr %value.sroa.6.0.copyload3.i, null
  tail call void @llvm.assume(i1 %11)
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.0.copyload3.i, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !81
  br label %bb11

bb11:                                             ; preds = %bb4.thread.i, %bb4.i, %bb2.i.i.i.i.i
  %_6.sroa.12.0.ph = phi i64 [ %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %bb2.i.i.i.i.i ], [ %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %bb4.i ], [ %_10.0.i.i.i.i.i.i.i.i.i.i.i, %bb4.thread.i ]
  store i64 6, ptr %_0, align 8
  %_40.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_6.sroa.12.0.ph, ptr %_40.sroa.2.0._0.sroa_idx, align 8
  br label %bb6

bb12:                                             ; preds = %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E.exit.thread27.loopexit.i", %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i", %bb2
  %value.sroa.0.015.i = phi i64 [ 0, %bb2 ], [ %value.sroa.0.0.copyload230.pre.i, %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E.exit.thread27.loopexit.i" ], [ 4, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %value.sroa.6.014.i = phi ptr [ inttoptr (i64 8 to ptr), %bb2 ], [ %value.sroa.6.0.copyload331.pre.i, %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E.exit.thread27.loopexit.i" ], [ %8, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !30
  %12 = ptrtoint ptr %value.sroa.6.014.i to i64
  %13 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %.val = load i64, ptr %13, align 8, !range !11, !noundef !2
  %14 = icmp eq i64 %.val, 0
  br i1 %14, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb12
  %.val1 = load ptr, ptr %4, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i = shl nuw i64 %.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit": ; preds = %bb12, %bb2.i.i.i.i
  store i64 %value.sroa.0.015.i, ptr %13, align 8
  store i64 %12, ptr %4, align 8
  store i64 %..i.i.i, ptr %5, align 8
  store i64 11, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb11, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"
  ret void
}

; histogram_merge_errors::IntervalHistogram::nearest_rank_bracket
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram20nearest_rank_bracket17hd7036a96e9e6d697E(ptr dead_on_unwind noalias noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, i64 noundef %numerator, i64 noundef %denominator) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = add i64 %numerator, -1
  %.not = icmp ult i64 %0, %denominator
  br i1 %.not, label %bb4, label %bb3

bb3:                                              ; preds = %start
  store <2 x i64> <i64 2, i64 7>, ptr %_0, align 8
  br label %bb18

bb4:                                              ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !82)
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_7.i = load ptr, ptr %1, align 8, !alias.scope !82, !noalias !85, !nonnull !2, !noundef !2
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_6.i = load i64, ptr %2, align 8, !alias.scope !82, !noalias !85, !noundef !2
  %_11.i = getelementptr inbounds nuw i64, ptr %_7.i, i64 %_6.i
  br label %bb1.i.i

bb1.i.i:                                          ; preds = %bb3.i.i, %bb4
  %_16.i24.i.i = phi ptr [ %_7.i, %bb4 ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb4 ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb4 ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_11.i
  br i1 %_6.i.i.i, label %bb20, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !87, !noundef !2
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb19, label %bb1.i.i, !prof !16

bb19:                                             ; preds = %bb3.i.i
  %_51.sroa.2.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_9.sroa.5.0.i.i, ptr %_51.sroa.2.0..sroa_idx, align 8
  store <2 x i64> <i64 2, i64 6>, ptr %_0, align 8
  br label %bb18

bb20:                                             ; preds = %bb1.i.i
  %3 = icmp eq i64 %accum.sroa.0.0.i.i, 0
  br i1 %3, label %bb7, label %bb8

bb7:                                              ; preds = %bb20
  store <2 x i64> <i64 2, i64 8>, ptr %_0, align 8
  br label %bb18

bb8:                                              ; preds = %bb20
  %4 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %accum.sroa.0.0.i.i, i64 %numerator)
  %_55.1 = extractvalue { i64, i1 } %4, 1
  br i1 %_55.1, label %bb21, label %bb23, !prof !16

bb23:                                             ; preds = %bb8
  %_55.0 = extractvalue { i64, i1 } %4, 0
  %_21 = add i64 %denominator, -1
  %_62.0 = add i64 %_21, %_55.0
  %_62.1 = icmp ult i64 %_62.0, %_55.0
  br i1 %_62.1, label %bb24, label %bb26, !prof !16

bb21:                                             ; preds = %bb8
  store <2 x i64> <i64 2, i64 6>, ptr %_0, align 8
  br label %bb18

bb26:                                             ; preds = %bb23
  %rank = udiv i64 %_62.0, %denominator
  br label %bb9

bb24:                                             ; preds = %bb23
  store <2 x i64> <i64 2, i64 6>, ptr %_0, align 8
  br label %bb18

bb9:                                              ; preds = %bb29, %bb26
  %iter.sroa.0.0 = phi ptr [ %_7.i, %bb26 ], [ %_16.i.i, %bb29 ]
  %iter.sroa.8.0 = phi i64 [ 0, %bb26 ], [ %_9.0.i, %bb29 ]
  %cumulative.sroa.0.0 = phi i64 [ 0, %bb26 ], [ %_88.0, %bb29 ]
  %_6.i.i = icmp eq ptr %iter.sroa.0.0, %_11.i
  br i1 %_6.i.i, label %bb12, label %bb11

bb11:                                             ; preds = %bb9
  %_35 = load i64, ptr %iter.sroa.0.0, align 8, !noundef !2
  %_88.0 = add i64 %_35, %cumulative.sroa.0.0
  %_88.1 = icmp ult i64 %_88.0, %cumulative.sroa.0.0
  br i1 %_88.1, label %bb27, label %bb29, !prof !16

bb12:                                             ; preds = %bb9
  store <2 x i64> <i64 2, i64 10>, ptr %_0, align 8
  br label %bb18

bb18:                                             ; preds = %bb34, %bb27, %bb24, %bb21, %bb7, %bb19, %bb3, %bb12
  ret void

bb29:                                             ; preds = %bb11
  %_9.0.i = add i64 %iter.sroa.8.0, 1
  %_16.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0, i64 8
  %_38.not = icmp ult i64 %_88.0, %rank
  br i1 %_38.not, label %bb9, label %bb13

bb27:                                             ; preds = %bb11
  store <2 x i64> <i64 2, i64 6>, ptr %_0, align 8
  br label %bb18

bb13:                                             ; preds = %bb29
  %_98 = icmp eq i64 %iter.sroa.8.0, 0
  br i1 %_98, label %bb13.bb32_crit_edge, label %bb31

bb13.bb32_crit_edge:                              ; preds = %bb13
  %.phi.trans.insert = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_110.pre = load i64, ptr %.phi.trans.insert, align 8
  br label %bb32

bb31:                                             ; preds = %bb13
  %_99 = add i64 %iter.sroa.8.0, -1
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_105 = load i64, ptr %5, align 8, !noundef !2
  %_107 = icmp ult i64 %_99, %_105
  br i1 %_107, label %bb33, label %panic

bb33:                                             ; preds = %bb31
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_106 = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %_102 = getelementptr inbounds nuw i64, ptr %_106, i64 %_99
  %_101 = load i64, ptr %_102, align 8, !noundef !2
  br label %bb32

panic:                                            ; preds = %bb31
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef %_99, i64 noundef %_105, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9034bc150239ddb23220298f62c78c3d) #21
  unreachable

bb32:                                             ; preds = %bb13.bb32_crit_edge, %bb33
  %_110 = phi i64 [ %_105, %bb33 ], [ %_110.pre, %bb13.bb32_crit_edge ]
  %_41.sroa.0.0 = phi i64 [ 1, %bb33 ], [ 0, %bb13.bb32_crit_edge ]
  %_41.sroa.5.0 = phi i64 [ %_101, %bb33 ], [ undef, %bb13.bb32_crit_edge ]
  %_112 = icmp ult i64 %iter.sroa.8.0, %_110
  br i1 %_112, label %bb34, label %panic4

bb34:                                             ; preds = %bb32
  %7 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_111 = load ptr, ptr %7, align 8, !nonnull !2, !noundef !2
  %_44 = getelementptr inbounds nuw i64, ptr %_111, i64 %iter.sroa.8.0
  %_43 = load i64, ptr %_44, align 8, !noundef !2
  store i64 %_41.sroa.0.0, ptr %_0, align 8
  %_40.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_41.sroa.5.0, ptr %_40.sroa.4.0._0.sroa_idx, align 8
  %_40.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_43, ptr %_40.sroa.5.0._0.sroa_idx, align 8
  %_40.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %rank, ptr %_40.sroa.6.0._0.sroa_idx, align 8
  %_40.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store i64 %accum.sroa.0.0.i.i, ptr %_40.sroa.7.0._0.sroa_idx, align 8
  br label %bb18

panic4:                                           ; preds = %bb32
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef %iter.sroa.8.0, i64 noundef %_110, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_713e1b0d46806bc8c2cd07e9f5848152) #21
  unreachable
}

; histogram_merge_errors::IntervalHistogram::empty
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %_3 = load i64, ptr %0, align 8, !noundef !2
  %_4 = icmp ult i64 %_3, 1152921504606846976
  tail call void @llvm.assume(i1 %_4)
  %_33.0.i.i = shl nuw nsw i64 %_3, 3
  %1 = icmp eq i64 %_3, 0
  br i1 %1, label %"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E.exit", label %bb3.i1.i

bb3.i1.i:                                         ; preds = %start
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !91
; call __rustc::__rust_alloc_zeroed
  %2 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed(i64 noundef range(i64 1, 9223372036854775801) %_33.0.i.i, i64 noundef 8) #19, !noalias !91
  %3 = icmp eq ptr %2, null
  br i1 %3, label %bb14.i, label %bb10.i.i

bb10.i.i:                                         ; preds = %bb3.i1.i
  %4 = ptrtoint ptr %2 to i64
  br label %"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E.exit"

bb14.i:                                           ; preds = %bb3.i1.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_33.0.i.i) #20, !noalias !96
  unreachable

"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E.exit": ; preds = %start, %bb10.i.i
  %_16.sroa.10.0.i = phi i64 [ %4, %bb10.i.i ], [ 8, %start ]
  %5 = inttoptr i64 %_16.sroa.10.0.i to ptr
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_3, ptr %6, align 8
  %counts.sroa.2.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %5, ptr %counts.sroa.2.0..sroa_idx, align 8
  %counts.sroa.3.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_3, ptr %counts.sroa.3.0..sroa_idx, align 8
  ret void
}

; histogram_merge_errors::IntervalHistogram::record
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram6record17hf22885ef7c56b9e5E(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, i64 noundef %value_us) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %self.val = load ptr, ptr %0, align 8, !nonnull !2, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %self.val12 = load i64, ptr %1, align 8, !noundef !2
  switch i64 %self.val12, label %bb4.i.i.i [
    i64 0, label %bb6.i
    i64 1, label %"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE.exit.thread.i"
  ]

bb4.i.i.i:                                        ; preds = %start, %bb4.i.i.i
  %size.sroa.0.019.i.i.i = phi i64 [ %3, %bb4.i.i.i ], [ %self.val12, %start ]
  %base.sroa.0.018.i.i.i = phi i64 [ %2, %bb4.i.i.i ], [ 0, %start ]
  %half11.i.i.i = lshr i64 %size.sroa.0.019.i.i.i, 1
  %mid.i.i.i = add nuw i64 %half11.i.i.i, %base.sroa.0.018.i.i.i
  %_35.i.i.i = icmp ult i64 %mid.i.i.i, %self.val12
  tail call void @llvm.assume(i1 %_35.i.i.i)
  %_32.i.i.i = getelementptr inbounds nuw i64, ptr %self.val, i64 %mid.i.i.i
  %_32.val.i.i.i = load i64, ptr %_32.i.i.i, align 8, !alias.scope !97, !noalias !102, !noundef !2
  %_0.i.i15.not.i.i.i = icmp ult i64 %_32.val.i.i.i, %value_us
  %2 = select i1 %_0.i.i15.not.i.i.i, i64 %mid.i.i.i, i64 %base.sroa.0.018.i.i.i, !unpredictable !2
  %3 = sub i64 %size.sroa.0.019.i.i.i, %half11.i.i.i
  %_6.i.i.i = icmp ugt i64 %3, 1
  br i1 %_6.i.i.i, label %bb4.i.i.i, label %"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE.exit.thread.i"

"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE.exit.thread.i": ; preds = %bb4.i.i.i, %start
  %base.sroa.0.0.lcssa.i.i.i = phi i64 [ 0, %start ], [ %2, %bb4.i.i.i ]
  %_38.i.i.i = getelementptr inbounds nuw i64, ptr %self.val, i64 %base.sroa.0.0.lcssa.i.i.i
  %_38.val.i.i.i = load i64, ptr %_38.i.i.i, align 8, !alias.scope !97, !noalias !102, !noundef !2
  %_0.i.i.i.i.i = icmp ult i64 %_38.val.i.i.i, %value_us
  %_28.i.i.i = zext i1 %_0.i.i.i.i.i to i64
  %result.i.i.i = add nuw nsw i64 %base.sroa.0.0.lcssa.i.i.i, %_28.i.i.i
  %cond1.i.i.i = icmp ule i64 %result.i.i.i, %self.val12
  tail call void @llvm.assume(i1 %cond1.i.i.i)
  %_162.i = icmp ult i64 %self.val12, 1152921504606846976
  tail call void @llvm.assume(i1 %_162.i)
  %_73.i = icmp samesign ult i64 %result.i.i.i, %self.val12
  br i1 %_73.i, label %bb6, label %bb5

bb6.i:                                            ; preds = %start
; call core::option::expect_failed
  tail call void @_RNvNtCs6Hz1PecaLG4_4core6option13expect_failed(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_4ed059f71d51ae16bc6826f989989385, i64 noundef 30, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_72e1b02f1dc44543daa9de23d3bba29e) #21, !noalias !107
  unreachable

bb5:                                              ; preds = %"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE.exit.thread.i"
  %4 = getelementptr i64, ptr %self.val, i64 %self.val12
  %_18.i = getelementptr i8, ptr %4, i64 -8
  %_9.i = load i64, ptr %_18.i, align 8, !noalias !107, !noundef !2
  store i64 3, ptr %_0, align 8
  %_27.sroa.2.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %value_us, ptr %_27.sroa.2.0._0.sroa_idx, align 8
  %_27.sroa.3.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_9.i, ptr %_27.sroa.3.0._0.sroa_idx, align 8
  br label %bb4

bb6:                                              ; preds = %"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE.exit.thread.i"
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_23 = load i64, ptr %5, align 8, !noundef !2
  %_25 = icmp ult i64 %result.i.i.i, %_23
  br i1 %_25, label %bb7, label %panic

bb7:                                              ; preds = %bb6
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_24 = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %_12 = getelementptr inbounds nuw i64, ptr %_24, i64 %result.i.i.i
  %_11 = load i64, ptr %_12, align 8, !noundef !2
  %_30.1 = icmp eq i64 %_11, -1
  br i1 %_30.1, label %bb8, label %bb11, !prof !16

panic:                                            ; preds = %bb6
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef %result.i.i.i, i64 noundef %_23, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_96d0d7cd51bf3727855c17e0e20001f5) #21
  unreachable

bb8:                                              ; preds = %bb7
  store i64 6, ptr %_0, align 8
  br label %bb4

bb11:                                             ; preds = %bb7
  %_30.0 = add nuw i64 %_11, 1
  store i64 %_30.0, ptr %_12, align 8
  store i64 11, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb8, %bb5, %bb11
  ret void
}

; histogram_merge_errors::IntervalHistogram::coarsen
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors17IntervalHistogram7coarsen17h8be800490d83b0d2E(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %target) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %result = alloca [48 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_42 = load ptr, ptr %0, align 8, !nonnull !2, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_41 = load i64, ptr %1, align 8, !noundef !2
  %_43.not = icmp eq i64 %_41, 0
  %2 = getelementptr inbounds nuw i8, ptr %target, i64 16
  %3 = load i64, ptr %2, align 8, !noundef !2
  %.not = icmp eq i64 %3, 0
  br i1 %_43.not, label %bb18, label %bb17

bb18:                                             ; preds = %start
  br i1 %.not, label %bb6.thread, label %bb5

bb6.thread:                                       ; preds = %bb18
  call void @llvm.lifetime.start.p0(ptr nonnull %result)
  br label %_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E.exit

bb17:                                             ; preds = %start
  br i1 %.not, label %bb5, label %bb25

bb2:                                              ; preds = %bb25
  %cond = icmp eq i64 %_41, 1
  br i1 %cond, label %bb1.us4.i, label %bb1.i

bb1.us4.i:                                        ; preds = %bb2, %bb13.us7.i
  %_222.us5.i = phi ptr [ %_22.us8.i, %bb13.us7.i ], [ %_48, %bb2 ]
  %_12.us6.not.not.i = icmp eq ptr %_222.us5.i, %8
  br i1 %_12.us6.not.not.i, label %bb6, label %bb13.us7.i

bb13.us7.i:                                       ; preds = %bb1.us4.i
  %_22.us8.i = getelementptr inbounds nuw i8, ptr %_222.us5.i, i64 8
  %ptr.val.us9.i = load i64, ptr %_222.us5.i, align 8, !noalias !108
  %_38.val.i.i.us13.i = load i64, ptr %_42, align 8, !alias.scope !112, !noalias !115, !noundef !2
  %.not.us14.i = icmp eq i64 %_38.val.i.i.us13.i, %ptr.val.us9.i
  br i1 %.not.us14.i, label %bb1.us4.i, label %bb5

bb1.i:                                            ; preds = %bb2, %"_ZN22histogram_merge_errors17IntervalHistogram7coarsen28_$u7b$$u7b$closure$u7d$$u7d$17hcb2570ebb2e1017fE.exit.loopexit.i"
  %_222.i = phi ptr [ %_22.i, %"_ZN22histogram_merge_errors17IntervalHistogram7coarsen28_$u7b$$u7b$closure$u7d$$u7d$17hcb2570ebb2e1017fE.exit.loopexit.i" ], [ %_48, %bb2 ]
  %_12.not.not.i = icmp eq ptr %_222.i, %8
  br i1 %_12.not.not.i, label %bb6, label %bb13.i

bb13.i:                                           ; preds = %bb1.i
  %ptr.val.i = load i64, ptr %_222.i, align 8, !noalias !108
  br label %bb4.i.i.i

bb4.i.i.i:                                        ; preds = %bb4.i.i.i, %bb13.i
  %size.sroa.0.017.i.i.i = phi i64 [ %5, %bb4.i.i.i ], [ %_41, %bb13.i ]
  %base.sroa.0.016.i.i.i = phi i64 [ %4, %bb4.i.i.i ], [ 0, %bb13.i ]
  %half11.i.i.i = lshr i64 %size.sroa.0.017.i.i.i, 1
  %mid.i.i.i = add nuw i64 %half11.i.i.i, %base.sroa.0.016.i.i.i
  %_35.i.i.i = icmp ult i64 %mid.i.i.i, %_41
  tail call void @llvm.assume(i1 %_35.i.i.i)
  %_32.i.i.i = getelementptr inbounds nuw i64, ptr %_42, i64 %mid.i.i.i
  %_32.val.i.i.i = load i64, ptr %_32.i.i.i, align 8, !alias.scope !112, !noalias !115, !noundef !2
  %_17.i.i.i = icmp ugt i64 %_32.val.i.i.i, %ptr.val.i
  %4 = select i1 %_17.i.i.i, i64 %base.sroa.0.016.i.i.i, i64 %mid.i.i.i, !unpredictable !2
  %5 = sub i64 %size.sroa.0.017.i.i.i, %half11.i.i.i
  %_6.i.i.i = icmp ugt i64 %5, 1
  br i1 %_6.i.i.i, label %bb4.i.i.i, label %"_ZN22histogram_merge_errors17IntervalHistogram7coarsen28_$u7b$$u7b$closure$u7d$$u7d$17hcb2570ebb2e1017fE.exit.loopexit.i"

"_ZN22histogram_merge_errors17IntervalHistogram7coarsen28_$u7b$$u7b$closure$u7d$$u7d$17hcb2570ebb2e1017fE.exit.loopexit.i": ; preds = %bb4.i.i.i
  %_22.i = getelementptr inbounds nuw i8, ptr %_222.i, i64 8
  %_38.i.i.i = getelementptr inbounds nuw i64, ptr %_42, i64 %4
  %_38.val.i.i.i = load i64, ptr %_38.i.i.i, align 8, !alias.scope !112, !noalias !115, !noundef !2
  %.not.i = icmp eq i64 %_38.val.i.i.i, %ptr.val.i
  br i1 %.not.i, label %bb1.i, label %bb5

bb25:                                             ; preds = %bb17
  %6 = getelementptr inbounds nuw i8, ptr %target, i64 8
  %_48 = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %7 = getelementptr i64, ptr %_42, i64 %_41
  %_44 = getelementptr i8, ptr %7, i64 -8
  %8 = getelementptr i64, ptr %_48, i64 %3
  %_50 = getelementptr i8, ptr %8, i64 -8
  %_54 = load i64, ptr %_44, align 8, !noundef !2
  %_55 = load i64, ptr %_50, align 8, !noundef !2
  %_51.not = icmp eq i64 %_54, %_55
  br i1 %_51.not, label %bb2, label %bb5

bb6:                                              ; preds = %bb1.i, %bb1.us4.i
  call void @llvm.lifetime.start.p0(ptr nonnull %result)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !117)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !120)
  %_4.i = icmp ult i64 %3, 1152921504606846976
  tail call void @llvm.assume(i1 %_4.i)
  %_33.0.i.i.i = shl nuw nsw i64 %3, 3
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !122
; call __rustc::__rust_alloc_zeroed
  %9 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed(i64 noundef range(i64 1, 9223372036854775801) %_33.0.i.i.i, i64 noundef 8) #19, !noalias !122
  %10 = icmp eq ptr %9, null
  br i1 %10, label %bb14.i.i, label %_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E.exit

bb14.i.i:                                         ; preds = %bb6
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_33.0.i.i.i) #20, !noalias !127
  unreachable

_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E.exit: ; preds = %bb6, %bb6.thread
  %_582393 = phi i64 [ 0, %bb6.thread ], [ %3, %bb6 ]
  %_16.sroa.10.0.i.i = phi ptr [ inttoptr (i64 8 to ptr), %bb6.thread ], [ %9, %bb6 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %result, ptr noundef nonnull align 8 dereferenceable(16) %target, i64 16, i1 false), !alias.scope !128
  %_12.sroa.4.0.result.sroa_idx = getelementptr inbounds nuw i8, ptr %result, i64 16
  store i64 %_582393, ptr %_12.sroa.4.0.result.sroa_idx, align 8, !alias.scope !128
  %11 = getelementptr inbounds nuw i8, ptr %result, i64 24
  store i64 %_582393, ptr %11, align 8, !alias.scope !117, !noalias !120
  %counts.sroa.2.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 32
  store ptr %_16.sroa.10.0.i.i, ptr %counts.sroa.2.0..sroa_idx.i, align 8, !alias.scope !117, !noalias !120
  %counts.sroa.3.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 40
  store i64 %_582393, ptr %counts.sroa.3.0..sroa_idx.i, align 8, !alias.scope !117, !noalias !120
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_71 = load ptr, ptr %12, align 8, !nonnull !2, !noundef !2
  %13 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_70 = load i64, ptr %13, align 8, !noundef !2
  %_75.idx = shl nuw nsw i64 %_70, 3
  %_75 = getelementptr inbounds nuw i8, ptr %_71, i64 %_75.idx
  %_6.i.i40 = icmp eq i64 %_70, 0
  br i1 %_6.i.i40, label %bb12, label %bb11.lr.ph

bb11.lr.ph:                                       ; preds = %_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E.exit
  %14 = getelementptr inbounds nuw i8, ptr %result, i64 8
  %_84 = load ptr, ptr %14, align 8, !nonnull !2
  br i1 %_43.not, label %panic, label %bb11.lr.ph.split

bb11.lr.ph.split:                                 ; preds = %bb11.lr.ph
  %_617.not.i.i = icmp eq i64 %_582393, 1
  br i1 %_617.not.i.i, label %bb11.us44, label %bb11

bb11.us44:                                        ; preds = %bb11.lr.ph.split, %bb24.us59
  %iter.sroa.8.042.us45 = phi i64 [ %_9.0.i.us48, %bb24.us59 ], [ 0, %bb11.lr.ph.split ]
  %iter.sroa.0.041.us46 = phi ptr [ %_16.i.i.us47, %bb24.us59 ], [ %_71, %bb11.lr.ph.split ]
  %_16.i.i.us47 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.041.us46, i64 8
  %_9.0.i.us48 = add nuw nsw i64 %iter.sroa.8.042.us45, 1
  %exitcond86.not = icmp eq i64 %iter.sroa.8.042.us45, %_41
  br i1 %exitcond86.not, label %panic, label %bb19.us50

bb19.us50:                                        ; preds = %bb11.us44
  %_22.us51 = getelementptr inbounds nuw i64, ptr %_42, i64 %iter.sroa.8.042.us45
  %15 = load i64, ptr %_22.us51, align 8, !noundef !2
  %_38.val.i.i.us = load i64, ptr %_84, align 8, !alias.scope !129, !noalias !134, !noundef !2
  %_0.i.i.i.i.us = icmp ult i64 %_38.val.i.i.us, %15
  br i1 %_0.i.i.i.i.us, label %panic1, label %bb20.us53

bb20.us53:                                        ; preds = %bb19.us50
  %_30.us55 = load i64, ptr %_16.sroa.10.0.i.i, align 8, !noundef !2
  %_32.us56 = load i64, ptr %iter.sroa.0.041.us46, align 8, !noundef !2
  %_91.0.us57 = add i64 %_32.us56, %_30.us55
  %_91.1.us58 = icmp ult i64 %_91.0.us57, %_30.us55
  br i1 %_91.1.us58, label %bb21, label %bb24.us59, !prof !16

bb24.us59:                                        ; preds = %bb20.us53
  store i64 %_91.0.us57, ptr %_16.sroa.10.0.i.i, align 8
  %_6.i.i.us60 = icmp eq ptr %_16.i.i.us47, %_75
  br i1 %_6.i.i.us60, label %bb12, label %bb11.us44

bb11:                                             ; preds = %bb11.lr.ph.split, %bb24
  %iter.sroa.8.042 = phi i64 [ %_9.0.i, %bb24 ], [ 0, %bb11.lr.ph.split ]
  %iter.sroa.0.041 = phi ptr [ %_16.i.i, %bb24 ], [ %_71, %bb11.lr.ph.split ]
  %_16.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.041, i64 8
  %_9.0.i = add nuw nsw i64 %iter.sroa.8.042, 1
  %exitcond.not = icmp eq i64 %iter.sroa.8.042, %_41
  br i1 %exitcond.not, label %panic, label %bb19

bb12:                                             ; preds = %bb24, %bb24.us59, %_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E.exit
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %result, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %result)
  br label %bb15

bb15:                                             ; preds = %bb2.i.i.i.i.i, %bb5, %bb21, %bb12
  ret void

bb19:                                             ; preds = %bb11
  %_22 = getelementptr inbounds nuw i64, ptr %_42, i64 %iter.sroa.8.042
  %16 = load i64, ptr %_22, align 8, !noundef !2
  br label %bb4.i.i

bb4.i.i:                                          ; preds = %bb19, %bb4.i.i
  %size.sroa.0.019.i.i = phi i64 [ %18, %bb4.i.i ], [ %_582393, %bb19 ]
  %base.sroa.0.018.i.i = phi i64 [ %17, %bb4.i.i ], [ 0, %bb19 ]
  %half11.i.i = lshr i64 %size.sroa.0.019.i.i, 1
  %mid.i.i = add nuw i64 %half11.i.i, %base.sroa.0.018.i.i
  %_35.i.i = icmp ult i64 %mid.i.i, %_582393
  tail call void @llvm.assume(i1 %_35.i.i)
  %_32.i.i = getelementptr inbounds nuw i64, ptr %_84, i64 %mid.i.i
  %_32.val.i.i = load i64, ptr %_32.i.i, align 8, !alias.scope !129, !noalias !134, !noundef !2
  %_0.i.i15.not.i.i = icmp ult i64 %_32.val.i.i, %16
  %17 = select i1 %_0.i.i15.not.i.i, i64 %mid.i.i, i64 %base.sroa.0.018.i.i, !unpredictable !2
  %18 = sub i64 %size.sroa.0.019.i.i, %half11.i.i
  %_6.i.i17 = icmp ugt i64 %18, 1
  br i1 %_6.i.i17, label %bb4.i.i, label %bb10.i.i.loopexit

bb10.i.i.loopexit:                                ; preds = %bb4.i.i
  %_38.i.i = getelementptr inbounds nuw i64, ptr %_84, i64 %17
  %_38.val.i.i = load i64, ptr %_38.i.i, align 8, !alias.scope !129, !noalias !134, !noundef !2
  %_0.i.i.i.i = icmp ult i64 %_38.val.i.i, %16
  %_28.i.i = zext i1 %_0.i.i.i.i to i64
  %result.i.i = add nuw nsw i64 %17, %_28.i.i
  %cond1.i.i = icmp ule i64 %result.i.i, %_582393
  tail call void @llvm.assume(i1 %cond1.i.i)
  %_89 = icmp ult i64 %result.i.i, %_582393
  br i1 %_89, label %bb20, label %panic1

panic:                                            ; preds = %bb11, %bb11.us44, %bb11.lr.ph
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef %_41, i64 noundef %_41, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4902ffe043ff59a1d70cb2012e4b3cfd) #21
  unreachable

bb20:                                             ; preds = %bb10.i.i.loopexit
  %_31 = getelementptr inbounds nuw i64, ptr %_16.sroa.10.0.i.i, i64 %result.i.i
  %_30 = load i64, ptr %_31, align 8, !noundef !2
  %_32 = load i64, ptr %iter.sroa.0.041, align 8, !noundef !2
  %_91.0 = add i64 %_32, %_30
  %_91.1 = icmp ult i64 %_91.0, %_30
  br i1 %_91.1, label %bb21, label %bb24, !prof !16

panic1:                                           ; preds = %bb10.i.i.loopexit, %bb19.us50
  %.us-phi43 = phi i64 [ 1, %bb19.us50 ], [ %result.i.i, %bb10.i.i.loopexit ]
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef %.us-phi43, i64 noundef %_582393, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4583e6a49f6781f6842cac8cdb2523af) #21
  unreachable

bb21:                                             ; preds = %bb20, %bb20.us53
  store <2 x i64> <i64 -9223372036854775808, i64 6>, ptr %_0, align 8
; call core::ptr::drop_in_place<histogram_merge_errors::IntervalHistogram>
  call fastcc void @"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E"(ptr noalias noundef align 8 dereferenceable(48) %result) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %result)
  br label %bb15

bb24:                                             ; preds = %bb20
  store i64 %_91.0, ptr %_31, align 8
  %_6.i.i = icmp eq ptr %_16.i.i, %_75
  br i1 %_6.i.i, label %bb12, label %bb11

bb5:                                              ; preds = %"_ZN22histogram_merge_errors17IntervalHistogram7coarsen28_$u7b$$u7b$closure$u7d$$u7d$17hcb2570ebb2e1017fE.exit.loopexit.i", %bb13.us7.i, %bb25, %bb18, %bb17
  store <2 x i64> <i64 -9223372036854775808, i64 9>, ptr %_0, align 8
  %target.val = load i64, ptr %target, align 8, !range !11, !noundef !2
  %19 = icmp eq i64 %target.val, 0
  br i1 %19, label %bb15, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb5
  %20 = getelementptr inbounds nuw i8, ptr %target, i64 8
  %target.val16 = load ptr, ptr %20, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %target.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %target.val16, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb15
}

; histogram_merge_errors::CumulativeHistogram::delta_since
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors19CumulativeHistogram11delta_since17h9655ef2f204d96edE(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %older) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %vector.i.i.i.i.i = alloca [24 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_15 = load i64, ptr %0, align 8, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %older, i64 16
  %_17 = load i64, ptr %1, align 8, !noundef !2
  %_19 = icmp eq i64 %_15, %_17
  br i1 %_19, label %bb7, label %bb1

bb7:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %older, i64 8
  %_18 = load ptr, ptr %2, align 8, !nonnull !2, !noundef !2
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_16 = load ptr, ptr %3, align 8, !nonnull !2, !noundef !2
  %_20 = shl nuw i64 %_15, 3
  %bcmp = tail call i32 @bcmp(ptr nonnull %_16, ptr nonnull %_18, i64 %_20)
  %_14.not = icmp eq i32 %bcmp, 0
  br i1 %_14.not, label %bb2, label %bb1

bb1:                                              ; preds = %start, %bb7
  store <2 x i64> <i64 -9223372036854775808, i64 4>, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_27 = load ptr, ptr %4, align 8, !nonnull !2, !noundef !2
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_26 = load i64, ptr %5, align 8, !noundef !2
  %6 = getelementptr inbounds nuw i8, ptr %older, i64 32
  %_10.val = load ptr, ptr %6, align 8, !nonnull !2, !noundef !2
  %7 = getelementptr inbounds nuw i8, ptr %older, i64 40
  %_10.val1 = load i64, ptr %7, align 8, !noundef !2
  %..i.i.i = tail call noundef i64 @llvm.umin.i64(i64 %_10.val1, i64 %_26)
  call void @llvm.lifetime.start.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !137
  %_2.i.i.i.i.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 0
  br i1 %_2.i.i.i.i.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2
  %.val.i.i.i.i.i.i.i.i.i = load i64, ptr %_27, align 8, !noalias !153, !noundef !2
  %.val3.i.i.i.i.i.i.i.i.i = load i64, ptr %_10.val, align 8, !noalias !153, !noundef !2
  %_9.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %.val.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i
  br i1 %_9.i.i.i.i.i.i.i.i.i.i.i, label %bb4.thread.i, label %bb3.i.i.i.i.i.i.i

bb4.thread.i:                                     ; preds = %bb3.i.i.i.i.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !137
  br label %bb11

bb3.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !163
; call __rustc::__rust_alloc
  %8 = tail call noundef align 8 dereferenceable_or_null(32) ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) 32, i64 noundef 8) #19, !noalias !163
  %9 = icmp eq ptr %8, null
  br i1 %9, label %bb3.i.i.i.i.i.i, label %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i"

bb3.i.i.i.i.i.i:                                  ; preds = %bb3.i.i.i.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 32) #20, !noalias !137
  unreachable

"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i": ; preds = %bb3.i.i.i.i.i.i.i
  %_10.i.i4.i.i.i.i.i.i.i.i.i = sub nuw i64 %.val.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i
  store i64 %_10.i.i4.i.i.i.i.i.i.i.i.i, ptr %8, align 8, !noalias !137
  store i64 4, ptr %vector.i.i.i.i.i, align 8, !noalias !137
  %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 8
  store ptr %8, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !137
  %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 16
  store i64 1, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !137
  tail call void @llvm.experimental.noalias.scope.decl(metadata !166)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !169)
  %_2.i.i.i.i.i.i5.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 1
  br i1 %_2.i.i.i.i.i.i5.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i3.i.i.i.i.i

bb3.i.i.i.i.i.i3.i.i.i.i.i:                       ; preds = %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i", %bb8.i.i.i.i.i.i.i
  %_23.i.i10.i.i.i.i.i = phi ptr [ %_23.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ %8, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %len.i.i.i.i.i.i.i = phi i64 [ %new_len.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ 1, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %new_len.i.i.i.i.i.i.i = add nuw nsw i64 %len.i.i.i.i.i.i.i, 1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_27, i64 %len.i.i.i.i.i.i.i
  %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_10.val, i64 %len.i.i.i.i.i.i.i
  %.val.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !172, !noundef !2
  %.val3.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !172, !noundef !2
  %_9.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %.val.i.i.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i.i.i
  br i1 %_9.i.i.i.i.i.i.i.i.i.i.i.i.i, label %bb4.i, label %bb3.i.i4.i.i.i.i.i

bb3.i.i4.i.i.i.i.i:                               ; preds = %bb3.i.i.i.i.i.i3.i.i.i.i.i
  %_10.i.i4.i.i.i.i.i.i.i.i.i.i.i = sub nuw i64 %.val.i.i.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i.i.i
  %_19.i.i.i.i.i.i.i = icmp samesign ult i64 %len.i.i.i.i.i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i.i.i.i.i.i.i)
  %self1.i.i.i.i.i.i.i = load i64, ptr %vector.i.i.i.i.i, align 8, !range !11, !alias.scope !184, !noalias !185, !noundef !2
  %_8.i.i5.i.i.i.i.i = icmp eq i64 %len.i.i.i.i.i.i.i, %self1.i.i.i.i.i.i.i
  br i1 %_8.i.i5.i.i.i.i.i, label %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i", label %bb8.i.i.i.i.i.i.i

"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i": ; preds = %bb3.i.i4.i.i.i.i.i
; call alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle
  call fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE"(ptr noalias noundef nonnull align 8 dereferenceable(24) %vector.i.i.i.i.i, i64 noundef %len.i.i.i.i.i.i.i, i64 noundef 1) #19
  %_23.i.i.pre.i.i.i.i.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !184, !noalias !185
  br label %bb8.i.i.i.i.i.i.i

bb8.i.i.i.i.i.i.i:                                ; preds = %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i", %bb3.i.i4.i.i.i.i.i
  %_23.i.i.i.i.i.i.i = phi ptr [ %_23.i.i.pre.i.i.i.i.i, %"_ZN5alloc3vec16Vec$LT$T$C$A$GT$7reserve17hdc774b33045c698aE.exit.i.i.i.i.i.i.i" ], [ %_23.i.i10.i.i.i.i.i, %bb3.i.i4.i.i.i.i.i ]
  %dst.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_23.i.i.i.i.i.i.i, i64 %len.i.i.i.i.i.i.i
  store i64 %_10.i.i4.i.i.i.i.i.i.i.i.i.i.i, ptr %dst.i.i.i.i.i.i.i, align 8, !noalias !186
  store i64 %new_len.i.i.i.i.i.i.i, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !184, !noalias !185
  %exitcond.not.i.i.i.i.i.i.i = icmp eq i64 %new_len.i.i.i.i.i.i.i, %..i.i.i
  br i1 %exitcond.not.i.i.i.i.i.i.i, label %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E.exit.thread24.loopexit.i", label %bb3.i.i.i.i.i.i3.i.i.i.i.i

"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E.exit.thread24.loopexit.i": ; preds = %bb8.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload226.pre.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !187
  %value.sroa.6.0.copyload327.pre.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !187
  br label %bb12

bb4.i:                                            ; preds = %bb3.i.i.i.i.i.i3.i.i.i.i.i
  %value.sroa.0.0.copyload2.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !187
  %value.sroa.6.0.copyload3.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !187
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !137
  %10 = icmp eq i64 %value.sroa.0.0.copyload2.i, 0
  br i1 %10, label %bb11, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb4.i
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %value.sroa.0.0.copyload2.i, 3
  %11 = icmp ne ptr %value.sroa.6.0.copyload3.i, null
  tail call void @llvm.assume(i1 %11)
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.0.copyload3.i, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !188
  br label %bb11

bb11:                                             ; preds = %bb4.thread.i, %bb4.i, %bb2.i.i.i.i.i
  store <2 x i64> <i64 -9223372036854775808, i64 5>, ptr %_0, align 8
  br label %bb6

bb12:                                             ; preds = %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E.exit.thread24.loopexit.i", %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i", %bb2
  %value.sroa.0.014.i = phi i64 [ 0, %bb2 ], [ %value.sroa.0.0.copyload226.pre.i, %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E.exit.thread24.loopexit.i" ], [ 4, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  %value.sroa.6.013.i = phi ptr [ inttoptr (i64 8 to ptr), %bb2 ], [ %value.sroa.6.0.copyload327.pre.i, %"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E.exit.thread24.loopexit.i" ], [ %8, %"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$16with_capacity_in17ha20f76af2b2a7a44E.exit.i.i.i.i.i" ]
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !137
  %12 = icmp eq i64 %_15, 0
  br i1 %12, label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit", label %bb3.i.i.i.i

bb3.i.i.i.i:                                      ; preds = %bb12
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !189
; call __rustc::__rust_alloc
  %13 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_20, i64 noundef 8) #19, !noalias !189
  %14 = icmp eq ptr %13, null
  br i1 %14, label %bb3.i.i.i, label %bb1.i.i

bb3.i.i.i:                                        ; preds = %bb3.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_20) #20, !noalias !197
  unreachable

bb1.i.i:                                          ; preds = %bb3.i.i.i.i
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %13, ptr nonnull readonly align 8 %_16, i64 %_20, i1 false), !noalias !198
  br label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit"

"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit": ; preds = %bb12, %bb1.i.i
  %_40.sroa.5.0 = phi ptr [ %13, %bb1.i.i ], [ inttoptr (i64 8 to ptr), %bb12 ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !199)
  %_18.i = icmp samesign ult i64 %..i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_18.i)
  %_19.i = icmp ult i64 %_15, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i)
  %_3.not.i = icmp eq i64 %..i.i.i, %_15
  br i1 %_3.not.i, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit"
  %15 = icmp ne ptr %value.sroa.6.013.i, null
  tail call void @llvm.assume(i1 %15)
  %_29.i = getelementptr inbounds nuw i64, ptr %value.sroa.6.013.i, i64 %_15
  br label %bb1.i.i5

bb1.i.i5:                                         ; preds = %bb3.i.i, %bb2.i
  %_16.i24.i.i = phi ptr [ %value.sroa.6.013.i, %bb2.i ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_29.i
  br i1 %_6.i.i.i, label %bb9.i, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i5
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !202, !noundef !2
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb5.i, label %bb1.i.i5, !prof !16

bb1.i:                                            ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit"
  %16 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 2, ptr %16, align 8, !alias.scope !199, !noalias !208
  br label %bb5.i

bb9.i:                                            ; preds = %bb1.i.i5
  store i64 %_15, ptr %_0, align 8, !noalias !208
  %_15.i.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %_40.sroa.5.0, ptr %_15.i.sroa.4.0._0.sroa_idx, align 8, !noalias !208
  %_15.i.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_15, ptr %_15.i.sroa.5.0._0.sroa_idx, align 8, !noalias !208
  %_15.i.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %value.sroa.0.014.i, ptr %_15.i.sroa.6.0._0.sroa_idx, align 8, !noalias !208
  %_15.i.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %value.sroa.6.013.i, ptr %_15.i.sroa.7.0._0.sroa_idx, align 8, !noalias !208
  %_15.i.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_15, ptr %_15.i.sroa.8.0._0.sroa_idx, align 8, !noalias !208
  br label %bb6

bb5.i:                                            ; preds = %bb3.i.i, %bb1.i
  %.sink14.i = phi i64 [ 16, %bb1.i ], [ 8, %bb3.i.i ]
  %_5.sink.i = phi i64 [ %_15, %bb1.i ], [ 6, %bb3.i.i ]
  %.sink.i = phi i64 [ 24, %bb1.i ], [ 16, %bb3.i.i ]
  %_4.sink.i = phi i64 [ %..i.i.i, %bb1.i ], [ %_9.sroa.5.0.i.i, %bb3.i.i ]
  %_6.sroa.4.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink14.i
  store i64 %_5.sink.i, ptr %_6.sroa.4.0..sroa_idx.i, align 8, !alias.scope !199, !noalias !208
  %_6.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink.i
  store i64 %_4.sink.i, ptr %_6.sroa.5.0..sroa_idx.i, align 8, !alias.scope !199, !noalias !208
  store i64 -9223372036854775808, ptr %_0, align 8, !alias.scope !199, !noalias !208
  %17 = icmp eq i64 %value.sroa.0.014.i, 0
  br i1 %17, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i", label %bb2.i.i.i.i.i3

bb2.i.i.i.i.i3:                                   ; preds = %bb5.i
  %18 = icmp ne ptr %value.sroa.6.013.i, null
  tail call void @llvm.assume(i1 %18)
  %alloc_size.i.i.i.i.i.i4 = shl nuw i64 %value.sroa.0.014.i, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.013.i, i64 noundef %alloc_size.i.i.i.i.i.i4, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !209
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i": ; preds = %bb2.i.i.i.i.i3, %bb5.i
  br i1 %12, label %bb6, label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i"
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_40.sroa.5.0, i64 noundef %_20, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !209
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i.i.i, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i", %bb9.i, %bb1, %bb11
  ret void
}

; histogram_merge_errors::CumulativeHistogram::new
; Function Attrs: nounwind uwtable
define void @_ZN22histogram_merge_errors19CumulativeHistogram3new17hda81f8ed0c23862cE(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %interval_totals) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %_11 = alloca [48 x i8], align 8
  %_5.sroa.6 = alloca i64, align 8
  %_5.sroa.10 = alloca i64, align 8
  %_5.sroa.12 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.6)
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.10)
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.12)
  %0 = getelementptr inbounds nuw i8, ptr %schema, i64 8
  %schema.val6 = load ptr, ptr %0, align 8, !nonnull !2, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %schema.val7 = load i64, ptr %1, align 8, !noundef !2
  %_33.0.i.i.i.i = shl nuw nsw i64 %schema.val7, 3
  %2 = icmp eq i64 %schema.val7, 0
  br i1 %2, label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit", label %bb3.i.i.i.i

bb3.i.i.i.i:                                      ; preds = %start
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !210
; call __rustc::__rust_alloc
  %3 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_33.0.i.i.i.i, i64 noundef 8) #19, !noalias !210
  %4 = icmp eq ptr %3, null
  br i1 %4, label %bb3.i.i.i, label %bb1.i.i

bb3.i.i.i:                                        ; preds = %bb3.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_33.0.i.i.i.i) #20, !noalias !218
  unreachable

bb1.i.i:                                          ; preds = %bb3.i.i.i.i
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %3, ptr nonnull readonly align 8 %schema.val6, i64 %_33.0.i.i.i.i, i1 false), !noalias !219
  br label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit"

"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit": ; preds = %start, %bb1.i.i
  %_14.sroa.5.0 = phi ptr [ %3, %bb1.i.i ], [ inttoptr (i64 8 to ptr), %start ]
  %5 = getelementptr inbounds nuw i8, ptr %interval_totals, i64 8
  %interval_totals.val4 = load ptr, ptr %5, align 8, !nonnull !2, !noundef !2
  %6 = getelementptr inbounds nuw i8, ptr %interval_totals, i64 16
  %interval_totals.val5 = load i64, ptr %6, align 8, !noundef !2
  %_33.0.i.i.i.i8 = shl nuw nsw i64 %interval_totals.val5, 3
  %7 = icmp eq i64 %interval_totals.val5, 0
  br i1 %7, label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit13", label %bb3.i.i.i.i9

bb3.i.i.i.i9:                                     ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit"
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !220
; call __rustc::__rust_alloc
  %8 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_33.0.i.i.i.i8, i64 noundef 8) #19, !noalias !220
  %9 = icmp eq ptr %8, null
  br i1 %9, label %bb3.i.i.i11, label %bb1.i.i10

bb3.i.i.i11:                                      ; preds = %bb3.i.i.i.i9
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_33.0.i.i.i.i8) #20, !noalias !228
  unreachable

bb1.i.i10:                                        ; preds = %bb3.i.i.i.i9
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %8, ptr nonnull readonly align 8 %interval_totals.val4, i64 %_33.0.i.i.i.i8, i1 false), !noalias !229
  br label %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit13"

"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit13": ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit", %bb1.i.i10
  %_7.sroa.6.0 = phi ptr [ %8, %bb1.i.i10 ], [ inttoptr (i64 8 to ptr), %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit" ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !230)
  %_18.i = icmp ult i64 %interval_totals.val5, 1152921504606846976
  tail call void @llvm.assume(i1 %_18.i)
  %_19.i = icmp ult i64 %schema.val7, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i)
  %_3.not.i = icmp eq i64 %interval_totals.val5, %schema.val7
  br i1 %_3.not.i, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit13"
  %_29.i = getelementptr inbounds nuw i64, ptr %_7.sroa.6.0, i64 %schema.val7
  br label %bb1.i.i14

bb1.i.i14:                                        ; preds = %bb3.i.i, %bb2.i
  %_16.i24.i.i = phi ptr [ %_7.sroa.6.0, %bb2.i ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_29.i
  br i1 %_6.i.i.i, label %_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E.exit, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i14
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !233, !noundef !2
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb5.i, label %bb1.i.i14, !prof !16

bb1.i:                                            ; preds = %"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE.exit13"
  store i64 2, ptr %_5.sroa.6, align 8, !alias.scope !230, !noalias !239
  br label %bb5.i

bb5.i:                                            ; preds = %bb3.i.i, %bb1.i
  %.sink14.i.sroa.phi = phi ptr [ %_5.sroa.10, %bb1.i ], [ %_5.sroa.6, %bb3.i.i ]
  %_5.sink.i = phi i64 [ %schema.val7, %bb1.i ], [ 6, %bb3.i.i ]
  %.sink.i.sroa.phi = phi ptr [ %_5.sroa.12, %bb1.i ], [ %_5.sroa.10, %bb3.i.i ]
  %_4.sink.i = phi i64 [ %interval_totals.val5, %bb1.i ], [ %_9.sroa.5.0.i.i, %bb3.i.i ]
  store i64 %_5.sink.i, ptr %.sink14.i.sroa.phi, align 8, !alias.scope !230, !noalias !239
  store i64 %_4.sink.i, ptr %.sink.i.sroa.phi, align 8, !alias.scope !230, !noalias !239
  br i1 %7, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i", label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb5.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_7.sroa.6.0, i64 noundef %_33.0.i.i.i.i8, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !240
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i": ; preds = %bb2.i.i.i.i.i, %bb5.i
  br i1 %2, label %bb8, label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i"
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_14.sroa.5.0, i64 noundef %_33.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !240
  br label %bb8

_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E.exit: ; preds = %bb1.i.i14
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.6)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.10)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.12)
  br i1 %2, label %"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E.exit", label %bb2.i.i.i.i.i20

bb8:                                              ; preds = %bb2.i.i.i.i.i.i, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit.i"
  %_5.sroa.6.0._5.sroa.6.0._5.sroa.6.0._5.sroa.6.8.copyload = load i64, ptr %_5.sroa.6, align 8
  %_5.sroa.10.0._5.sroa.10.0._5.sroa.10.0._5.sroa.10.8.copyload = load i64, ptr %_5.sroa.10, align 8
  %_5.sroa.12.0._5.sroa.12.0._5.sroa.12.0._5.sroa.12.8.copyload = load i64, ptr %_5.sroa.12, align 8
  %10 = inttoptr i64 %_5.sroa.6.0._5.sroa.6.0._5.sroa.6.0._5.sroa.6.8.copyload to ptr
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.6)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.10)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.12)
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %10, ptr %11, align 8
  %_21.sroa.2.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_5.sroa.10.0._5.sroa.10.0._5.sroa.10.0._5.sroa.10.8.copyload, ptr %_21.sroa.2.0..sroa_idx, align 8
  %_21.sroa.3.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_5.sroa.12.0._5.sroa.12.0._5.sroa.12.0._5.sroa.12.8.copyload, ptr %_21.sroa.3.0..sroa_idx, align 8
  store i64 -9223372036854775808, ptr %_0, align 8
  %interval_totals.val = load i64, ptr %interval_totals, align 8, !range !11, !noundef !2
  %12 = icmp eq i64 %interval_totals.val, 0
  br i1 %12, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb8
  %alloc_size.i.i.i.i.i = shl nuw i64 %interval_totals.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %interval_totals.val4, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit": ; preds = %bb8, %bb2.i.i.i.i
  %schema.val = load i64, ptr %schema, align 8, !range !11, !noundef !2
  %13 = icmp eq i64 %schema.val, 0
  br i1 %13, label %bb6, label %bb2.i.i.i.i.i15

bb2.i.i.i.i.i15:                                  ; preds = %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"
  %alloc_size.i.i.i.i.i.i16 = shl nuw i64 %schema.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %schema.val6, i64 noundef %alloc_size.i.i.i.i.i.i16, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb6

bb2.i.i.i.i.i20:                                  ; preds = %_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E.exit
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_14.sroa.5.0, i64 noundef %_33.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !241
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_7.sroa.6.0, i64 noundef %_33.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !241
  br label %"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E.exit"

"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E.exit": ; preds = %_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E.exit, %bb2.i.i.i.i.i20
  call void @llvm.lifetime.start.p0(ptr nonnull %_11)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_11, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %14 = getelementptr inbounds nuw i8, ptr %_11, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %14, ptr noundef nonnull align 8 dereferenceable(24) %interval_totals, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %_11, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_11)
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i.i15, %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", %"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E.exit"
  ret void
}

; <&T as core::fmt::Debug>::fmt
; Function Attrs: nounwind uwtable
define internal noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h74381398086a151dE"(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !2, !align !244, !noundef !2
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !245, !noalias !248, !noundef !2
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsC_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <u64 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsd_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <u64 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsE_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt.exit

_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&T as core::fmt::Debug>::fmt
; Function Attrs: nounwind uwtable
define internal noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17h7b64d8fa4133a980E"(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !2, !align !244, !noundef !2
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !250, !noalias !253, !noundef !2
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt.exit

_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&T as core::fmt::Debug>::fmt
; Function Attrs: nounwind uwtable
define internal noundef zeroext i1 @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E"(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #1 {
start:
  %__self_11.i = alloca [8 x i8], align 8
  %__self_1.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !2, !align !244, !noundef !2
  tail call void @llvm.experimental.noalias.scope.decl(metadata !255)
  %_3.i = load i64, ptr %_3, align 8, !range !258, !alias.scope !255, !noalias !259, !noundef !2
  switch i64 %_3.i, label %default.unreachable [
    i64 0, label %bb12.i
    i64 1, label %bb11.i
    i64 2, label %bb10.i
    i64 3, label %bb9.i
    i64 4, label %bb8.i
    i64 5, label %bb7.i
    i64 6, label %bb6.i
    i64 7, label %bb5.i
    i64 8, label %bb4.i
    i64 9, label %bb3.i
    i64 10, label %bb2.i
  ]

default.unreachable:                              ; preds = %start
  unreachable

bb12.i:                                           ; preds = %start
; call <core::fmt::Formatter>::write_str
  %0 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_5ee3dd04a3ebbd2958f69478a791f011, i64 noundef 11) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb11.i:                                           ; preds = %start
; call <core::fmt::Formatter>::write_str
  %1 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_52433ae1027e4929c7c1de5d6490f243, i64 noundef 19) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb10.i:                                           ; preds = %start
  %__self_0.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1.i), !noalias !261
  %2 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %2, ptr %__self_1.i, align 8, !noalias !261
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_ee08c9d314e4c5b701504a1a6f89727d, i64 noundef 19, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_adba73bbb963ea705e05d8e8c86355c2, i64 noundef 6, ptr noundef nonnull readonly align 1 %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf, i64 noundef 6, ptr noundef nonnull align 1 %__self_1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1.i), !noalias !261
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb9.i:                                            ; preds = %start
  %__self_02.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_11.i), !noalias !261
  %4 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %4, ptr %__self_11.i, align 8, !noalias !261
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %5 = call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_fc4accf12cdb5d5f3207e98a294cf4c2, i64 noundef 21, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_58c73da900326cd1d22dde7834877fb1, i64 noundef 8, ptr noundef nonnull readonly align 1 %__self_02.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.2, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_86933f980174c2bccf56810e0d831ebb, i64 noundef 10, ptr noundef nonnull align 1 %__self_11.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_11.i), !noalias !261
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb8.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_49160125fb4cd837bc8bd9b6ec63004a, i64 noundef 14) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb7.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_99f3a809f00b524a3a34761496eda872, i64 noundef 12) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb6.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_937ef498e46ce3dd2899f48f05d77c47, i64 noundef 18) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb5.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %9 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_f672c6af06448a01ecac398fe971f727, i64 noundef 15) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb4.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %10 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_ce01d5de1e0bacc55ae5953b06653b2d, i64 noundef 14) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb3.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %11 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_99be15a9e516526f280317bea0cca5d0, i64 noundef 17) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

bb2.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %12 = tail call noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance) @alloc_4d26e1d2bef2fb4016390b651f78947e, i64 noundef 20) #19, !noalias !255
  br label %"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit"

"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E.exit": ; preds = %bb12.i, %bb11.i, %bb10.i, %bb9.i, %bb8.i, %bb7.i, %bb6.i, %bb5.i, %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %0, %bb12.i ], [ %1, %bb11.i ], [ %3, %bb10.i ], [ %5, %bb9.i ], [ %6, %bb8.i ], [ %7, %bb7.i ], [ %8, %bb6.i ], [ %9, %bb5.i ], [ %10, %bb4.i ], [ %11, %bb3.i ], [ %12, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; core::ptr::drop_in_place<histogram_merge_errors::IntervalHistogram>
; Function Attrs: nounwind uwtable
define internal fastcc void @"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E"(ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(48) %_1) unnamed_addr #1 {
start:
  %_1.val = load i64, ptr %_1, align 8, !range !11, !noundef !2
  %0 = icmp eq i64 %_1.val, 0
  br i1 %0, label %"_ZN4core3ptr57drop_in_place$LT$histogram_merge_errors..BucketSchema$GT$17h7bafada64a242d80E.exit", label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_1, i64 8
  %_1.val2 = load ptr, ptr %1, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %_1.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %"_ZN4core3ptr57drop_in_place$LT$histogram_merge_errors..BucketSchema$GT$17h7bafada64a242d80E.exit"

"_ZN4core3ptr57drop_in_place$LT$histogram_merge_errors..BucketSchema$GT$17h7bafada64a242d80E.exit": ; preds = %start, %bb2.i.i.i.i.i
  %2 = getelementptr inbounds nuw i8, ptr %_1, i64 24
  %.val = load i64, ptr %2, align 8, !range !11, !noundef !2
  %3 = icmp eq i64 %.val, 0
  br i1 %3, label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit", label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %"_ZN4core3ptr57drop_in_place$LT$histogram_merge_errors..BucketSchema$GT$17h7bafada64a242d80E.exit"
  %4 = getelementptr inbounds nuw i8, ptr %_1, i64 32
  %.val1 = load ptr, ptr %4, align 8, !nonnull !2, !noundef !2
  %alloc_size.i.i.i.i.i = shl nuw i64 %.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr noundef nonnull %.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit"

"_ZN4core3ptr47drop_in_place$LT$alloc..vec..Vec$LT$u64$GT$$GT$17hd408d4cf2430928dE.exit": ; preds = %"_ZN4core3ptr57drop_in_place$LT$histogram_merge_errors..BucketSchema$GT$17h7bafada64a242d80E.exit", %bb2.i.i.i.i
  ret void
}

; alloc::raw_vec::RawVecInner<A>::finish_grow
; Function Attrs: cold nounwind uwtable
define internal fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE"(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) initializes((0, 8)) %_0, i64 %self.0.val, ptr %self.8.val, i64 noundef %cap) unnamed_addr #3 {
start:
  %_33.0 = shl i64 %cap, 3
  %_33.1 = icmp ult i64 %cap, 2305843009213693952
  %_38 = icmp ult i64 %_33.0, 9223372036854775801
  %or.cond = and i1 %_33.1, %_38
  br i1 %or.cond, label %bb15, label %bb11, !prof !262

bb15:                                             ; preds = %start
  %0 = icmp eq i64 %self.0.val, 0
  br i1 %0, label %bb5, label %bb3

bb3:                                              ; preds = %bb15
  %alloc_size.i = shl nuw i64 %self.0.val, 3
  %1 = icmp ne ptr %self.8.val, null
  tail call void @llvm.assume(i1 %1)
  %cond.i.i = icmp uge i64 %_33.0, %alloc_size.i
  tail call void @llvm.assume(i1 %cond.i.i)
; call __rustc::__rust_realloc
  %raw_ptr.i.i = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc14___rust_realloc(ptr noundef nonnull %self.8.val, i64 noundef %alloc_size.i, i64 noundef 8, i64 noundef range(i64 0, 9223372036854775801) %_33.0) #19
  br label %bb7

bb5:                                              ; preds = %bb15
  %2 = icmp eq i64 %_33.0, 0
  br i1 %2, label %bb9, label %bb1.i.i

bb1.i.i:                                          ; preds = %bb5
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc
  %3 = tail call noundef align 8 ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_33.0, i64 noundef 8) #19
  br label %bb7

bb7:                                              ; preds = %bb1.i.i, %bb3
  %raw_ptr.i.i.pn = phi ptr [ %raw_ptr.i.i, %bb3 ], [ %3, %bb1.i.i ]
  %4 = icmp eq ptr %raw_ptr.i.i.pn, null
  br i1 %4, label %bb8, label %bb9

bb8:                                              ; preds = %bb7
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 8, ptr %5, align 8
  br label %bb11

bb9:                                              ; preds = %bb5, %bb7
  %raw_ptr.i.i.pn8 = phi ptr [ %raw_ptr.i.i.pn, %bb7 ], [ inttoptr (i64 8 to ptr), %bb5 ]
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %raw_ptr.i.i.pn8, ptr %6, align 8
  br label %bb11

bb11:                                             ; preds = %start, %bb9, %bb8
  %.sink9 = phi i64 [ 16, %bb9 ], [ 16, %bb8 ], [ 8, %start ]
  %_33.0.sink = phi i64 [ %_33.0, %bb9 ], [ %_33.0, %bb8 ], [ 0, %start ]
  %storemerge8 = phi i64 [ 0, %bb9 ], [ 1, %bb8 ], [ 1, %start ]
  %7 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink9
  store i64 %_33.0.sink, ptr %7, align 8
  store i64 %storemerge8, ptr %_0, align 8
  ret void
}

; alloc::raw_vec::RawVecInner<A>::reserve::do_reserve_and_handle
; Function Attrs: cold nounwind uwtable
define internal fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17he73fe0b2f988e0acE"(ptr noalias noundef nonnull align 8 captures(none) dereferenceable(16) %slf, i64 noundef %len, i64 noundef %additional) unnamed_addr #3 personality ptr @rust_eh_personality {
start:
  %self3.i = alloca [24 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !263)
  %_25.0.i = add i64 %additional, %len
  %_25.1.i = icmp ult i64 %_25.0.i, %len
  br i1 %_25.1.i, label %bb2, label %bb9.i

bb9.i:                                            ; preds = %start
  %self5.i = load i64, ptr %slf, align 8, !range !11, !alias.scope !263, !noundef !2
  %v16.i = shl nuw i64 %self5.i, 1
  %..i.i = tail call noundef i64 @llvm.umax.i64(i64 %_25.0.i, i64 range(i64 0, -1) %v16.i)
  %..i16.i = tail call noundef i64 @llvm.umax.i64(i64 %..i.i, i64 4)
  call void @llvm.lifetime.start.p0(ptr nonnull %self3.i), !noalias !263
  %0 = getelementptr inbounds nuw i8, ptr %slf, i64 8
  %self.val15.i = load ptr, ptr %0, align 8, !alias.scope !263
; call alloc::raw_vec::RawVecInner<A>::finish_grow
  call fastcc void @"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h518a16fb694a4edfE"(ptr noalias noundef align 8 captures(none) dereferenceable(24) %self3.i, i64 %self5.i, ptr %self.val15.i, i64 noundef %..i16.i) #19
  %_37.i = load i64, ptr %self3.i, align 8, !range !266, !noalias !263, !noundef !2
  %1 = trunc nuw i64 %_37.i to i1
  %2 = getelementptr inbounds nuw i8, ptr %self3.i, i64 8
  br i1 %1, label %bb18.i, label %bb3

bb18.i:                                           ; preds = %bb9.i
  %e.0.i = load i64, ptr %2, align 8, !range !267, !noalias !263, !noundef !2
  %3 = getelementptr inbounds nuw i8, ptr %self3.i, i64 16
  %e.1.i = load i64, ptr %3, align 8, !noalias !263
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !263
  br label %bb2

bb2:                                              ; preds = %bb18.i, %start
  %_0.sroa.5.0.i.ph = phi i64 [ undef, %start ], [ %e.1.i, %bb18.i ]
  %_0.sroa.0.0.i.ph = phi i64 [ 0, %start ], [ %e.0.i, %bb18.i ]
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef %_0.sroa.0.0.i.ph, i64 %_0.sroa.5.0.i.ph) #20
  unreachable

bb3:                                              ; preds = %bb9.i
  %v.0.i = load ptr, ptr %2, align 8, !noalias !263, !nonnull !2, !noundef !2
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !263
  store ptr %v.0.i, ptr %0, align 8, !alias.scope !263
  %4 = icmp sgt i64 %..i16.i, -1
  tail call void @llvm.assume(i1 %4)
  store i64 %..i16.i, ptr %slf, align 8, !alias.scope !263
  ret void
}

; <histogram_merge_errors::HistogramError as core::fmt::Display>::fmt
; Function Attrs: nounwind uwtable
define noundef zeroext i1 @"_ZN77_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Display$GT$3fmt17hab127273c3d61cffE"(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(24) %formatter) unnamed_addr #1 {
start:
  %args = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %args)
  store ptr %self, ptr %args, align 8
  %_6.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 8
  store ptr @"_ZN42_$LT$$RF$T$u20$as$u20$core..fmt..Debug$GT$3fmt17he9a3d11ba9d43de8E", ptr %_6.sroa.4.0..sroa_idx, align 8
  %_18.0 = load ptr, ptr %formatter, align 8, !nonnull !2, !align !268, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %formatter, i64 8
  %_18.1 = load ptr, ptr %1, align 8, !nonnull !2, !align !244, !noundef !2
; call core::fmt::write
  %2 = call noundef zeroext i1 @_RNvNtCs6Hz1PecaLG4_4core3fmt5write(ptr noundef nonnull align 1 %_18.0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(48) %_18.1, ptr noundef nonnull @alloc_0c812808379efded5a4fb82d2790b556, ptr noundef nonnull %args) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %args)
  ret i1 %2
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable
define noundef zeroext i1 @topic44_checked_merge_four(ptr noalias noundef align 8 captures(none) dereferenceable(32) %destination, ptr noalias noundef readonly align 8 captures(none) dereferenceable(32) %source) unnamed_addr #4 {
start:
  %_5 = load i64, ptr %destination, align 8, !noundef !2
  %_6 = load i64, ptr %source, align 8, !noundef !2
  %_20.0 = add i64 %_6, %_5
  %_20.1 = icmp ult i64 %_20.0, %_5
  br i1 %_20.1, label %bb1, label %bb4, !prof !16

bb4:                                              ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %destination, i64 8
  %_9 = load i64, ptr %0, align 8, !noundef !2
  %1 = getelementptr inbounds nuw i8, ptr %source, i64 8
  %_10 = load i64, ptr %1, align 8, !noundef !2
  %_24.0 = add i64 %_10, %_9
  %_24.1 = icmp ult i64 %_24.0, %_9
  br i1 %_24.1, label %bb1, label %bb7, !prof !16

bb7:                                              ; preds = %bb4
  %2 = getelementptr inbounds nuw i8, ptr %destination, i64 16
  %_13 = load i64, ptr %2, align 8, !noundef !2
  %3 = getelementptr inbounds nuw i8, ptr %source, i64 16
  %_14 = load i64, ptr %3, align 8, !noundef !2
  %_28.0 = add i64 %_14, %_13
  %_28.1 = icmp ult i64 %_28.0, %_13
  br i1 %_28.1, label %bb1, label %bb10, !prof !16

bb10:                                             ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %destination, i64 24
  %_17 = load i64, ptr %4, align 8, !noundef !2
  %5 = getelementptr inbounds nuw i8, ptr %source, i64 24
  %_18 = load i64, ptr %5, align 8, !noundef !2
  %_32.0 = add i64 %_18, %_17
  %_32.1 = icmp ult i64 %_32.0, %_17
  br i1 %_32.1, label %bb1, label %bb13, !prof !16

bb13:                                             ; preds = %bb10
  store i64 %_20.0, ptr %destination, align 8
  store i64 %_24.0, ptr %0, align 8
  store i64 %_28.0, ptr %2, align 8
  store i64 %_32.0, ptr %4, align 8
  br label %bb1

bb1:                                              ; preds = %bb10, %bb7, %bb4, %start, %bb13
  %_0.sroa.0.0.off0 = phi i1 [ true, %bb13 ], [ false, %start ], [ false, %bb4 ], [ false, %bb7 ], [ false, %bb10 ]
  ret i1 %_0.sroa.0.0.off0
}

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #6

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; __rustc::__rust_dealloc
; Function Attrs: nounwind allockind("free") uwtable
declare void @_RNvCsfLfy6EI15iL_7___rustc14___rust_dealloc(ptr allocptr noundef captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #8

; __rustc::__rust_realloc
; Function Attrs: nounwind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias noundef ptr @_RNvCsfLfy6EI15iL_7___rustc14___rust_realloc(ptr allocptr noundef, i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807), i64 noundef) unnamed_addr #9

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind uwtable
declare void @_RNvCsfLfy6EI15iL_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #1

; __rustc::__rust_alloc
; Function Attrs: nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCsfLfy6EI15iL_7___rustc12___rust_alloc(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #10

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #11

; <u64 as core::fmt::Display>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXsd_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u64 as core::fmt::UpperHex>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXsE_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <u64 as core::fmt::LowerHex>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXsC_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::Display>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXsi_NtNtNtCs6Hz1PecaLG4_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::UpperHex>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXs8_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; <usize as core::fmt::LowerHex>::fmt
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvXs6_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #1

; Function Attrs: nounwind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #1

; core::option::expect_failed
; Function Attrs: cold noinline noreturn nounwind uwtable
declare void @_RNvNtCs6Hz1PecaLG4_4core6option13expect_failed(ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #12

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nounwind optsize uwtable
declare void @_RNvNtCs6Hz1PecaLG4_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #13

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #14

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nounwind optsize uwtable
declare void @_RNvNtCs3U9RWQJh2dM_5alloc7raw_vec12handle_error(i64 noundef range(i64 0, -9223372036854775807), i64) unnamed_addr #15

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef) unnamed_addr #1

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvMsa_NtCs6Hz1PecaLG4_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef, ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noalias noundef nonnull readonly align 1 captures(address, read_provenance), i64 noundef, ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #1

; core::fmt::write
; Function Attrs: nounwind uwtable
declare noundef zeroext i1 @_RNvNtCs6Hz1PecaLG4_4core3fmt5write(ptr noundef nonnull align 1, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #1

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: read)
declare i32 @bcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #16

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #17

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #18

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #18

attributes #0 = { inlinehint nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #1 = { nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #2 = { nofree norecurse nosync nounwind memory(read, argmem: readwrite, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #3 = { cold nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #4 = { mustprogress nofree noinline norecurse nosync nounwind willreturn memory(argmem: readwrite) uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { nounwind allockind("free") uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #9 = { nounwind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #10 = { nounwind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCsfLfy6EI15iL_7___rustc19___rust_alloc_zeroed" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #11 = { nounwind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #12 = { cold noinline noreturn nounwind uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #13 = { cold minsize noinline noreturn nounwind optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #14 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #15 = { cold minsize noreturn nounwind optsize uwtable "frame-pointer"="non-leaf" "probe-stack"="inline-asm" "target-cpu"="neoverse-v1" "target-features"="+fp-armv8,+sha2,+lse,+neon,+sm4,+sha3,+crc,+sve,+aes,+rand,+v8a,+outline-atomics" }
attributes #16 = { nocallback nofree nounwind willreturn memory(argmem: read) }
attributes #17 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #18 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #19 = { nounwind }
attributes #20 = { noreturn nounwind }
attributes #21 = { noinline noreturn nounwind }

!llvm.module.flags = !{!0}
!llvm.ident = !{!1}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{!"rustc version 1.95.0 (59807616e 2026-04-14)"}
!2 = !{}
!3 = !{!4, !6}
!4 = distinct !{!4, !5, !"_ZN22histogram_merge_errors12BucketSchema3new28_$u7b$$u7b$closure$u7d$$u7d$17hd3cff3dbbacb6f7dE: %pair.0"}
!5 = distinct !{!5, !"_ZN22histogram_merge_errors12BucketSchema3new28_$u7b$$u7b$closure$u7d$$u7d$17hd3cff3dbbacb6f7dE"}
!6 = distinct !{!6, !7, !"_ZN4core4iter6traits8iterator8Iterator3any5check28_$u7b$$u7b$closure$u7d$$u7d$17hf36b6958dfdcecd8E: %x.0"}
!7 = distinct !{!7, !"_ZN4core4iter6traits8iterator8Iterator3any5check28_$u7b$$u7b$closure$u7d$$u7d$17hf36b6958dfdcecd8E"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17hd250844b51516964E: %self"}
!10 = distinct !{!10, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17hd250844b51516964E"}
!11 = !{i64 0, i64 -9223372036854775808}
!12 = !{!13, !15}
!13 = distinct !{!13, !14, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %_0"}
!14 = distinct !{!14, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE"}
!15 = distinct !{!15, !14, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %self"}
!16 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!17 = !{!18}
!18 = distinct !{!18, !19, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE: %_0"}
!19 = distinct !{!19, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE"}
!20 = !{!18, !21}
!21 = distinct !{!21, !19, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE: %self"}
!22 = !{!23, !18}
!23 = distinct !{!23, !24, !"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$11from_output17h0f3769c029146264E: %_0"}
!24 = distinct !{!24, !"_ZN79_$LT$core..result..Result$LT$T$C$E$GT$$u20$as$u20$core..ops..try_trait..Try$GT$11from_output17h0f3769c029146264E"}
!25 = !{!21}
!26 = !{!27, !29, !18}
!27 = distinct !{!27, !28, !"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h998185d85cd258feE: %_0"}
!28 = distinct !{!28, !"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h998185d85cd258feE"}
!29 = distinct !{!29, !28, !"_ZN153_$LT$core..result..Result$LT$T$C$F$GT$$u20$as$u20$core..ops..try_trait..FromResidual$LT$core..result..Result$LT$core..convert..Infallible$C$E$GT$$GT$$GT$13from_residual17h998185d85cd258feE: %residual"}
!30 = !{!31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!31 = distinct !{!31, !32, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17haf42617379d1ef40E: %_0"}
!32 = distinct !{!32, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17haf42617379d1ef40E"}
!33 = distinct !{!33, !32, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17haf42617379d1ef40E: %iterator"}
!34 = distinct !{!34, !35, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h38afcbda990985c9E: %_0"}
!35 = distinct !{!35, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h38afcbda990985c9E"}
!36 = distinct !{!36, !35, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h38afcbda990985c9E: %iterator"}
!37 = distinct !{!37, !38, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h594092ba13a8bc59E: %_0"}
!38 = distinct !{!38, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h594092ba13a8bc59E"}
!39 = distinct !{!39, !38, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h594092ba13a8bc59E: %iter"}
!40 = distinct !{!40, !41, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E: %_0"}
!41 = distinct !{!41, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E"}
!42 = distinct !{!42, !41, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17h7058335bae7e8c20E: %i"}
!43 = distinct !{!43, !44, !"_ZN4core4iter8adapters11try_process17h1141ec64a600692fE: %_0"}
!44 = distinct !{!44, !"_ZN4core4iter8adapters11try_process17h1141ec64a600692fE"}
!45 = distinct !{!45, !44, !"_ZN4core4iter8adapters11try_process17h1141ec64a600692fE: %iter"}
!46 = !{!47, !49, !51, !52, !54, !31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!47 = distinct !{!47, !48, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h2ea7118300fe1a33E: %self"}
!48 = distinct !{!48, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h2ea7118300fe1a33E"}
!49 = distinct !{!49, !50, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E: %self"}
!50 = distinct !{!50, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E"}
!51 = distinct !{!51, !50, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E: %g.1"}
!52 = distinct !{!52, !53, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h466822d5c73250b9E: %self"}
!53 = distinct !{!53, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h466822d5c73250b9E"}
!54 = distinct !{!54, !55, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hd3ef453ce8f86097E: %self"}
!55 = distinct !{!55, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hd3ef453ce8f86097E"}
!56 = !{!57, !31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!57 = distinct !{!57, !58, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!58 = distinct !{!58, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!59 = !{!60}
!60 = distinct !{!60, !61, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17h3dbaa380e8b0c9caE: %self"}
!61 = distinct !{!61, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17h3dbaa380e8b0c9caE"}
!62 = !{!63}
!63 = distinct !{!63, !64, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h2a4396d925e9dfd9E: %self"}
!64 = distinct !{!64, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h2a4396d925e9dfd9E"}
!65 = !{!66, !68, !70, !71, !73, !63, !75, !60, !76, !31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!66 = distinct !{!66, !67, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h2ea7118300fe1a33E: %self"}
!67 = distinct !{!67, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h2ea7118300fe1a33E"}
!68 = distinct !{!68, !69, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E: %self"}
!69 = distinct !{!69, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E"}
!70 = distinct !{!70, !69, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h563f367ebcd9ea71E: %g.1"}
!71 = distinct !{!71, !72, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h466822d5c73250b9E: %self"}
!72 = distinct !{!72, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h466822d5c73250b9E"}
!73 = distinct !{!73, !74, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hd3ef453ce8f86097E: %self"}
!74 = distinct !{!74, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hd3ef453ce8f86097E"}
!75 = distinct !{!75, !64, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h2a4396d925e9dfd9E: %iterator"}
!76 = distinct !{!76, !61, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17h3dbaa380e8b0c9caE: %iter"}
!77 = !{!63, !60}
!78 = !{!75, !76, !31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!79 = !{!63, !75, !60, !76, !31, !33, !34, !36, !37, !39, !40, !42, !43, !45}
!80 = !{!33, !36, !39, !42, !43, !45}
!81 = !{!43, !45}
!82 = !{!83}
!83 = distinct !{!83, !84, !"_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E: %self"}
!84 = distinct !{!84, !"_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E"}
!85 = !{!86}
!86 = distinct !{!86, !84, !"_ZN22histogram_merge_errors17IntervalHistogram11total_count17hed21afdaa3040899E: %_0"}
!87 = !{!88, !90, !86, !83}
!88 = distinct !{!88, !89, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE: %_0"}
!89 = distinct !{!89, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE"}
!90 = distinct !{!90, !89, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h477245e0f084c4baE: %self"}
!91 = !{!92, !94}
!92 = distinct !{!92, !93, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!93 = distinct !{!93, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!94 = distinct !{!94, !95, !"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E: %_0"}
!95 = distinct !{!95, !"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E"}
!96 = !{!94}
!97 = !{!98, !100}
!98 = distinct !{!98, !99, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h9c24d6e47f72aa2fE: %self.0"}
!99 = distinct !{!99, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h9c24d6e47f72aa2fE"}
!100 = distinct !{!100, !101, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE: %self.0"}
!101 = distinct !{!101, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE"}
!102 = !{!103, !104, !105}
!103 = distinct !{!103, !99, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h9c24d6e47f72aa2fE: argument 1"}
!104 = distinct !{!104, !101, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h50d8b8c2af84baffE: argument 1"}
!105 = distinct !{!105, !106, !"_ZN22histogram_merge_errors12BucketSchema12bucket_index17h4ef8619baa5ed8f7E: %_0"}
!106 = distinct !{!106, !"_ZN22histogram_merge_errors12BucketSchema12bucket_index17h4ef8619baa5ed8f7E"}
!107 = !{!105}
!108 = !{!109, !111}
!109 = distinct !{!109, !110, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3any17hd233b86db0c0e844E: %self"}
!110 = distinct !{!110, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3any17hd233b86db0c0e844E"}
!111 = distinct !{!111, !110, !"_ZN91_$LT$core..slice..iter..Iter$LT$T$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$3any17hd233b86db0c0e844E: argument 1"}
!112 = !{!113}
!113 = distinct !{!113, !114, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17hb7967eb9471d4d2fE: %self.0"}
!114 = distinct !{!114, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17hb7967eb9471d4d2fE"}
!115 = !{!116, !109, !111}
!116 = distinct !{!116, !114, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17hb7967eb9471d4d2fE: argument 1"}
!117 = !{!118}
!118 = distinct !{!118, !119, !"_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E: %_0"}
!119 = distinct !{!119, !"_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E"}
!120 = !{!121}
!121 = distinct !{!121, !119, !"_ZN22histogram_merge_errors17IntervalHistogram5empty17h9a8a9b85d5384c88E: %schema"}
!122 = !{!123, !125, !118, !121}
!123 = distinct !{!123, !124, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!124 = distinct !{!124, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!125 = distinct !{!125, !126, !"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E: %_0"}
!126 = distinct !{!126, !"_ZN62_$LT$T$u20$as$u20$alloc..vec..spec_from_elem..SpecFromElem$GT$9from_elem17hba6adda5fefbd6f7E"}
!127 = !{!125, !118, !121}
!128 = !{!118, !121}
!129 = !{!130, !132}
!130 = distinct !{!130, !131, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h4d9e44c83effe4ccE: %self.0"}
!131 = distinct !{!131, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h4d9e44c83effe4ccE"}
!132 = distinct !{!132, !133, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h2c17599dd260a997E: %self.0"}
!133 = distinct !{!133, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h2c17599dd260a997E"}
!134 = !{!135, !136}
!135 = distinct !{!135, !131, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$16binary_search_by17h4d9e44c83effe4ccE: argument 1"}
!136 = distinct !{!136, !133, !"_ZN4core5slice29_$LT$impl$u20$$u5b$T$u5d$$GT$15partition_point17h2c17599dd260a997E: argument 1"}
!137 = !{!138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!138 = distinct !{!138, !139, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h4e907db160d65a15E: %_0"}
!139 = distinct !{!139, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h4e907db160d65a15E"}
!140 = distinct !{!140, !139, !"_ZN111_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter_nested..SpecFromIterNested$LT$T$C$I$GT$$GT$9from_iter17h4e907db160d65a15E: %iterator"}
!141 = distinct !{!141, !142, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h91595fefc00c35c2E: %_0"}
!142 = distinct !{!142, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h91595fefc00c35c2E"}
!143 = distinct !{!143, !142, !"_ZN98_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$alloc..vec..spec_from_iter..SpecFromIter$LT$T$C$I$GT$$GT$9from_iter17h91595fefc00c35c2E: %iterator"}
!144 = distinct !{!144, !145, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h43a3d17fdc9c6173E: %_0"}
!145 = distinct !{!145, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h43a3d17fdc9c6173E"}
!146 = distinct !{!146, !145, !"_ZN95_$LT$alloc..vec..Vec$LT$T$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$T$GT$$GT$9from_iter17h43a3d17fdc9c6173E: %iter"}
!147 = distinct !{!147, !148, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E: %_0"}
!148 = distinct !{!148, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E"}
!149 = distinct !{!149, !148, !"_ZN136_$LT$core..result..Result$LT$V$C$E$GT$$u20$as$u20$core..iter..traits..collect..FromIterator$LT$core..result..Result$LT$A$C$E$GT$$GT$$GT$9from_iter28_$u7b$$u7b$closure$u7d$$u7d$17he7d66c1ee5335ef3E: %i"}
!150 = distinct !{!150, !151, !"_ZN4core4iter8adapters11try_process17h17747377196e463bE: %_0"}
!151 = distinct !{!151, !"_ZN4core4iter8adapters11try_process17h17747377196e463bE"}
!152 = distinct !{!152, !151, !"_ZN4core4iter8adapters11try_process17h17747377196e463bE: %iter"}
!153 = !{!154, !156, !158, !159, !161, !138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!154 = distinct !{!154, !155, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h7cf1687aef25f44dE: %self"}
!155 = distinct !{!155, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h7cf1687aef25f44dE"}
!156 = distinct !{!156, !157, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E: %self"}
!157 = distinct !{!157, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E"}
!158 = distinct !{!158, !157, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E: %g.1"}
!159 = distinct !{!159, !160, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17hfe8ee7fb5569dfe3E: %self"}
!160 = distinct !{!160, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17hfe8ee7fb5569dfe3E"}
!161 = distinct !{!161, !162, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hedc894980f44f8b2E: %self"}
!162 = distinct !{!162, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hedc894980f44f8b2E"}
!163 = !{!164, !138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!164 = distinct !{!164, !165, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!165 = distinct !{!165, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!166 = !{!167}
!167 = distinct !{!167, !168, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17hbe467c28ea9f46e9E: %self"}
!168 = distinct !{!168, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17hbe467c28ea9f46e9E"}
!169 = !{!170}
!170 = distinct !{!170, !171, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h170264316a143c17E: %self"}
!171 = distinct !{!171, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h170264316a143c17E"}
!172 = !{!173, !175, !177, !178, !180, !170, !182, !167, !183, !138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!173 = distinct !{!173, !174, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h7cf1687aef25f44dE: %self"}
!174 = distinct !{!174, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h7cf1687aef25f44dE"}
!175 = distinct !{!175, !176, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E: %self"}
!176 = distinct !{!176, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E"}
!177 = distinct !{!177, !176, !"_ZN102_$LT$core..iter..adapters..map..Map$LT$I$C$F$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17h3dc62a82d335ce80E: %g.1"}
!178 = distinct !{!178, !179, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17hfe8ee7fb5569dfe3E: %self"}
!179 = distinct !{!179, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$8try_fold17hfe8ee7fb5569dfe3E"}
!180 = distinct !{!180, !181, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hedc894980f44f8b2E: %self"}
!181 = distinct !{!181, !"_ZN106_$LT$core..iter..adapters..GenericShunt$LT$I$C$R$GT$$u20$as$u20$core..iter..traits..iterator..Iterator$GT$4next17hedc894980f44f8b2E"}
!182 = distinct !{!182, !171, !"_ZN5alloc3vec16Vec$LT$T$C$A$GT$16extend_desugared17h170264316a143c17E: %iterator"}
!183 = distinct !{!183, !168, !"_ZN97_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$alloc..vec..spec_extend..SpecExtend$LT$T$C$I$GT$$GT$11spec_extend17hbe467c28ea9f46e9E: %iter"}
!184 = !{!170, !167}
!185 = !{!182, !183, !138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!186 = !{!170, !182, !167, !183, !138, !140, !141, !143, !144, !146, !147, !149, !150, !152}
!187 = !{!140, !143, !146, !149, !150, !152}
!188 = !{!150, !152}
!189 = !{!190, !192, !194, !195}
!190 = distinct !{!190, !191, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!191 = distinct !{!191, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!192 = distinct !{!192, !193, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %v"}
!193 = distinct !{!193, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE"}
!194 = distinct !{!194, !193, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %s.0"}
!195 = distinct !{!195, !196, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE: %_0"}
!196 = distinct !{!196, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE"}
!197 = !{!192, !194, !195}
!198 = !{!192, !195}
!199 = !{!200}
!200 = distinct !{!200, !201, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %_0"}
!201 = distinct !{!201, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E"}
!202 = !{!203, !205, !200, !206, !207}
!203 = distinct !{!203, !204, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %_0"}
!204 = distinct !{!204, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE"}
!205 = distinct !{!205, !204, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %self"}
!206 = distinct !{!206, !201, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %schema"}
!207 = distinct !{!207, !201, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %counts"}
!208 = !{!206, !207}
!209 = !{!200, !206, !207}
!210 = !{!211, !213, !215, !216}
!211 = distinct !{!211, !212, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!212 = distinct !{!212, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!213 = distinct !{!213, !214, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %v"}
!214 = distinct !{!214, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE"}
!215 = distinct !{!215, !214, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %s.0"}
!216 = distinct !{!216, !217, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE: %_0"}
!217 = distinct !{!217, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE"}
!218 = !{!213, !215, !216}
!219 = !{!213, !216}
!220 = !{!221, !223, !225, !226}
!221 = distinct !{!221, !222, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E: %_0"}
!222 = distinct !{!222, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$15try_allocate_in17h3d27477bbb425867E"}
!223 = distinct !{!223, !224, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %v"}
!224 = distinct !{!224, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE"}
!225 = distinct !{!225, !224, !"_ZN87_$LT$T$u20$as$u20$alloc..slice..$LT$impl$u20$$u5b$T$u5d$$GT$..to_vec_in..ConvertVec$GT$6to_vec17h9e9c508f7ad800ffE: %s.0"}
!226 = distinct !{!226, !227, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE: %_0"}
!227 = distinct !{!227, !"_ZN67_$LT$alloc..vec..Vec$LT$T$C$A$GT$$u20$as$u20$core..clone..Clone$GT$5clone17h21e2e4981eacb87dE"}
!228 = !{!223, !225, !226}
!229 = !{!223, !226}
!230 = !{!231}
!231 = distinct !{!231, !232, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %_0"}
!232 = distinct !{!232, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E"}
!233 = !{!234, !236, !231, !237, !238}
!234 = distinct !{!234, !235, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %_0"}
!235 = distinct !{!235, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE"}
!236 = distinct !{!236, !235, !"_ZN4core4iter6traits8iterator8Iterator8try_fold17h1eef65f4af3fbe4cE: %self"}
!237 = distinct !{!237, !232, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %schema"}
!238 = distinct !{!238, !232, !"_ZN22histogram_merge_errors17IntervalHistogram11from_counts17hfdbe8685ebf1dc99E: %counts"}
!239 = !{!237, !238}
!240 = !{!231, !237, !238}
!241 = !{!242}
!242 = distinct !{!242, !243, !"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E: %_1"}
!243 = distinct !{!243, !"_ZN4core3ptr62drop_in_place$LT$histogram_merge_errors..IntervalHistogram$GT$17h2cd836c24d9a75c6E"}
!244 = !{i64 8}
!245 = !{!246}
!246 = distinct !{!246, !247, !"_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt: %f"}
!247 = distinct !{!247, !"_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt"}
!248 = !{!249}
!249 = distinct !{!249, !247, !"_RNvXsX_NtNtCs6Hz1PecaLG4_4core3fmt3numyNtB7_5Debug3fmt: %self"}
!250 = !{!251}
!251 = distinct !{!251, !252, !"_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt: %f"}
!252 = distinct !{!252, !"_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt"}
!253 = !{!254}
!254 = distinct !{!254, !252, !"_RNvXsZ_NtNtCs6Hz1PecaLG4_4core3fmt3numjNtB7_5Debug3fmt: %self"}
!255 = !{!256}
!256 = distinct !{!256, !257, !"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E: %self"}
!257 = distinct !{!257, !"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E"}
!258 = !{i64 0, i64 11}
!259 = !{!260}
!260 = distinct !{!260, !257, !"_ZN75_$LT$histogram_merge_errors..HistogramError$u20$as$u20$core..fmt..Debug$GT$3fmt17h391d67d31a27afe7E: %f"}
!261 = !{!256, !260}
!262 = !{!"branch_weights", i32 2000, i32 2002}
!263 = !{!264}
!264 = distinct !{!264, !265, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$14grow_amortized17hd6ea9463a1ec7214E: %self"}
!265 = distinct !{!265, !"_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$14grow_amortized17hd6ea9463a1ec7214E"}
!266 = !{i64 0, i64 2}
!267 = !{i64 0, i64 -9223372036854775807}
!268 = !{i64 1}
