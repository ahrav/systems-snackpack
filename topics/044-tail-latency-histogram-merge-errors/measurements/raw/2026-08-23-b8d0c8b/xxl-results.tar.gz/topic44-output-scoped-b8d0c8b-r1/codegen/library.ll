; ModuleID = 'histogram_merge_errors.e5c864da82682430-cgu.0'
source_filename = "histogram_merge_errors.e5c864da82682430-cgu.0"
target datalayout = "e-m:e-p270:32:32-p271:32:32-p272:64:64-i64:64-i128:128-f80:128-n8:16:32:64-S128"
target triple = "x86_64-unknown-linux-gnu"

@alloc_5b145d9140118075524495df4810a119 = private unnamed_addr constant [168 x i8] c"/tmp/topic44-output-scoped-b8d0c8b-r1/.work/source/systems-snackpack-b8d0c8b06bd29dab090d40f18aa6aa086b5fdf76/topics/044-tail-latency-histogram-merge-errors/src/lib.rs\00", align 1
@alloc_4ed059f71d51ae16bc6826f989989385 = private unnamed_addr constant [30 x i8] c"a validated schema is nonempty", align 1
@alloc_72e1b02f1dc44543daa9de23d3bba29e = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00?\00\00\00\16\00\00\00" }>, align 8
@alloc_9034bc150239ddb23220298f62c78c3d = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\EB\00\00\00D\00\00\00" }>, align 8
@alloc_713e1b0d46806bc8c2cd07e9f5848152 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\EC\00\00\00D\00\00\00" }>, align 8
@alloc_96d0d7cd51bf3727855c17e0e20001f5 = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\85\00\00\00)\00\00\00" }>, align 8
@alloc_4902ffe043ff59a1d70cb2012e4b3cfd = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\0D\01\00\00;\00\00\00" }>, align 8
@alloc_4583e6a49f6781f6842cac8cdb2523af = private unnamed_addr constant <{ ptr, [16 x i8] }> <{ ptr @alloc_5b145d9140118075524495df4810a119, [16 x i8] c"\A7\00\00\00\00\00\00\00\12\01\00\008\00\00\00" }>, align 8
@alloc_0c812808379efded5a4fb82d2790b556 = private unnamed_addr constant [2 x i8] c"\C0\00", align 1
@alloc_5ee3dd04a3ebbd2958f69478a791f011 = private unnamed_addr constant [11 x i8] c"EmptySchema", align 1
@alloc_52433ae1027e4929c7c1de5d6490f243 = private unnamed_addr constant [19 x i8] c"NonIncreasingBounds", align 1
@vtable.0 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt }>, align 8
@vtable.1 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors }>, align 8
@alloc_ee08c9d314e4c5b701504a1a6f89727d = private unnamed_addr constant [19 x i8] c"BucketCountMismatch", align 1
@alloc_adba73bbb963ea705e05d8e8c86355c2 = private unnamed_addr constant [6 x i8] c"bounds", align 1
@alloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf = private unnamed_addr constant [6 x i8] c"counts", align 1
@vtable.2 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt }>, align 8
@vtable.3 = private unnamed_addr constant <{ [24 x i8], ptr }> <{ [24 x i8] c"\00\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00\08\00\00\00\00\00\00\00", ptr @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors }>, align 8
@alloc_fc4accf12cdb5d5f3207e98a294cf4c2 = private unnamed_addr constant [21 x i8] c"ObservationOutOfRange", align 1
@alloc_58c73da900326cd1d22dde7834877fb1 = private unnamed_addr constant [8 x i8] c"value_us", align 1
@alloc_86933f980174c2bccf56810e0d831ebb = private unnamed_addr constant [10 x i8] c"maximum_us", align 1
@alloc_49160125fb4cd837bc8bd9b6ec63004a = private unnamed_addr constant [14 x i8] c"SchemaMismatch", align 1
@alloc_99f3a809f00b524a3a34761496eda872 = private unnamed_addr constant [12 x i8] c"CounterReset", align 1
@alloc_937ef498e46ce3dd2899f48f05d77c47 = private unnamed_addr constant [18 x i8] c"ArithmeticOverflow", align 1
@alloc_f672c6af06448a01ecac398fe971f727 = private unnamed_addr constant [15 x i8] c"InvalidQuantile", align 1
@alloc_ce01d5de1e0bacc55ae5953b06653b2d = private unnamed_addr constant [14 x i8] c"EmptyHistogram", align 1
@alloc_99be15a9e516526f280317bea0cca5d0 = private unnamed_addr constant [17 x i8] c"InvalidCoarsening", align 1
@alloc_4d26e1d2bef2fb4016390b651f78947e = private unnamed_addr constant [20 x i8] c"CountInvariantBroken", align 1

; core::ptr::drop_glue::<histogram_merge_errors::IntervalHistogram>
; Function Attrs: nounwind nonlazybind uwtable
define internal fastcc void @_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_(ptr noalias noundef nonnull readonly align 8 captures(none) dereferenceable(48) %_1) unnamed_addr #0 {
start:
  %_1.val = load i64, ptr %_1, align 8, !range !3, !noundef !4
  %0 = icmp eq i64 %_1.val, 0
  br i1 %0, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors12BucketSchemaEBD_.exit, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_1, i64 8
  %_1.val2 = load ptr, ptr %1, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %_1.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_1.val2, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors12BucketSchemaEBD_.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors12BucketSchemaEBD_.exit: ; preds = %start, %bb2.i.i.i.i.i
  %2 = getelementptr inbounds nuw i8, ptr %_1, i64 24
  %.val = load i64, ptr %2, align 8, !range !3, !noundef !4
  %3 = icmp eq i64 %.val, 0
  br i1 %3, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors12BucketSchemaEBD_.exit
  %4 = getelementptr inbounds nuw i8, ptr %_1, i64 32
  %.val1 = load ptr, ptr %4, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i = shl nuw i64 %.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors12BucketSchemaEBD_.exit, %bb2.i.i.i.i
  ret void
}

; <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
; Function Attrs: cold nounwind nonlazybind uwtable
define internal fastcc void @_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef nonnull align 8 captures(none) dereferenceable(16) %slf, i64 noundef %len, i64 noundef %additional) unnamed_addr #1 personality ptr @rust_eh_personality {
start:
  %self3.i = alloca [24 x i8], align 8
  tail call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %_25.0.i = add i64 %additional, %len
  %_25.1.i = icmp ult i64 %_25.0.i, %len
  br i1 %_25.1.i, label %bb2, label %bb9.i

bb9.i:                                            ; preds = %start
  %self5.i = load i64, ptr %slf, align 8, !range !3, !alias.scope !5, !noundef !4
  %v16.i = shl nuw i64 %self5.i, 1
  %..i.i = tail call noundef i64 @llvm.umax.i64(i64 %_25.0.i, i64 range(i64 0, -1) %v16.i)
  %..i16.i = tail call noundef i64 @llvm.umax.i64(i64 %..i.i, i64 4)
  call void @llvm.lifetime.start.p0(ptr nonnull %self3.i), !noalias !5
  %0 = getelementptr inbounds nuw i8, ptr %slf, i64 8
  %self.val15.i = load ptr, ptr %0, align 8, !alias.scope !5
; call <alloc::raw_vec::RawVecInner>::finish_grow
  call fastcc void @_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef align 8 captures(none) dereferenceable(24) %self3.i, i64 %self5.i, ptr %self.val15.i, i64 noundef %..i16.i) #19
  %_37.i = load i64, ptr %self3.i, align 8, !range !8, !noalias !5, !noundef !4
  %1 = trunc nuw i64 %_37.i to i1
  %2 = getelementptr inbounds nuw i8, ptr %self3.i, i64 8
  br i1 %1, label %bb18.i, label %bb3

bb18.i:                                           ; preds = %bb9.i
  %e.0.i = load i64, ptr %2, align 8, !range !9, !noalias !5, !noundef !4
  %3 = getelementptr inbounds nuw i8, ptr %self3.i, i64 16
  %e.1.i = load i64, ptr %3, align 8, !noalias !5
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !5
  br label %bb2

bb2:                                              ; preds = %bb18.i, %start
  %_0.sroa.5.0.i.ph = phi i64 [ undef, %start ], [ %e.1.i, %bb18.i ]
  %_0.sroa.0.0.i.ph = phi i64 [ 0, %start ], [ %e.0.i, %bb18.i ]
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef %_0.sroa.0.0.i.ph, i64 %_0.sroa.5.0.i.ph) #20
  unreachable

bb3:                                              ; preds = %bb9.i
  %v.0.i = load ptr, ptr %2, align 8, !noalias !5, !nonnull !4, !noundef !4
  call void @llvm.lifetime.end.p0(ptr nonnull %self3.i), !noalias !5
  store ptr %v.0.i, ptr %0, align 8, !alias.scope !5
  %4 = icmp sgt i64 %..i16.i, -1
  tail call void @llvm.assume(i1 %4)
  store i64 %..i16.i, ptr %slf, align 8, !alias.scope !5
  ret void
}

; <histogram_merge_errors::BucketSchema>::new
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new(ptr dead_on_unwind noalias noundef writable writeonly sret([32 x i8]) align 8 captures(none) dereferenceable(32) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %upper_bounds_us) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 16
  %_10 = load i64, ptr %0, align 8, !noundef !4
  %_11 = icmp ult i64 %_10, 1152921504606846976
  tail call void @llvm.assume(i1 %_11)
  %1 = icmp eq i64 %_10, 0
  br i1 %1, label %bb5, label %bb2

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 8
  %_15 = load ptr, ptr %2, align 8, !nonnull !4, !noundef !4
  br label %bb1.us.i

bb1.us.i:                                         ; preds = %bb2, %bb3.us.i
  %_28.i9.us.i = phi ptr [ %_28.i.us.i, %bb3.us.i ], [ %_15, %bb2 ]
  %new_len.i8.us.i = phi i64 [ %new_len.i.us.i, %bb3.us.i ], [ %_10, %bb2 ]
  %_2.i.us.not.not.i = icmp ult i64 %new_len.i8.us.i, 2
  br i1 %_2.i.us.not.not.i, label %bb4, label %bb3.us.i

bb3.us.i:                                         ; preds = %bb1.us.i
  %new_len.i.us.i = add nsw i64 %new_len.i8.us.i, -1
  %_28.i.us.i = getelementptr inbounds nuw i8, ptr %_28.i9.us.i, i64 8
  %_3.i.i.us.i = load i64, ptr %_28.i9.us.i, align 8, !alias.scope !10, !noalias !15, !noundef !4
  %_6.i.i.us.i = load i64, ptr %_28.i.us.i, align 8, !alias.scope !10, !noalias !15, !noundef !4
  %_0.i.i.not.us.i = icmp ult i64 %_3.i.i.us.i, %_6.i.i.us.i
  br i1 %_0.i.i.not.us.i, label %bb1.us.i, label %bb5

bb5:                                              ; preds = %bb3.us.i, %start
  %.sink = phi i64 [ 0, %start ], [ 1, %bb3.us.i ]
  %3 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %.sink, ptr %3, align 8
  store i64 1, ptr %_0, align 8
  %upper_bounds_us.val = load i64, ptr %upper_bounds_us, align 8, !range !3, !noundef !4
  %4 = icmp eq i64 %upper_bounds_us.val, 0
  br i1 %4, label %bb6, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb5
  %5 = getelementptr inbounds nuw i8, ptr %upper_bounds_us, i64 8
  %upper_bounds_us.val1 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i = shl nuw i64 %upper_bounds_us.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %upper_bounds_us.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb6

bb4:                                              ; preds = %bb1.us.i
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %6, ptr noundef nonnull align 8 dereferenceable(24) %upper_bounds_us, i64 24, i1 false)
  store i64 0, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i, %bb5, %bb4
  ret void
}

; <histogram_merge_errors::CumulativeHistogram>::delta_since
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %older) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %vector.i.i.i.i.i = alloca [24 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_15 = load i64, ptr %0, align 8, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %older, i64 16
  %_17 = load i64, ptr %1, align 8, !noundef !4
  %_19 = icmp eq i64 %_15, %_17
  br i1 %_19, label %bb7, label %bb1

bb7:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %older, i64 8
  %_18 = load ptr, ptr %2, align 8, !nonnull !4, !noundef !4
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_16 = load ptr, ptr %3, align 8, !nonnull !4, !noundef !4
  %_20 = shl nuw i64 %_15, 3
  %bcmp = tail call i32 @bcmp(ptr nonnull %_16, ptr nonnull %_18, i64 %_20)
  %_14.not = icmp eq i32 %bcmp, 0
  br i1 %_14.not, label %bb2, label %bb1

bb1:                                              ; preds = %start, %bb7
  %4 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 4, ptr %4, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %bb7
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_27 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_26 = load i64, ptr %6, align 8, !noundef !4
  %7 = getelementptr inbounds nuw i8, ptr %older, i64 32
  %_10.val = load ptr, ptr %7, align 8, !nonnull !4, !noundef !4
  %8 = getelementptr inbounds nuw i8, ptr %older, i64 40
  %_10.val1 = load i64, ptr %8, align 8, !noundef !4
  %..i.i.i = tail call noundef i64 @llvm.umin.i64(i64 %_10.val1, i64 %_26)
  call void @llvm.lifetime.start.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !18
  %_2.i.i.i.i.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 0
  br i1 %_2.i.i.i.i.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2
  %.val.i.i.i.i.i.i.i.i.i = load i64, ptr %_27, align 8, !noalias !34, !noundef !4
  %.val3.i.i.i.i.i.i.i.i.i = load i64, ptr %_10.val, align 8, !noalias !34, !noundef !4
  %_9.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %.val.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i
  br i1 %_9.i.i.i.i.i.i.i.i.i.i.i, label %bb4.thread.i, label %bb3.i.i.i.i.i.i.i

bb4.thread.i:                                     ; preds = %bb3.i.i.i.i.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !18
  br label %bb11

bb3.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !44
; call __rustc::__rust_alloc
  %9 = tail call noundef align 8 dereferenceable_or_null(32) ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) 32, i64 noundef 8) #19, !noalias !44
  %10 = icmp eq ptr %9, null
  br i1 %10, label %bb3.i.i.i.i.i.i, label %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i

bb3.i.i.i.i.i.i:                                  ; preds = %bb3.i.i.i.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 32) #20, !noalias !18
  unreachable

_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i: ; preds = %bb3.i.i.i.i.i.i.i
  %_10.i.i4.i.i.i.i.i.i.i.i.i = sub nuw i64 %.val.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i
  store i64 %_10.i.i4.i.i.i.i.i.i.i.i.i, ptr %9, align 8, !noalias !18
  store i64 4, ptr %vector.i.i.i.i.i, align 8, !noalias !18
  %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 8
  store ptr %9, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !18
  %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 16
  store i64 1, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !18
  tail call void @llvm.experimental.noalias.scope.decl(metadata !47)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !50)
  %_2.i.i.i.i.i.i5.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 1
  br i1 %_2.i.i.i.i.i.i5.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i3.i.i.i.i.i

bb3.i.i.i.i.i.i3.i.i.i.i.i:                       ; preds = %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i, %bb8.i.i.i.i.i.i.i
  %_23.i.i10.i.i.i.i.i = phi ptr [ %_23.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ %9, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %len.i.i.i.i.i.i.i = phi i64 [ %new_len.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ 1, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %new_len.i.i.i.i.i.i.i = add nuw nsw i64 %len.i.i.i.i.i.i.i, 1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_27, i64 %len.i.i.i.i.i.i.i
  %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_10.val, i64 %len.i.i.i.i.i.i.i
  %.val.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !53, !noundef !4
  %.val3.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !53, !noundef !4
  %_9.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %.val.i.i.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i.i.i
  br i1 %_9.i.i.i.i.i.i.i.i.i.i.i.i.i, label %bb4.i, label %bb3.i.i4.i.i.i.i.i

bb3.i.i4.i.i.i.i.i:                               ; preds = %bb3.i.i.i.i.i.i3.i.i.i.i.i
  %_10.i.i4.i.i.i.i.i.i.i.i.i.i.i = sub nuw i64 %.val.i.i.i.i.i.i.i.i.i.i.i, %.val3.i.i.i.i.i.i.i.i.i.i.i
  %_19.i.i.i.i.i.i.i = icmp samesign ult i64 %len.i.i.i.i.i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i.i.i.i.i.i.i)
  %self1.i.i.i.i.i.i.i = load i64, ptr %vector.i.i.i.i.i, align 8, !range !3, !alias.scope !65, !noalias !66, !noundef !4
  %_8.i.i5.i.i.i.i.i = icmp eq i64 %len.i.i.i.i.i.i.i, %self1.i.i.i.i.i.i.i
  br i1 %_8.i.i5.i.i.i.i.i, label %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i, label %bb8.i.i.i.i.i.i.i

_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i: ; preds = %bb3.i.i4.i.i.i.i.i
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call fastcc void @_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef nonnull align 8 dereferenceable(24) %vector.i.i.i.i.i, i64 noundef %len.i.i.i.i.i.i.i, i64 noundef 1) #19
  %_23.i.i.pre.i.i.i.i.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !65, !noalias !66
  br label %bb8.i.i.i.i.i.i.i

bb8.i.i.i.i.i.i.i:                                ; preds = %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i, %bb3.i.i4.i.i.i.i.i
  %_23.i.i.i.i.i.i.i = phi ptr [ %_23.i.i.pre.i.i.i.i.i, %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i ], [ %_23.i.i10.i.i.i.i.i, %bb3.i.i4.i.i.i.i.i ]
  %dst.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_23.i.i.i.i.i.i.i, i64 %len.i.i.i.i.i.i.i
  store i64 %_10.i.i4.i.i.i.i.i.i.i.i.i.i.i, ptr %dst.i.i.i.i.i.i.i, align 8, !noalias !67
  store i64 %new_len.i.i.i.i.i.i.i, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !65, !noalias !66
  %exitcond.not.i.i.i.i.i.i.i = icmp eq i64 %new_len.i.i.i.i.i.i.i, %..i.i.i
  br i1 %exitcond.not.i.i.i.i.i.i.i, label %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_.exit.thread24.loopexit.i, label %bb3.i.i.i.i.i.i3.i.i.i.i.i

_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_.exit.thread24.loopexit.i: ; preds = %bb8.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload226.pre.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !68
  %value.sroa.6.0.copyload327.pre.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !68
  br label %bb12

bb4.i:                                            ; preds = %bb3.i.i.i.i.i.i3.i.i.i.i.i
  %value.sroa.0.0.copyload2.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !68
  %value.sroa.6.0.copyload3.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !68
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !18
  %11 = icmp eq i64 %value.sroa.0.0.copyload2.i, 0
  br i1 %11, label %bb11, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb4.i
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %value.sroa.0.0.copyload2.i, 3
  %12 = icmp ne ptr %value.sroa.6.0.copyload3.i, null
  tail call void @llvm.assume(i1 %12)
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.0.copyload3.i, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !69
  br label %bb11

bb11:                                             ; preds = %bb4.thread.i, %bb4.i, %bb2.i.i.i.i.i
  %13 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 5, ptr %13, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb12:                                             ; preds = %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_.exit.thread24.loopexit.i, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i, %bb2
  %value.sroa.0.014.i = phi i64 [ 0, %bb2 ], [ %value.sroa.0.0.copyload226.pre.i, %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_.exit.thread24.loopexit.i ], [ 4, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %value.sroa.6.013.i = phi ptr [ inttoptr (i64 8 to ptr), %bb2 ], [ %value.sroa.6.0.copyload327.pre.i, %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_.exit.thread24.loopexit.i ], [ %9, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !18
  %14 = icmp eq i64 %_15, 0
  br i1 %14, label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb3.i.i.i.i

bb3.i.i.i.i:                                      ; preds = %bb12
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !70
; call __rustc::__rust_alloc
  %15 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_20, i64 noundef 8) #19, !noalias !70
  %16 = icmp eq ptr %15, null
  br i1 %16, label %bb3.i.i.i, label %bb1.i.i

bb3.i.i.i:                                        ; preds = %bb3.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_20) #20, !noalias !78
  unreachable

bb1.i.i:                                          ; preds = %bb3.i.i.i.i
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %15, ptr nonnull readonly align 8 %_16, i64 %_20, i1 false), !noalias !79
  br label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit

_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %bb12, %bb1.i.i
  %_40.sroa.5.0 = phi ptr [ %15, %bb1.i.i ], [ inttoptr (i64 8 to ptr), %bb12 ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !80)
  %_18.i = icmp samesign ult i64 %..i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_18.i)
  %_19.i = icmp ult i64 %_15, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i)
  %_3.not.i = icmp eq i64 %..i.i.i, %_15
  br i1 %_3.not.i, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit
  %17 = icmp ne ptr %value.sroa.6.013.i, null
  tail call void @llvm.assume(i1 %17)
  %_29.i = getelementptr inbounds nuw i64, ptr %value.sroa.6.013.i, i64 %_15
  br label %bb1.i.i5

bb1.i.i5:                                         ; preds = %bb3.i.i, %bb2.i
  %_16.i24.i.i = phi ptr [ %value.sroa.6.013.i, %bb2.i ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_29.i
  br i1 %_6.i.i.i, label %bb9.i, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i5
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !83, !noundef !4
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb5.i, label %bb1.i.i5, !prof !89

bb1.i:                                            ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit
  %18 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 2, ptr %18, align 8, !alias.scope !80, !noalias !90
  br label %bb5.i

bb9.i:                                            ; preds = %bb1.i.i5
  store i64 %_15, ptr %_0, align 8, !noalias !90
  %_15.i.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %_40.sroa.5.0, ptr %_15.i.sroa.4.0._0.sroa_idx, align 8, !noalias !90
  %_15.i.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_15, ptr %_15.i.sroa.5.0._0.sroa_idx, align 8, !noalias !90
  %_15.i.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %value.sroa.0.014.i, ptr %_15.i.sroa.6.0._0.sroa_idx, align 8, !noalias !90
  %_15.i.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %value.sroa.6.013.i, ptr %_15.i.sroa.7.0._0.sroa_idx, align 8, !noalias !90
  %_15.i.sroa.8.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_15, ptr %_15.i.sroa.8.0._0.sroa_idx, align 8, !noalias !90
  br label %bb6

bb5.i:                                            ; preds = %bb3.i.i, %bb1.i
  %.sink14.i = phi i64 [ 16, %bb1.i ], [ 8, %bb3.i.i ]
  %_5.sink.i = phi i64 [ %_15, %bb1.i ], [ 6, %bb3.i.i ]
  %.sink.i = phi i64 [ 24, %bb1.i ], [ 16, %bb3.i.i ]
  %_4.sink.i = phi i64 [ %..i.i.i, %bb1.i ], [ %_9.sroa.5.0.i.i, %bb3.i.i ]
  %_6.sroa.4.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink14.i
  store i64 %_5.sink.i, ptr %_6.sroa.4.0..sroa_idx.i, align 8, !alias.scope !80, !noalias !90
  %_6.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink.i
  store i64 %_4.sink.i, ptr %_6.sroa.5.0..sroa_idx.i, align 8, !alias.scope !80, !noalias !90
  store i64 -1, ptr %_0, align 8, !alias.scope !80, !noalias !90
  %19 = icmp eq i64 %value.sroa.0.014.i, 0
  br i1 %19, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i, label %bb2.i.i.i.i.i3

bb2.i.i.i.i.i3:                                   ; preds = %bb5.i
  %20 = icmp ne ptr %value.sroa.6.013.i, null
  tail call void @llvm.assume(i1 %20)
  %alloc_size.i.i.i.i.i.i4 = shl nuw i64 %value.sroa.0.014.i, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.013.i, i64 noundef %alloc_size.i.i.i.i.i.i4, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !91
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i: ; preds = %bb2.i.i.i.i.i3, %bb5.i
  br i1 %14, label %bb6, label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_40.sroa.5.0, i64 noundef %_20, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !91
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i.i.i, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i, %bb9.i, %bb1, %bb11
  ret void
}

; <histogram_merge_errors::CumulativeHistogram>::new
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %interval_totals) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_11 = alloca [48 x i8], align 8
  %_5.sroa.7 = alloca i64, align 8
  %_5.sroa.11 = alloca i64, align 8
  %_5.sroa.13 = alloca i64, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.7)
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.11)
  call void @llvm.lifetime.start.p0(ptr nonnull %_5.sroa.13)
  %0 = getelementptr inbounds nuw i8, ptr %schema, i64 8
  %schema.val = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %schema.val5 = load i64, ptr %1, align 8, !noundef !4
  %_34.0.i.i.i.i = shl nuw nsw i64 %schema.val5, 3
  %2 = icmp eq i64 %schema.val5, 0
  br i1 %2, label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb3.i.i.i.i

bb3.i.i.i.i:                                      ; preds = %start
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !92
; call __rustc::__rust_alloc
  %3 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_34.0.i.i.i.i, i64 noundef 8) #19, !noalias !92
  %4 = icmp eq ptr %3, null
  br i1 %4, label %bb3.i.i.i, label %bb1.i.i

bb3.i.i.i:                                        ; preds = %bb3.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_34.0.i.i.i.i) #20, !noalias !100
  unreachable

bb1.i.i:                                          ; preds = %bb3.i.i.i.i
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %3, ptr nonnull readonly align 8 %schema.val, i64 %_34.0.i.i.i.i, i1 false), !noalias !101
  br label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit

_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %start, %bb1.i.i
  %_14.sroa.5.0 = phi ptr [ %3, %bb1.i.i ], [ inttoptr (i64 8 to ptr), %start ]
  %5 = getelementptr inbounds nuw i8, ptr %interval_totals, i64 8
  %interval_totals.val3 = load ptr, ptr %5, align 8, !nonnull !4, !noundef !4
  %6 = getelementptr inbounds nuw i8, ptr %interval_totals, i64 16
  %interval_totals.val4 = load i64, ptr %6, align 8, !noundef !4
  %_34.0.i.i.i.i8 = shl nuw nsw i64 %interval_totals.val4, 3
  %7 = icmp eq i64 %interval_totals.val4, 0
  br i1 %7, label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit13, label %bb3.i.i.i.i9

bb3.i.i.i.i9:                                     ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !102
; call __rustc::__rust_alloc
  %8 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_34.0.i.i.i.i8, i64 noundef 8) #19, !noalias !102
  %9 = icmp eq ptr %8, null
  br i1 %9, label %bb3.i.i.i11, label %bb1.i.i10

bb3.i.i.i11:                                      ; preds = %bb3.i.i.i.i9
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_34.0.i.i.i.i8) #20, !noalias !110
  unreachable

bb1.i.i10:                                        ; preds = %bb3.i.i.i.i9
  tail call void @llvm.memcpy.p0.p0.i64(ptr nonnull align 8 %8, ptr nonnull readonly align 8 %interval_totals.val3, i64 %_34.0.i.i.i.i8, i1 false), !noalias !111
  br label %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit13

_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit13: ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit, %bb1.i.i10
  %_7.sroa.6.0 = phi ptr [ %8, %bb1.i.i10 ], [ inttoptr (i64 8 to ptr), %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit ]
  tail call void @llvm.experimental.noalias.scope.decl(metadata !112)
  %_18.i = icmp ult i64 %interval_totals.val4, 1152921504606846976
  tail call void @llvm.assume(i1 %_18.i)
  %_19.i = icmp ult i64 %schema.val5, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i)
  %_3.not.i = icmp eq i64 %interval_totals.val4, %schema.val5
  br i1 %_3.not.i, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit13
  %_29.i = getelementptr inbounds nuw i64, ptr %_7.sroa.6.0, i64 %schema.val5
  br label %bb1.i.i14

bb1.i.i14:                                        ; preds = %bb3.i.i, %bb2.i
  %_16.i24.i.i = phi ptr [ %_7.sroa.6.0, %bb2.i ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb2.i ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_29.i
  br i1 %_6.i.i.i, label %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts.exit, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i14
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !115, !noundef !4
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb5.i, label %bb1.i.i14, !prof !89

bb1.i:                                            ; preds = %_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors.exit13
  store i64 2, ptr %_5.sroa.7, align 8, !alias.scope !112, !noalias !121
  br label %bb5.i

bb5.i:                                            ; preds = %bb3.i.i, %bb1.i
  %.sink14.i.sroa.phi = phi ptr [ %_5.sroa.11, %bb1.i ], [ %_5.sroa.7, %bb3.i.i ]
  %_5.sink.i = phi i64 [ %schema.val5, %bb1.i ], [ 6, %bb3.i.i ]
  %.sink.i.sroa.phi = phi ptr [ %_5.sroa.13, %bb1.i ], [ %_5.sroa.11, %bb3.i.i ]
  %_4.sink.i = phi i64 [ %interval_totals.val4, %bb1.i ], [ %_9.sroa.5.0.i.i, %bb3.i.i ]
  store i64 %_5.sink.i, ptr %.sink14.i.sroa.phi, align 8, !alias.scope !112, !noalias !121
  store i64 %_4.sink.i, ptr %.sink.i.sroa.phi, align 8, !alias.scope !112, !noalias !121
  br i1 %7, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb5.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_7.sroa.6.0, i64 noundef %_34.0.i.i.i.i8, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !122
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i: ; preds = %bb2.i.i.i.i.i, %bb5.i
  br i1 %2, label %bb8, label %bb2.i.i.i.i.i.i

bb2.i.i.i.i.i.i:                                  ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_14.sroa.5.0, i64 noundef %_34.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !122
  br label %bb8

_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts.exit: ; preds = %bb1.i.i14
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.11)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.13)
  br i1 %2, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_.exit, label %bb2.i.i.i.i.i20

bb8:                                              ; preds = %bb2.i.i.i.i.i.i, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit.i
  %_5.sroa.7.0._5.sroa.7.0._5.sroa.7.0._5.sroa.7.8.copyload = load i64, ptr %_5.sroa.7, align 8
  %_5.sroa.11.0._5.sroa.11.0._5.sroa.11.0._5.sroa.11.8.copyload = load i64, ptr %_5.sroa.11, align 8
  %_5.sroa.13.0._5.sroa.13.0._5.sroa.13.0._5.sroa.13.8.copyload = load i64, ptr %_5.sroa.13, align 8
  %10 = inttoptr i64 %_5.sroa.7.0._5.sroa.7.0._5.sroa.7.0._5.sroa.7.8.copyload to ptr
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.7)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.11)
  call void @llvm.lifetime.end.p0(ptr nonnull %_5.sroa.13)
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %10, ptr %11, align 8
  %_21.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_5.sroa.11.0._5.sroa.11.0._5.sroa.11.0._5.sroa.11.8.copyload, ptr %_21.sroa.4.0..sroa_idx, align 8
  %_21.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_5.sroa.13.0._5.sroa.13.0._5.sroa.13.0._5.sroa.13.8.copyload, ptr %_21.sroa.5.0..sroa_idx, align 8
  store i64 -1, ptr %_0, align 8
  %interval_totals.val = load i64, ptr %interval_totals, align 8, !range !3, !noundef !4
  %12 = icmp eq i64 %interval_totals.val, 0
  br i1 %12, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb8
  %alloc_size.i.i.i.i.i = shl nuw i64 %interval_totals.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %interval_totals.val3, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %bb8, %bb2.i.i.i.i
  %schema.val6 = load i64, ptr %schema, align 8, !range !3, !noundef !4
  %13 = icmp eq i64 %schema.val6, 0
  br i1 %13, label %bb6, label %bb2.i.i.i.i.i15

bb2.i.i.i.i.i15:                                  ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit
  %alloc_size.i.i.i.i.i.i16 = shl nuw i64 %schema.val6, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %schema.val, i64 noundef %alloc_size.i.i.i.i.i.i16, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb6

bb2.i.i.i.i.i20:                                  ; preds = %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts.exit
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_14.sroa.5.0, i64 noundef %_34.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !123
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %_7.sroa.6.0, i64 noundef %_34.0.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !123
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_.exit: ; preds = %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts.exit, %bb2.i.i.i.i.i20
  call void @llvm.lifetime.start.p0(ptr nonnull %_11)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_11, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %14 = getelementptr inbounds nuw i8, ptr %_11, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %14, ptr noundef nonnull align 8 dereferenceable(24) %interval_totals, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %_11, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_11)
  br label %bb6

bb6:                                              ; preds = %bb2.i.i.i.i.i15, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_.exit
  ret void
}

; <alloc::raw_vec::RawVecInner>::finish_grow
; Function Attrs: cold nounwind nonlazybind uwtable
define internal fastcc void @_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors(ptr dead_on_unwind noalias noundef nonnull writable writeonly align 8 captures(none) dereferenceable(24) initializes((0, 8)) %_0, i64 %self.0.val, ptr %self.8.val, i64 noundef %cap) unnamed_addr #1 {
start:
  %_34.0 = shl i64 %cap, 3
  %_34.1 = icmp ult i64 %cap, 2305843009213693952
  %_39 = icmp ult i64 %_34.0, 9223372036854775801
  %or.cond = and i1 %_34.1, %_39
  br i1 %or.cond, label %bb15, label %bb11, !prof !126

bb15:                                             ; preds = %start
  %0 = icmp eq i64 %self.0.val, 0
  br i1 %0, label %bb5, label %bb3

bb3:                                              ; preds = %bb15
  %alloc_size.i = shl nuw i64 %self.0.val, 3
  %1 = icmp ne ptr %self.8.val, null
  tail call void @llvm.assume(i1 %1)
  %cond.i.i = icmp uge i64 %_34.0, %alloc_size.i
  tail call void @llvm.assume(i1 %cond.i.i)
; call __rustc::__rust_realloc
  %raw_ptr.i.i = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc14___rust_realloc(ptr noundef nonnull %self.8.val, i64 noundef %alloc_size.i, i64 noundef 8, i64 noundef range(i64 0, 9223372036854775801) %_34.0) #19
  br label %bb7

bb5:                                              ; preds = %bb15
  %2 = icmp eq i64 %_34.0, 0
  br i1 %2, label %bb9, label %bb1.i.i

bb1.i.i:                                          ; preds = %bb5
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19
; call __rustc::__rust_alloc
  %3 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) %_34.0, i64 noundef 8) #19
  br label %bb7

bb7:                                              ; preds = %bb1.i.i, %bb3
  %raw_ptr.i.i.pn = phi ptr [ %raw_ptr.i.i, %bb3 ], [ %3, %bb1.i.i ]
  %4 = icmp eq ptr %raw_ptr.i.i.pn, null
  br i1 %4, label %bb8, label %bb9

bb8:                                              ; preds = %bb7
  %5 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 8, ptr %5, align 8
  br label %bb11

bb9:                                              ; preds = %bb5, %bb7
  %raw_ptr.i.i.pn8 = phi ptr [ %raw_ptr.i.i.pn, %bb7 ], [ inttoptr (i64 8 to ptr), %bb5 ]
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store ptr %raw_ptr.i.i.pn8, ptr %6, align 8
  br label %bb11

bb11:                                             ; preds = %start, %bb9, %bb8
  %.sink9 = phi i64 [ 16, %bb9 ], [ 16, %bb8 ], [ 8, %start ]
  %_34.0.sink = phi i64 [ %_34.0, %bb9 ], [ %_34.0, %bb8 ], [ 0, %start ]
  %storemerge9 = phi i64 [ 0, %bb9 ], [ 1, %bb8 ], [ 1, %start ]
  %7 = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink9
  store i64 %_34.0.sink, ptr %7, align 8
  store i64 %storemerge9, ptr %_0, align 8
  ret void
}

; <histogram_merge_errors::IntervalHistogram>::from_counts
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %counts) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %_15 = alloca [48 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %counts, i64 16
  %_4 = load i64, ptr %0, align 8, !noundef !4
  %_18 = icmp ult i64 %_4, 1152921504606846976
  tail call void @llvm.assume(i1 %_18)
  %1 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %_5 = load i64, ptr %1, align 8, !noundef !4
  %_19 = icmp ult i64 %_5, 1152921504606846976
  tail call void @llvm.assume(i1 %_19)
  %_3.not = icmp eq i64 %_4, %_5
  br i1 %_3.not, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %counts, i64 8
  %_25 = load ptr, ptr %2, align 8, !nonnull !4, !noundef !4
  %_29 = getelementptr inbounds nuw i64, ptr %_25, i64 %_4
  br label %bb1.i

bb1.i:                                            ; preds = %bb3.i, %bb2
  %_16.i24.i = phi ptr [ %_25, %bb2 ], [ %_16.i.i, %bb3.i ]
  %_9.sroa.5.0.i = phi i64 [ undef, %bb2 ], [ %_8.0.i.i, %bb3.i ]
  %accum.sroa.0.0.i = phi i64 [ 0, %bb2 ], [ %_8.0.i.i, %bb3.i ]
  %_6.i.i = icmp eq ptr %_16.i24.i, %_29
  br i1 %_6.i.i, label %bb9, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_16.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i, i64 8
  %.val.i = load i64, ptr %_16.i24.i, align 8, !noalias !127, !noundef !4
  %_8.0.i.i = add i64 %.val.i, %accum.sroa.0.0.i
  %_8.1.i.i = icmp ult i64 %_8.0.i.i, %accum.sroa.0.0.i
  br i1 %_8.1.i.i, label %bb5, label %bb1.i, !prof !89

bb1:                                              ; preds = %start
  %3 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 2, ptr %3, align 8
  br label %bb5

bb9:                                              ; preds = %bb1.i
  call void @llvm.lifetime.start.p0(ptr nonnull %_15)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_15, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %4 = getelementptr inbounds nuw i8, ptr %_15, i64 24
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %4, ptr noundef nonnull align 8 dereferenceable(24) %counts, i64 24, i1 false)
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %_15, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %_15)
  br label %bb7

bb7:                                              ; preds = %bb2.i.i.i.i.i, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, %bb9
  ret void

bb5:                                              ; preds = %bb3.i, %bb1
  %.sink14 = phi i64 [ 16, %bb1 ], [ 8, %bb3.i ]
  %_5.sink = phi i64 [ %_5, %bb1 ], [ 6, %bb3.i ]
  %.sink = phi i64 [ 24, %bb1 ], [ 16, %bb3.i ]
  %_4.sink = phi i64 [ %_4, %bb1 ], [ %_9.sroa.5.0.i, %bb3.i ]
  %_6.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink14
  store i64 %_5.sink, ptr %_6.sroa.4.0..sroa_idx, align 8
  %_6.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 %.sink
  store i64 %_4.sink, ptr %_6.sroa.5.0..sroa_idx, align 8
  store i64 -1, ptr %_0, align 8
  %counts.val = load i64, ptr %counts, align 8, !range !3, !noundef !4
  %5 = icmp eq i64 %counts.val, 0
  br i1 %5, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb5
  %6 = getelementptr inbounds nuw i8, ptr %counts, i64 8
  %counts.val5 = load ptr, ptr %6, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i = shl nuw i64 %counts.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %counts.val5, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %bb5, %bb2.i.i.i.i
  %schema.val = load i64, ptr %schema, align 8, !range !3, !noundef !4
  %7 = icmp eq i64 %schema.val, 0
  br i1 %7, label %bb7, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit
  %8 = getelementptr inbounds nuw i8, ptr %schema, i64 8
  %schema.val6 = load ptr, ptr %8, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %schema.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %schema.val6, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb7
}

; <histogram_merge_errors::IntervalHistogram>::total_count
; Function Attrs: nofree norecurse nosync nounwind nonlazybind memory(read, argmem: readwrite, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self) unnamed_addr #2 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_7 = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_6 = load i64, ptr %1, align 8, !noundef !4
  %_11 = getelementptr inbounds nuw i64, ptr %_7, i64 %_6
  tail call void @llvm.experimental.noalias.scope.decl(metadata !131)
  br label %bb1.i

bb1.i:                                            ; preds = %bb3.i, %start
  %_16.i24.i = phi ptr [ %_7, %start ], [ %_16.i.i, %bb3.i ]
  %_9.sroa.5.0.i = phi i64 [ undef, %start ], [ %_8.0.i.i, %bb3.i ]
  %accum.sroa.0.0.i = phi i64 [ 0, %start ], [ %_8.0.i.i, %bb3.i ]
  %_6.i.i = icmp eq ptr %_16.i24.i, %_11
  br i1 %_6.i.i, label %bb10.i, label %bb3.i

bb3.i:                                            ; preds = %bb1.i
  %_16.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i, i64 8
  %.val.i = load i64, ptr %_16.i24.i, align 8, !noalias !134, !noundef !4
  %_8.0.i.i = add i64 %.val.i, %accum.sroa.0.0.i
  %_8.1.i.i = icmp ult i64 %_8.0.i.i, %accum.sroa.0.0.i
  br i1 %_8.1.i.i, label %bb8.i, label %bb1.i, !prof !89

bb10.i:                                           ; preds = %bb1.i
  %2 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %accum.sroa.0.0.i, ptr %2, align 8, !alias.scope !136, !noalias !139
  store i64 -1, ptr %_0, align 8, !alias.scope !136, !noalias !139
  br label %_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_.exit

bb8.i:                                            ; preds = %bb3.i
  store i64 6, ptr %_0, align 8, !alias.scope !140, !noalias !139
  %residual.sroa.4.0._0.sroa_idx.i = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_9.sroa.5.0.i, ptr %residual.sroa.4.0._0.sroa_idx.i, align 8, !alias.scope !140, !noalias !139
  br label %_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_.exit

_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_.exit: ; preds = %bb10.i, %bb8.i
  ret void
}

; <histogram_merge_errors::IntervalHistogram>::merge_compatible
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef align 8 captures(none) dereferenceable(48) %self, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %other) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %vector.i.i.i.i.i = alloca [24 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_14 = load i64, ptr %0, align 8, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %other, i64 16
  %_16 = load i64, ptr %1, align 8, !noundef !4
  %_18 = icmp eq i64 %_14, %_16
  br i1 %_18, label %bb7, label %bb1

bb7:                                              ; preds = %start
  %2 = getelementptr inbounds nuw i8, ptr %other, i64 8
  %_17 = load ptr, ptr %2, align 8, !nonnull !4, !noundef !4
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_15 = load ptr, ptr %3, align 8, !nonnull !4, !noundef !4
  %_19 = shl nuw i64 %_14, 3
  %bcmp = tail call i32 @bcmp(ptr nonnull %_15, ptr nonnull %_17, i64 %_19)
  %_13.not = icmp eq i32 %bcmp, 0
  br i1 %_13.not, label %bb2, label %bb1

bb1:                                              ; preds = %start, %bb7
  store i64 4, ptr %_0, align 8
  br label %bb6

bb2:                                              ; preds = %bb7
  %4 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_26 = load ptr, ptr %4, align 8, !nonnull !4, !noundef !4
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_25 = load i64, ptr %5, align 8, !noundef !4
  %6 = getelementptr inbounds nuw i8, ptr %other, i64 32
  %_10.val = load ptr, ptr %6, align 8, !nonnull !4, !noundef !4
  %7 = getelementptr inbounds nuw i8, ptr %other, i64 40
  %_10.val2 = load i64, ptr %7, align 8, !noundef !4
  %..i.i.i = tail call noundef i64 @llvm.umin.i64(i64 %_10.val2, i64 %_25)
  call void @llvm.lifetime.start.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !144
  %_2.i.i.i.i.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 0
  br i1 %_2.i.i.i.i.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i:                            ; preds = %bb2
  %.val.i.i.i.i.i.i.i.i.i = load i64, ptr %_26, align 8, !noalias !160, !noundef !4
  %.val3.i.i.i.i.i.i.i.i.i = load i64, ptr %_10.val, align 8, !noalias !160, !noundef !4
  %_10.0.i.i.i.i.i.i.i.i.i.i.i = add i64 %.val3.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i
  %_10.1.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i
  br i1 %_10.1.i.i.i.i.i.i.i.i.i.i.i, label %bb4.thread.i, label %bb3.i.i.i.i.i.i.i, !prof !89

bb4.thread.i:                                     ; preds = %bb3.i.i.i.i.i.i.i.i.i
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !144
  br label %bb11

bb3.i.i.i.i.i.i.i:                                ; preds = %bb3.i.i.i.i.i.i.i.i.i
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !170
; call __rustc::__rust_alloc
  %8 = tail call noundef align 8 dereferenceable_or_null(32) ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef range(i64 0, 9223372036854775801) 32, i64 noundef 8) #19, !noalias !170
  %9 = icmp eq ptr %8, null
  br i1 %9, label %bb3.i.i.i.i.i.i, label %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i

bb3.i.i.i.i.i.i:                                  ; preds = %bb3.i.i.i.i.i.i.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 32) #20, !noalias !144
  unreachable

_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i: ; preds = %bb3.i.i.i.i.i.i.i
  store i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i, ptr %8, align 8, !noalias !144
  store i64 4, ptr %vector.i.i.i.i.i, align 8, !noalias !144
  %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 8
  store ptr %8, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !144
  %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i = getelementptr inbounds nuw i8, ptr %vector.i.i.i.i.i, i64 16
  store i64 1, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !144
  tail call void @llvm.experimental.noalias.scope.decl(metadata !173)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !176)
  %_2.i.i.i.i.i.i6.i.i.i.i.i.i.i.not = icmp eq i64 %..i.i.i, 1
  br i1 %_2.i.i.i.i.i.i6.i.i.i.i.i.i.i.not, label %bb12, label %bb3.i.i.i.i.i.i.i.i.i.i.i

bb3.i.i.i.i.i.i.i.i.i.i.i:                        ; preds = %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i, %bb8.i.i.i.i.i.i.i
  %_23.i.i12.i.i.i.i.i = phi ptr [ %_23.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ %8, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %len.i.i.i.i.i.i.i = phi i64 [ %new_len.i.i.i.i.i.i.i, %bb8.i.i.i.i.i.i.i ], [ 1, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %new_len.i.i.i.i.i.i.i = add nuw nsw i64 %len.i.i.i.i.i.i.i, 1
  %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_26, i64 %len.i.i.i.i.i.i.i
  %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_10.val, i64 %len.i.i.i.i.i.i.i
  %.val.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !179, !noundef !4
  %.val3.i.i.i.i.i.i.i.i.i.i.i = load i64, ptr %_3.i1.i.i.i.i.i.i.i.i.i.i.i.i.i, align 8, !noalias !179, !noundef !4
  %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i = add i64 %.val3.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i.i.i
  %_10.1.i.i.i.i.i.i.i.i.i.i.i.i.i = icmp ult i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %.val.i.i.i.i.i.i.i.i.i.i.i
  br i1 %_10.1.i.i.i.i.i.i.i.i.i.i.i.i.i, label %bb4.i, label %bb3.i.i3.i.i.i.i.i, !prof !89

bb3.i.i3.i.i.i.i.i:                               ; preds = %bb3.i.i.i.i.i.i.i.i.i.i.i
  %_19.i.i.i.i.i.i.i = icmp samesign ult i64 %len.i.i.i.i.i.i.i, 1152921504606846976
  tail call void @llvm.assume(i1 %_19.i.i.i.i.i.i.i)
  %self1.i.i.i.i.i.i.i = load i64, ptr %vector.i.i.i.i.i, align 8, !range !3, !alias.scope !191, !noalias !192, !noundef !4
  %_8.i.i4.i.i.i.i.i = icmp eq i64 %len.i.i.i.i.i.i.i, %self1.i.i.i.i.i.i.i
  br i1 %_8.i.i4.i.i.i.i.i, label %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i, label %bb8.i.i.i.i.i.i.i

_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i: ; preds = %bb3.i.i3.i.i.i.i.i
; call <alloc::raw_vec::RawVecInner<_>>::reserve::do_reserve_and_handle::<alloc::alloc::Global>
  call fastcc void @_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef nonnull align 8 dereferenceable(24) %vector.i.i.i.i.i, i64 noundef %len.i.i.i.i.i.i.i, i64 noundef 1) #19
  %_23.i.i.pre.i.i.i.i.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !191, !noalias !192
  br label %bb8.i.i.i.i.i.i.i

bb8.i.i.i.i.i.i.i:                                ; preds = %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i, %bb3.i.i3.i.i.i.i.i
  %_23.i.i.i.i.i.i.i = phi ptr [ %_23.i.i.pre.i.i.i.i.i, %_RNvMs_NtCscdodAO9FK5_5alloc3vecINtB4_3VecyE7reserveCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i.i.i ], [ %_23.i.i12.i.i.i.i.i, %bb3.i.i3.i.i.i.i.i ]
  %dst.i.i.i.i.i.i.i = getelementptr inbounds nuw i64, ptr %_23.i.i.i.i.i.i.i, i64 %len.i.i.i.i.i.i.i
  store i64 %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, ptr %dst.i.i.i.i.i.i.i, align 8, !noalias !193
  store i64 %new_len.i.i.i.i.i.i.i, ptr %vector1.sroa.6.0.vector.sroa_idx.i.i.i.i.i, align 8, !alias.scope !191, !noalias !192
  %exitcond.not.i.i.i.i.i.i.i = icmp eq i64 %new_len.i.i.i.i.i.i.i, %..i.i.i
  br i1 %exitcond.not.i.i.i.i.i.i.i, label %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_.exit.thread27.loopexit.i, label %bb3.i.i.i.i.i.i.i.i.i.i.i

_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_.exit.thread27.loopexit.i: ; preds = %bb8.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload230.pre.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !194
  %value.sroa.6.0.copyload331.pre.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !194
  br label %bb12

bb4.i:                                            ; preds = %bb3.i.i.i.i.i.i.i.i.i.i.i
  %value.sroa.0.0.copyload2.i = load i64, ptr %vector.i.i.i.i.i, align 8, !noalias !194
  %value.sroa.6.0.copyload3.i = load ptr, ptr %vector1.sroa.4.0.vector.sroa_idx.i.i.i.i.i, align 8, !noalias !194
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !144
  %10 = icmp eq i64 %value.sroa.0.0.copyload2.i, 0
  br i1 %10, label %bb11, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb4.i
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %value.sroa.0.0.copyload2.i, 3
  %11 = icmp ne ptr %value.sroa.6.0.copyload3.i, null
  tail call void @llvm.assume(i1 %11)
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %value.sroa.6.0.copyload3.i, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19, !noalias !195
  br label %bb11

bb11:                                             ; preds = %bb4.thread.i, %bb4.i, %bb2.i.i.i.i.i
  %_6.sroa.12.0.ph = phi i64 [ %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %bb2.i.i.i.i.i ], [ %_10.0.i.i.i.i.i.i.i.i.i.i.i.i.i, %bb4.i ], [ %_10.0.i.i.i.i.i.i.i.i.i.i.i, %bb4.thread.i ]
  store i64 6, ptr %_0, align 8
  %_40.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_6.sroa.12.0.ph, ptr %_40.sroa.4.0._0.sroa_idx, align 8
  br label %bb6

bb12:                                             ; preds = %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_.exit.thread27.loopexit.i, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i, %bb2
  %value.sroa.0.015.i = phi i64 [ 0, %bb2 ], [ %value.sroa.0.0.copyload230.pre.i, %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_.exit.thread27.loopexit.i ], [ 4, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  %value.sroa.6.014.i = phi ptr [ inttoptr (i64 8 to ptr), %bb2 ], [ %value.sroa.6.0.copyload331.pre.i, %_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_.exit.thread27.loopexit.i ], [ %8, %_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner16with_capacity_inCsjJ7XxL93Zka_22histogram_merge_errors.exit.i.i.i.i.i ]
  call void @llvm.lifetime.end.p0(ptr nonnull %vector.i.i.i.i.i), !noalias !144
  %12 = ptrtoint ptr %value.sroa.6.014.i to i64
  %13 = getelementptr inbounds nuw i8, ptr %self, i64 24
  %.val = load i64, ptr %13, align 8, !range !3, !noundef !4
  %14 = icmp eq i64 %.val, 0
  br i1 %14, label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb2.i.i.i.i

bb2.i.i.i.i:                                      ; preds = %bb12
  %.val1 = load ptr, ptr %4, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i = shl nuw i64 %.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %.val1, i64 noundef %alloc_size.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit

_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %bb12, %bb2.i.i.i.i
  store i64 %value.sroa.0.015.i, ptr %13, align 8
  store i64 %12, ptr %4, align 8
  store i64 %..i.i.i, ptr %5, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb6

bb6:                                              ; preds = %bb1, %bb11, %_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueINtNtCscdodAO9FK5_5alloc3vec3VecyEECsjJ7XxL93Zka_22histogram_merge_errors.exit
  ret void
}

; <histogram_merge_errors::IntervalHistogram>::nearest_rank_bracket
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket(ptr dead_on_unwind noalias noundef writable writeonly sret([40 x i8]) align 8 captures(none) dereferenceable(40) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, i64 noundef %numerator, i64 noundef %denominator) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = add i64 %numerator, -1
  %.not = icmp ult i64 %0, %denominator
  br i1 %.not, label %bb4, label %bb3

bb3:                                              ; preds = %start
  %1 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 7, ptr %1, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb4:                                              ; preds = %start
  tail call void @llvm.experimental.noalias.scope.decl(metadata !196)
  %2 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_7.i = load ptr, ptr %2, align 8, !alias.scope !196, !noalias !199, !nonnull !4, !noundef !4
  %3 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_6.i = load i64, ptr %3, align 8, !alias.scope !196, !noalias !199, !noundef !4
  %_11.i = getelementptr inbounds nuw i64, ptr %_7.i, i64 %_6.i
  br label %bb1.i.i

bb1.i.i:                                          ; preds = %bb3.i.i, %bb4
  %_16.i24.i.i = phi ptr [ %_7.i, %bb4 ], [ %_16.i.i.i, %bb3.i.i ]
  %_9.sroa.5.0.i.i = phi i64 [ undef, %bb4 ], [ %_8.0.i.i.i, %bb3.i.i ]
  %accum.sroa.0.0.i.i = phi i64 [ 0, %bb4 ], [ %_8.0.i.i.i, %bb3.i.i ]
  %_6.i.i.i = icmp eq ptr %_16.i24.i.i, %_11.i
  br i1 %_6.i.i.i, label %bb21, label %bb3.i.i

bb3.i.i:                                          ; preds = %bb1.i.i
  %_16.i.i.i = getelementptr inbounds nuw i8, ptr %_16.i24.i.i, i64 8
  %.val.i.i = load i64, ptr %_16.i24.i.i, align 8, !noalias !201, !noundef !4
  %_8.0.i.i.i = add i64 %.val.i.i, %accum.sroa.0.0.i.i
  %_8.1.i.i.i = icmp ult i64 %_8.0.i.i.i, %accum.sroa.0.0.i.i
  br i1 %_8.1.i.i.i, label %bb20, label %bb1.i.i, !prof !89

bb20:                                             ; preds = %bb3.i.i
  %4 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 6, ptr %4, align 8
  %_51.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_9.sroa.5.0.i.i, ptr %_51.sroa.4.0..sroa_idx, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb21:                                             ; preds = %bb1.i.i
  %5 = icmp eq i64 %accum.sroa.0.0.i.i, 0
  br i1 %5, label %bb7, label %bb8

bb7:                                              ; preds = %bb21
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 8, ptr %6, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb8:                                              ; preds = %bb21
  %7 = tail call { i64, i1 } @llvm.umul.with.overflow.i64(i64 %accum.sroa.0.0.i.i, i64 %numerator)
  %_55.1 = extractvalue { i64, i1 } %7, 1
  br i1 %_55.1, label %bb22, label %bb24, !prof !89

bb24:                                             ; preds = %bb8
  %_55.0 = extractvalue { i64, i1 } %7, 0
  %_21 = add i64 %denominator, -1
  %_62.0 = add i64 %_21, %_55.0
  %_62.1 = icmp ult i64 %_62.0, %_55.0
  br i1 %_62.1, label %bb25, label %bb27, !prof !89

bb22:                                             ; preds = %bb8
  %8 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 6, ptr %8, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb27:                                             ; preds = %bb24
  %rank = udiv i64 %_62.0, %denominator
  br label %bb9

bb25:                                             ; preds = %bb24
  %9 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 6, ptr %9, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb9:                                              ; preds = %bb30, %bb27
  %iter.sroa.0.0 = phi ptr [ %_7.i, %bb27 ], [ %_16.i.i, %bb30 ]
  %iter.sroa.8.0 = phi i64 [ 0, %bb27 ], [ %_9.0.i, %bb30 ]
  %cumulative.sroa.0.0 = phi i64 [ 0, %bb27 ], [ %_88.0, %bb30 ]
  %_6.i.i = icmp eq ptr %iter.sroa.0.0, %_11.i
  br i1 %_6.i.i, label %bb12, label %bb11

bb11:                                             ; preds = %bb9
  %_35 = load i64, ptr %iter.sroa.0.0, align 8, !noundef !4
  %_88.0 = add i64 %_35, %cumulative.sroa.0.0
  %_88.1 = icmp ult i64 %_88.0, %cumulative.sroa.0.0
  br i1 %_88.1, label %bb28, label %bb30, !prof !89

bb12:                                             ; preds = %bb9
  %10 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 10, ptr %10, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb19:                                             ; preds = %bb35, %bb28, %bb22, %bb25, %bb7, %bb20, %bb3, %bb12
  ret void

bb30:                                             ; preds = %bb11
  %_9.0.i = add i64 %iter.sroa.8.0, 1
  %_16.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.0, i64 8
  %_38.not = icmp ult i64 %_88.0, %rank
  br i1 %_38.not, label %bb9, label %bb13

bb28:                                             ; preds = %bb11
  %11 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 6, ptr %11, align 8
  store i64 2, ptr %_0, align 8
  br label %bb19

bb13:                                             ; preds = %bb30
  %_98 = icmp eq i64 %iter.sroa.8.0, 0
  br i1 %_98, label %bb13.bb33_crit_edge, label %bb32

bb13.bb33_crit_edge:                              ; preds = %bb13
  %.phi.trans.insert = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_110.pre = load i64, ptr %.phi.trans.insert, align 8
  br label %bb33

bb32:                                             ; preds = %bb13
  %_99 = add i64 %iter.sroa.8.0, -1
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_105 = load i64, ptr %12, align 8, !noundef !4
  %_107 = icmp ult i64 %_99, %_105
  br i1 %_107, label %bb34, label %panic

bb34:                                             ; preds = %bb32
  %13 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_106 = load ptr, ptr %13, align 8, !nonnull !4, !noundef !4
  %_102 = getelementptr inbounds nuw i64, ptr %_106, i64 %_99
  %_101 = load i64, ptr %_102, align 8, !noundef !4
  br label %bb33

panic:                                            ; preds = %bb32
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef %_99, i64 noundef %_105, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_9034bc150239ddb23220298f62c78c3d) #20
  unreachable

bb33:                                             ; preds = %bb13.bb33_crit_edge, %bb34
  %_110 = phi i64 [ %_105, %bb34 ], [ %_110.pre, %bb13.bb33_crit_edge ]
  %_41.sroa.0.0 = phi i64 [ 1, %bb34 ], [ 0, %bb13.bb33_crit_edge ]
  %_41.sroa.5.0 = phi i64 [ %_101, %bb34 ], [ undef, %bb13.bb33_crit_edge ]
  %_112 = icmp ult i64 %iter.sroa.8.0, %_110
  br i1 %_112, label %bb35, label %panic4

bb35:                                             ; preds = %bb33
  %14 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_111 = load ptr, ptr %14, align 8, !nonnull !4, !noundef !4
  %_44 = getelementptr inbounds nuw i64, ptr %_111, i64 %iter.sroa.8.0
  %_43 = load i64, ptr %_44, align 8, !noundef !4
  store i64 %_41.sroa.0.0, ptr %_0, align 8
  %_40.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %_41.sroa.5.0, ptr %_40.sroa.4.0._0.sroa_idx, align 8
  %_40.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_43, ptr %_40.sroa.5.0._0.sroa_idx, align 8
  %_40.sroa.6.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %rank, ptr %_40.sroa.6.0._0.sroa_idx, align 8
  %_40.sroa.7.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store i64 %accum.sroa.0.0.i.i, ptr %_40.sroa.7.0._0.sroa_idx, align 8
  br label %bb19

panic4:                                           ; preds = %bb33
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef %iter.sroa.8.0, i64 noundef %_110, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_713e1b0d46806bc8c2cd07e9f5848152) #20
  unreachable
}

; <histogram_merge_errors::IntervalHistogram>::empty
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %schema) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %schema, i64 16
  %_3 = load i64, ptr %0, align 8, !noundef !4
  %_4 = icmp ult i64 %_3, 1152921504606846976
  tail call void @llvm.assume(i1 %_4)
  %_34.0.i.i = shl nuw nsw i64 %_3, 3
  %1 = icmp eq i64 %_3, 0
  br i1 %1, label %_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors.exit, label %bb3.i1.i

bb3.i1.i:                                         ; preds = %start
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !205
; call __rustc::__rust_alloc_zeroed
  %2 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64 noundef range(i64 1, 9223372036854775801) %_34.0.i.i, i64 noundef 8) #19, !noalias !205
  %3 = icmp eq ptr %2, null
  br i1 %3, label %bb14.i, label %bb10.i.i

bb10.i.i:                                         ; preds = %bb3.i1.i
  %4 = ptrtoint ptr %2 to i64
  br label %_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors.exit

bb14.i:                                           ; preds = %bb3.i1.i
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_34.0.i.i) #20, !noalias !210
  unreachable

_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors.exit: ; preds = %start, %bb10.i.i
  %_16.sroa.10.0.i = phi i64 [ %4, %bb10.i.i ], [ 8, %start ]
  %5 = inttoptr i64 %_16.sroa.10.0.i to ptr
  tail call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(24) %_0, ptr noundef nonnull align 8 dereferenceable(24) %schema, i64 24, i1 false)
  %6 = getelementptr inbounds nuw i8, ptr %_0, i64 24
  store i64 %_3, ptr %6, align 8
  %counts.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 32
  store ptr %5, ptr %counts.sroa.4.0..sroa_idx, align 8
  %counts.sroa.5.0..sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 40
  store i64 %_3, ptr %counts.sroa.5.0..sroa_idx, align 8
  ret void
}

; <histogram_merge_errors::IntervalHistogram>::record
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record(ptr dead_on_unwind noalias noundef writable writeonly sret([24 x i8]) align 8 captures(none) dereferenceable(24) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, i64 noundef %value_us) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %self.val = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %self.val12 = load i64, ptr %1, align 8, !noundef !4
  switch i64 %self.val12, label %bb4.i.i.i [
    i64 0, label %bb6.i
    i64 1, label %_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_.exit.thread.i
  ]

bb4.i.i.i:                                        ; preds = %start, %bb4.i.i.i
  %size.sroa.0.019.i.i.i = phi i64 [ %3, %bb4.i.i.i ], [ %self.val12, %start ]
  %base.sroa.0.018.i.i.i = phi i64 [ %2, %bb4.i.i.i ], [ 0, %start ]
  %half11.i.i.i = lshr i64 %size.sroa.0.019.i.i.i, 1
  %mid.i.i.i = add nuw i64 %half11.i.i.i, %base.sroa.0.018.i.i.i
  %_35.i.i.i = icmp ult i64 %mid.i.i.i, %self.val12
  tail call void @llvm.assume(i1 %_35.i.i.i)
  %_32.i.i.i = getelementptr inbounds nuw i64, ptr %self.val, i64 %mid.i.i.i
  %_32.val.i.i.i = load i64, ptr %_32.i.i.i, align 8, !alias.scope !211, !noalias !216, !noundef !4
  %_0.i.i15.not.i.i.i = icmp ult i64 %_32.val.i.i.i, %value_us
  %2 = select i1 %_0.i.i15.not.i.i.i, i64 %mid.i.i.i, i64 %base.sroa.0.018.i.i.i, !unpredictable !4
  %3 = sub i64 %size.sroa.0.019.i.i.i, %half11.i.i.i
  %_6.i.i.i = icmp ugt i64 %3, 1
  br i1 %_6.i.i.i, label %bb4.i.i.i, label %_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_.exit.thread.i

_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_.exit.thread.i: ; preds = %bb4.i.i.i, %start
  %base.sroa.0.0.lcssa.i.i.i = phi i64 [ 0, %start ], [ %2, %bb4.i.i.i ]
  %_38.i.i.i = getelementptr inbounds nuw i64, ptr %self.val, i64 %base.sroa.0.0.lcssa.i.i.i
  %_38.val.i.i.i = load i64, ptr %_38.i.i.i, align 8, !alias.scope !211, !noalias !216, !noundef !4
  %_0.i.i.i.i.i = icmp ult i64 %_38.val.i.i.i, %value_us
  %_28.i.i.i = zext i1 %_0.i.i.i.i.i to i64
  %result.i.i.i = add nuw nsw i64 %base.sroa.0.0.lcssa.i.i.i, %_28.i.i.i
  %cond1.i.i.i = icmp ule i64 %result.i.i.i, %self.val12
  tail call void @llvm.assume(i1 %cond1.i.i.i)
  %_162.i = icmp ult i64 %self.val12, 1152921504606846976
  tail call void @llvm.assume(i1 %_162.i)
  %_73.i = icmp samesign ult i64 %result.i.i.i, %self.val12
  br i1 %_73.i, label %bb6, label %bb5

bb6.i:                                            ; preds = %start
; call core::option::expect_failed
  tail call void @_RNvNtCs4NRVxsYgnAr_4core6option13expect_failed(ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_4ed059f71d51ae16bc6826f989989385, i64 noundef 30, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_72e1b02f1dc44543daa9de23d3bba29e) #20, !noalias !221
  unreachable

bb5:                                              ; preds = %_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_.exit.thread.i
  %4 = getelementptr i64, ptr %self.val, i64 %self.val12
  %_18.i = getelementptr i8, ptr %4, i64 -8
  %_9.i = load i64, ptr %_18.i, align 8, !noalias !221, !noundef !4
  store i64 3, ptr %_0, align 8
  %_27.sroa.4.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 %value_us, ptr %_27.sroa.4.0._0.sroa_idx, align 8
  %_27.sroa.5.0._0.sroa_idx = getelementptr inbounds nuw i8, ptr %_0, i64 16
  store i64 %_9.i, ptr %_27.sroa.5.0._0.sroa_idx, align 8
  br label %bb4

bb6:                                              ; preds = %_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_.exit.thread.i
  %5 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_23 = load i64, ptr %5, align 8, !noundef !4
  %_25 = icmp ult i64 %result.i.i.i, %_23
  br i1 %_25, label %bb7, label %panic

bb7:                                              ; preds = %bb6
  %6 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_24 = load ptr, ptr %6, align 8, !nonnull !4, !noundef !4
  %_12 = getelementptr inbounds nuw i64, ptr %_24, i64 %result.i.i.i
  %_11 = load i64, ptr %_12, align 8, !noundef !4
  %_30.1 = icmp eq i64 %_11, -1
  br i1 %_30.1, label %bb8, label %bb11, !prof !89

panic:                                            ; preds = %bb6
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef %result.i.i.i, i64 noundef %_23, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_96d0d7cd51bf3727855c17e0e20001f5) #20
  unreachable

bb8:                                              ; preds = %bb7
  store i64 6, ptr %_0, align 8
  br label %bb4

bb11:                                             ; preds = %bb7
  %_30.0 = add nuw i64 %_11, 1
  store i64 %_30.0, ptr %_12, align 8
  store i64 -1, ptr %_0, align 8
  br label %bb4

bb4:                                              ; preds = %bb8, %bb5, %bb11
  ret void
}

; <histogram_merge_errors::IntervalHistogram>::coarsen
; Function Attrs: nounwind nonlazybind uwtable
define void @_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen(ptr dead_on_unwind noalias noundef writable writeonly sret([48 x i8]) align 8 captures(none) dereferenceable(48) %_0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(48) %self, ptr dead_on_return noalias noundef readonly align 8 captures(none) dereferenceable(24) %target) unnamed_addr #0 personality ptr @rust_eh_personality {
start:
  %result = alloca [48 x i8], align 8
  %0 = getelementptr inbounds nuw i8, ptr %self, i64 8
  %_42 = load ptr, ptr %0, align 8, !nonnull !4, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %self, i64 16
  %_41 = load i64, ptr %1, align 8, !noundef !4
  %_43.not = icmp eq i64 %_41, 0
  %2 = getelementptr inbounds nuw i8, ptr %target, i64 16
  %3 = load i64, ptr %2, align 8, !noundef !4
  %.not = icmp eq i64 %3, 0
  br i1 %_43.not, label %bb18, label %bb17

bb18:                                             ; preds = %start
  br i1 %.not, label %bb6.thread, label %bb5

bb6.thread:                                       ; preds = %bb18
  call void @llvm.lifetime.start.p0(ptr nonnull %result)
  br label %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty.exit

bb17:                                             ; preds = %start
  br i1 %.not, label %bb5, label %bb25

bb2:                                              ; preds = %bb25
  %cond = icmp eq i64 %_41, 1
  br i1 %cond, label %bb1.us4.i, label %bb1.i

bb1.us4.i:                                        ; preds = %bb2, %bb13.us7.i
  %_222.us5.i = phi ptr [ %_22.us8.i, %bb13.us7.i ], [ %_48, %bb2 ]
  %_12.us6.not.not.i = icmp eq ptr %_222.us5.i, %8
  br i1 %_12.us6.not.not.i, label %bb6, label %bb13.us7.i

bb13.us7.i:                                       ; preds = %bb1.us4.i
  %_22.us8.i = getelementptr inbounds nuw i8, ptr %_222.us5.i, i64 8
  %ptr.val.us9.i = load i64, ptr %_222.us5.i, align 8, !noalias !222
  %_38.val.i.i.us13.i = load i64, ptr %_42, align 8, !alias.scope !226, !noalias !229, !noundef !4
  %.not.us14.i = icmp eq i64 %_38.val.i.i.us13.i, %ptr.val.us9.i
  br i1 %.not.us14.i, label %bb1.us4.i, label %bb5

bb1.i:                                            ; preds = %bb2, %_RNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB6_17IntervalHistogram7coarsen0B6_.exit.loopexit.i
  %_222.i = phi ptr [ %_22.i, %_RNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB6_17IntervalHistogram7coarsen0B6_.exit.loopexit.i ], [ %_48, %bb2 ]
  %_12.not.not.i = icmp eq ptr %_222.i, %8
  br i1 %_12.not.not.i, label %bb6, label %bb13.i

bb13.i:                                           ; preds = %bb1.i
  %ptr.val.i = load i64, ptr %_222.i, align 8, !noalias !222
  br label %bb4.i.i.i

bb4.i.i.i:                                        ; preds = %bb4.i.i.i, %bb13.i
  %size.sroa.0.017.i.i.i = phi i64 [ %5, %bb4.i.i.i ], [ %_41, %bb13.i ]
  %base.sroa.0.016.i.i.i = phi i64 [ %4, %bb4.i.i.i ], [ 0, %bb13.i ]
  %half11.i.i.i = lshr i64 %size.sroa.0.017.i.i.i, 1
  %mid.i.i.i = add nuw i64 %half11.i.i.i, %base.sroa.0.016.i.i.i
  %_35.i.i.i = icmp ult i64 %mid.i.i.i, %_41
  tail call void @llvm.assume(i1 %_35.i.i.i)
  %_32.i.i.i = getelementptr inbounds nuw i64, ptr %_42, i64 %mid.i.i.i
  %_32.val.i.i.i = load i64, ptr %_32.i.i.i, align 8, !alias.scope !226, !noalias !229, !noundef !4
  %_17.i.i.i = icmp ugt i64 %_32.val.i.i.i, %ptr.val.i
  %4 = select i1 %_17.i.i.i, i64 %base.sroa.0.016.i.i.i, i64 %mid.i.i.i, !unpredictable !4
  %5 = sub i64 %size.sroa.0.017.i.i.i, %half11.i.i.i
  %_6.i.i.i = icmp ugt i64 %5, 1
  br i1 %_6.i.i.i, label %bb4.i.i.i, label %_RNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB6_17IntervalHistogram7coarsen0B6_.exit.loopexit.i

_RNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB6_17IntervalHistogram7coarsen0B6_.exit.loopexit.i: ; preds = %bb4.i.i.i
  %_22.i = getelementptr inbounds nuw i8, ptr %_222.i, i64 8
  %_38.i.i.i = getelementptr inbounds nuw i64, ptr %_42, i64 %4
  %_38.val.i.i.i = load i64, ptr %_38.i.i.i, align 8, !alias.scope !226, !noalias !229, !noundef !4
  %.not.i = icmp eq i64 %_38.val.i.i.i, %ptr.val.i
  br i1 %.not.i, label %bb1.i, label %bb5

bb25:                                             ; preds = %bb17
  %6 = getelementptr inbounds nuw i8, ptr %target, i64 8
  %_48 = load ptr, ptr %6, align 8, !nonnull !4, !noundef !4
  %7 = getelementptr i64, ptr %_42, i64 %_41
  %_44 = getelementptr i8, ptr %7, i64 -8
  %8 = getelementptr i64, ptr %_48, i64 %3
  %_50 = getelementptr i8, ptr %8, i64 -8
  %_54 = load i64, ptr %_44, align 8, !noundef !4
  %_55 = load i64, ptr %_50, align 8, !noundef !4
  %_51.not = icmp eq i64 %_54, %_55
  br i1 %_51.not, label %bb2, label %bb5

bb6:                                              ; preds = %bb1.i, %bb1.us4.i
  call void @llvm.lifetime.start.p0(ptr nonnull %result)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !231)
  tail call void @llvm.experimental.noalias.scope.decl(metadata !234)
  %_4.i = icmp ult i64 %3, 1152921504606846976
  tail call void @llvm.assume(i1 %_4.i)
  %_34.0.i.i.i = shl nuw nsw i64 %3, 3
; call __rustc::__rust_no_alloc_shim_is_unstable_v2
  tail call void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() #19, !noalias !236
; call __rustc::__rust_alloc_zeroed
  %9 = tail call noundef align 8 ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64 noundef range(i64 1, 9223372036854775801) %_34.0.i.i.i, i64 noundef 8) #19, !noalias !236
  %10 = icmp eq ptr %9, null
  br i1 %10, label %bb14.i.i, label %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty.exit

bb14.i.i:                                         ; preds = %bb6
; call alloc::raw_vec::handle_error
  tail call void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef 8, i64 %_34.0.i.i.i) #20, !noalias !241
  unreachable

_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty.exit: ; preds = %bb6, %bb6.thread
  %_582393 = phi i64 [ 0, %bb6.thread ], [ %3, %bb6 ]
  %_16.sroa.10.0.i.i = phi ptr [ inttoptr (i64 8 to ptr), %bb6.thread ], [ %9, %bb6 ]
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(16) %result, ptr noundef nonnull align 8 dereferenceable(16) %target, i64 16, i1 false), !alias.scope !242
  %_12.sroa.4.0.result.sroa_idx = getelementptr inbounds nuw i8, ptr %result, i64 16
  store i64 %_582393, ptr %_12.sroa.4.0.result.sroa_idx, align 8, !alias.scope !242
  %11 = getelementptr inbounds nuw i8, ptr %result, i64 24
  store i64 %_582393, ptr %11, align 8, !alias.scope !231, !noalias !234
  %counts.sroa.4.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 32
  store ptr %_16.sroa.10.0.i.i, ptr %counts.sroa.4.0..sroa_idx.i, align 8, !alias.scope !231, !noalias !234
  %counts.sroa.5.0..sroa_idx.i = getelementptr inbounds nuw i8, ptr %result, i64 40
  store i64 %_582393, ptr %counts.sroa.5.0..sroa_idx.i, align 8, !alias.scope !231, !noalias !234
  %12 = getelementptr inbounds nuw i8, ptr %self, i64 32
  %_71 = load ptr, ptr %12, align 8, !nonnull !4, !noundef !4
  %13 = getelementptr inbounds nuw i8, ptr %self, i64 40
  %_70 = load i64, ptr %13, align 8, !noundef !4
  %_75.idx = shl nuw nsw i64 %_70, 3
  %_75 = getelementptr inbounds nuw i8, ptr %_71, i64 %_75.idx
  %_6.i.i40 = icmp eq i64 %_70, 0
  br i1 %_6.i.i40, label %bb12, label %bb11.lr.ph

bb11.lr.ph:                                       ; preds = %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty.exit
  %14 = getelementptr inbounds nuw i8, ptr %result, i64 8
  %_84 = load ptr, ptr %14, align 8, !nonnull !4
  br i1 %_43.not, label %panic, label %bb11.lr.ph.split

bb11.lr.ph.split:                                 ; preds = %bb11.lr.ph
  %_617.not.i.i = icmp eq i64 %_582393, 1
  br i1 %_617.not.i.i, label %bb11.us44, label %bb11

bb11.us44:                                        ; preds = %bb11.lr.ph.split, %bb24.us59
  %iter.sroa.8.042.us45 = phi i64 [ %_9.0.i.us48, %bb24.us59 ], [ 0, %bb11.lr.ph.split ]
  %iter.sroa.0.041.us46 = phi ptr [ %_16.i.i.us47, %bb24.us59 ], [ %_71, %bb11.lr.ph.split ]
  %_16.i.i.us47 = getelementptr inbounds nuw i8, ptr %iter.sroa.0.041.us46, i64 8
  %_9.0.i.us48 = add nuw nsw i64 %iter.sroa.8.042.us45, 1
  %exitcond86.not = icmp eq i64 %iter.sroa.8.042.us45, %_41
  br i1 %exitcond86.not, label %panic, label %bb19.us50

bb19.us50:                                        ; preds = %bb11.us44
  %_22.us51 = getelementptr inbounds nuw i64, ptr %_42, i64 %iter.sroa.8.042.us45
  %15 = load i64, ptr %_22.us51, align 8, !noundef !4
  %_38.val.i.i.us = load i64, ptr %_84, align 8, !alias.scope !243, !noalias !248, !noundef !4
  %_0.i.i.i.i.us = icmp ult i64 %_38.val.i.i.us, %15
  br i1 %_0.i.i.i.i.us, label %panic1, label %bb20.us53

bb20.us53:                                        ; preds = %bb19.us50
  %_30.us55 = load i64, ptr %_16.sroa.10.0.i.i, align 8, !noundef !4
  %_32.us56 = load i64, ptr %iter.sroa.0.041.us46, align 8, !noundef !4
  %_91.0.us57 = add i64 %_32.us56, %_30.us55
  %_91.1.us58 = icmp ult i64 %_91.0.us57, %_30.us55
  br i1 %_91.1.us58, label %bb21, label %bb24.us59, !prof !89

bb24.us59:                                        ; preds = %bb20.us53
  store i64 %_91.0.us57, ptr %_16.sroa.10.0.i.i, align 8
  %_6.i.i.us60 = icmp eq ptr %_16.i.i.us47, %_75
  br i1 %_6.i.i.us60, label %bb12, label %bb11.us44

bb11:                                             ; preds = %bb11.lr.ph.split, %bb24
  %iter.sroa.8.042 = phi i64 [ %_9.0.i, %bb24 ], [ 0, %bb11.lr.ph.split ]
  %iter.sroa.0.041 = phi ptr [ %_16.i.i, %bb24 ], [ %_71, %bb11.lr.ph.split ]
  %_16.i.i = getelementptr inbounds nuw i8, ptr %iter.sroa.0.041, i64 8
  %_9.0.i = add nuw nsw i64 %iter.sroa.8.042, 1
  %exitcond.not = icmp eq i64 %iter.sroa.8.042, %_41
  br i1 %exitcond.not, label %panic, label %bb19

bb12:                                             ; preds = %bb24, %bb24.us59, %_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty.exit
  call void @llvm.memcpy.p0.p0.i64(ptr noundef nonnull align 8 dereferenceable(48) %_0, ptr noundef nonnull align 8 dereferenceable(48) %result, i64 48, i1 false)
  call void @llvm.lifetime.end.p0(ptr nonnull %result)
  br label %bb15

bb15:                                             ; preds = %bb2.i.i.i.i.i, %bb5, %bb21, %bb12
  ret void

bb19:                                             ; preds = %bb11
  %_22 = getelementptr inbounds nuw i64, ptr %_42, i64 %iter.sroa.8.042
  %16 = load i64, ptr %_22, align 8, !noundef !4
  br label %bb4.i.i

bb4.i.i:                                          ; preds = %bb19, %bb4.i.i
  %size.sroa.0.019.i.i = phi i64 [ %18, %bb4.i.i ], [ %_582393, %bb19 ]
  %base.sroa.0.018.i.i = phi i64 [ %17, %bb4.i.i ], [ 0, %bb19 ]
  %half11.i.i = lshr i64 %size.sroa.0.019.i.i, 1
  %mid.i.i = add nuw i64 %half11.i.i, %base.sroa.0.018.i.i
  %_35.i.i = icmp ult i64 %mid.i.i, %_582393
  tail call void @llvm.assume(i1 %_35.i.i)
  %_32.i.i = getelementptr inbounds nuw i64, ptr %_84, i64 %mid.i.i
  %_32.val.i.i = load i64, ptr %_32.i.i, align 8, !alias.scope !243, !noalias !248, !noundef !4
  %_0.i.i15.not.i.i = icmp ult i64 %_32.val.i.i, %16
  %17 = select i1 %_0.i.i15.not.i.i, i64 %mid.i.i, i64 %base.sroa.0.018.i.i, !unpredictable !4
  %18 = sub i64 %size.sroa.0.019.i.i, %half11.i.i
  %_6.i.i17 = icmp ugt i64 %18, 1
  br i1 %_6.i.i17, label %bb4.i.i, label %bb10.i.i.loopexit

bb10.i.i.loopexit:                                ; preds = %bb4.i.i
  %_38.i.i = getelementptr inbounds nuw i64, ptr %_84, i64 %17
  %_38.val.i.i = load i64, ptr %_38.i.i, align 8, !alias.scope !243, !noalias !248, !noundef !4
  %_0.i.i.i.i = icmp ult i64 %_38.val.i.i, %16
  %_28.i.i = zext i1 %_0.i.i.i.i to i64
  %result.i.i = add nuw nsw i64 %17, %_28.i.i
  %cond1.i.i = icmp ule i64 %result.i.i, %_582393
  tail call void @llvm.assume(i1 %cond1.i.i)
  %_89 = icmp ult i64 %result.i.i, %_582393
  br i1 %_89, label %bb20, label %panic1

panic:                                            ; preds = %bb11, %bb11.us44, %bb11.lr.ph
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef %_41, i64 noundef %_41, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4902ffe043ff59a1d70cb2012e4b3cfd) #20
  unreachable

bb20:                                             ; preds = %bb10.i.i.loopexit
  %_31 = getelementptr inbounds nuw i64, ptr %_16.sroa.10.0.i.i, i64 %result.i.i
  %_30 = load i64, ptr %_31, align 8, !noundef !4
  %_32 = load i64, ptr %iter.sroa.0.041, align 8, !noundef !4
  %_91.0 = add i64 %_32, %_30
  %_91.1 = icmp ult i64 %_91.0, %_30
  br i1 %_91.1, label %bb21, label %bb24, !prof !89

panic1:                                           ; preds = %bb10.i.i.loopexit, %bb19.us50
  %.us-phi43 = phi i64 [ 1, %bb19.us50 ], [ %result.i.i, %bb10.i.i.loopexit ]
; call core::panicking::panic_bounds_check
  tail call void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef %.us-phi43, i64 noundef %_582393, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) @alloc_4583e6a49f6781f6842cac8cdb2523af) #20
  unreachable

bb21:                                             ; preds = %bb20, %bb20.us53
  %19 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 6, ptr %19, align 8
  store i64 -1, ptr %_0, align 8
; call core::ptr::drop_glue::<histogram_merge_errors::IntervalHistogram>
  call fastcc void @_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_(ptr noalias noundef align 8 dereferenceable(48) %result) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %result)
  br label %bb15

bb24:                                             ; preds = %bb20
  store i64 %_91.0, ptr %_31, align 8
  %_6.i.i = icmp eq ptr %_16.i.i, %_75
  br i1 %_6.i.i, label %bb12, label %bb11

bb5:                                              ; preds = %_RNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB6_17IntervalHistogram7coarsen0B6_.exit.loopexit.i, %bb13.us7.i, %bb25, %bb18, %bb17
  %20 = getelementptr inbounds nuw i8, ptr %_0, i64 8
  store i64 9, ptr %20, align 8
  store i64 -1, ptr %_0, align 8
  %target.val = load i64, ptr %target, align 8, !range !3, !noundef !4
  %21 = icmp eq i64 %target.val, 0
  br i1 %21, label %bb15, label %bb2.i.i.i.i.i

bb2.i.i.i.i.i:                                    ; preds = %bb5
  %22 = getelementptr inbounds nuw i8, ptr %target, i64 8
  %target.val16 = load ptr, ptr %22, align 8, !nonnull !4, !noundef !4
  %alloc_size.i.i.i.i.i.i = shl nuw i64 %target.val, 3
; call __rustc::__rust_dealloc
  tail call void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr noundef nonnull %target.val16, i64 noundef %alloc_size.i.i.i.i.i.i, i64 noundef range(i64 1, -9223372036854775807) 8) #19
  br label %bb15
}

; <histogram_merge_errors::HistogramError as core::fmt::Display>::fmt
; Function Attrs: nounwind nonlazybind uwtable
define noundef zeroext i1 @_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24) %0, ptr noalias noundef readonly align 8 captures(none) dereferenceable(24) %formatter) unnamed_addr #0 {
start:
  %args = alloca [16 x i8], align 8
  %self = alloca [8 x i8], align 8
  store ptr %0, ptr %self, align 8
  call void @llvm.lifetime.start.p0(ptr nonnull %args)
  store ptr %self, ptr %args, align 8
  %_6.sroa.4.0..sroa_idx = getelementptr inbounds nuw i8, ptr %args, i64 8
  store ptr @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_, ptr %_6.sroa.4.0..sroa_idx, align 8
  %_18.0 = load ptr, ptr %formatter, align 8, !nonnull !4, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %formatter, i64 8
  %_18.1 = load ptr, ptr %1, align 8, !nonnull !4, !align !251, !noundef !4
; call core::fmt::write
  %2 = call noundef zeroext i1 @_RNvNtCs4NRVxsYgnAr_4core3fmt5write(ptr noundef nonnull %_18.0, ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(48) %_18.1, ptr noundef nonnull @alloc_0c812808379efded5a4fb82d2790b556, ptr noundef nonnull %args) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %args)
  ret i1 %2
}

; <&histogram_merge_errors::HistogramError as core::fmt::Debug>::fmt
; Function Attrs: nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %__self_11.i = alloca [8 x i8], align 8
  %__self_1.i = alloca [8 x i8], align 8
  %_3 = load ptr, ptr %self, align 8, !nonnull !4, !align !251, !noundef !4
  tail call void @llvm.experimental.noalias.scope.decl(metadata !252)
  %_3.i = load i64, ptr %_3, align 8, !range !255, !alias.scope !252, !noalias !256, !noundef !4
  switch i64 %_3.i, label %default.unreachable [
    i64 0, label %bb12.i
    i64 1, label %bb11.i
    i64 2, label %bb10.i
    i64 3, label %bb9.i
    i64 4, label %bb8.i
    i64 5, label %bb7.i
    i64 6, label %bb6.i
    i64 7, label %bb5.i
    i64 8, label %bb4.i
    i64 9, label %bb3.i
    i64 10, label %bb2.i
  ]

default.unreachable:                              ; preds = %start
  unreachable

bb12.i:                                           ; preds = %start
; call <core::fmt::Formatter>::write_str
  %0 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_5ee3dd04a3ebbd2958f69478a791f011, i64 noundef 11) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb11.i:                                           ; preds = %start
; call <core::fmt::Formatter>::write_str
  %1 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_52433ae1027e4929c7c1de5d6490f243, i64 noundef 19) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb10.i:                                           ; preds = %start
  %__self_0.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_1.i), !noalias !258
  %2 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %2, ptr %__self_1.i, align 8, !noalias !258
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %3 = call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ee08c9d314e4c5b701504a1a6f89727d, i64 noundef 19, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_adba73bbb963ea705e05d8e8c86355c2, i64 noundef 6, ptr noundef nonnull readonly %__self_0.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.0, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf, i64 noundef 6, ptr noundef nonnull %__self_1.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.1) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_1.i), !noalias !258
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb9.i:                                            ; preds = %start
  %__self_02.i = getelementptr inbounds nuw i8, ptr %_3, i64 8
  call void @llvm.lifetime.start.p0(ptr nonnull %__self_11.i), !noalias !258
  %4 = getelementptr inbounds nuw i8, ptr %_3, i64 16
  store ptr %4, ptr %__self_11.i, align 8, !noalias !258
; call <core::fmt::Formatter>::debug_struct_field2_finish
  %5 = call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_fc4accf12cdb5d5f3207e98a294cf4c2, i64 noundef 21, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_58c73da900326cd1d22dde7834877fb1, i64 noundef 8, ptr noundef nonnull readonly %__self_02.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.2, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_86933f980174c2bccf56810e0d831ebb, i64 noundef 10, ptr noundef nonnull %__self_11.i, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32) @vtable.3) #19
  call void @llvm.lifetime.end.p0(ptr nonnull %__self_11.i), !noalias !258
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb8.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %6 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_49160125fb4cd837bc8bd9b6ec63004a, i64 noundef 14) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb7.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %7 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_99f3a809f00b524a3a34761496eda872, i64 noundef 12) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb6.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %8 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_937ef498e46ce3dd2899f48f05d77c47, i64 noundef 18) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb5.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %9 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_f672c6af06448a01ecac398fe971f727, i64 noundef 15) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb4.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %10 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_ce01d5de1e0bacc55ae5953b06653b2d, i64 noundef 14) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb3.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %11 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_99be15a9e516526f280317bea0cca5d0, i64 noundef 17) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

bb2.i:                                            ; preds = %start
; call <core::fmt::Formatter>::write_str
  %12 = tail call noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef nonnull align 8 dereferenceable(24) %f, ptr noalias noundef nonnull readonly captures(address, read_provenance) @alloc_4d26e1d2bef2fb4016390b651f78947e, i64 noundef 20) #19, !noalias !252
  br label %_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit

_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt.exit: ; preds = %bb12.i, %bb11.i, %bb10.i, %bb9.i, %bb8.i, %bb7.i, %bb6.i, %bb5.i, %bb4.i, %bb3.i, %bb2.i
  %_0.sroa.0.0.in.i = phi i1 [ %0, %bb12.i ], [ %1, %bb11.i ], [ %3, %bb10.i ], [ %5, %bb9.i ], [ %6, %bb8.i ], [ %7, %bb7.i ], [ %8, %bb6.i ], [ %9, %bb5.i ], [ %10, %bb4.i ], [ %11, %bb3.i ], [ %12, %bb2.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&usize as core::fmt::Debug>::fmt
; Function Attrs: nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !4, !align !251, !noundef !4
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !259, !noalias !262, !noundef !4
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt.exit

_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <&u64 as core::fmt::Debug>::fmt
; Function Attrs: nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors(ptr noalias noundef readonly align 8 captures(none) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #0 {
start:
  %_3 = load ptr, ptr %self, align 8, !nonnull !4, !align !251, !noundef !4
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4.i = load i32, ptr %0, align 8, !alias.scope !264, !noalias !267, !noundef !4
  %_3.i = and i32 %_4.i, 33554432
  %1 = icmp eq i32 %_3.i, 0
  br i1 %1, label %bb2.i, label %bb1.i

bb2.i:                                            ; preds = %start
  %_5.i = and i32 %_4.i, 67108864
  %2 = icmp eq i32 %_5.i, 0
  br i1 %2, label %bb4.i, label %bb3.i

bb1.i:                                            ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt.exit

bb4.i:                                            ; preds = %bb2.i
; call <u64 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt.exit

bb3.i:                                            ; preds = %bb2.i
; call <u64 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %_3, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt.exit

_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt.exit: ; preds = %bb1.i, %bb4.i, %bb3.i
  %_0.sroa.0.0.in.i = phi i1 [ %4, %bb4.i ], [ %5, %bb3.i ], [ %3, %bb1.i ]
  ret i1 %_0.sroa.0.0.in.i
}

; <u64 as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #3 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !4
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <u64 as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb4:                                              ; preds = %bb2
; call <u64 as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb3:                                              ; preds = %bb2
; call <u64 as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; <usize as core::fmt::Debug>::fmt
; Function Attrs: inlinehint nounwind nonlazybind uwtable
define internal noundef zeroext i1 @_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef align 8 dereferenceable(24) %f) unnamed_addr #3 {
start:
  %0 = getelementptr inbounds nuw i8, ptr %f, i64 16
  %_4 = load i32, ptr %0, align 8, !noundef !4
  %_3 = and i32 %_4, 33554432
  %1 = icmp eq i32 %_3, 0
  br i1 %1, label %bb2, label %bb1

bb2:                                              ; preds = %start
  %_5 = and i32 %_4, 67108864
  %2 = icmp eq i32 %_5, 0
  br i1 %2, label %bb4, label %bb3

bb1:                                              ; preds = %start
; call <usize as core::fmt::LowerHex>::fmt
  %3 = tail call noundef zeroext i1 @_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb4:                                              ; preds = %bb2
; call <usize as core::fmt::Display>::fmt
  %4 = tail call noundef zeroext i1 @_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb3:                                              ; preds = %bb2
; call <usize as core::fmt::UpperHex>::fmt
  %5 = tail call noundef zeroext i1 @_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef nonnull readonly align 8 captures(address, read_provenance) dereferenceable(8) %self, ptr noalias noundef nonnull align 8 dereferenceable(24) %f) #19
  br label %bb6

bb6:                                              ; preds = %bb4, %bb3, %bb1
  %_0.sroa.0.0.in = phi i1 [ %4, %bb4 ], [ %5, %bb3 ], [ %3, %bb1 ]
  ret i1 %_0.sroa.0.0.in
}

; Function Attrs: mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite) uwtable
define noundef zeroext i1 @topic44_checked_merge_four(ptr noalias noundef align 8 captures(none) dereferenceable(32) %destination, ptr noalias noundef readonly align 8 captures(none) dereferenceable(32) %source) unnamed_addr #4 {
start:
  %_5 = load i64, ptr %destination, align 8, !noundef !4
  %_6 = load i64, ptr %source, align 8, !noundef !4
  %_20.0 = add i64 %_6, %_5
  %_20.1 = icmp ult i64 %_20.0, %_5
  br i1 %_20.1, label %bb3, label %bb6, !prof !89

bb6:                                              ; preds = %start
  %0 = getelementptr inbounds nuw i8, ptr %destination, i64 8
  %_9 = load i64, ptr %0, align 8, !noundef !4
  %1 = getelementptr inbounds nuw i8, ptr %source, i64 8
  %_10 = load i64, ptr %1, align 8, !noundef !4
  %_24.0 = add i64 %_10, %_9
  %_24.1 = icmp ult i64 %_24.0, %_9
  br i1 %_24.1, label %bb3, label %bb9, !prof !89

bb9:                                              ; preds = %bb6
  %2 = getelementptr inbounds nuw i8, ptr %destination, i64 16
  %_13 = load i64, ptr %2, align 8, !noundef !4
  %3 = getelementptr inbounds nuw i8, ptr %source, i64 16
  %_14 = load i64, ptr %3, align 8, !noundef !4
  %_28.0 = add i64 %_14, %_13
  %_28.1 = icmp ult i64 %_28.0, %_13
  br i1 %_28.1, label %bb3, label %bb12, !prof !89

bb12:                                             ; preds = %bb9
  %4 = getelementptr inbounds nuw i8, ptr %destination, i64 24
  %_17 = load i64, ptr %4, align 8, !noundef !4
  %5 = getelementptr inbounds nuw i8, ptr %source, i64 24
  %_18 = load i64, ptr %5, align 8, !noundef !4
  %_32.0 = add i64 %_18, %_17
  %_32.1 = icmp ult i64 %_32.0, %_17
  br i1 %_32.1, label %bb3, label %bb15, !prof !89

bb15:                                             ; preds = %bb12
  store i64 %_20.0, ptr %destination, align 8
  store i64 %_24.0, ptr %0, align 8
  store i64 %_28.0, ptr %2, align 8
  store i64 %_32.0, ptr %4, align 8
  br label %bb3

bb3:                                              ; preds = %bb12, %bb9, %bb6, %start, %bb15
  %_0.sroa.0.0 = phi i1 [ true, %bb15 ], [ false, %start ], [ false, %bb6 ], [ false, %bb9 ], [ false, %bb12 ]
  ret i1 %_0.sroa.0.0
}

; Function Attrs: nounwind nonlazybind uwtable
declare noundef range(i32 0, 10) i32 @rust_eh_personality(i32 noundef, i32 noundef, i64 noundef, ptr noundef, ptr noundef) unnamed_addr #0

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.start.p0(ptr captures(none)) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite)
declare void @llvm.lifetime.end.p0(ptr captures(none)) #5

; Function Attrs: mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write)
declare void @llvm.assume(i1 noundef) #6

; Function Attrs: mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite)
declare void @llvm.memcpy.p0.p0.i64(ptr noalias writeonly captures(none), ptr noalias readonly captures(none), i64, i1 immarg) #7

; alloc::raw_vec::handle_error
; Function Attrs: cold minsize noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error(i64 noundef range(i64 0, -9223372036854775807), i64) unnamed_addr #8

; core::panicking::panic_bounds_check
; Function Attrs: cold minsize noinline noreturn nounwind nonlazybind optsize uwtable
declare void @_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check(i64 noundef, i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #9

; core::option::expect_failed
; Function Attrs: cold noinline noreturn nounwind nonlazybind uwtable
declare void @_RNvNtCs4NRVxsYgnAr_4core6option13expect_failed(ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(24)) unnamed_addr #10

; __rustc::__rust_dealloc
; Function Attrs: nounwind nonlazybind allockind("free") uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc(ptr allocptr noundef nonnull captures(address), i64 noundef, i64 noundef range(i64 1, -9223372036854775807)) unnamed_addr #11

; __rustc::__rust_realloc
; Function Attrs: nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable
declare noalias noundef ptr @_RNvCs9wFQrvczXsK_7___rustc14___rust_realloc(ptr allocptr noundef nonnull, i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807), i64 noundef) unnamed_addr #12

; __rustc::__rust_no_alloc_shim_is_unstable_v2
; Function Attrs: nounwind nonlazybind uwtable
declare void @_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2() unnamed_addr #0

; __rustc::__rust_alloc
; Function Attrs: nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #13

; __rustc::__rust_alloc_zeroed
; Function Attrs: nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable
declare noalias noundef ptr @_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed(i64 noundef, i64 allocalign noundef range(i64 1, -9223372036854775807)) unnamed_addr #14

; Function Attrs: mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare { i64, i1 } @llvm.umul.with.overflow.i64(i64, i64) #15

; core::fmt::write
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvNtCs4NRVxsYgnAr_4core3fmt5write(ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(48), ptr noundef nonnull, ptr noundef nonnull) unnamed_addr #0

; <u64 as core::fmt::Display>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <u64 as core::fmt::UpperHex>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <u64 as core::fmt::LowerHex>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <usize as core::fmt::Display>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <usize as core::fmt::UpperHex>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <usize as core::fmt::LowerHex>::fmt
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt(ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(8), ptr noalias noundef align 8 dereferenceable(24)) unnamed_addr #0

; <core::fmt::Formatter>::write_str
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef) unnamed_addr #0

; <core::fmt::Formatter>::debug_struct_field2_finish
; Function Attrs: nounwind nonlazybind uwtable
declare noundef zeroext i1 @_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter26debug_struct_field2_finish(ptr noalias noundef align 8 dereferenceable(24), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32), ptr noalias noundef nonnull readonly captures(address, read_provenance), i64 noundef, ptr noundef nonnull, ptr noalias noundef readonly align 8 captures(address, read_provenance) dereferenceable(32)) unnamed_addr #0

; Function Attrs: nocallback nofree nounwind nonlazybind willreturn memory(argmem: read)
declare i32 @bcmp(ptr captures(none), ptr captures(none), i64) local_unnamed_addr #16

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #17

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umin.i64(i64, i64) #18

; Function Attrs: nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none)
declare i64 @llvm.umax.i64(i64, i64) #18

attributes #0 = { nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #1 = { cold nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #2 = { nofree norecurse nosync nounwind nonlazybind memory(read, argmem: readwrite, inaccessiblemem: readwrite, target_mem0: none, target_mem1: none) uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #3 = { inlinehint nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #4 = { mustprogress nofree noinline norecurse nosync nounwind nonlazybind willreturn memory(argmem: readwrite) uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #5 = { mustprogress nocallback nofree nosync nounwind willreturn memory(argmem: readwrite) }
attributes #6 = { mustprogress nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: write) }
attributes #7 = { mustprogress nocallback nofree nounwind willreturn memory(argmem: readwrite) }
attributes #8 = { cold minsize noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #9 = { cold minsize noinline noreturn nounwind nonlazybind optsize uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #10 = { cold noinline noreturn nounwind nonlazybind uwtable "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #11 = { nounwind nonlazybind allockind("free") uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #12 = { nounwind nonlazybind allockind("realloc,aligned") allocsize(3) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #13 = { nounwind nonlazybind allockind("alloc,uninitialized,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "alloc-variant-zeroed"="_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed" "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #14 = { nounwind nonlazybind allockind("alloc,zeroed,aligned") allocsize(0) uwtable "alloc-family"="__rust_alloc" "probe-stack"="inline-asm" "target-cpu"="sapphirerapids" "target-features"="+prfchw,+cldemote,+avx,+aes,+sahf,+pclmul,-xop,+crc32,-amx-fp8,+xsaves,+avx512fp16,-usermsr,-sm4,-egpr,+sse4.1,-avx10.1,+avx512ifma,+xsave,+sse4.2,-tsxldtrk,-sm3,-ptwrite,-widekl,-movrs,+invpcid,+64bit,+xsavec,+avx512vpopcntdq,+cmov,-avx512vp2intersect,+avx512cd,+movbe,-avxvnniint8,-ccmp,+amx-int8,-kl,-sha512,+avxvnni,-rtm,+adx,+avx2,-hreset,+movdiri,+serialize,+vpclmulqdq,+avx512vl,-uintr,-cf,+clflushopt,-raoint,-cmpccxadd,+bmi,+amx-tile,+sse,+gfni,-avxvnniint16,-amx-fp16,-zu,-ndd,+xsaveopt,+rdrnd,+avx512f,+amx-bf16,+avx512bf16,+avx512vnni,-push2pop2,+cx8,+avx512bw,+sse3,+pku,-nf,-amx-tf32,-amx-avx512,+fsgsbase,-clzero,-mwaitx,-lwp,+lzcnt,+sha,+movdir64b,-ppx,+wbnoinvd,-enqcmd,-avxneconvert,-tbm,-pconfig,-amx-complex,+ssse3,+cx16,-avx10.2,+bmi2,+fma,+popcnt,-avxifma,+f16c,+avx512bitalg,-rdpru,+clwb,+mmx,+sse2,+rdseed,+avx512vbmi2,-prefetchi,-amx-movrs,+rdpid,-fma4,+avx512vbmi,-shstk,+vaes,+waitpkg,-sgx,+fxsr,+avx512dq,-sse4a" }
attributes #15 = { mustprogress nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #16 = { nocallback nofree nounwind nonlazybind willreturn memory(argmem: read) }
attributes #17 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #18 = { nocallback nocreateundeforpoison nofree nosync nounwind speculatable willreturn memory(none) }
attributes #19 = { nounwind }
attributes #20 = { noreturn nounwind }

!llvm.module.flags = !{!0, !1}
!llvm.ident = !{!2}

!0 = !{i32 8, !"PIC Level", i32 2}
!1 = !{i32 2, !"RtLibUseGOT", i32 1}
!2 = !{!"rustc version 1.97.1 (8bab26f4f 2026-07-14)"}
!3 = !{i64 0, i64 -9223372036854775808}
!4 = !{}
!5 = !{!6}
!6 = distinct !{!6, !7, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsjJ7XxL93Zka_22histogram_merge_errors: %self"}
!7 = distinct !{!7, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner14grow_amortizedCsjJ7XxL93Zka_22histogram_merge_errors"}
!8 = !{i64 0, i64 2}
!9 = !{i64 0, i64 -9223372036854775807}
!10 = !{!11, !13}
!11 = distinct !{!11, !12, !"_RNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB4_12BucketSchema3new0B4_: %pair.0"}
!12 = distinct !{!12, !"_RNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB4_12BucketSchema3new0B4_"}
!13 = distinct !{!13, !14, !"_RNCINvNvNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3any5checkRSyNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB1j_12BucketSchema3new0E0B1j_: %x.0"}
!14 = distinct !{!14, !"_RNCINvNvNtNtNtNtCs4NRVxsYgnAr_4core4iter6traits8iterator8Iterator3any5checkRSyNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB1j_12BucketSchema3new0E0B1j_"}
!15 = !{!16}
!16 = distinct !{!16, !17, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3any5checkRSyNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB25_12BucketSchema3new0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB25_: %self"}
!17 = distinct !{!17, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter7WindowsyENtNtNtNtBa_4iter6traits8iterator8Iterator8try_folduNCINvNvBO_3any5checkRSyNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB25_12BucketSchema3new0E0INtNtNtBa_3ops12control_flow11ControlFlowuEEB25_"}
!18 = !{!19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!19 = distinct !{!19, !20, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3z_19CumulativeHistogram11delta_since0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3z_14HistogramErrorEEE9from_iterB3z_: %_0"}
!20 = distinct !{!20, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3z_19CumulativeHistogram11delta_since0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3z_14HistogramErrorEEE9from_iterB3z_"}
!21 = distinct !{!21, !20, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3z_19CumulativeHistogram11delta_since0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3z_14HistogramErrorEEE9from_iterB3z_: %iterator"}
!22 = distinct !{!22, !23, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3m_19CumulativeHistogram11delta_since0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3m_14HistogramErrorEEE9from_iterB3m_: %_0"}
!23 = distinct !{!23, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3m_19CumulativeHistogram11delta_since0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3m_14HistogramErrorEEE9from_iterB3m_"}
!24 = distinct !{!24, !23, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3m_19CumulativeHistogram11delta_since0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3m_14HistogramErrorEEE9from_iterB3m_: %iterator"}
!25 = distinct !{!25, !26, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3B_19CumulativeHistogram11delta_since0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3B_14HistogramErrorEEEB3B_: %_0"}
!26 = distinct !{!26, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3B_19CumulativeHistogram11delta_since0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3B_14HistogramErrorEEEB3B_"}
!27 = distinct !{!27, !26, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3B_19CumulativeHistogram11delta_since0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3B_14HistogramErrorEEEB3B_: %iter"}
!28 = distinct !{!28, !29, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_: %_0"}
!29 = distinct !{!29, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_"}
!30 = distinct !{!30, !29, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs0_B1n_NtB1n_19CumulativeHistogram11delta_since0EE0B1n_: %i"}
!31 = distinct !{!31, !32, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB21_19CumulativeHistogram11delta_since0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB21_14HistogramErrorENCINvXso_B3n_IB3l_INtNtCscdodAO9FK5_5alloc3vec3VecyEB47_EINtNtNtB4_6traits7collect12FromIteratorIB3l_yB47_EE9from_iterBQ_E0B4M_EB21_: %_0"}
!32 = distinct !{!32, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB21_19CumulativeHistogram11delta_since0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB21_14HistogramErrorENCINvXso_B3n_IB3l_INtNtCscdodAO9FK5_5alloc3vec3VecyEB47_EINtNtNtB4_6traits7collect12FromIteratorIB3l_yB47_EE9from_iterBQ_E0B4M_EB21_"}
!33 = distinct !{!33, !32, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB21_19CumulativeHistogram11delta_since0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB21_14HistogramErrorENCINvXso_B3n_IB3l_INtNtCscdodAO9FK5_5alloc3vec3VecyEB47_EINtNtNtB4_6traits7collect12FromIteratorIB3l_yB47_EE9from_iterBQ_E0B4M_EB21_: %iter"}
!34 = !{!35, !37, !39, !40, !42, !19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!35 = distinct !{!35, !36, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs0_B34_NtB34_19CumulativeHistogram11delta_since0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_: %self"}
!36 = distinct !{!36, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs0_B34_NtB34_19CumulativeHistogram11delta_since0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_"}
!37 = distinct !{!37, !38, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_: %self"}
!38 = distinct !{!38, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_"}
!39 = distinct !{!39, !38, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_: %g.1"}
!40 = distinct !{!40, !41, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB29_19CumulativeHistogram11delta_since0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB29_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4C_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5P_5Break0E0B5P_EB29_: %self"}
!41 = distinct !{!41, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB29_19CumulativeHistogram11delta_since0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB29_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4C_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5P_5Break0E0B5P_EB29_"}
!42 = distinct !{!42, !43, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_19CumulativeHistogram11delta_since0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB28_: %self"}
!43 = distinct !{!43, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_19CumulativeHistogram11delta_since0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB28_"}
!44 = !{!45, !19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!45 = distinct !{!45, !46, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!46 = distinct !{!46, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!47 = !{!48}
!48 = distinct !{!48, !49, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3h_19CumulativeHistogram11delta_since0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3h_14HistogramErrorEEE11spec_extendB3h_: %self"}
!49 = distinct !{!49, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3h_19CumulativeHistogram11delta_since0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3h_14HistogramErrorEEE11spec_extendB3h_"}
!50 = !{!51}
!51 = distinct !{!51, !52, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB35_19CumulativeHistogram11delta_since0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB35_14HistogramErrorEEEB35_: %self"}
!52 = distinct !{!52, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB35_19CumulativeHistogram11delta_since0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB35_14HistogramErrorEEEB35_"}
!53 = !{!54, !56, !58, !59, !61, !51, !63, !48, !64, !19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!54 = distinct !{!54, !55, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs0_B34_NtB34_19CumulativeHistogram11delta_since0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_: %self"}
!55 = distinct !{!55, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs0_B34_NtB34_19CumulativeHistogram11delta_since0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_"}
!56 = distinct !{!56, !57, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_: %self"}
!57 = distinct !{!57, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_"}
!58 = distinct !{!58, !57, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1S_19CumulativeHistogram11delta_since0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1S_14HistogramErrorEEB3a_8try_folduNCINvNvB3a_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6i_5Break0E0B6i_E0IB6j_B6i_EEB1S_: %g.1"}
!59 = distinct !{!59, !60, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB29_19CumulativeHistogram11delta_since0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB29_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4C_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5P_5Break0E0B5P_EB29_: %self"}
!60 = distinct !{!60, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB29_19CumulativeHistogram11delta_since0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB29_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4C_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5P_5Break0E0B5P_EB29_"}
!61 = distinct !{!61, !62, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_19CumulativeHistogram11delta_since0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB28_: %self"}
!62 = distinct !{!62, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_19CumulativeHistogram11delta_since0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB28_"}
!63 = distinct !{!63, !52, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB35_19CumulativeHistogram11delta_since0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB35_14HistogramErrorEEEB35_: %iterator"}
!64 = distinct !{!64, !49, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3h_19CumulativeHistogram11delta_since0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3h_14HistogramErrorEEE11spec_extendB3h_: %iter"}
!65 = !{!51, !48}
!66 = !{!63, !64, !19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!67 = !{!51, !63, !48, !64, !19, !21, !22, !24, !25, !27, !28, !30, !31, !33}
!68 = !{!21, !24, !27, !30, !31, !33}
!69 = !{!31, !33}
!70 = !{!71, !73, !75, !76}
!71 = distinct !{!71, !72, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!72 = distinct !{!72, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!73 = distinct !{!73, !74, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %v"}
!74 = distinct !{!74, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors"}
!75 = distinct !{!75, !74, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %s.0"}
!76 = distinct !{!76, !77, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!77 = distinct !{!77, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors"}
!78 = !{!73, !75, !76}
!79 = !{!73, !76}
!80 = !{!81}
!81 = distinct !{!81, !82, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %_0"}
!82 = distinct !{!82, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts"}
!83 = !{!84, !86, !81, !87, !88}
!84 = distinct !{!84, !85, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %_0"}
!85 = distinct !{!85, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_"}
!86 = distinct !{!86, !85, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %self"}
!87 = distinct !{!87, !82, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %schema"}
!88 = distinct !{!88, !82, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %counts"}
!89 = !{!"branch_weights", !"expected", i32 1, i32 2000}
!90 = !{!87, !88}
!91 = !{!81, !87, !88}
!92 = !{!93, !95, !97, !98}
!93 = distinct !{!93, !94, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!94 = distinct !{!94, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!95 = distinct !{!95, !96, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %v"}
!96 = distinct !{!96, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors"}
!97 = distinct !{!97, !96, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %s.0"}
!98 = distinct !{!98, !99, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!99 = distinct !{!99, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors"}
!100 = !{!95, !97, !98}
!101 = !{!95, !98}
!102 = !{!103, !105, !107, !108}
!103 = distinct !{!103, !104, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!104 = distinct !{!104, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!105 = distinct !{!105, !106, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %v"}
!106 = distinct !{!106, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors"}
!107 = distinct !{!107, !106, !"_RINvXs_NvMNtCscdodAO9FK5_5alloc5sliceSp9to_vec_inyNtB5_10ConvertVec6to_vecNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %s.0"}
!108 = distinct !{!108, !109, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!109 = distinct !{!109, !"_RNvXsa_NtCscdodAO9FK5_5alloc3vecINtB5_3VecyENtNtCs4NRVxsYgnAr_4core5clone5Clone5cloneCsjJ7XxL93Zka_22histogram_merge_errors"}
!110 = !{!105, !107, !108}
!111 = !{!105, !108}
!112 = !{!113}
!113 = distinct !{!113, !114, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %_0"}
!114 = distinct !{!114, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts"}
!115 = !{!116, !118, !113, !119, !120}
!116 = distinct !{!116, !117, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %_0"}
!117 = distinct !{!117, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_"}
!118 = distinct !{!118, !117, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %self"}
!119 = distinct !{!119, !114, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %schema"}
!120 = distinct !{!120, !114, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts: %counts"}
!121 = !{!119, !120}
!122 = !{!113, !119, !120}
!123 = !{!124}
!124 = distinct !{!124, !125, !"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_: %_1"}
!125 = distinct !{!125, !"_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_"}
!126 = !{!"branch_weights", i32 2000, i32 2002}
!127 = !{!128, !130}
!128 = distinct !{!128, !129, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %_0"}
!129 = distinct !{!129, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_"}
!130 = distinct !{!130, !129, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11from_counts0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %self"}
!131 = !{!132}
!132 = distinct !{!132, !133, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %_0"}
!133 = distinct !{!133, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_"}
!134 = !{!132, !135}
!135 = distinct !{!135, !133, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %self"}
!136 = !{!137, !132}
!137 = distinct !{!137, !138, !"_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorENtNtNtB7_3ops9try_trait3Try11from_outputBN_: %_0"}
!138 = distinct !{!138, !"_RNvXsp_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorENtNtNtB7_3ops9try_trait3Try11from_outputBN_"}
!139 = !{!135}
!140 = !{!141, !143, !132}
!141 = distinct !{!141, !142, !"_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualBN_: %_0"}
!142 = distinct !{!142, !"_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualBN_"}
!143 = distinct !{!143, !142, !"_RNvXsq_NtCs4NRVxsYgnAr_4core6resultINtB5_6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtB7_3ops9try_trait12FromResidualIBy_NtNtB7_7convert10InfallibleBL_EE13from_residualBN_: %residual"}
!144 = !{!145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!145 = distinct !{!145, !146, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3y_17IntervalHistogram16merge_compatible0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3y_14HistogramErrorEEE9from_iterB3y_: %_0"}
!146 = distinct !{!146, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3y_17IntervalHistogram16merge_compatible0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3y_14HistogramErrorEEE9from_iterB3y_"}
!147 = distinct !{!147, !146, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec21spec_from_iter_nestedINtB4_3VecyEINtB2_18SpecFromIterNestedyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1w_3map3MapINtNtB1w_3zip3ZipINtNtNtB1A_5slice4iter4IteryEB2T_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3y_17IntervalHistogram16merge_compatible0EINtNtB1A_6result6ResultNtNtB1A_7convert10InfallibleNtB3y_14HistogramErrorEEE9from_iterB3y_: %iterator"}
!148 = distinct !{!148, !149, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3l_17IntervalHistogram16merge_compatible0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3l_14HistogramErrorEEE9from_iterB3l_: %_0"}
!149 = distinct !{!149, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3l_17IntervalHistogram16merge_compatible0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3l_14HistogramErrorEEE9from_iterB3l_"}
!150 = distinct !{!150, !149, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec14spec_from_iterINtB4_3VecyEINtB2_12SpecFromIteryINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1j_3map3MapINtNtB1j_3zip3ZipINtNtNtB1n_5slice4iter4IteryEB2G_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3l_17IntervalHistogram16merge_compatible0EINtNtB1n_6result6ResultNtNtB1n_7convert10InfallibleNtB3l_14HistogramErrorEEE9from_iterB3l_: %iterator"}
!151 = distinct !{!151, !152, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3A_17IntervalHistogram16merge_compatible0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3A_14HistogramErrorEEEB3A_: %_0"}
!152 = distinct !{!152, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3A_17IntervalHistogram16merge_compatible0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3A_14HistogramErrorEEEB3A_"}
!153 = distinct !{!153, !152, !"_RINvXse_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyEINtNtNtNtCs4NRVxsYgnAr_4core4iter6traits7collect12FromIteratoryE9from_iterINtNtBO_8adapters12GenericShuntINtNtB1W_3map3MapINtNtB1W_3zip3ZipINtNtNtBQ_5slice4iter4IteryEB2W_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3A_17IntervalHistogram16merge_compatible0EINtNtBQ_6result6ResultNtNtBQ_7convert10InfallibleNtB3A_14HistogramErrorEEEB3A_: %iter"}
!154 = distinct !{!154, !155, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_: %_0"}
!155 = distinct !{!155, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_"}
!156 = distinct !{!156, !155, !"_RNCINvXso_NtCs4NRVxsYgnAr_4core6resultINtB8_6ResultINtNtCscdodAO9FK5_5alloc3vec3VecyENtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEINtNtNtNtBa_4iter6traits7collect12FromIteratorIBB_yB1l_EE9from_iterINtNtNtB2n_8adapters3map3MapINtNtB3q_3zip3ZipINtNtNtBa_5slice4iter4IteryEB44_ENCNvMs_B1n_NtB1n_17IntervalHistogram16merge_compatible0EE0B1n_: %i"}
!157 = distinct !{!157, !158, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB20_17IntervalHistogram16merge_compatible0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB20_14HistogramErrorENCINvXso_B3p_IB3n_INtNtCscdodAO9FK5_5alloc3vec3VecyEB49_EINtNtNtB4_6traits7collect12FromIteratorIB3n_yB49_EE9from_iterBQ_E0B4O_EB20_: %_0"}
!158 = distinct !{!158, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB20_17IntervalHistogram16merge_compatible0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB20_14HistogramErrorENCINvXso_B3p_IB3n_INtNtCscdodAO9FK5_5alloc3vec3VecyEB49_EINtNtNtB4_6traits7collect12FromIteratorIB3n_yB49_EE9from_iterBQ_E0B4O_EB20_"}
!159 = distinct !{!159, !158, !"_RINvNtNtCs4NRVxsYgnAr_4core4iter8adapters11try_processINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1m_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB20_17IntervalHistogram16merge_compatible0EyINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB20_14HistogramErrorENCINvXso_B3p_IB3n_INtNtCscdodAO9FK5_5alloc3vec3VecyEB49_EINtNtNtB4_6traits7collect12FromIteratorIB3n_yB49_EE9from_iterBQ_E0B4O_EB20_: %iter"}
!160 = !{!161, !163, !165, !166, !168, !145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!161 = distinct !{!161, !162, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs_B34_NtB34_17IntervalHistogram16merge_compatible0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_: %self"}
!162 = distinct !{!162, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs_B34_NtB34_17IntervalHistogram16merge_compatible0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_"}
!163 = distinct !{!163, !164, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_: %self"}
!164 = distinct !{!164, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_"}
!165 = distinct !{!165, !164, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_: %g.1"}
!166 = distinct !{!166, !167, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_17IntervalHistogram16merge_compatible0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4E_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5R_5Break0E0B5R_EB28_: %self"}
!167 = distinct !{!167, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_17IntervalHistogram16merge_compatible0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4E_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5R_5Break0E0B5R_EB28_"}
!168 = distinct !{!168, !169, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB27_17IntervalHistogram16merge_compatible0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB27_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB27_: %self"}
!169 = distinct !{!169, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB27_17IntervalHistogram16merge_compatible0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB27_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB27_"}
!170 = !{!171, !145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!171 = distinct !{!171, !172, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!172 = distinct !{!172, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!173 = !{!174}
!174 = distinct !{!174, !175, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3g_17IntervalHistogram16merge_compatible0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3g_14HistogramErrorEEE11spec_extendB3g_: %self"}
!175 = distinct !{!175, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3g_17IntervalHistogram16merge_compatible0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3g_14HistogramErrorEEE11spec_extendB3g_"}
!176 = !{!177}
!177 = distinct !{!177, !178, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB34_17IntervalHistogram16merge_compatible0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB34_14HistogramErrorEEEB34_: %self"}
!178 = distinct !{!178, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB34_17IntervalHistogram16merge_compatible0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB34_14HistogramErrorEEEB34_"}
!179 = !{!180, !182, !184, !185, !187, !177, !189, !174, !190, !145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!180 = distinct !{!180, !181, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs_B34_NtB34_17IntervalHistogram16merge_compatible0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_: %self"}
!181 = distinct !{!181, !"_RINvYINtNtNtNtCs4NRVxsYgnAr_4core4iter8adapters3zip3ZipINtNtNtBc_5slice4iter4IteryEBR_ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvNtB8_3map12map_try_foldTRyB2y_EINtNtBc_6result6ResultyNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorEuINtNtNtBc_3ops12control_flow11ControlFlowIB3Z_yEENCNvMs_B34_NtB34_17IntervalHistogram16merge_compatible0NCINvXB8_INtB8_12GenericShuntINtB2a_3MapB3_B4L_EIB2G_NtNtBc_7convert10InfallibleB32_EEB1n_8try_folduNCINvNvB1n_12try_for_each4callyB4D_NcNtB4D_5Break0E0B4D_E0E0B3Y_EB34_"}
!182 = distinct !{!182, !183, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_: %self"}
!183 = distinct !{!183, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_"}
!184 = distinct !{!184, !183, !"_RINvXs0_NtNtNtCs4NRVxsYgnAr_4core4iter8adapters3mapINtB6_3MapINtNtB8_3zip3ZipINtNtNtBc_5slice4iter4IteryEB1d_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1R_17IntervalHistogram16merge_compatible0ENtNtNtBa_6traits8iterator8Iterator8try_folduNCINvXB8_INtB8_12GenericShuntBN_INtNtBc_6result6ResultNtNtBc_7convert10InfallibleNtB1R_14HistogramErrorEEB3c_8try_folduNCINvNvB3c_12try_for_each4callyINtNtNtBc_3ops12control_flow11ControlFlowyENcNtB6k_5Break0E0B6k_E0IB6l_B6k_EEB1R_: %g.1"}
!185 = distinct !{!185, !186, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_17IntervalHistogram16merge_compatible0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4E_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5R_5Break0E0B5R_EB28_: %self"}
!186 = distinct !{!186, !"_RINvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB3_12GenericShuntINtNtB3_3map3MapINtNtB3_3zip3ZipINtNtNtB7_5slice4iter4IteryEB1u_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB28_17IntervalHistogram16merge_compatible0EINtNtB7_6result6ResultNtNtB7_7convert10InfallibleNtB28_14HistogramErrorEENtNtNtB5_6traits8iterator8Iterator8try_folduNCINvNvB4E_12try_for_each4callyINtNtNtB7_3ops12control_flow11ControlFlowyENcNtB5R_5Break0E0B5R_EB28_"}
!187 = distinct !{!187, !188, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB27_17IntervalHistogram16merge_compatible0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB27_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB27_: %self"}
!188 = distinct !{!188, !"_RNvXNtNtCs4NRVxsYgnAr_4core4iter8adaptersINtB2_12GenericShuntINtNtB2_3map3MapINtNtB2_3zip3ZipINtNtNtB6_5slice4iter4IteryEB1t_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB27_17IntervalHistogram16merge_compatible0EINtNtB6_6result6ResultNtNtB6_7convert10InfallibleNtB27_14HistogramErrorEENtNtNtB4_6traits8iterator8Iterator4nextB27_"}
!189 = distinct !{!189, !178, !"_RINvMsj_NtCscdodAO9FK5_5alloc3vecINtB6_3VecyE16extend_desugaredINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB12_3map3MapINtNtB12_3zip3ZipINtNtNtB16_5slice4iter4IteryEB2p_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB34_17IntervalHistogram16merge_compatible0EINtNtB16_6result6ResultNtNtB16_7convert10InfallibleNtB34_14HistogramErrorEEEB34_: %iterator"}
!190 = distinct !{!190, !175, !"_RNvXNtNtCscdodAO9FK5_5alloc3vec11spec_extendINtB4_3VecyEINtB2_10SpecExtendyINtNtNtCs4NRVxsYgnAr_4core4iter8adapters12GenericShuntINtNtB1e_3map3MapINtNtB1e_3zip3ZipINtNtNtB1i_5slice4iter4IteryEB2B_ENCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB3g_17IntervalHistogram16merge_compatible0EINtNtB1i_6result6ResultNtNtB1i_7convert10InfallibleNtB3g_14HistogramErrorEEE11spec_extendB3g_: %iter"}
!191 = !{!177, !174}
!192 = !{!189, !190, !145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!193 = !{!177, !189, !174, !190, !145, !147, !148, !150, !151, !153, !154, !156, !157, !159}
!194 = !{!147, !150, !153, !156, !157, !159}
!195 = !{!157, !159}
!196 = !{!197}
!197 = distinct !{!197, !198, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count: %self"}
!198 = distinct !{!198, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count"}
!199 = !{!200}
!200 = distinct !{!200, !198, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count: %_0"}
!201 = !{!202, !204, !200, !197}
!202 = distinct !{!202, !203, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %_0"}
!203 = distinct !{!203, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_"}
!204 = distinct !{!204, !203, !"_RINvYINtNtNtCs4NRVxsYgnAr_4core5slice4iter4IteryENtNtNtNtBa_4iter6traits8iterator8Iterator8try_foldyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1H_17IntervalHistogram11total_count0INtNtBa_6result6ResultyNtB1H_14HistogramErrorEEB1H_: %self"}
!205 = !{!206, !208}
!206 = distinct !{!206, !207, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!207 = distinct !{!207, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!208 = distinct !{!208, !209, !"_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!209 = distinct !{!209, !"_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors"}
!210 = !{!208}
!211 = !{!212, !214}
!212 = distinct !{!212, !213, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB1i_12BucketSchema12bucket_index0E0EB1i_: %self.0"}
!213 = distinct !{!213, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB1i_12BucketSchema12bucket_index0E0EB1i_"}
!214 = distinct !{!214, !215, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_: %self.0"}
!215 = distinct !{!215, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_"}
!216 = !{!217, !218, !219}
!217 = distinct !{!217, !213, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB1i_12BucketSchema12bucket_index0E0EB1i_: argument 1"}
!218 = distinct !{!218, !215, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtBS_12BucketSchema12bucket_index0EBS_: argument 1"}
!219 = distinct !{!219, !220, !"_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema12bucket_index: %_0"}
!220 = distinct !{!220, !"_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema12bucket_index"}
!221 = !{!219}
!222 = !{!223, !225}
!223 = distinct !{!223, !224, !"_RINvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB7_4IteryENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1I_17IntervalHistogram7coarsen0EB1I_: %self"}
!224 = distinct !{!224, !"_RINvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB7_4IteryENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1I_17IntervalHistogram7coarsen0EB1I_"}
!225 = distinct !{!225, !224, !"_RINvXs2J_NtNtCs4NRVxsYgnAr_4core5slice4iterINtB7_4IteryENtNtNtNtBb_4iter6traits8iterator8Iterator3anyNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1I_17IntervalHistogram7coarsen0EB1I_: argument 1"}
!226 = !{!227}
!227 = distinct !{!227, !228, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCNvB2_13binary_search0ECsjJ7XxL93Zka_22histogram_merge_errors: %self.0"}
!228 = distinct !{!228, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCNvB2_13binary_search0ECsjJ7XxL93Zka_22histogram_merge_errors"}
!229 = !{!230, !223, !225}
!230 = distinct !{!230, !228, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCNvB2_13binary_search0ECsjJ7XxL93Zka_22histogram_merge_errors: argument 1"}
!231 = !{!232}
!232 = distinct !{!232, !233, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty: %_0"}
!233 = distinct !{!233, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty"}
!234 = !{!235}
!235 = distinct !{!235, !233, !"_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty: %schema"}
!236 = !{!237, !239, !232, !235}
!237 = distinct !{!237, !238, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!238 = distinct !{!238, !"_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner15try_allocate_inCsjJ7XxL93Zka_22histogram_merge_errors"}
!239 = distinct !{!239, !240, !"_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors: %_0"}
!240 = distinct !{!240, !"_RINvXs_NtNtCscdodAO9FK5_5alloc3vec14spec_from_elemyNtB5_12SpecFromElem9from_elemNtNtB9_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors"}
!241 = !{!239, !232, !235}
!242 = !{!232, !235}
!243 = !{!244, !246}
!244 = distinct !{!244, !245, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1k_17IntervalHistogram7coarsens_0E0EB1k_: %self.0"}
!245 = distinct !{!245, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1k_17IntervalHistogram7coarsens_0E0EB1k_"}
!246 = distinct !{!246, !247, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtBU_17IntervalHistogram7coarsens_0EBU_: %self.0"}
!247 = distinct !{!247, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtBU_17IntervalHistogram7coarsens_0EBU_"}
!248 = !{!249, !250}
!249 = distinct !{!249, !245, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy16binary_search_byNCINvB2_15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB1k_17IntervalHistogram7coarsens_0E0EB1k_: argument 1"}
!250 = distinct !{!250, !247, !"_RINvMNtCs4NRVxsYgnAr_4core5sliceSy15partition_pointNCNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtBU_17IntervalHistogram7coarsens_0EBU_: argument 1"}
!251 = !{i64 8}
!252 = !{!253}
!253 = distinct !{!253, !254, !"_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt: %self"}
!254 = distinct !{!254, !"_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt"}
!255 = !{i64 0, i64 11}
!256 = !{!257}
!257 = distinct !{!257, !254, !"_RNvXsq_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt5Debug3fmt: %f"}
!258 = !{!253, !257}
!259 = !{!260}
!260 = distinct !{!260, !261, !"_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt: %f"}
!261 = distinct !{!261, !"_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt"}
!262 = !{!263}
!263 = distinct !{!263, !261, !"_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt: %self"}
!264 = !{!265}
!265 = distinct !{!265, !266, !"_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt: %f"}
!266 = distinct !{!266, !"_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt"}
!267 = !{!268}
!268 = distinct !{!268, !266, !"_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt: %self"}
