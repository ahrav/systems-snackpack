	.file	"histogram_merge_errors.e5c864da82682430-cgu.0"
	.section	.text._RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_,"ax",@progbits
	.p2align	4
	.type	_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_,@function
_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	(%rdi), %rsi
	testq	%rsi, %rsi
	je	.LBB0_2
	movq	8(%rbx), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB0_2:
	movq	24(%rbx), %rsi
	testq	%rsi, %rsi
	je	.LBB0_3
	movq	32(%rbx), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	popq	%rbx
	.cfi_def_cfa_offset 8
	jmpq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB0_3:
	.cfi_def_cfa_offset 16
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end0:
	.size	_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_, .Lfunc_end0-_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_
	.cfi_endproc

	.section	.text.unlikely._RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors,"ax",@progbits
	.p2align	4
	.type	_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors,@function
_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$24, %rsp
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	addq	%rdx, %rsi
	jb	.LBB1_1
	movq	%rdi, %rbx
	movq	(%rdi), %rax
	leaq	(%rax,%rax), %rcx
	cmpq	%rcx, %rsi
	cmovaq	%rsi, %rcx
	cmpq	$5, %rcx
	movl	$4, %r14d
	cmovaeq	%rcx, %r14
	movq	8(%rdi), %rdx
	movq	%rsp, %rdi
	movq	%rax, %rsi
	movq	%r14, %rcx
	callq	_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors
	cmpl	$1, (%rsp)
	je	.LBB1_3
	movq	8(%rsp), %rax
	movq	%rax, 8(%rbx)
	movq	%r14, (%rbx)
	addq	$24, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB1_1:
	.cfi_def_cfa_offset 48
	xorl	%edi, %edi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB1_3:
	movq	8(%rsp), %rdi
	movq	16(%rsp), %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end1:
	.size	_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors, .Lfunc_end1-_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors
	.cfi_endproc

	.section	.text._RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new,"ax",@progbits
	.globl	_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new
	.p2align	4
	.type	_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new,@function
_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new:
	.cfi_startproc
	pushq	%rbx
	.cfi_def_cfa_offset 16
	.cfi_offset %rbx, -16
	movq	%rdi, %rbx
	movq	16(%rsi), %rax
	testq	%rax, %rax
	je	.LBB2_1
	movq	8(%rsi), %rcx
	addq	$8, %rcx
	.p2align	4
.LBB2_3:
	cmpq	$2, %rax
	jb	.LBB2_8
	decq	%rax
	movq	-8(%rcx), %rdx
	cmpq	(%rcx), %rdx
	leaq	8(%rcx), %rcx
	jb	.LBB2_3
	movl	$1, %eax
	jmp	.LBB2_6
.LBB2_1:
	xorl	%eax, %eax
.LBB2_6:
	movq	%rax, 8(%rbx)
	movq	$1, (%rbx)
	movq	(%rsi), %rax
	testq	%rax, %rax
	je	.LBB2_9
	movq	8(%rsi), %rdi
	shlq	$3, %rax
	movl	$8, %edx
	movq	%rax, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB2_9:
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.LBB2_8:
	.cfi_def_cfa_offset 16
	movq	16(%rsi), %rax
	movq	%rax, 24(%rbx)
	vmovups	(%rsi), %xmm0
	vmovups	%xmm0, 8(%rbx)
	movq	$0, (%rbx)
	movq	%rbx, %rax
	popq	%rbx
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end2:
	.size	_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new, .Lfunc_end2-_RNvMCsjJ7XxL93Zka_22histogram_merge_errorsNtB2_12BucketSchema3new
	.cfi_endproc

	.section	.text._RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since,"ax",@progbits
	.globl	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since
	.p2align	4
	.type	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since,@function
_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movq	16(%rsi), %r15
	cmpq	16(%rdx), %r15
	jne	.LBB3_2
	movq	%rdx, %r12
	movq	%rsi, %rbp
	movq	8(%rdx), %rsi
	movq	8(%rbp), %r13
	leaq	(,%r15,8), %r14
	movq	%r13, %rdi
	movq	%r14, %rdx
	callq	*bcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB3_5
.LBB3_2:
	movq	$4, 8(%rbx)
.LBB3_3:
	movq	$-1, (%rbx)
.LBB3_4:
	movq	%rbx, %rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB3_5:
	.cfi_def_cfa_offset 112
	movq	%r13, 48(%rsp)
	movq	40(%rbp), %r13
	movq	40(%r12), %rax
	cmpq	%r13, %rax
	cmovbq	%rax, %r13
	movl	$8, %edi
	testq	%r13, %r13
	je	.LBB3_8
	movq	32(%rbp), %rax
	movq	32(%r12), %rcx
	movq	(%rax), %r14
	subq	(%rcx), %r14
	jae	.LBB3_9
.LBB3_7:
	movq	$5, 8(%rbx)
	jmp	.LBB3_3
.LBB3_8:
	xorl	%esi, %esi
	movl	$8, %r12d
	testq	%r15, %r15
	jne	.LBB3_20
.LBB3_22:
	cmpq	%r15, %r13
	jne	.LBB3_27
.LBB3_23:
	xorl	%eax, %eax
	xorl	%ecx, %ecx
	.p2align	4
.LBB3_24:
	cmpq	%rax, %r14
	je	.LBB3_32
	movq	%rcx, %r13
	addq	(%r12,%rax), %rcx
	leaq	8(%rax), %rax
	jae	.LBB3_24
	movl	$16, %eax
	movl	$6, %edx
	movl	$8, %ecx
	jmp	.LBB3_28
.LBB3_9:
	movq	%rcx, 40(%rsp)
	movq	%rax, 8(%rsp)
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$32, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB3_34
	movq	%rax, %r12
	movq	%r14, (%rax)
	movq	$4, 16(%rsp)
	movq	%rax, 24(%rsp)
	movq	$1, 32(%rsp)
	movl	$4, %esi
	cmpq	$1, %r13
	jne	.LBB3_12
	leaq	(,%r15,8), %r14
	movl	$8, %edi
	testq	%r15, %r15
	jne	.LBB3_20
	jmp	.LBB3_22
.LBB3_32:
	movq	%r15, (%rbx)
	movq	%rdi, 8(%rbx)
	movq	%r15, 16(%rbx)
	movq	%rsi, 24(%rbx)
	movq	%r12, 32(%rbx)
	movq	%r15, 40(%rbx)
	jmp	.LBB3_4
.LBB3_12:
	movl	$1, %ebp
	leaq	16(%rsp), %rsi
	movl	$8, %edi
	movq	8(%rsp), %rax
	movq	40(%rsp), %rcx
	.p2align	4
.LBB3_13:
	movq	(%rax,%rbp,8), %r14
	subq	(%rcx,%rbp,8), %r14
	jb	.LBB3_17
	cmpq	16(%rsp), %rbp
	je	.LBB3_16
.LBB3_15:
	movq	%r14, (%r12,%rbp,8)
	incq	%rbp
	movq	%rbp, 32(%rsp)
	cmpq	%rbp, %r13
	jne	.LBB3_13
	jmp	.LBB3_19
.LBB3_16:
	movl	$1, %edx
	movq	%rsi, %rdi
	movq	%rsi, %r12
	movq	%rbp, %rsi
	callq	_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors
	movq	%r12, %rsi
	movq	40(%rsp), %rcx
	movq	8(%rsp), %rax
	movl	$8, %edi
	movq	24(%rsp), %r12
	jmp	.LBB3_15
.LBB3_17:
	movq	16(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB3_7
	movq	24(%rsp), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB3_7
.LBB3_19:
	movq	16(%rsp), %rsi
	movq	24(%rsp), %r12
	leaq	(,%r15,8), %r14
	testq	%r15, %r15
	je	.LBB3_22
.LBB3_20:
	movq	%rsi, 8(%rsp)
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%r14, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB3_33
	movq	%rax, %rbp
	movq	%rax, %rdi
	movq	48(%rsp), %rsi
	movq	%r14, %rdx
	callq	*memcpy@GOTPCREL(%rip)
	movq	%rbp, %rdi
	movq	8(%rsp), %rsi
	cmpq	%r15, %r13
	je	.LBB3_23
.LBB3_27:
	movq	$2, 8(%rbx)
	movl	$24, %eax
	movl	$16, %ecx
	movq	%r15, %rdx
.LBB3_28:
	movq	%rdx, (%rbx,%rcx)
	movq	%r13, (%rbx,%rax)
	movq	$-1, (%rbx)
	testq	%rsi, %rsi
	je	.LBB3_30
	shlq	$3, %rsi
	movl	$8, %edx
	movq	%rdi, %r13
	movq	%r12, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r13, %rdi
.LBB3_30:
	testq	%r15, %r15
	je	.LBB3_4
	movl	$8, %edx
	movq	%r14, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB3_4
.LBB3_33:
	movl	$8, %edi
	movq	%r14, %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB3_34:
	movl	$8, %edi
	movl	$32, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end3:
	.size	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since, .Lfunc_end3-_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram11delta_since
	.cfi_endproc

	.section	.text._RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new,"ax",@progbits
	.globl	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new
	.p2align	4
	.type	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new,@function
_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$104, %rsp
	.cfi_def_cfa_offset 160
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, (%rsp)
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	8(%rsi), %rax
	movq	%rax, 16(%rsp)
	movq	16(%rsi), %r15
	leaq	(,%r15,8), %r13
	movl	$8, %r12d
	movl	$8, %ebp
	testq	%r15, %r15
	je	.LBB4_3
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%r13, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB4_24
	movq	%rax, %rbp
	movq	%rax, %rdi
	movq	16(%rsp), %rsi
	movq	%r13, %rdx
	callq	*memcpy@GOTPCREL(%rip)
.LBB4_3:
	movq	%rbp, 24(%rsp)
	movq	%r14, 32(%rsp)
	movq	(%rsp), %rax
	movq	8(%rax), %rcx
	movq	%rcx, 8(%rsp)
	movq	16(%rax), %r14
	leaq	(,%r14,8), %rbp
	testq	%r14, %r14
	je	.LBB4_6
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%rbp, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB4_25
	movq	%rax, %r12
	movq	%rax, %rdi
	movq	8(%rsp), %rsi
	movq	%rbp, %rdx
	callq	*memcpy@GOTPCREL(%rip)
.LBB4_6:
	cmpq	%r15, %r14
	jne	.LBB4_11
	xorl	%esi, %esi
	leaq	40(%rsp), %rax
	leaq	48(%rsp), %rcx
	xorl	%edi, %edi
	movq	%rbp, %r8
	movq	24(%rsp), %rbp
	.p2align	4
.LBB4_8:
	cmpq	%rsi, %r13
	je	.LBB4_20
	movq	%rdi, %rdx
	addq	(%r12,%rsi), %rdi
	leaq	8(%rsi), %rsi
	jae	.LBB4_8
	movl	$6, %esi
	jmp	.LBB4_12
.LBB4_11:
	movq	$2, 48(%rsp)
	leaq	96(%rsp), %rax
	leaq	40(%rsp), %rcx
	movq	%r15, %rsi
	movq	%r14, %rdx
	movq	%rbp, %r8
	movq	24(%rsp), %rbp
.LBB4_12:
	movq	%rsi, (%rcx)
	movq	%rdx, (%rax)
	testq	%r14, %r14
	je	.LBB4_14
	movl	$8, %edx
	movq	%r12, %rdi
	movq	%r8, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB4_14:
	testq	%r15, %r15
	movq	32(%rsp), %r14
	je	.LBB4_16
	movl	$8, %edx
	movq	%rbp, %rdi
	movq	%r13, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB4_16:
	movq	48(%rsp), %rax
	movq	40(%rsp), %rcx
	movq	96(%rsp), %rdx
	movq	%rax, 8(%rbx)
	movq	%rcx, 16(%rbx)
	movq	%rdx, 24(%rbx)
	movq	$-1, (%rbx)
	movq	(%rsp), %rax
	movq	(%rax), %rsi
	testq	%rsi, %rsi
	je	.LBB4_18
	shlq	$3, %rsi
	movl	$8, %edx
	movq	8(%rsp), %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB4_18:
	movq	(%r14), %rsi
	testq	%rsi, %rsi
	je	.LBB4_23
	shlq	$3, %rsi
	movl	$8, %edx
	movq	16(%rsp), %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB4_23
.LBB4_20:
	testq	%r15, %r15
	je	.LBB4_22
	movq	_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip), %r14
	movl	$8, %edx
	movq	%rbp, %rdi
	movq	%r13, %rsi
	callq	*%r14
	movl	$8, %edx
	movq	%r12, %rdi
	movq	%r13, %rsi
	callq	*%r14
.LBB4_22:
	movq	32(%rsp), %rcx
	movq	16(%rcx), %rax
	movq	%rax, 64(%rsp)
	vmovups	(%rcx), %xmm0
	vmovaps	%xmm0, 48(%rsp)
	movq	(%rsp), %rax
	vmovups	(%rax), %xmm0
	vmovups	%xmm0, 72(%rsp)
	movq	16(%rax), %rax
	movq	%rax, 88(%rsp)
	vmovups	48(%rsp), %xmm0
	vmovups	%xmm0, (%rbx)
	movq	64(%rsp), %rax
	movq	%rax, 16(%rbx)
	movq	72(%rsp), %rax
	movq	%rax, 24(%rbx)
	movq	64(%rsp), %rax
	movq	%rax, 16(%rbx)
	vmovups	72(%rsp), %xmm0
	vmovups	%xmm0, 24(%rbx)
	movq	88(%rsp), %rax
	movq	%rax, 40(%rbx)
.LBB4_23:
	movq	%rbx, %rax
	addq	$104, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB4_24:
	.cfi_def_cfa_offset 160
	movl	$8, %edi
	movq	%r13, %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB4_25:
	movl	$8, %edi
	movq	%rbp, %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end4:
	.size	_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new, .Lfunc_end4-_RNvMs0_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_19CumulativeHistogram3new
	.cfi_endproc

	.section	.text.unlikely._RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors,"ax",@progbits
	.p2align	4
	.type	_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors,@function
_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%rbx
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rdi, %rbx
	leaq	(,%rcx,8), %r14
	shrq	$61, %rcx
	setne	%al
	movabsq	$9223372036854775800, %rcx
	cmpq	%rcx, %r14
	seta	%cl
	movl	$1, %r15d
	orb	%al, %cl
	je	.LBB5_2
	movl	$8, %eax
	xorl	%r14d, %r14d
	jmp	.LBB5_10
.LBB5_2:
	testq	%rsi, %rsi
	je	.LBB5_4
	shlq	$3, %rsi
	movq	%rdx, %rdi
	movl	$8, %edx
	movq	%r14, %rcx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_realloc@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB5_6
	jmp	.LBB5_9
.LBB5_4:
	testq	%r14, %r14
	je	.LBB5_5
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%r14, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB5_6
.LBB5_9:
	movq	$8, 8(%rbx)
	movl	$16, %eax
	jmp	.LBB5_10
.LBB5_5:
	movl	$8, %eax
.LBB5_6:
	movq	%rax, 8(%rbx)
	movl	$16, %eax
	xorl	%r15d, %r15d
.LBB5_10:
	movq	%r14, (%rbx,%rax)
	movq	%r15, (%rbx)
	popq	%rbx
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end5:
	.size	_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors, .Lfunc_end5-_RNvMs4_NtCscdodAO9FK5_5alloc7raw_vecNtB5_11RawVecInner11finish_growCsjJ7XxL93Zka_22histogram_merge_errors
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	subq	$56, %rsp
	.cfi_def_cfa_offset 80
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rdi, %rbx
	movq	16(%rdx), %rax
	movq	16(%rsi), %rdi
	cmpq	%rdi, %rax
	jne	.LBB6_7
	movq	8(%rdx), %rdi
	shlq	$3, %rax
	xorl	%r8d, %r8d
	xorl	%r9d, %r9d
	.p2align	4
.LBB6_2:
	cmpq	%r8, %rax
	je	.LBB6_5
	movq	%r9, %rcx
	addq	(%rdi,%r8), %r9
	leaq	8(%r8), %r8
	jae	.LBB6_2
	movl	$16, %r8d
	movl	$6, %edi
	movl	$8, %r9d
	jmp	.LBB6_8
.LBB6_7:
	movq	$2, 8(%rbx)
	movl	$24, %r8d
	movl	$16, %r9d
	movq	%rax, %rcx
.LBB6_8:
	movq	%rdi, (%rbx,%r9)
	movq	%rcx, (%rbx,%r8)
	movq	$-1, (%rbx)
	movq	(%rdx), %rax
	testq	%rax, %rax
	je	.LBB6_10
	movq	8(%rdx), %rdi
	shlq	$3, %rax
	movl	$8, %edx
	movq	%rsi, %r14
	movq	%rax, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	%r14, %rsi
.LBB6_10:
	movq	(%rsi), %rax
	testq	%rax, %rax
	je	.LBB6_6
	movq	8(%rsi), %rdi
	shlq	$3, %rax
	movl	$8, %edx
	movq	%rax, %rsi
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB6_6
.LBB6_5:
	movq	16(%rsi), %rax
	movq	%rax, 16(%rsp)
	vmovups	(%rsi), %xmm0
	vmovaps	%xmm0, (%rsp)
	vmovups	(%rdx), %xmm0
	vmovups	%xmm0, 24(%rsp)
	movq	16(%rdx), %rax
	movq	%rax, 40(%rsp)
	vmovups	(%rsp), %xmm0
	vmovups	%xmm0, (%rbx)
	movq	16(%rsp), %rax
	movq	%rax, 16(%rbx)
	movq	24(%rsp), %rax
	movq	%rax, 24(%rbx)
	movq	16(%rsp), %rax
	movq	%rax, 16(%rbx)
	vmovups	24(%rsp), %xmm0
	vmovups	%xmm0, 24(%rbx)
	movq	40(%rsp), %rax
	movq	%rax, 40(%rbx)
.LBB6_6:
	movq	%rbx, %rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end6:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts, .Lfunc_end6-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11from_counts
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count:
	.cfi_startproc
	movq	%rdi, %rax
	movq	32(%rsi), %rcx
	movq	40(%rsi), %rdx
	shlq	$3, %rdx
	xorl	%esi, %esi
	xorl	%edi, %edi
	.p2align	4
.LBB7_1:
	cmpq	%rsi, %rdx
	je	.LBB7_5
	movq	%rdi, %r8
	addq	(%rcx,%rsi), %rdi
	leaq	8(%rsi), %rsi
	jae	.LBB7_1
	movq	$6, (%rax)
	movq	%r8, 8(%rax)
	retq
.LBB7_5:
	movq	%rdi, 8(%rax)
	movq	$-1, (%rax)
	retq
.Lfunc_end7:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count, .Lfunc_end7-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram11total_count
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$40, %rsp
	.cfi_def_cfa_offset 96
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdx, %r15
	movq	%rdi, %r12
	movq	16(%rsi), %rdx
	cmpq	16(%r15), %rdx
	jne	.LBB8_2
	movq	%rsi, %r14
	movq	8(%r15), %rsi
	movq	8(%r14), %rdi
	shlq	$3, %rdx
	callq	*bcmp@GOTPCREL(%rip)
	testl	%eax, %eax
	je	.LBB8_3
.LBB8_2:
	movq	$4, (%r12)
.LBB8_21:
	movq	%r12, %rax
	addq	$40, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB8_3:
	.cfi_def_cfa_offset 96
	movq	40(%r14), %rcx
	movq	40(%r15), %rax
	cmpq	%rcx, %rax
	cmovbq	%rax, %rcx
	testq	%rcx, %rcx
	movq	%rcx, 8(%rsp)
	je	.LBB8_4
	movq	32(%r14), %r13
	movq	32(%r15), %rbp
	movq	(%rbp), %rbx
	addq	(%r13), %rbx
	jb	.LBB8_20
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$32, %edi
	movl	$8, %esi
	callq	*_RNvCs9wFQrvczXsK_7___rustc12___rust_alloc@GOTPCREL(%rip)
	testq	%rax, %rax
	je	.LBB8_22
	movq	%rax, %r15
	movq	%rbx, (%rax)
	movq	$4, 16(%rsp)
	movq	%rax, 24(%rsp)
	movq	$1, 32(%rsp)
	movl	$4, %ebx
	movq	8(%rsp), %rcx
	cmpq	$1, %rcx
	je	.LBB8_14
	movq	%r12, (%rsp)
	movl	$1, %r12d
	jmp	.LBB8_9
	.p2align	4
.LBB8_12:
	movq	%rbx, (%r15,%r12,8)
	incq	%r12
	movq	%r12, 32(%rsp)
	cmpq	%r12, %rcx
	je	.LBB8_13
.LBB8_9:
	movq	(%rbp,%r12,8), %rbx
	addq	(%r13,%r12,8), %rbx
	jb	.LBB8_17
	cmpq	16(%rsp), %r12
	jne	.LBB8_12
	movl	$1, %edx
	leaq	16(%rsp), %rdi
	movq	%r12, %rsi
	callq	_RINvNvMs2_NtCscdodAO9FK5_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJ7XxL93Zka_22histogram_merge_errors
	movq	8(%rsp), %rcx
	movq	24(%rsp), %r15
	jmp	.LBB8_12
.LBB8_4:
	movl	$8, %r15d
	xorl	%ebx, %ebx
.LBB8_14:
	movq	24(%r14), %rsi
	testq	%rsi, %rsi
	je	.LBB8_16
.LBB8_15:
	movq	32(%r14), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	movq	8(%rsp), %rcx
.LBB8_16:
	movq	%rbx, 24(%r14)
	movq	%r15, 32(%r14)
	movq	%rcx, 40(%r14)
	movq	$-1, (%r12)
	jmp	.LBB8_21
.LBB8_13:
	movq	16(%rsp), %rbx
	movq	24(%rsp), %r15
	movq	(%rsp), %r12
	movq	24(%r14), %rsi
	testq	%rsi, %rsi
	jne	.LBB8_15
	jmp	.LBB8_16
.LBB8_17:
	movq	16(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB8_19
	movq	24(%rsp), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
.LBB8_19:
	movq	(%rsp), %r12
.LBB8_20:
	movq	$6, (%r12)
	movq	%rbx, 8(%r12)
	jmp	.LBB8_21
.LBB8_22:
	movl	$8, %edi
	movl	$32, %esi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end8:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible, .Lfunc_end8-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram16merge_compatible
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	leaq	-1(%rdx), %rax
	cmpq	%rcx, %rax
	jae	.LBB9_1
	movq	32(%rsi), %r9
	movq	40(%rsi), %r10
	shlq	$3, %r10
	xorl	%eax, %eax
	xorl	%r8d, %r8d
	.p2align	4
.LBB9_3:
	cmpq	%rax, %r10
	je	.LBB9_6
	movq	%r8, %r11
	addq	(%r9,%rax), %r8
	leaq	8(%rax), %rax
	jae	.LBB9_3
	movq	$6, 8(%rdi)
	movq	%r11, 16(%rdi)
	movq	$2, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_1:
	.cfi_def_cfa_offset 16
	movq	$7, 8(%rdi)
	movq	$2, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_6:
	.cfi_def_cfa_offset 16
	testq	%r8, %r8
	je	.LBB9_7
	movq	%r8, %rax
	mulq	%rdx
	jo	.LBB9_22
	movq	%rax, %rdx
	leaq	-1(%rcx), %rax
	addq	%rdx, %rax
	jb	.LBB9_22
	movq	%rax, %rdx
	orq	%rcx, %rdx
	shrq	$32, %rdx
	je	.LBB9_11
	xorl	%edx, %edx
	divq	%rcx
	jmp	.LBB9_13
.LBB9_7:
	movq	$8, 8(%rdi)
	movq	$2, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_11:
	.cfi_def_cfa_offset 16
	xorl	%edx, %edx
	divl	%ecx
.LBB9_13:
	movq	$-1, %rcx
	xorl	%edx, %edx
	.p2align	4
.LBB9_14:
	testq	%r10, %r10
	je	.LBB9_19
	addq	8(%r9,%rcx,8), %rdx
	jb	.LBB9_22
	incq	%rcx
	addq	$-8, %r10
	cmpq	%rax, %rdx
	jb	.LBB9_14
	testq	%rcx, %rcx
	je	.LBB9_18
	leaq	-1(%rcx), %r9
	movq	16(%rsi), %r10
	cmpq	%r10, %r9
	jae	.LBB9_28
	movq	8(%rsi), %rdx
	movq	-8(%rdx,%rcx,8), %r9
	movl	$1, %edx
	cmpq	%r10, %rcx
	jae	.LBB9_27
.LBB9_26:
	movq	8(%rsi), %rsi
	movq	(%rsi,%rcx,8), %rcx
	movq	%rdx, (%rdi)
	movq	%r9, 8(%rdi)
	movq	%rcx, 16(%rdi)
	movq	%rax, 24(%rdi)
	movq	%r8, 32(%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_19:
	.cfi_def_cfa_offset 16
	movq	$10, 8(%rdi)
	movq	$2, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_18:
	.cfi_def_cfa_offset 16
	movq	16(%rsi), %r10
	xorl	%edx, %edx
	cmpq	%r10, %rcx
	jb	.LBB9_26
.LBB9_27:
	leaq	.Lalloc_713e1b0d46806bc8c2cd07e9f5848152(%rip), %rdx
	movq	%rcx, %rdi
	movq	%r10, %rsi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB9_22:
	movq	$6, 8(%rdi)
	movq	$2, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB9_28:
	.cfi_def_cfa_offset 16
	leaq	.Lalloc_9034bc150239ddb23220298f62c78c3d(%rip), %rdx
	movq	%r9, %rdi
	movq	%r10, %rsi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end9:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket, .Lfunc_end9-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram20nearest_rank_bracket
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty:
	.cfi_startproc
	pushq	%r15
	.cfi_def_cfa_offset 16
	pushq	%r14
	.cfi_def_cfa_offset 24
	pushq	%r12
	.cfi_def_cfa_offset 32
	pushq	%rbx
	.cfi_def_cfa_offset 40
	pushq	%rax
	.cfi_def_cfa_offset 48
	.cfi_offset %rbx, -40
	.cfi_offset %r12, -32
	.cfi_offset %r14, -24
	.cfi_offset %r15, -16
	movq	%rsi, %r14
	movq	%rdi, %rbx
	movq	16(%rsi), %r12
	testq	%r12, %r12
	je	.LBB10_1
	leaq	(,%r12,8), %r15
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	movq	%r15, %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed@GOTPCREL(%rip)
	testq	%rax, %rax
	jne	.LBB10_3
	movl	$8, %edi
	movq	%r15, %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.LBB10_1:
	movl	$8, %eax
.LBB10_3:
	movq	16(%r14), %rcx
	movq	%rcx, 16(%rbx)
	vmovups	(%r14), %xmm0
	vmovups	%xmm0, (%rbx)
	movq	%r12, 24(%rbx)
	movq	%rax, 32(%rbx)
	movq	%r12, 40(%rbx)
	movq	%rbx, %rax
	addq	$8, %rsp
	.cfi_def_cfa_offset 40
	popq	%rbx
	.cfi_def_cfa_offset 32
	popq	%r12
	.cfi_def_cfa_offset 24
	popq	%r14
	.cfi_def_cfa_offset 16
	popq	%r15
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end10:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty, .Lfunc_end10-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram5empty
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record:
	.cfi_startproc
	pushq	%rax
	.cfi_def_cfa_offset 16
	movq	8(%rsi), %rcx
	movq	16(%rsi), %r8
	cmpq	$1, %r8
	je	.LBB11_1
	testq	%r8, %r8
	je	.LBB11_12
	xorl	%eax, %eax
	movq	%r8, %r9
	.p2align	4
.LBB11_4:
	movq	%r9, %r10
	shrq	%r10
	leaq	(%r10,%rax), %r11
	cmpq	%rdx, (%rcx,%r11,8)
	cmovbq	%r11, %rax
	subq	%r10, %r9
	cmpq	$1, %r9
	ja	.LBB11_4
	cmpq	%rdx, (%rcx,%rax,8)
	adcq	$0, %rax
	cmpq	%r8, %rax
	jae	.LBB11_6
.LBB11_7:
	movq	40(%rsi), %rcx
	cmpq	%rcx, %rax
	jae	.LBB11_13
	movq	32(%rsi), %rcx
	movq	(%rcx,%rax,8), %rdx
	cmpq	$-1, %rdx
	je	.LBB11_9
	incq	%rdx
	movq	%rdx, (%rcx,%rax,8)
	movq	$-1, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB11_1:
	.cfi_def_cfa_offset 16
	xorl	%eax, %eax
	cmpq	%rdx, (%rcx,%rax,8)
	adcq	$0, %rax
	cmpq	%r8, %rax
	jb	.LBB11_7
.LBB11_6:
	movq	-8(%rcx,%r8,8), %rax
	movq	$3, (%rdi)
	movq	%rdx, 8(%rdi)
	movq	%rax, 16(%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB11_9:
	.cfi_def_cfa_offset 16
	movq	$6, (%rdi)
	movq	%rdi, %rax
	popq	%rcx
	.cfi_def_cfa_offset 8
	retq
.LBB11_12:
	.cfi_def_cfa_offset 16
	leaq	.Lalloc_4ed059f71d51ae16bc6826f989989385(%rip), %rdi
	leaq	.Lalloc_72e1b02f1dc44543daa9de23d3bba29e(%rip), %rdx
	movl	$30, %esi
	callq	*_RNvNtCs4NRVxsYgnAr_4core6option13expect_failed@GOTPCREL(%rip)
.LBB11_13:
	leaq	.Lalloc_96d0d7cd51bf3727855c17e0e20001f5(%rip), %rdx
	movq	%rax, %rdi
	movq	%rcx, %rsi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.Lfunc_end11:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record, .Lfunc_end11-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram6record
	.cfi_endproc

	.section	.text._RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen,"ax",@progbits
	.globl	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen
	.p2align	4
	.type	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen,@function
_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen:
	.cfi_startproc
	pushq	%rbp
	.cfi_def_cfa_offset 16
	pushq	%r15
	.cfi_def_cfa_offset 24
	pushq	%r14
	.cfi_def_cfa_offset 32
	pushq	%r13
	.cfi_def_cfa_offset 40
	pushq	%r12
	.cfi_def_cfa_offset 48
	pushq	%rbx
	.cfi_def_cfa_offset 56
	subq	$56, %rsp
	.cfi_def_cfa_offset 112
	.cfi_offset %rbx, -56
	.cfi_offset %r12, -48
	.cfi_offset %r13, -40
	.cfi_offset %r14, -32
	.cfi_offset %r15, -24
	.cfi_offset %rbp, -16
	movq	%rdi, %rbx
	movq	8(%rsi), %r13
	movq	16(%rsi), %r15
	movq	16(%rdx), %r14
	testq	%r15, %r15
	je	.LBB12_1
	testq	%r14, %r14
	je	.LBB12_36
	movq	8(%rdx), %rax
	movq	-8(%r13,%r15,8), %rcx
	cmpq	-8(%rax,%r14,8), %rcx
	jne	.LBB12_36
	cmpq	$1, %r15
	jne	.LBB12_5
	leaq	(,%r14,8), %rcx
	xorl	%edi, %edi
	.p2align	4
.LBB12_11:
	cmpq	%rdi, %rcx
	je	.LBB12_13
	movq	(%r13), %r8
	cmpq	(%rax,%rdi), %r8
	leaq	8(%rdi), %rdi
	je	.LBB12_11
	jmp	.LBB12_36
.LBB12_1:
	testq	%r14, %r14
	je	.LBB12_2
.LBB12_36:
	movq	$9, 8(%rbx)
	movq	$-1, (%rbx)
	movq	(%rdx), %rsi
	testq	%rsi, %rsi
	je	.LBB12_32
	movq	8(%rdx), %rdi
	shlq	$3, %rsi
	movl	$8, %edx
	callq	*_RNvCs9wFQrvczXsK_7___rustc14___rust_dealloc@GOTPCREL(%rip)
	jmp	.LBB12_32
.LBB12_2:
	movl	$8, %eax
	xorl	%r14d, %r14d
	jmp	.LBB12_14
.LBB12_5:
	leaq	(%rax,%r14,8), %rcx
	.p2align	4
.LBB12_6:
	cmpq	%rcx, %rax
	je	.LBB12_13
	movq	(%rax), %rdi
	movq	%r15, %r8
	xorl	%r9d, %r9d
	.p2align	4
.LBB12_8:
	movq	%r9, %r10
	movq	%r8, %r11
	shrq	%r11
	addq	%r11, %r9
	cmpq	%rdi, (%r13,%r9,8)
	cmovaq	%r10, %r9
	subq	%r11, %r8
	cmpq	$1, %r8
	ja	.LBB12_8
	addq	$8, %rax
	cmpq	%rdi, (%r13,%r9,8)
	je	.LBB12_6
	jmp	.LBB12_36
.LBB12_13:
	movq	%rsi, %rbp
	movq	%rdx, %r12
	callq	*_RNvCs9wFQrvczXsK_7___rustc35___rust_no_alloc_shim_is_unstable_v2@GOTPCREL(%rip)
	movl	$8, %esi
	leaq	(,%r14,8), %rax
	movq	%rax, 48(%rsp)
	leaq	(,%r14,8), %rdi
	callq	*_RNvCs9wFQrvczXsK_7___rustc19___rust_alloc_zeroed@GOTPCREL(%rip)
	movq	%r12, %rdx
	movq	%rbp, %rsi
	testq	%rax, %rax
	je	.LBB12_38
.LBB12_14:
	vmovups	(%rdx), %xmm0
	vmovaps	%xmm0, (%rsp)
	movq	%r14, 16(%rsp)
	movq	%r14, 24(%rsp)
	movq	%rax, 32(%rsp)
	movq	%r14, 40(%rsp)
	movq	40(%rsi), %rdi
	testq	%rdi, %rdi
	je	.LBB12_31
	testq	%r15, %r15
	je	.LBB12_33
	movq	32(%rsi), %rdx
	movq	8(%rsp), %rcx
	cmpq	$1, %r14
	jne	.LBB12_17
	shlq	$3, %rdi
	xorl	%esi, %esi
	movq	%r15, %r8
	.p2align	4
.LBB12_25:
	subq	$1, %r8
	jb	.LBB12_33
	movq	(%rcx), %r9
	cmpq	(%r13,%rsi), %r9
	jb	.LBB12_27
	movq	(%rdx,%rsi), %r9
	addq	(%rax), %r9
	jb	.LBB12_23
	movq	%r9, (%rax)
	addq	$8, %rsi
	cmpq	%rsi, %rdi
	jne	.LBB12_25
	jmp	.LBB12_31
.LBB12_17:
	leaq	(%rdx,%rdi,8), %rsi
	xorl	%r8d, %r8d
	.p2align	4
.LBB12_18:
	cmpq	%r15, %r8
	je	.LBB12_33
	leaq	8(%rdx), %r9
	movq	(%r13,%r8,8), %r10
	incq	%r8
	movq	%r14, %r11
	xorl	%edi, %edi
	.p2align	4
.LBB12_20:
	movq	%r11, %r12
	shrq	%r12
	leaq	(%r12,%rdi), %rbp
	cmpq	%r10, (%rcx,%rbp,8)
	cmovbq	%rbp, %rdi
	subq	%r12, %r11
	cmpq	$1, %r11
	ja	.LBB12_20
	cmpq	%r10, (%rcx,%rdi,8)
	adcq	$0, %rdi
	cmpq	%r14, %rdi
	jae	.LBB12_28
	movq	(%rdx), %rdx
	addq	(%rax,%rdi,8), %rdx
	jb	.LBB12_23
	movq	%rdx, (%rax,%rdi,8)
	movq	%r9, %rdx
	cmpq	%rsi, %r9
	jne	.LBB12_18
.LBB12_31:
	vmovups	(%rsp), %xmm0
	movq	16(%rsp), %rax
	movq	24(%rsp), %rcx
	movq	16(%rsp), %rdx
	movq	%rdx, 16(%rbx)
	movq	24(%rsp), %rdx
	movq	%rdx, 24(%rbx)
	movq	32(%rsp), %rdx
	movq	%rdx, 32(%rbx)
	movq	40(%rsp), %rdx
	movq	%rdx, 40(%rbx)
	vmovups	%xmm0, (%rbx)
	movq	%rax, 16(%rbx)
	movq	%rcx, 24(%rbx)
.LBB12_32:
	movq	%rbx, %rax
	addq	$56, %rsp
	.cfi_def_cfa_offset 56
	popq	%rbx
	.cfi_def_cfa_offset 48
	popq	%r12
	.cfi_def_cfa_offset 40
	popq	%r13
	.cfi_def_cfa_offset 32
	popq	%r14
	.cfi_def_cfa_offset 24
	popq	%r15
	.cfi_def_cfa_offset 16
	popq	%rbp
	.cfi_def_cfa_offset 8
	retq
.LBB12_23:
	.cfi_def_cfa_offset 112
	movq	$6, 8(%rbx)
	movq	$-1, (%rbx)
	movq	%rsp, %rdi
	callq	_RINvNtCs4NRVxsYgnAr_4core3ptr9drop_glueNtCsjJ7XxL93Zka_22histogram_merge_errors17IntervalHistogramEBD_
	jmp	.LBB12_32
.LBB12_33:
	leaq	.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd(%rip), %rdx
	movq	%r15, %rdi
	movq	%r15, %rsi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB12_27:
	movl	$1, %edi
.LBB12_28:
	leaq	.Lalloc_4583e6a49f6781f6842cac8cdb2523af(%rip), %rdx
	movq	%r14, %rsi
	callq	*_RNvNtCs4NRVxsYgnAr_4core9panicking18panic_bounds_check@GOTPCREL(%rip)
.LBB12_38:
	movl	$8, %edi
	movq	48(%rsp), %rsi
	callq	*_RNvNtCscdodAO9FK5_5alloc7raw_vec12handle_error@GOTPCREL(%rip)
.Lfunc_end12:
	.size	_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen, .Lfunc_end12-_RNvMs_CsjJ7XxL93Zka_22histogram_merge_errorsNtB4_17IntervalHistogram7coarsen
	.cfi_endproc

	.section	.text._RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt,"ax",@progbits
	.globl	_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt
	.p2align	4
	.type	_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt,@function
_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt:
	.cfi_startproc
	subq	$24, %rsp
	.cfi_def_cfa_offset 32
	movq	%rdi, (%rsp)
	movq	%rsp, %rax
	movq	%rax, 8(%rsp)
	leaq	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_(%rip), %rax
	movq	%rax, 16(%rsp)
	movq	(%rsi), %rdi
	movq	8(%rsi), %rsi
	leaq	.Lalloc_0c812808379efded5a4fb82d2790b556(%rip), %rdx
	leaq	8(%rsp), %rcx
	callq	*_RNvNtCs4NRVxsYgnAr_4core3fmt5write@GOTPCREL(%rip)
	addq	$24, %rsp
	.cfi_def_cfa_offset 8
	retq
.Lfunc_end13:
	.size	_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt, .Lfunc_end13-_RNvXs1_CsjJ7XxL93Zka_22histogram_merge_errorsNtB5_14HistogramErrorNtNtCs4NRVxsYgnAr_4core3fmt7Display3fmt
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_:
	.cfi_startproc
	pushq	%r14
	.cfi_def_cfa_offset 16
	pushq	%rbx
	.cfi_def_cfa_offset 24
	pushq	%rax
	.cfi_def_cfa_offset 32
	.cfi_offset %rbx, -24
	.cfi_offset %r14, -16
	movq	%rsi, %rax
	movq	(%rdi), %rcx
	movq	(%rcx), %rdx
	leaq	.LJTI14_0(%rip), %rsi
	movslq	(%rsi,%rdx,4), %rdx
	addq	%rsi, %rdx
	jmpq	*%rdx
.LBB14_1:
	leaq	.Lalloc_5ee3dd04a3ebbd2958f69478a791f011(%rip), %rsi
	movl	$11, %edx
	jmp	.LBB14_8
.LBB14_6:
	leaq	.Lalloc_49160125fb4cd837bc8bd9b6ec63004a(%rip), %rsi
	jmp	.LBB14_7
.LBB14_13:
	leaq	.Lalloc_99be15a9e516526f280317bea0cca5d0(%rip), %rsi
	movl	$17, %edx
	jmp	.LBB14_8
.LBB14_3:
	leaq	8(%rcx), %r9
	addq	$16, %rcx
	movq	%rcx, (%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	.Lvtable.1(%rip), %r10
	leaq	8(%rsp), %r11
	leaq	.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf(%rip), %rbx
	leaq	.Lvtable.0(%rip), %r14
	leaq	.Lalloc_ee08c9d314e4c5b701504a1a6f89727d(%rip), %rsi
	leaq	.Lalloc_adba73bbb963ea705e05d8e8c86355c2(%rip), %rcx
	movl	$19, %edx
	movl	$6, %r8d
	movq	%rax, %rdi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	$6
	.cfi_adjust_cfa_offset 8
	jmp	.LBB14_4
.LBB14_5:
	.cfi_def_cfa_offset 32
	leaq	8(%rcx), %r9
	addq	$16, %rcx
	movq	%rcx, (%rsp)
	subq	$8, %rsp
	.cfi_adjust_cfa_offset 8
	leaq	.Lvtable.3(%rip), %r10
	leaq	8(%rsp), %r11
	leaq	.Lalloc_86933f980174c2bccf56810e0d831ebb(%rip), %rbx
	leaq	.Lvtable.2(%rip), %r14
	leaq	.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2(%rip), %rsi
	leaq	.Lalloc_58c73da900326cd1d22dde7834877fb1(%rip), %rcx
	movl	$21, %edx
	movl	$8, %r8d
	movq	%rax, %rdi
	pushq	%r10
	.cfi_adjust_cfa_offset 8
	pushq	%r11
	.cfi_adjust_cfa_offset 8
	pushq	$10
	.cfi_adjust_cfa_offset 8
.LBB14_4:
	pushq	%rbx
	.cfi_adjust_cfa_offset 8
	pushq	%r14
	.cfi_adjust_cfa_offset 8
	callq	*_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter26debug_struct_field2_finish@GOTPCREL(%rip)
	addq	$48, %rsp
	.cfi_adjust_cfa_offset -48
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	retq
.LBB14_11:
	.cfi_def_cfa_offset 32
	leaq	.Lalloc_f672c6af06448a01ecac398fe971f727(%rip), %rsi
	movl	$15, %edx
	jmp	.LBB14_8
.LBB14_2:
	leaq	.Lalloc_52433ae1027e4929c7c1de5d6490f243(%rip), %rsi
	movl	$19, %edx
	jmp	.LBB14_8
.LBB14_9:
	leaq	.Lalloc_99f3a809f00b524a3a34761496eda872(%rip), %rsi
	movl	$12, %edx
	jmp	.LBB14_8
.LBB14_10:
	leaq	.Lalloc_937ef498e46ce3dd2899f48f05d77c47(%rip), %rsi
	movl	$18, %edx
	jmp	.LBB14_8
.LBB14_14:
	leaq	.Lalloc_4d26e1d2bef2fb4016390b651f78947e(%rip), %rsi
	movl	$20, %edx
	jmp	.LBB14_8
.LBB14_12:
	leaq	.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d(%rip), %rsi
.LBB14_7:
	movl	$14, %edx
.LBB14_8:
	movq	%rax, %rdi
	addq	$8, %rsp
	.cfi_def_cfa_offset 24
	popq	%rbx
	.cfi_def_cfa_offset 16
	popq	%r14
	.cfi_def_cfa_offset 8
	jmpq	*_RNvMsa_NtCs4NRVxsYgnAr_4core3fmtNtB5_9Formatter9write_str@GOTPCREL(%rip)
.Lfunc_end14:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_, .Lfunc_end14-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_
	.cfi_endproc
	.section	.rodata._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRNtCsjJ7XxL93Zka_22histogram_merge_errors14HistogramErrorNtB6_5Debug3fmtBy_,"a",@progbits
	.p2align	2, 0x0
.LJTI14_0:
	.long	.LBB14_1-.LJTI14_0
	.long	.LBB14_2-.LJTI14_0
	.long	.LBB14_3-.LJTI14_0
	.long	.LBB14_5-.LJTI14_0
	.long	.LBB14_6-.LJTI14_0
	.long	.LBB14_9-.LJTI14_0
	.long	.LBB14_10-.LJTI14_0
	.long	.LBB14_11-.LJTI14_0
	.long	.LBB14_12-.LJTI14_0
	.long	.LBB14_13-.LJTI14_0
	.long	.LBB14_14-.LJTI14_0

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors:
	.cfi_startproc
	movq	(%rdi), %rdi
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB15_3
	testl	$67108864, %eax
	jne	.LBB15_2
	jmpq	*_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB15_3:
	jmpq	*_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB15_2:
	jmpq	*_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end15:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors, .Lfunc_end15-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors
	.cfi_endproc

	.section	.text._RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors,"ax",@progbits
	.p2align	4
	.type	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors,@function
_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors:
	.cfi_startproc
	movq	(%rdi), %rdi
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB16_3
	testl	$67108864, %eax
	jne	.LBB16_2
	jmpq	*_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB16_3:
	jmpq	*_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB16_2:
	jmpq	*_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end16:
	.size	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors, .Lfunc_end16-_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors
	.cfi_endproc

	.section	.text._RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt,@function
_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt:
	.cfi_startproc
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB17_3
	testl	$67108864, %eax
	jne	.LBB17_2
	jmpq	*_RNvXsd_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impyNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB17_3:
	jmpq	*_RNvXsC_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB17_2:
	jmpq	*_RNvXsE_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end17:
	.size	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt, .Lfunc_end17-_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text._RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt,"ax",@progbits
	.p2align	4
	.type	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt,@function
_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt:
	.cfi_startproc
	movl	16(%rsi), %eax
	testl	$33554432, %eax
	jne	.LBB18_3
	testl	$67108864, %eax
	jne	.LBB18_2
	jmpq	*_RNvXsi_NtNtNtCs4NRVxsYgnAr_4core3fmt3num3impjNtB9_7Display3fmt@GOTPCREL(%rip)
.LBB18_3:
	jmpq	*_RNvXs6_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8LowerHex3fmt@GOTPCREL(%rip)
.LBB18_2:
	jmpq	*_RNvXs8_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_8UpperHex3fmt@GOTPCREL(%rip)
.Lfunc_end18:
	.size	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt, .Lfunc_end18-_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt
	.cfi_endproc

	.section	.text.topic44_checked_merge_four,"ax",@progbits
	.globl	topic44_checked_merge_four
	.p2align	4
	.type	topic44_checked_merge_four,@function
topic44_checked_merge_four:
	.cfi_startproc
	movq	(%rsi), %rax
	addq	(%rdi), %rax
	jb	.LBB19_5
	movq	8(%rsi), %rcx
	addq	8(%rdi), %rcx
	jb	.LBB19_5
	movq	16(%rsi), %rdx
	addq	16(%rdi), %rdx
	jb	.LBB19_5
	movq	24(%rsi), %rsi
	addq	24(%rdi), %rsi
	jb	.LBB19_5
	movq	%rax, (%rdi)
	movq	%rcx, 8(%rdi)
	movq	%rdx, 16(%rdi)
	movq	%rsi, 24(%rdi)
	movb	$1, %al
	retq
.LBB19_5:
	xorl	%eax, %eax
	retq
.Lfunc_end19:
	.size	topic44_checked_merge_four, .Lfunc_end19-topic44_checked_merge_four
	.cfi_endproc

	.type	.Lalloc_5b145d9140118075524495df4810a119,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lalloc_5b145d9140118075524495df4810a119:
	.asciz	"/tmp/topic44-output-scoped-b8d0c8b-r1/.work/source/systems-snackpack-b8d0c8b06bd29dab090d40f18aa6aa086b5fdf76/topics/044-tail-latency-histogram-merge-errors/src/lib.rs"
	.size	.Lalloc_5b145d9140118075524495df4810a119, 168

	.type	.Lalloc_4ed059f71d51ae16bc6826f989989385,@object
	.section	.rodata..Lalloc_4ed059f71d51ae16bc6826f989989385,"a",@progbits
.Lalloc_4ed059f71d51ae16bc6826f989989385:
	.ascii	"a validated schema is nonempty"
	.size	.Lalloc_4ed059f71d51ae16bc6826f989989385, 30

	.type	.Lalloc_72e1b02f1dc44543daa9de23d3bba29e,@object
	.section	.data.rel.ro..Lalloc_72e1b02f1dc44543daa9de23d3bba29e,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_72e1b02f1dc44543daa9de23d3bba29e:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000?\000\000\000\026\000\000"
	.size	.Lalloc_72e1b02f1dc44543daa9de23d3bba29e, 24

	.type	.Lalloc_9034bc150239ddb23220298f62c78c3d,@object
	.section	.data.rel.ro..Lalloc_9034bc150239ddb23220298f62c78c3d,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_9034bc150239ddb23220298f62c78c3d:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\353\000\000\000D\000\000"
	.size	.Lalloc_9034bc150239ddb23220298f62c78c3d, 24

	.type	.Lalloc_713e1b0d46806bc8c2cd07e9f5848152,@object
	.section	.data.rel.ro..Lalloc_713e1b0d46806bc8c2cd07e9f5848152,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_713e1b0d46806bc8c2cd07e9f5848152:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\354\000\000\000D\000\000"
	.size	.Lalloc_713e1b0d46806bc8c2cd07e9f5848152, 24

	.type	.Lalloc_96d0d7cd51bf3727855c17e0e20001f5,@object
	.section	.data.rel.ro..Lalloc_96d0d7cd51bf3727855c17e0e20001f5,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_96d0d7cd51bf3727855c17e0e20001f5:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\205\000\000\000)\000\000"
	.size	.Lalloc_96d0d7cd51bf3727855c17e0e20001f5, 24

	.type	.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd,@object
	.section	.data.rel.ro..Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\r\001\000\000;\000\000"
	.size	.Lalloc_4902ffe043ff59a1d70cb2012e4b3cfd, 24

	.type	.Lalloc_4583e6a49f6781f6842cac8cdb2523af,@object
	.section	.data.rel.ro..Lalloc_4583e6a49f6781f6842cac8cdb2523af,"aw",@progbits
	.p2align	3, 0x0
.Lalloc_4583e6a49f6781f6842cac8cdb2523af:
	.quad	.Lalloc_5b145d9140118075524495df4810a119
	.asciz	"\247\000\000\000\000\000\000\000\022\001\000\0008\000\000"
	.size	.Lalloc_4583e6a49f6781f6842cac8cdb2523af, 24

	.type	.Lalloc_0c812808379efded5a4fb82d2790b556,@object
	.section	.rodata.str1.1,"aMS",@progbits,1
.Lalloc_0c812808379efded5a4fb82d2790b556:
	.asciz	"\300"
	.size	.Lalloc_0c812808379efded5a4fb82d2790b556, 2

	.type	.Lalloc_5ee3dd04a3ebbd2958f69478a791f011,@object
	.section	.rodata..Lalloc_5ee3dd04a3ebbd2958f69478a791f011,"a",@progbits
.Lalloc_5ee3dd04a3ebbd2958f69478a791f011:
	.ascii	"EmptySchema"
	.size	.Lalloc_5ee3dd04a3ebbd2958f69478a791f011, 11

	.type	.Lalloc_52433ae1027e4929c7c1de5d6490f243,@object
	.section	.rodata..Lalloc_52433ae1027e4929c7c1de5d6490f243,"a",@progbits
.Lalloc_52433ae1027e4929c7c1de5d6490f243:
	.ascii	"NonIncreasingBounds"
	.size	.Lalloc_52433ae1027e4929c7c1de5d6490f243, 19

	.type	.Lvtable.0,@object
	.section	.data.rel.ro..Lvtable.0,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.0:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXsZ_NtNtCs4NRVxsYgnAr_4core3fmt3numjNtB7_5Debug3fmt
	.size	.Lvtable.0, 32

	.type	.Lvtable.1,@object
	.section	.data.rel.ro..Lvtable.1,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.1:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRjNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors
	.size	.Lvtable.1, 32

	.type	.Lalloc_ee08c9d314e4c5b701504a1a6f89727d,@object
	.section	.rodata..Lalloc_ee08c9d314e4c5b701504a1a6f89727d,"a",@progbits
.Lalloc_ee08c9d314e4c5b701504a1a6f89727d:
	.ascii	"BucketCountMismatch"
	.size	.Lalloc_ee08c9d314e4c5b701504a1a6f89727d, 19

	.type	.Lalloc_adba73bbb963ea705e05d8e8c86355c2,@object
	.section	.rodata..Lalloc_adba73bbb963ea705e05d8e8c86355c2,"a",@progbits
.Lalloc_adba73bbb963ea705e05d8e8c86355c2:
	.ascii	"bounds"
	.size	.Lalloc_adba73bbb963ea705e05d8e8c86355c2, 6

	.type	.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf,@object
	.section	.rodata..Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf,"a",@progbits
.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf:
	.ascii	"counts"
	.size	.Lalloc_3dfbaa94cc35c2ffab6bdeb2b51b9acf, 6

	.type	.Lvtable.2,@object
	.section	.data.rel.ro..Lvtable.2,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.2:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXsX_NtNtCs4NRVxsYgnAr_4core3fmt3numyNtB7_5Debug3fmt
	.size	.Lvtable.2, 32

	.type	.Lvtable.3,@object
	.section	.data.rel.ro..Lvtable.3,"aw",@progbits
	.p2align	3, 0x0
.Lvtable.3:
	.asciz	"\000\000\000\000\000\000\000\000\b\000\000\000\000\000\000\000\b\000\000\000\000\000\000"
	.quad	_RNvXs1g_NtCs4NRVxsYgnAr_4core3fmtRyNtB6_5Debug3fmtCsjJ7XxL93Zka_22histogram_merge_errors
	.size	.Lvtable.3, 32

	.type	.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2,@object
	.section	.rodata..Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2,"a",@progbits
.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2:
	.ascii	"ObservationOutOfRange"
	.size	.Lalloc_fc4accf12cdb5d5f3207e98a294cf4c2, 21

	.type	.Lalloc_58c73da900326cd1d22dde7834877fb1,@object
	.section	.rodata.cst8,"aM",@progbits,8
.Lalloc_58c73da900326cd1d22dde7834877fb1:
	.ascii	"value_us"
	.size	.Lalloc_58c73da900326cd1d22dde7834877fb1, 8

	.type	.Lalloc_86933f980174c2bccf56810e0d831ebb,@object
	.section	.rodata..Lalloc_86933f980174c2bccf56810e0d831ebb,"a",@progbits
.Lalloc_86933f980174c2bccf56810e0d831ebb:
	.ascii	"maximum_us"
	.size	.Lalloc_86933f980174c2bccf56810e0d831ebb, 10

	.type	.Lalloc_49160125fb4cd837bc8bd9b6ec63004a,@object
	.section	.rodata..Lalloc_49160125fb4cd837bc8bd9b6ec63004a,"a",@progbits
.Lalloc_49160125fb4cd837bc8bd9b6ec63004a:
	.ascii	"SchemaMismatch"
	.size	.Lalloc_49160125fb4cd837bc8bd9b6ec63004a, 14

	.type	.Lalloc_99f3a809f00b524a3a34761496eda872,@object
	.section	.rodata..Lalloc_99f3a809f00b524a3a34761496eda872,"a",@progbits
.Lalloc_99f3a809f00b524a3a34761496eda872:
	.ascii	"CounterReset"
	.size	.Lalloc_99f3a809f00b524a3a34761496eda872, 12

	.type	.Lalloc_937ef498e46ce3dd2899f48f05d77c47,@object
	.section	.rodata..Lalloc_937ef498e46ce3dd2899f48f05d77c47,"a",@progbits
.Lalloc_937ef498e46ce3dd2899f48f05d77c47:
	.ascii	"ArithmeticOverflow"
	.size	.Lalloc_937ef498e46ce3dd2899f48f05d77c47, 18

	.type	.Lalloc_f672c6af06448a01ecac398fe971f727,@object
	.section	.rodata..Lalloc_f672c6af06448a01ecac398fe971f727,"a",@progbits
.Lalloc_f672c6af06448a01ecac398fe971f727:
	.ascii	"InvalidQuantile"
	.size	.Lalloc_f672c6af06448a01ecac398fe971f727, 15

	.type	.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d,@object
	.section	.rodata..Lalloc_ce01d5de1e0bacc55ae5953b06653b2d,"a",@progbits
.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d:
	.ascii	"EmptyHistogram"
	.size	.Lalloc_ce01d5de1e0bacc55ae5953b06653b2d, 14

	.type	.Lalloc_99be15a9e516526f280317bea0cca5d0,@object
	.section	.rodata..Lalloc_99be15a9e516526f280317bea0cca5d0,"a",@progbits
.Lalloc_99be15a9e516526f280317bea0cca5d0:
	.ascii	"InvalidCoarsening"
	.size	.Lalloc_99be15a9e516526f280317bea0cca5d0, 17

	.type	.Lalloc_4d26e1d2bef2fb4016390b651f78947e,@object
	.section	.rodata..Lalloc_4d26e1d2bef2fb4016390b651f78947e,"a",@progbits
.Lalloc_4d26e1d2bef2fb4016390b651f78947e:
	.ascii	"CountInvariantBroken"
	.size	.Lalloc_4d26e1d2bef2fb4016390b651f78947e, 20

	.ident	"rustc version 1.97.1 (8bab26f4f 2026-07-14)"
	.section	".note.GNU-stack","",@progbits
